﻿using System;
using Android.App;
using Android.Content;
using Android.Gms.Ads;
using Android.Gms.Ads.Formats;
using Android.Gms.Ads.Reward;
using WoWonder.Helpers.Model;
using Exception = System.Exception;
using Object = Java.Lang.Object;

namespace WoWonder.Helpers.Ads
{
    public static class AdsGoogle
    {
        private static int CountInterstitial;
        private static int CountRewarded;

        #region Interstitial

        private class AdmobInterstitial
        {
            private InterstitialAd Ad;

            public void ShowAd(Context context)
            {
                try
                { 
                    Ad = new InterstitialAd(context);
                    Ad.AdUnitId = AppSettings.AdInterstitialKey;

                    var intlistener = new InterstitialAdListener(Ad);
                    intlistener.OnAdLoaded();
                    Ad.AdListener = intlistener;
                    
                    var requestbuilder = new AdRequest.Builder();
                    requestbuilder.AddTestDevice(UserDetails.AndroidId);
                    Ad.LoadAd(requestbuilder.Build());
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }
        }

        private class InterstitialAdListener : AdListener
        {
            private readonly InterstitialAd Ad;

            public InterstitialAdListener(InterstitialAd ad)
            {
                Ad = ad;
            }

            public override void OnAdLoaded()
            {
                base.OnAdLoaded();

                if (Ad.IsLoaded)
                    Ad.Show();
            }
        }


        public static void Ad_Interstitial(Context context)
        {
            try
            {
                if (AppSettings.ShowAdmobInterstitial)
                {
                    if (CountInterstitial == AppSettings.ShowAdmobInterstitialCount)
                    {
                        CountInterstitial = 0;
                        AdmobInterstitial ads = new AdmobInterstitial();
                        ads.ShowAd(context);
                    }

                    CountInterstitial++;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        #region Native

        private class AdmobNative :Object, UnifiedNativeAd.IOnUnifiedNativeAdLoadedListener
        {
            private Activity Context;
            public void ShowAd(Activity context)
            {
                try
                {
                    Context = context;
                    AdLoader.Builder builder = new AdLoader.Builder(context, AppSettings.AdAdmobNativeKey);
                    builder.ForUnifiedNativeAd(this);
                    VideoOptions videoOptions = new VideoOptions.Builder()
                        .SetStartMuted(true)
                        .Build();
                    NativeAdOptions adOptions = new NativeAdOptions.Builder()
                        .SetVideoOptions(videoOptions)
                        .Build();

                    builder.WithNativeAdOptions(adOptions);

                    AdLoader adLoader = builder.WithAdListener(new AdListener()).Build();
                    adLoader.LoadAd(new AdRequest.Builder().Build());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnUnifiedNativeAdLoaded(UnifiedNativeAd ad)
            {
                try
                {
                    NativeTemplateStyle styles = new NativeTemplateStyle.Builder().Build();

                    TemplateView template = Context.FindViewById<TemplateView>(Resource.Id.my_template);
                    
                    if (template.GetTemplateTypeName() == TemplateView.BigTemplate)
                    {
                        template.PopulateUnifiedNativeAdView(ad);
                    }
                    else
                    {
                        template.SetStyles(styles);
                        template.SetNativeAd(ad);
                    } 
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }
         
        public static void Ad_AdmobNative(Activity context)
        {
            try
            {
                if (AppSettings.ShowAdmobNative)
                {
                    AdmobNative ads = new AdmobNative();
                    ads.ShowAd(context); 
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        //Rewarded Video >>
        //===================================================

        #region Rewarded

        private class AdmobRewardedVideo : AdListener, IRewardedVideoAdListener
        {
            private static readonly long CounterTime = 10;
            private static readonly int GameOverReward = 1;
            private IRewardedVideoAd Rad;

            public void ShowAd(Context context)
            {
                try
                {
                    // Use an activity context to get the rewarded video instance.
                    Rad = MobileAds.GetRewardedVideoAdInstance(context);
                    Rad.RewardedVideoAdListener = this;
                   
                    OnRewardedVideoAdLoaded();
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }

            public override void OnAdLoaded()
            {
                try
                {
                    base.OnAdLoaded();

                    OnRewardedVideoAdLoaded();

                    if (Rad.IsLoaded)
                        Rad.Show();
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }

            public void OnRewarded(IRewardItem reward)
            {
                //Toast.MakeText(Application.Context, "onRewarded! currency: " + reward.Type + "  amount: " + reward.Amount , ToastLength.Short).Show();

                if (Rad.IsLoaded)
                    Rad.Show();
            }
              

            public void OnRewardedVideoAdClosed()
            {
                
            }

            public void OnRewardedVideoAdFailedToLoad(int errorCode)
            {
                //Toast.MakeText(Application.Context, "No ads currently available", ToastLength.Short).Show();
            }

            public void OnRewardedVideoAdLeftApplication()
            {

            }

            public void OnRewardedVideoAdLoaded()
            {
                try
                {
                    if (!Rad.IsLoaded)
                    {
                        Rad.LoadAd(AppSettings.AdRewardVideoKey, new AdRequest.Builder().Build());
                        Rad.Show();
                    }


                    //Bundle extras = new Bundle();
                    //extras.PutBoolean("_noRefresh", true);

                    //var requestBuilder = new AdRequest.Builder();
                    //requestBuilder.AddTestDevice(UserDetails.AndroidId);
                    //requestBuilder.AddNetworkExtrasBundle(new AdMobAdapter().Class, extras);
                    //Rad.UserId = Application.Context.GetString(Resource.String.admob_app_id);
                    //Rad.LoadAd(AppSettings.AdRewardVideoKey, requestBuilder.Build());
                    //Rad.Show();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnRewardedVideoAdOpened()
            {

            }

            public void OnRewardedVideoCompleted()
            {
                
            }

            public void OnRewardedVideoStarted()
            {

            } 
        }

        public static void Ad_RewardedVideo(Context context)
        {
            try
            {
                if (AppSettings.ShowAdmobRewardVideo)
                {
                    if (CountRewarded == AppSettings.ShowAdmobRewardedVideoCount)
                    {
                        CountRewarded = 0;
                        AdmobRewardedVideo ads = new AdmobRewardedVideo();
                        ads.ShowAd(context);
                    }

                    CountRewarded++;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion
    }
}