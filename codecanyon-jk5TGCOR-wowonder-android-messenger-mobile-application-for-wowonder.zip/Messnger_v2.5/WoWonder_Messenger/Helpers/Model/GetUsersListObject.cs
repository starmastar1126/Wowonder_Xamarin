﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using WoWonderClient.Classes.Global;


namespace WoWonder.Helpers.Model
{
    public class GetUsersListObject
    {
        [JsonProperty("api_status", NullValueHandling = NullValueHandling.Ignore)]
        public string ApiStatus { get; set; }

        [JsonProperty("api_text", NullValueHandling = NullValueHandling.Ignore)]
        public string ApiText { get; set; }

        [JsonProperty("api_version", NullValueHandling = NullValueHandling.Ignore)]
        public string ApiVersion { get; set; }

        [JsonProperty("theme_url", NullValueHandling = NullValueHandling.Ignore)]
        public string ThemeUrl { get; set; }

        [JsonProperty("users", NullValueHandling = NullValueHandling.Ignore)]
        public List<User> Users { get; set; }

        [JsonProperty("video_call", NullValueHandling = NullValueHandling.Ignore)]
        public bool? VideoCall { get; set; }

        [JsonProperty("video_call_user", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(CallUserUnionConverter))]
        public CallUserUnion? VideoCallUser { get; set; }

        [JsonProperty("audio_call", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AudioCall { get; set; }

        [JsonProperty("audio_call_user", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(CallUserUnionConverter))]
        public CallUserUnion? AudioCallUser { get; set; }

        [JsonProperty("agora_call", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AgoraCall { get; set; }

        [JsonProperty("agora_call_data", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(CallUserUnionConverter))]
        public CallUserUnion? AgoraCallData { get; set; }
         
        public class User : UserDataObject
        {
            [JsonProperty("profile_picture", NullValueHandling = NullValueHandling.Ignore)]
            public string OldAvatar { get; set; }

            [JsonProperty("cover_picture", NullValueHandling = NullValueHandling.Ignore)]
            public string OldCover { get; set; }

            [JsonProperty("chat_color", NullValueHandling = NullValueHandling.Ignore)]
            public new string ChatColor { get; set; }

            [JsonProperty("chat_time", NullValueHandling = NullValueHandling.Ignore)]
            public string ChatTime { get; set; }

            [JsonProperty("last_message", NullValueHandling = NullValueHandling.Ignore)]
            public LastMessage LastMessage { get; set; }
        }

        public class LastMessage
        {

            [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
            public string Id { get; set; }

            [JsonProperty("from_id", NullValueHandling = NullValueHandling.Ignore)]
            public string FromId { get; set; }

            [JsonProperty("group_id", NullValueHandling = NullValueHandling.Ignore)]
            public string GroupId { get; set; }

            [JsonProperty("to_id", NullValueHandling = NullValueHandling.Ignore)]
            public string ToId { get; set; }

            [JsonProperty("text", NullValueHandling = NullValueHandling.Ignore)]
            public string Text { get; set; }

            [JsonProperty("media", NullValueHandling = NullValueHandling.Ignore)]
            public string Media { get; set; }

            [JsonProperty("mediaFileName", NullValueHandling = NullValueHandling.Ignore)]
            public string MediaFileName { get; set; }

            [JsonProperty("mediaFileNames", NullValueHandling = NullValueHandling.Ignore)]
            public string MediaFileNames { get; set; }

            [JsonProperty("time", NullValueHandling = NullValueHandling.Ignore)]
            public string Time { get; set; }

            [JsonProperty("seen", NullValueHandling = NullValueHandling.Ignore)]
            public string Seen { get; set; }

            [JsonProperty("deleted_one", NullValueHandling = NullValueHandling.Ignore)]
            public string DeletedOne { get; set; }

            [JsonProperty("deleted_two", NullValueHandling = NullValueHandling.Ignore)]
            public string DeletedTwo { get; set; }

            [JsonProperty("sent_push", NullValueHandling = NullValueHandling.Ignore)]
            public string SentPush { get; set; }

            [JsonProperty("notification_id", NullValueHandling = NullValueHandling.Ignore)]
            public string NotificationId { get; set; }

            [JsonProperty("type_two", NullValueHandling = NullValueHandling.Ignore)]
            public string TypeTwo { get; set; }

            [JsonProperty("stickers", NullValueHandling = NullValueHandling.Ignore)]
            public string Stickers { get; set; }

            [JsonProperty("CallUser_id", NullValueHandling = NullValueHandling.Ignore)]
            public string CallUserId { get; set; }

            [JsonProperty("product_id", NullValueHandling = NullValueHandling.Ignore)]
            public string ProductId { get; set; }

            [JsonProperty("date_time", NullValueHandling = NullValueHandling.Ignore)]
            public string DateTime { get; set; }
        }
    }
     
    public class CallUser
    {

        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public Data data { get; set; }

        [JsonProperty("user_id", NullValueHandling = NullValueHandling.Ignore)]
        public string UserId { get; set; }

        [JsonProperty("avatar", NullValueHandling = NullValueHandling.Ignore)]
        public string Avatar { get; set; }

        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        public class Data
        {

            [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
            public string Id { get; set; }

            [JsonProperty("call_id", NullValueHandling = NullValueHandling.Ignore)]
            public string CallId { get; set; }

            [JsonProperty("access_token", NullValueHandling = NullValueHandling.Ignore)]
            public string AccessToken { get; set; }

            [JsonProperty("call_id_2", NullValueHandling = NullValueHandling.Ignore)]
            public string CallId2 { get; set; }

            [JsonProperty("access_token_2", NullValueHandling = NullValueHandling.Ignore)]
            public string AccessToken2 { get; set; }

            [JsonProperty("from_id", NullValueHandling = NullValueHandling.Ignore)]
            public string FromId { get; set; }

            [JsonProperty("to_id", NullValueHandling = NullValueHandling.Ignore)]
            public string ToId { get; set; }

            [JsonProperty("room_name", NullValueHandling = NullValueHandling.Ignore)]
            public string RoomName { get; set; }

            [JsonProperty("active", NullValueHandling = NullValueHandling.Ignore)]
            public string Active { get; set; }

            [JsonProperty("called", NullValueHandling = NullValueHandling.Ignore)]
            public string Called { get; set; }

            [JsonProperty("time", NullValueHandling = NullValueHandling.Ignore)]
            public string Time { get; set; }

            [JsonProperty("declined", NullValueHandling = NullValueHandling.Ignore)]
            public string Declined { get; set; }

            [JsonProperty("url", NullValueHandling = NullValueHandling.Ignore)]
            public string Url { get; set; }


            //Agora Call
            [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
            public string Type { get; set; }

            [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
            public string Status { get; set; }
        }
    }


    public partial struct CallUserUnion
    {
        public List<object> AnythingArray;
        public CallUser CallUserClass;
        public static implicit operator CallUserUnion(List<object> anythingArray) => new CallUserUnion { AnythingArray = anythingArray };
        public static implicit operator CallUserUnion(CallUser callUserClass) => new CallUserUnion { CallUserClass = callUserClass };
    }
     
    internal class CallUserUnionConverter : JsonConverter
    {
        public override bool CanConvert(Type t) => t == typeof(CallUserUnion) || t == typeof(CallUserUnion?);

        public override object ReadJson(JsonReader reader, Type t, object existingValue, JsonSerializer serializer)
        {
            switch (reader.TokenType)
            {
                case JsonToken.StartObject:
                    var objectValue = serializer.Deserialize<CallUser>(reader);
                    return new CallUserUnion { CallUserClass = objectValue };
                case JsonToken.StartArray:
                    var arrayValue = serializer.Deserialize<List<object>>(reader);
                    return new CallUserUnion { AnythingArray = arrayValue };
            }
            throw new Exception("Cannot unmarshal type CallUserUnion");
        }

        public override void WriteJson(JsonWriter writer, object untypedValue, JsonSerializer serializer)
        {
            var value = (CallUserUnion)untypedValue;
            if (value.AnythingArray != null)
            {
                serializer.Serialize(writer, value.AnythingArray);
                return;
            }
            if (value.CallUserClass != null)
            {
                serializer.Serialize(writer, value.CallUserClass);
                return;
            }
            throw new Exception("Cannot marshal type CallUserUnion");
        }

        public static readonly CallUserUnionConverter Singleton = new CallUserUnionConverter();
    }

    internal static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters =
            {
                CallUserUnionConverter.Singleton, 
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
        };
    }


}