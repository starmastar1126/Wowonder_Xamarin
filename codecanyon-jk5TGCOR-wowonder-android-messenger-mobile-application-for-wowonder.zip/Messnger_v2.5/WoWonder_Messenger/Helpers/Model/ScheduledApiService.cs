﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.Tab;
using WoWonder.Frameworks;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using Exception = System.Exception;

namespace WoWonder.Helpers.Model
{
    [Service]
    public class ScheduledApiService : Service
    {
        private readonly Handler MainHandler = new Handler();
        private ResultReceiver ResultSender;
        
        public override IBinder OnBind(Intent intent)
        {
            return null;
        }

        public override void OnCreate()
        {
            try
            {
                base.OnCreate();

                MainHandler.PostDelayed(new ApiPostUpdaterHelper(Application.Context, MainHandler, ResultSender), AppSettings.RefreshChatActivitiesSeconds);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
        {
            try
            {
                var rec = intent.GetParcelableExtra("receiverTag");
                ResultSender = (ResultReceiver)rec;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            MainHandler.PostDelayed(new ApiPostUpdaterHelper(Application.Context, MainHandler, ResultSender), AppSettings.RefreshChatActivitiesSeconds);

            return base.OnStartCommand(intent, flags, startId);
        }
    }

    public class ApiPostUpdaterHelper : Java.Lang.Object, IRunnable
    {
        private readonly Handler MainHandler;
        private readonly Context Activity;
        private readonly ResultReceiver ResultSender;

        public ApiPostUpdaterHelper(Context activity, Handler mainHandler, ResultReceiver resultSender)
        {
            MainHandler = mainHandler;
            Activity = activity;
            ResultSender = resultSender; 
        }

        public async void Run()
        {
            try
            { 
                //Toast.MakeText(Application.Context, "Started", ToastLength.Short).Show(); 
                if (ResultSender == null)
                {
                    try
                    {
                        SqLiteDatabase dbDatabase = new SqLiteDatabase();
                        var login = dbDatabase.Get_data_Login_Credentials();
                        Console.WriteLine(login);
                        (int apiStatus, var respond) = await ApiRequest.Get_users_list_Async();
                        dbDatabase.Dispose();
                        if (apiStatus != 200 || !(respond is GetUsersListObject result))
                        {
                           // Methods.DisplayReportResult(Activity, respond);
                        }
                        else
                        {
                            //Toast.MakeText(Application.Context, "ResultSender 1 \n" + data, ToastLength.Short).Show();

                            #region Call >> Video_Call_User

                            try
                            {
                                if (AppSettings.EnableAudioVideoCall)
                                { 
                                    if (AppSettings.UseTwilioLibrary)
                                    {
                                        bool twilioVideoCall = false;

                                        if (AppSettings.EnableVideoCall)
                                        {
                                            twilioVideoCall = result.VideoCall ?? false;

                                            #region Twilio Video call

                                            if (twilioVideoCall && !TabbedMainActivity.RunCall)
                                            {
                                                var callUser = result.VideoCallUser?.CallUserClass;
                                                if (callUser != null)
                                                {
                                                    TabbedMainActivity.RunCall = true;

                                                    var userId = callUser.UserId;
                                                    var avatar = callUser.Avatar;
                                                    var name = callUser.Name;

                                                    var videosData = callUser.data;
                                                    if (videosData != null)
                                                    {
                                                        var id = videosData.Id; //call_id
                                                        var accessToken = videosData.AccessToken;
                                                        var accessToken2 = videosData.AccessToken2;
                                                        var fromId = videosData.FromId;
                                                        var active = videosData.Active;
                                                        var time = videosData.Called;
                                                        var declined = videosData.Declined;
                                                        var roomName = videosData.RoomName;

                                                        Intent intent = new Intent(Activity, typeof(VideoAudioComingCallActivity));
                                                        intent.PutExtra("UserID", userId);
                                                        intent.PutExtra("avatar", avatar);
                                                        intent.PutExtra("name", name);
                                                        intent.PutExtra("access_token", accessToken);
                                                        intent.PutExtra("access_token_2", accessToken2);
                                                        intent.PutExtra("from_id", fromId);
                                                        intent.PutExtra("active", active);
                                                        intent.PutExtra("time", time);
                                                        intent.PutExtra("CallID", id);
                                                        intent.PutExtra("status", declined);
                                                        intent.PutExtra("room_name", roomName);
                                                        intent.PutExtra("declined", declined);
                                                        intent.PutExtra("type", "Twilio_video_call");

                                                        string avatarSplit = avatar.Split('/').Last();
                                                        var getImg = Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage, avatarSplit);
                                                        if (getImg == "File Dont Exists")
                                                            Methods.MultiMedia.DownloadMediaTo_DiskAsync(Methods.Path.FolderDiskImage, avatar);

                                                        if (!VideoAudioComingCallActivity.IsActive)
                                                        {
                                                            intent.AddFlags(ActivityFlags.NewTask);
                                                            Activity.StartActivity(intent);
                                                        } 
                                                    }
                                                } 
                                            }
                                            else if (twilioVideoCall == false)
                                            {
                                                if (TabbedMainActivity.RunCall)
                                                {
                                                    TabbedMainActivity.RunCall = false;
                                                    if (VideoAudioComingCallActivity.IsActive)
                                                        VideoAudioComingCallActivity.CallActivity?.Finish();
                                                } 
                                            }

                                            #endregion 
                                        }

                                        if (AppSettings.EnableAudioCall)
                                        {
                                            var twilioAudioCall = result.AudioCall ?? false;

                                            #region Twilio Audio call

                                            if (twilioAudioCall && !TabbedMainActivity.RunCall)
                                            {
                                                var callUser = result.AudioCallUser?.CallUserClass;
                                                if (callUser != null)
                                                {
                                                    TabbedMainActivity.RunCall = true;

                                                    var userId = callUser.UserId;
                                                    var avatar = callUser.Avatar;
                                                    var name = callUser.Name;

                                                    var videosData = callUser.data;
                                                    if (videosData != null)
                                                    {
                                                        var id = videosData.Id; //call_id
                                                        var accessToken = videosData.AccessToken;
                                                        var accessToken2 = videosData.AccessToken2;
                                                        var fromId = videosData.FromId;
                                                        var active = videosData.Active;
                                                        var time = videosData.Called;
                                                        var declined = videosData.Declined;
                                                        var roomName = videosData.RoomName;

                                                        Intent intent = new Intent(Activity, typeof(VideoAudioComingCallActivity));
                                                        intent.PutExtra("UserID", userId);
                                                        intent.PutExtra("avatar", avatar);
                                                        intent.PutExtra("name", name);
                                                        intent.PutExtra("access_token", accessToken);
                                                        intent.PutExtra("access_token_2", accessToken2);
                                                        intent.PutExtra("from_id", fromId);
                                                        intent.PutExtra("active", active);
                                                        intent.PutExtra("time", time);
                                                        intent.PutExtra("CallID", id);
                                                        intent.PutExtra("status", declined);
                                                        intent.PutExtra("room_name", roomName);
                                                        intent.PutExtra("declined", declined);
                                                        intent.PutExtra("type", "Twilio_audio_call");

                                                        string avatarSplit = avatar.Split('/').Last();
                                                        var getImg =
                                                            Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage,
                                                                avatarSplit);
                                                        if (getImg == "File Dont Exists")
                                                            Methods.MultiMedia.DownloadMediaTo_DiskAsync(
                                                                Methods.Path.FolderDiskImage, avatar);

                                                        if (!VideoAudioComingCallActivity.IsActive)
                                                        {
                                                            intent.AddFlags(ActivityFlags.NewTask);
                                                            Activity.StartActivity(intent);
                                                        }
                                                    }
                                                }
                                            }
                                            else if (twilioAudioCall == false && twilioVideoCall == false)
                                            {
                                                if (TabbedMainActivity.RunCall)
                                                {
                                                    TabbedMainActivity.RunCall = false;
                                                    if (VideoAudioComingCallActivity.IsActive)
                                                        VideoAudioComingCallActivity.CallActivity?.Finish();
                                                }
                                            }

                                            #endregion
                                        }
                                    }
                                    else if (AppSettings.UseAgoraLibrary)
                                    {
                                        #region Agora Audio/Video call
                                         
                                        var agoraCall = result.AgoraCall ?? false;
                                        if (agoraCall && !TabbedMainActivity.RunCall)
                                        {
                                            var callUser = result.AgoraCallData?.CallUserClass;
                                            if (callUser != null)
                                            {
                                                TabbedMainActivity.RunCall = true;

                                                var userId = callUser.UserId;
                                                var avatar = callUser.Avatar;
                                                var name = callUser.Name;

                                                var videosData = callUser.data;
                                                if (videosData != null)
                                                {
                                                    var id = videosData.Id; //call_id
                                                                            //var accessToken = videosData.AccessToken;
                                                                            //var accessToken2 = videosData.AccessToken2;
                                                    var fromId = videosData.FromId;
                                                    //var active = videosData.Active;
                                                    var time = videosData.Called;
                                                    //var declined = videosData.Declined;
                                                    var roomName = videosData.RoomName;
                                                    var type = videosData.Type;
                                                    var status = videosData.Status;

                                                    string avatarSplit = avatar.Split('/').Last();
                                                    var getImg = Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage, avatarSplit);
                                                    if (getImg == "File Dont Exists")
                                                        Methods.MultiMedia.DownloadMediaTo_DiskAsync(Methods.Path.FolderDiskImage, avatar);

                                                    if (type == "video")
                                                    {
                                                        if (AppSettings.EnableVideoCall)
                                                        {
                                                            Intent intent = new Intent(Activity, typeof(VideoAudioComingCallActivity));
                                                            intent.PutExtra("UserID", userId);
                                                            intent.PutExtra("avatar", avatar);
                                                            intent.PutExtra("name", name);
                                                            intent.PutExtra("from_id", fromId);
                                                            intent.PutExtra("status", status);
                                                            intent.PutExtra("time", time);
                                                            intent.PutExtra("CallID", id);
                                                            intent.PutExtra("room_name", roomName);
                                                            intent.PutExtra("type", "Agora_video_call_recieve");
                                                            intent.PutExtra("declined", "0");

                                                            if (!VideoAudioComingCallActivity.IsActive)
                                                            {
                                                                intent.AddFlags(ActivityFlags.NewTask);
                                                                Activity.StartActivity(intent);
                                                            }
                                                        }
                                                    }
                                                    else if (type == "audio")
                                                    {
                                                        if (AppSettings.EnableAudioCall)
                                                        {
                                                            Intent intent = new Intent(Activity, typeof(VideoAudioComingCallActivity));
                                                            intent.PutExtra("UserID", userId);
                                                            intent.PutExtra("avatar", avatar);
                                                            intent.PutExtra("name", name);
                                                            intent.PutExtra("from_id", fromId);
                                                            intent.PutExtra("status", status);
                                                            intent.PutExtra("time", time);
                                                            intent.PutExtra("CallID", id);
                                                            intent.PutExtra("room_name", roomName);
                                                            intent.PutExtra("type", "Agora_audio_call_recieve");
                                                            intent.PutExtra("declined", "0");

                                                            if (!VideoAudioComingCallActivity.IsActive)
                                                            {
                                                                intent.AddFlags(ActivityFlags.NewTask);
                                                                Activity.StartActivity(intent);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (agoraCall == false)
                                        {
                                            if (TabbedMainActivity.RunCall)
                                            {
                                                TabbedMainActivity.RunCall = false;
                                                if (VideoAudioComingCallActivity.IsActive)
                                                    VideoAudioComingCallActivity.CallActivity?.Finish();
                                            } 
                                        }

                                        #endregion
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }

                            #endregion

                            if (result.Users.Count > 0)
                            {
                                ListUtils.UserList = new ObservableCollection<GetUsersListObject.User>(result.Users);

                                //Insert All data users to database
                                dbDatabase.Insert_Or_Update_LastUsersChat(ListUtils.UserList);
                                dbDatabase.Dispose();
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        // Toast.MakeText(Application.Context, "Exception  " + e, ToastLength.Short).Show();
                    }
                }
                else
                {
                    (int apiStatus, var respond) = await ApiRequest.Get_users_list_Async("35", "0", false);
                    if (apiStatus != 200 || !(respond is GetUsersListObject result))
                    { 
                        if (respond is ErrorObject errorMessage)
                        {
                            string errorText = errorMessage._errors.ErrorText;

                            if (errorText.Contains("Invalid or expired access_token") || errorText.Contains("No session sent"))
                                ApiRequest.Logout(TabbedMainActivity.GetInstance());
                        } 
                    }
                    else
                    {
                        var b = new Bundle();
                        b.PutString("Json", JsonConvert.SerializeObject(result));
                        ResultSender.Send(0, b);

                        //Toast.MakeText(Application.Context, "ResultSender 2 \n" + data, ToastLength.Short).Show();

                        Console.WriteLine("Allen Post + started");
                    }
                }
                 
                MainHandler.PostDelayed(new ApiPostUpdaterHelper(Activity, MainHandler, ResultSender), AppSettings.RefreshChatActivitiesSeconds);  
            }
            catch (Exception e)
            {
                //Toast.MakeText(Application.Context, "ResultSender failed", ToastLength.Short).Show();
                MainHandler.PostDelayed(new ApiPostUpdaterHelper(Activity, MainHandler, ResultSender), AppSettings.RefreshChatActivitiesSeconds);
                Console.WriteLine(e);
                Console.WriteLine("Allen Post + failed");
            }
        } 
    }
}