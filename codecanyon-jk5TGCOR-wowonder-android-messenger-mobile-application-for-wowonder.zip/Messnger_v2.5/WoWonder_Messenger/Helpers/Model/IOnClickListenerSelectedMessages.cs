﻿using Android.Views;

namespace WoWonder.Helpers.Model
{
    public interface IOnClickListenerSelectedMessages
    {
        void ItemClick(View view, MessageData obj, int pos);
        void ItemLongClick(View view, MessageData obj, int pos);

    }
}