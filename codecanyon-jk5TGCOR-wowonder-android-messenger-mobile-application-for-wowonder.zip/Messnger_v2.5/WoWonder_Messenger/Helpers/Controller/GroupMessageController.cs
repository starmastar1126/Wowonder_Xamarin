﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WoWonder.Activities.GroupChat;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Activities.Tab;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.GroupChat;
using WoWonderClient.Requests;

namespace WoWonder.Helpers.Controller
{
    public static class GroupMessageController
    {  
        //############# DONT'T MODIFY HERE ############# 
        private static GroupObject GroupData; 
        private static GroupChatWindowActivity MainWindowActivity;

        //========================= Functions =========================
        public static async Task SendMessageTask(GroupChatWindowActivity windowActivity, string id, string messageId, string text = "", string contact = "", string pathFile = "", string imageUrl = "", string stickerId = "", string gifUrl = "")
        {
            try
            {
                MainWindowActivity = windowActivity;
                if (windowActivity.GroupData != null)
                    GroupData = windowActivity.GroupData;
                 
                var (apiStatus, respond) = await RequestsAsync.GroupChat.Send_MessageToGroupChat(id, messageId, text, contact, pathFile, imageUrl, stickerId, gifUrl);
                if (apiStatus == 200)
                {
                    if (respond is GroupSendMessageObject result)
                    {  
                        UpdateLastIdMessage(result.Data);
                    }
                }
                else Methods.DisplayReportResult(windowActivity, respond);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static void UpdateLastIdMessage(List<WoWonderClient.Classes.Message.MessageData> chatMessages)
        {
            try
            {
                foreach (var messageInfo in chatMessages)
                {
                    if (messageInfo.Stickers == null)
                        messageInfo.Stickers = "";

                    if (messageInfo.Text == null)
                        messageInfo.Text = "";

                    messageInfo.Stickers = messageInfo.Stickers.Replace(".mp4", ".gif");

                    var id = messageInfo.Id;
                    var fromId = messageInfo.FromId; // user id
                    var groupId = messageInfo.GroupId;
                    var toId = messageInfo.ToId;
                    var text = messageInfo.Text;
                    var media = messageInfo.Media;
                    var mediaFileName = messageInfo.MediaFileName;
                    var mediaFileNames = messageInfo.MediaFileNames;
                    var time = messageInfo.Time;
                    //var seen = messageInfo.Seen;
                    var deletedOne = messageInfo.DeletedOne;
                    var deletedTwo = messageInfo.DeletedTwo;
                    var sentPush = messageInfo.SentPush;
                    var notificationId = messageInfo.NotificationId;
                    var typeTwo = messageInfo.TypeTwo;
                    var stickers = Methods.FunString.StringNullRemover(messageInfo.Stickers);
                    var timeText = messageInfo.TimeText;
                    var position = messageInfo.Position;
                    var type = messageInfo.Type;
                    var fileSize = messageInfo.FileSize;
                    var sendTime = messageInfo.MessageHashId;
                    var dataUser = messageInfo.UserData;
                    var productId = messageInfo.ProductId;
                    var onwer = messageInfo.Onwer;

                    var checker = MainWindowActivity?.MAdapter?.MessageList.FirstOrDefault(a => a.Id == sendTime); 
                    if (checker != null)
                    {
                        checker.Id = id;
                        checker.TimeText = timeText;
                        checker.FromId = fromId;
                        checker.GroupId = groupId;
                        checker.ToId = toId;
                        checker.Position = position;
                        checker.Media = media;
                        checker.MediaFileName = mediaFileName;
                        checker.MediaFileNames = mediaFileNames;
                        checker.Time = time;
                        checker.Seen = "1";
                        checker.DeletedOne = deletedOne;
                        checker.DeletedTwo = deletedTwo;
                        checker.SentPush = sentPush;
                        checker.NotificationId = notificationId;
                        checker.TypeTwo = typeTwo;
                        checker.Stickers = stickers;
                        checker.Position = position;
                        checker.FileSize = fileSize;
                        checker.UserData = dataUser;
                        checker.ProductId = productId;
                        checker.Onwer = onwer;
                         
                        if (checker.Stickers == null)
                            checker.Stickers = "";

                        //var decode = text.Contains("http");
                        checker.Text = Methods.FunString.DecodeString(text);
                        
                        checker.Type = type == "right_gif" || text == "" && (type == "right_text" || type == "left_text") && stickers.Contains(".gif") ? "right_gif" : type;

                        if (type == "right_contact")
                        {
                            string[] stringSeparators = { "&quot;" };
                            var name = text.Split(stringSeparators, StringSplitOptions.None);
                            var stringName = name[3];
                            var stringNumber = name[7];
                            checker.ContactName = stringName;
                            checker.ContactNumber = stringNumber;
                        }
                         
                        if (GroupData != null)
                        {
                            var index = TabbedMainActivity.GetInstance().LastGroupChatsTab.MAdapter.LastGroupList.IndexOf(TabbedMainActivity.GetInstance().LastGroupChatsTab.MAdapter.LastGroupList.FirstOrDefault(x => x.GroupId == groupId));
                            if (index > -1)
                            {
                                TabbedMainActivity.GetInstance().LastGroupChatsTab.MAdapter.LastGroupList.Move(index, 0);
                                TabbedMainActivity.GetInstance().LastGroupChatsTab.MAdapter.NotifyItemMoved(index, 0); 
                            }
                        }
                        else
                        {
                            //insert new  
                            TabbedMainActivity.GetInstance().LastGroupChatsTab.MAdapter.LastGroupList.Insert(0,GroupData);
                            TabbedMainActivity.GetInstance().LastGroupChatsTab.MAdapter.NotifyItemInserted(0);
                        }
                         
                        //Update data RecyclerView Messages.
                        if (type != "right_sticker")
                            MainWindowActivity.Update_One_Messeges(checker);

                        if (SettingsPrefsFragment.SSoundControl)
                            Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("Popup_SendMesseges.mp3");
                    }
                }

                GroupData = null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }
}