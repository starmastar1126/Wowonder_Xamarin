using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.Widget;
using WoWonder.Activities.ChatWindow;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Activities.Tab;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Message;
using WoWonderClient.Requests;
using MessageData = WoWonder.Helpers.Model.MessageData;

namespace WoWonder.Helpers.Controller
{
    public static class MessageController
    {
        //############# DON'T  MODIFY HERE #############
        private static GetUsersListObject.User Datauser;
        private static UserDataObject UserData;
        private static ChatWindowActivity WindowActivity;

        private static TabbedMainActivity GlobalContext;
        //========================= Functions =========================
        public static async Task SendMessageTask(ChatWindowActivity windowActivity, string userid, string messageId, string text = "", string contact = "", string pathFile = "", string imageUrl = "", string stickerId = "", string gifUrl = "")
        {
            try
            {
                WindowActivity = windowActivity;
                if (windowActivity.DataUser != null)
                    Datauser = windowActivity.DataUser;
                else if (windowActivity.UserData != null)
                    UserData = windowActivity.UserData;

                GlobalContext = TabbedMainActivity.GetInstance();

                StartApiService(userid, messageId, text, contact, pathFile, imageUrl, stickerId, gifUrl);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static void StartApiService(string userid, string messageId, string text = "", string contact = "", string pathFile = "", string imageUrl = "", string stickerId = "", string gifUrl = "")
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(WindowActivity, WindowActivity.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => SendMessage(userid, messageId, text, contact, pathFile, imageUrl, stickerId, gifUrl) });
        }

        private static async Task SendMessage(string userid, string messageId, string text = "", string contact = "", string pathFile = "", string imageUrl = "", string stickerId = "", string gifUrl = "")
        {
            var (apiStatus, respond) = await RequestsAsync.Message.Send_Message(userid, messageId, text, contact, pathFile, imageUrl, stickerId, gifUrl);
            if (apiStatus == 200)
            {
                if (respond is SendMessageObject result)
                {
                    UpdateLastIdMessage(result);
                }
            }
            else Methods.DisplayReportResult(WindowActivity, respond);
        }

        private static void UpdateLastIdMessage(SendMessageObject chatMessages)
        {
            try
            { 
                foreach (var messageInfo in chatMessages.MessageData)
                {
                   var message = WoWonderTools.MessageFilter(messageInfo.ToId, messageInfo);

                    var id = message.Id;
                    var fromId = message.FromId; // user id
                    var groupId = message.GroupId;
                    var toId = message.ToId;
                    var text = Methods.FunString.DecodeString(message.Text);
                    var textlong = message.Text;
                    var media = message.Media;
                    var mediaFileName = message.MediaFileName;
                    var mediaFileNames = message.MediaFileNames;
                    var time = message.Time;
                    var seen = message.Seen;
                    var deletedOne = message.DeletedOne;
                    var deletedTwo = message.DeletedTwo;
                    var sentPush = message.SentPush;
                    var notificationId = message.NotificationId;
                    var typeTwo = message.TypeTwo;
                    var stickers = message.Stickers;
                    var timeText = message.TimeText;
                    var position = message.Position;
                    var type = message.Type;
                    var fileSize = message.FileSize;
                    var sendTime = message.MessageHashId;
                    var productId = message.ProductId;
                    var onwer = message.Onwer;

                    var dataUser = message.MessageUser;

                    MessageData checker = WindowActivity?.MAdapter?.MessageList?.FirstOrDefault(a => a.Id == sendTime);
                    if (checker != null)
                    { 
                        checker.Id = id;
                        //checker.TimeText = timeText;
                        checker.FromId = fromId;
                        checker.GroupId = groupId;
                        checker.ToId = toId;
                        checker.Position = position;
                        checker.Media = media;
                        checker.MediaFileName = mediaFileName;
                        checker.MediaFileNames = mediaFileNames;
                        checker.Time = time;
                        checker.Seen = "1";
                        checker.DeletedOne = deletedOne;
                        checker.DeletedTwo = deletedTwo;
                        checker.SentPush = sentPush;
                        checker.NotificationId = notificationId;
                        checker.TypeTwo = typeTwo;
                        checker.Stickers = stickers;
                        checker.Position = position;
                        checker.FileSize = fileSize;
                        checker.UserData = dataUser;
                        checker.ProductId = productId;
                        checker.Onwer = onwer;

                        checker.Type = type == "right_gif" || text == "" && (type == "right_text" || type == "left_text") && stickers.Contains(".gif") ? "right_gif" : type;
 
                        var updaterUser = GlobalContext.LastMessagesTab.MAdapter.MLastMessagesUser.FirstOrDefault(a => a.UserId == toId);
                        if (updaterUser != null)
                        {
                            var index = GlobalContext.LastMessagesTab.MAdapter.MLastMessagesUser.IndexOf(GlobalContext.LastMessagesTab.MAdapter.MLastMessagesUser.FirstOrDefault(x => x.UserId == toId));
                            if (index > -1)
                            {
                                if (string.IsNullOrEmpty(text))
                                {
                                    if (type == "right_gif" || text == "" && (type == "right_text" || type == "left_text") && stickers.Contains(".gif"))
                                        text = Application.Context.GetText(Resource.String.Lbl_SendGifFile);
                                    else if (type == "right_text")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendMessage);
                                    else if (type == "right_sticker")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendStickerFile);
                                    else if (type == "right_contact")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendContactnumber);
                                    else if (type == "right_file")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendFile);
                                    else if (type == "right_video")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendVideoFile);
                                    else if (type == "right_image")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendImageFile);
                                    else if (type == "right_audio" || type == "right_Audio")
                                        text = Application.Context.GetText(Resource.String.Lbl_SendAudioFile);
                                }

                                updaterUser.LastMessage.Text = type == "right_text" ? text != null && text.Contains("http") ? text : Methods.FunString.DecodeString(text) : text;
                                GlobalContext.RunOnUiThread(() =>
                                {
                                    GlobalContext?.LastMessagesTab.MAdapter.MLastMessagesUser.Move(index, 0);
                                    GlobalContext?.LastMessagesTab.MAdapter.NotifyItemMoved(index, 0);
                                    GlobalContext?.LastMessagesTab?.MAdapter.NotifyItemChanged(index, "WithoutBlob");
                                });
                                SqLiteDatabase dbSqLite = new SqLiteDatabase();
                                //Update All data users to database
                                dbSqLite.Insert_Or_Update_LastUsersChat(new ObservableCollection<GetUsersListObject.User>() { updaterUser });
                                dbSqLite.Dispose();
                            }
                        }
                        else
                        {
                            //insert new user  
                            var data = ConvertData(checker);
                            if (data != null)
                            {
                                GlobalContext.RunOnUiThread(() =>
                                {
                                    GlobalContext.LastMessagesTab.MAdapter.MLastMessagesUser.Insert(0, data);
                                    GlobalContext.LastMessagesTab.MAdapter.NotifyItemInserted(0);
                                    GlobalContext.LastMessagesTab?.MRecycler.ScrollToPosition(GlobalContext.LastMessagesTab.MAdapter.MLastMessagesUser.IndexOf(data));
                                });

                                //Update All data users to database
                                //dbDatabase.Insert_Or_Update_LastUsersChat(new ObservableCollection<GetUsersListObject.User>
                                //{
                                //    data
                                //});
                            }
                        }

                        //checker.Media = media;
                        //Update All data users to database
                        SqLiteDatabase dbDatabase = new SqLiteDatabase();
                        dbDatabase.Insert_Or_Update_To_one_MessagesTable(checker);
                        dbDatabase.Dispose();

                        //Update data RecyclerView Messages.
                        if (type != "right_sticker")
                            WindowActivity.Update_One_Messeges(checker);

                        if (SettingsPrefsFragment.SSoundControl)
                            Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("Popup_SendMesseges.mp3");
                    } 
                }

                Datauser = null;
                UserData = null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static GetUsersListObject.User ConvertData(MessageData ms)
        {
            try
            {
                if (Datauser != null)
                {
                    GetUsersListObject.User user = new GetUsersListObject.User
                    {
                        UserId = ms.ToId,
                        Username = Datauser.Username,
                        Avatar = Datauser.Avatar,
                        Cover = Datauser.Cover,
                        LastseenTimeText = Datauser.LastseenTimeText,
                        Lastseen = Datauser.Lastseen,
                        Url = Datauser.Url,
                        Name = Datauser.Name,
                        LastseenUnixTime = Datauser.LastseenUnixTime,
                        ChatColor = Datauser.ChatColor ?? AppSettings.MainColor,
                        Verified = Datauser.Verified,
                        LastMessage = new GetUsersListObject.LastMessage
                        {
                            Id = ms.Id,
                            FromId = ms.FromId,
                            GroupId = ms.GroupId,
                            ToId = ms.ToId,
                            Text = ms.Text,
                            Media = ms.Media,
                            MediaFileName = ms.MediaFileName,
                            MediaFileNames = ms.MediaFileNames,
                            Time = ms.Time,
                            Seen = ms.Seen,
                            DeletedOne = ms.DeletedOne,
                            DeletedTwo = ms.DeletedTwo,
                            SentPush = ms.SentPush,
                            NotificationId = ms.NotificationId,
                            TypeTwo = ms.TypeTwo,
                            Stickers = ms.Stickers
                        }
                    };
                    return user;
                }
                if (UserData != null)
                {
                    GetUsersListObject.User user = new GetUsersListObject.User
                    {
                        UserId = ms.ToId,
                        Username = UserData.Username,
                        Avatar = UserData.Avatar,
                        Cover = UserData.Cover,
                        LastseenTimeText = UserData.LastseenTimeText,
                        Lastseen = UserData.Lastseen,
                        Url = UserData.Url,
                        Name = UserData.Name,
                        LastseenUnixTime = UserData.LastseenUnixTime,
                        ChatColor = AppSettings.MainColor,
                        Verified = UserData.Verified,
                        LastMessage = new GetUsersListObject.LastMessage()
                        {
                            Id = ms.Id,
                            FromId = ms.FromId,
                            GroupId = ms.GroupId,
                            ToId = ms.ToId,
                            Text = ms.Text,
                            Media = ms.Media,
                            MediaFileName = ms.MediaFileName,
                            MediaFileNames = ms.MediaFileNames,
                            Time = ms.Time,
                            Seen = ms.Seen,
                            DeletedOne = ms.DeletedOne,
                            DeletedTwo = ms.DeletedTwo,
                            SentPush = ms.SentPush,
                            NotificationId = ms.NotificationId,
                            TypeTwo = ms.TypeTwo,
                            Stickers = ms.Stickers
                        }
                    };
                    return user;
                }

                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static void UpdateRecyclerLastMessageView(GetUsersListObject.LastMessage result, GetUsersListObject.User user, int index, TabbedMainActivity context)
        {
            try
            {
                if (IsImageExtension(result.MediaFileName))
                {
                    result.Text = Application.Context.GetText(Resource.String.Lbl_SendImageFile);
                }
                else if (IsVideoExtension(result.MediaFileName))
                {
                    result.Text = Application.Context.GetText(Resource.String.Lbl_SendVideoFile);
                }
                else if (IsAudioExtension(result.MediaFileName))
                {
                    result.Text = Application.Context.GetText(Resource.String.Lbl_SendAudioFile);
                }
                else if (IsFileExtension(result.MediaFileName))
                {
                    result.Text = Application.Context.GetText(Resource.String.Lbl_SendFile);
                }
                else if (result.MediaFileName.Contains(".gif") || result.MediaFileName.Contains(".GIF"))
                {
                    result.Text = Application.Context.GetText(Resource.String.Lbl_SendGifFile);
                }
                //TODO: WAEL
                else
                {
                    result.Text = Methods.FunString.DecodeString(result.Text);
                }

                //if (string.IsNullOrEmpty(text))
                //{
                //   
                //    else if (type == "right_text")
                //        text = Application.Context.GetText(Resource.String.Lbl_SendMessage);
                //    else if (type == "right_sticker")
                //        text = Application.Context.GetText(Resource.String.Lbl_SendStickerFile);
                //    else if (type == "right_contact")
                //        text = Application.Context.GetText(Resource.String.Lbl_SendContactnumber);
                //    else if (type == "right_file")
                //      

                context.RunOnUiThread(() =>
                {
                    context.LastMessagesTab?.MAdapter.NotifyItemChanged(index);
                });


                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                //Update All data users to database
                dbDatabase.Insert_Or_Update_LastUsersChat(new ObservableCollection<GetUsersListObject.User>() { user });
                dbDatabase.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);

            }
        }

        public static readonly string[] ImageValidExtensions = { ".jpg", ".bmp", ".gif", ".png", ".jpeg", ".tif" };
        public static readonly string[] VideoValidExtensions = { ".mp4", ".avi", ".mov", ".flv", ".wmv", ".divx", ".mpeg", ".mpeg2" };
        public static readonly string[] AudioValidExtensions = { ".mp3", ".wav", ".aiff", ".pcm", ".wmv" };
        public static readonly string[] FilesValidExtensions = { ".zip", ".pdf", ".doc", ".xml", ".txt" };

        public static bool IsImageExtension(string text)
        {
            return ImageValidExtensions.Any(text.Contains);
        }

        public static bool IsVideoExtension(string text)
        {
            return VideoValidExtensions.Any(text.Contains);
        }
        public static bool IsAudioExtension(string text)
        {
            return AudioValidExtensions.Any(text.Contains);
        }

        public static bool IsFileExtension(string text)
        {
            return FilesValidExtensions.Any(text.Contains);
        }
    }
}