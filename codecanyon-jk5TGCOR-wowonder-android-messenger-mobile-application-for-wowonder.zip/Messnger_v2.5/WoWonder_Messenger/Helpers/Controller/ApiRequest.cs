using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Gms.Auth.Api;
using Android.Widget;
using Java.IO;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.Authentication;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Frameworks.onesignal;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using Xamarin.Facebook;
using Xamarin.Facebook.Login;
using Console = System.Console;
using Exception = System.Exception;
using Profile = Xamarin.Facebook.Profile;

namespace WoWonder.Helpers.Controller
{
    public static class ApiRequest
    {
        //############# DONT'T MODIFY HERE #############

        //Main API URLS
        //*********************************************************
        private static readonly string ApiGetUsersList = Client.WebsiteUrl + "/app_api.php?application=phone&type=get_users_list";
        private static readonly string ApiGetUserMessages = Client.WebsiteUrl + "/app_api.php?application=phone&type=get_user_messages";
        private static readonly string ApiSendVideoCallAnswer = Client.WebsiteUrl + "/app_api.php?application=phone&type=video_call_answer";
        private static readonly string ApiCreateVideoCallAnswer = Client.WebsiteUrl + "/app_api.php?application=phone&type=create_video_call";
        private static readonly string ApiCheckForVideoAnswer = Client.WebsiteUrl + "/app_api.php?application=phone&type=check_for_answer";
        private static readonly string ApiSendAudioCallAnswer = Client.WebsiteUrl + "/app_api.php?application=phone&type=audio_call_answer";
        private static readonly string ApiCreateAudioCallAnswer = Client.WebsiteUrl + "/app_api.php?application=phone&type=create_audio_call";
        private static readonly string ApiSendAgoraCallAction = Client.WebsiteUrl + "/app_api.php?application=phone&type=call_agora_actions";
        private static readonly string ApiCreateAgoraCallEvent = Client.WebsiteUrl + "/app_api.php?application=phone&type=create_agora_call";
        private static readonly string ApiCheckForAgoraAnswer = Client.WebsiteUrl + "/app_api.php?application=phone&type=check_agora_for_answer";
        private static readonly string ApiGetSearchGifs = "https://api.giphy.com/v1/gifs/search?api_key=b9427ca5441b4f599efa901f195c9f58&q=";
        private static readonly string ApiGetTimeZone = "http://ip-api.com/json/";
        //########################## Client ##########################

        public static async Task<(int, dynamic)> Get_users_list_Async(string limit = "35", string offset = "0", bool onlineEnabled = true)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var values = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("user_profile_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken),
                        new KeyValuePair<string, string>("list_type", "all"),
                        new KeyValuePair<string, string>("limit", limit),
                        new KeyValuePair<string, string>("offset", offset),
                    };

                    if (onlineEnabled)
                        values.Add(new KeyValuePair<string, string>("SetOnline", "1"));

                    var formContent = new FormUrlEncodedContent(values);
                    var response = await client.PostAsync(ApiGetUsersList, formContent);
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<GetUsersListObject>(json);
                    string apiStatus = data.ApiStatus;
                    if (apiStatus == "200")
                    {
                        return (200, data); // return json;
                    }

                    var error = JsonConvert.DeserializeObject<ErrorObject>(json);
                    return (400, error);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return (404, "error : " + e.Message);
            }
        }

        public static async Task<string> GetTimeZoneAsync()
        {
            try
            {
                if (AppSettings.AutoCodeTimeZone)
                {
                    using (var client = new HttpClient())
                    {
                        var response = await client.GetAsync(ApiGetTimeZone);
                        string json = await response.Content.ReadAsStringAsync();
                        var data = JsonConvert.DeserializeObject<TimeZoneObject>(json);
                        return data?.Timezone;
                    }
                }
                else
                {
                    return AppSettings.CodeTimeZone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return AppSettings.CodeTimeZone;
            }
        }

        #region Messages

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="beforeMessageId"></param>
        /// <param name="afterMessageId"></param>
        /// <param name="limit"></param>
        /// <returns></returns>
        public static async Task<(int, dynamic)> FetchUserChatMessages(string id, string beforeMessageId = "0", string afterMessageId = "0", string limit = "100")
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("recipient_id", id),
                        new KeyValuePair<string, string>("before_message_id", beforeMessageId),
                        new KeyValuePair<string, string>("after_message_id", afterMessageId),
                        new KeyValuePair<string, string>("limit", limit),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiGetUserMessages, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<UserChatMessagesObject>(json);
                    if (data.ApiStatus == 200)
                    {
                        return (200, data);
                    }

                    var error = JsonConvert.DeserializeObject<ErrorObject>(json);
                    return (400, error);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("error : " + e.Message);
                return (404, "error : " + e.Message);
            }
        }

        #endregion

        #region Call

        public static async Task<string> Send_Twilio_Video_Call_Answer_Async(string answerType, string callId)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("answer_type", answerType),
                        new KeyValuePair<string, string>("call_id", callId),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiSendVideoCallAnswer, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["status"].ToString();
                    if (apiStatus == "200")
                    {
                        return !string.IsNullOrEmpty(data["url"].ToString()) ? data["url"].ToString() : "";
                    }

                    return "Decline";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<Classes.CallUser> Create_Twilio_Video_Call_Answer_Async(string recipientId)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("recipient_id", recipientId),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiCreateVideoCallAnswer, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["status"].ToString();
                    if (apiStatus == "200")
                    {
                        Classes.CallUser videoData = new Classes.CallUser
                        {
                            AccessToken = data["access_token"].ToString(),
                            AccessToken2 = data["access_token_2"].ToString(),
                            Id = data["id"].ToString(),
                            RoomName = data["room_name"].ToString(),
                            Type = "Twilio_video_call"
                        };

                        return videoData;
                    }

                    return null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<string> Check_Twilio_Call_Answer_Async(string callId, string callType)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("call_id", callId),
                        new KeyValuePair<string, string>("call_type", callType),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiCheckForVideoAnswer, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        string callstatus = data["call_status"].ToString();
                        return callstatus;
                    }

                    return "400";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }


        public static async Task<string> Send_Twilio_Audio_Call_Answer_Async(string answerType, string callId)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("answer_type", answerType),
                        new KeyValuePair<string, string>("call_id", callId),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiSendAudioCallAnswer, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["status"].ToString();
                    if (apiStatus == "200")
                    {
                        string urlVideo = data["url"].ToString();
                        return urlVideo;
                    }

                    return "Decline";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<Classes.CallUser> Create_Twilio_Audio_Call_Answer_Async(string recipientId)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("recipient_id", recipientId),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiCreateAudioCallAnswer, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["status"].ToString();
                    if (apiStatus == "200")
                    {
                        Classes.CallUser videoData = new Classes.CallUser
                        {
                            AccessToken = data["access_token"].ToString(),
                            AccessToken2 = data["access_token_2"].ToString(),
                            Id = data["id"].ToString(),
                            RoomName = data["room_name"].ToString(),
                            Type = "Twilio_audio_call"
                        };
                        return videoData;
                    }

                    return null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        /// ###############################
        /// Agora framework Api 

        public static async Task<string> Send_Agora_Call_Action_Async(string answerType, string callId)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("answer_type", answerType),
                        new KeyValuePair<string, string>("call_id", callId),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiSendAgoraCallAction, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["status"].ToString();
                    return apiStatus;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<string> Check_Agora_Call_Answer_Async(string callId, string callType)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("call_id", callId),
                        new KeyValuePair<string, string>("call_type", callType),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiCheckForAgoraAnswer, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        string callstatus = data["call_status"].ToString();
                        return callstatus;
                    }

                    return "400";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<Classes.CallUser> Create_Agora_Call_Event_Async(string recipientId, string callType)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", UserDetails.UserId),
                        new KeyValuePair<string, string>("recipient_id", recipientId),
                        new KeyValuePair<string, string>("call_type", callType),
                        new KeyValuePair<string, string>("s", UserDetails.AccessToken)
                    });

                    var response = await client.PostAsync(ApiCreateAgoraCallEvent, formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["status"].ToString();
                    if (apiStatus == "200")
                    {
                        Classes.CallUser vidodata = new Classes.CallUser();

                        if (data.ContainsKey("id"))
                            vidodata.Id = data["id"].ToString();
                        if (data.ContainsKey("room_name"))
                            vidodata.RoomName = data["room_name"].ToString();

                        vidodata.Type = callType;

                        return vidodata;
                    }

                    return null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        /// ###############################

        #endregion

        public static async Task<ObservableCollection<GifGiphyClass.Datum>> Search_Gifs_Web(string searchKey)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Application.Context, Application.Context.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    return new ObservableCollection<GifGiphyClass.Datum>();
                }
                else
                {
                    using (var client = new HttpClient())
                    {
                        var response = await client.GetAsync(ApiGetSearchGifs + searchKey);
                        response.EnsureSuccessStatusCode();
                        string json = await response.Content.ReadAsStringAsync();
                        var data = JsonConvert.DeserializeObject<GifGiphyClass>(json);

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            if (data.meta.Status == 200)
                            {
                                return new ObservableCollection<GifGiphyClass.Datum>(data.Data);
                            }
                            else
                            {
                                return new ObservableCollection<GifGiphyClass.Datum>();
                            }
                        }
                        else
                        {
                            return new ObservableCollection<GifGiphyClass.Datum>();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return new ObservableCollection<GifGiphyClass.Datum>();
            }
        }

        public static async Task<GetSiteSettingsObject.Config> GetSettings_Api(Activity context)
        {
            if (Methods.CheckConnectivity())
            {
                await SetLangUserAsync().ConfigureAwait(false);

                (var apiStatus, dynamic respond) = await Current.GetSettings();

                if (apiStatus != 200 || !(respond is GetSiteSettingsObject result) || result.config == null)
                    return Methods.DisplayReportResult(context, respond);

                ListUtils.SettingsSiteList = result.config;

                AppSettings.OneSignalAppId = result.config.AndroidMPushId;
                OneSignalNotification.RegisterNotificationDevice();

                //Products Categories
                var listProducts = result.config.ProductsCategories.Select(cat => new Classes.Categories
                {
                    CategoriesId = cat.Key,
                    CategoriesName = cat.Value,
                    CategoriesColor = "#ffffff"
                }).ToList();

                ListUtils.ListCategoriesProducts.Clear();
                ListUtils.ListCategoriesProducts = new ObservableCollection<Classes.Categories>(listProducts);

                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                dbDatabase.InsertOrUpdateSettings(result.config);
                dbDatabase.Dispose();

                return result.config;

            }
            else
            {
                Toast.MakeText(Application.Context, Application.Context.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                return null;
            }
        }

        private static async Task SetLangUserAsync()
        {
            try
            {
                string lang;
                if (AppSettings.Lang.Contains("en"))
                    lang = "english";
                else if (AppSettings.Lang.Contains("ar"))
                    lang = "arabic";
                else if (AppSettings.Lang.Contains("de"))
                    lang = "german";
                else if (AppSettings.Lang.Contains("el"))
                    lang = "greek";
                else if (AppSettings.Lang.Contains("es"))
                    lang = "spanish";
                else if (AppSettings.Lang.Contains("fr"))
                    lang = "french";
                else if (AppSettings.Lang.Contains("it"))
                    lang = "italian";
                else if (AppSettings.Lang.Contains("ja"))
                    lang = "japanese";
                else if (AppSettings.Lang.Contains("nl"))
                    lang = "dutch";
                else if (AppSettings.Lang.Contains("pt"))
                    lang = "portuguese";
                else if (AppSettings.Lang.Contains("ro"))
                    lang = "romanian";
                else if (AppSettings.Lang.Contains("ru"))
                    lang = "russian";
                else if (AppSettings.Lang.Contains("sq"))
                    lang = "albanian";
                else if (AppSettings.Lang.Contains("sr"))
                    lang = "serbian";
                else if (AppSettings.Lang.Contains("tr"))
                    lang = "turkish";
                else
                    lang = string.IsNullOrEmpty(UserDetails.LangName) ? UserDetails.LangName : "english";

                var dataPrivacy = new Dictionary<string, string>
                {
                    {"language", lang}
                };

                if (Methods.CheckConnectivity())
                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => RequestsAsync.Global.Update_User_Data(dataPrivacy) });
                else
                    Toast.MakeText(Application.Context, Application.Context.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public static async Task Get_MyProfileData_Api(Activity context)
        {
            if (Methods.CheckConnectivity())
            {
                (int apiStatus, var respond) = await RequestsAsync.Global.Get_User_Data(UserDetails.UserId);
                if (apiStatus == 200)
                {
                    if (respond is GetUserDataObject result)
                    {
                        UserDetails.Avatar = result.UserData.Avatar;
                        UserDetails.Cover = result.UserData.Cover;
                        UserDetails.Username = result.UserData.Username;
                        UserDetails.FullName = result.UserData.Name;
                        UserDetails.Email = result.UserData.Email;

                        ListUtils.MyProfileList = new ObservableCollection<UserDataObject>();
                        ListUtils.MyProfileList.Clear();
                        ListUtils.MyProfileList.Add(result.UserData);

                        context.RunOnUiThread(() =>
                        {
                            SqLiteDatabase dbDatabase = new SqLiteDatabase();

                            // user_data
                            if (result.UserData != null)
                            {
                                //Insert Or Update All data user_data
                                dbDatabase.Insert_Or_Update_To_MyProfileTable(result.UserData);

                                if (result.Following.Count > 0)
                                {
                                    //Insert Or Update All data Groups
                                    dbDatabase.Insert_Or_Replace_MyContactTable(new ObservableCollection<UserDataObject>(result.Following));
                                }

                                dbDatabase.Dispose();
                            }
                        });
                    }
                }
            }
        }
        /////////////////////////////////////////////////////////////////
        private static bool RunLogout;

        public static async void Delete(Activity context)
        {
            try
            {
                if (RunLogout == false)
                {
                    RunLogout = true;

                    await RemoveData("Delete");

                    context.RunOnUiThread(() =>
                    {
                        Methods.Path.DeleteAll_MyFolderDisk();

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();

                        Runtime.GetRuntime().RunFinalization();
                        Runtime.GetRuntime().Gc();
                        TrimCache(context);

                        dbDatabase.ClearAll();
                        dbDatabase.DropAll();

                        dbDatabase.CheckTablesStatus();
                        dbDatabase.Dispose();

                        MainSettings.SharedData.Edit().Clear().Commit();

                        Intent intent = new Intent(context, typeof(LoginActivity));
                        intent.AddCategory(Intent.CategoryHome);
                        intent.SetAction(Intent.ActionMain);
                        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                        context.StartActivity(intent);
                        context.FinishAffinity();
                        context.Finish();
                    });

                    RunLogout = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static async void Logout(Activity context)
        {
            try
            {
                if (RunLogout == false)
                {
                    RunLogout = true;

                    await RemoveData("Logout");

                    context.RunOnUiThread(() =>
                    {
                        Methods.Path.DeleteAll_MyFolderDisk();

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();

                        Runtime.GetRuntime().RunFinalization();
                        Runtime.GetRuntime().Gc();
                        TrimCache(context);

                        dbDatabase.ClearAll();
                        dbDatabase.DropAll();

                        dbDatabase.CheckTablesStatus();
                        dbDatabase.Dispose();

                        var intentService = new Intent(context, typeof(ScheduledApiService));
                        context.StopService(intentService);

                        MainSettings.SharedData.Edit().Clear().Commit();

                        Intent intent = new Intent(context, typeof(LoginActivity));
                        intent.AddCategory(Intent.CategoryHome);
                        intent.SetAction(Intent.ActionMain);
                        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                        context.StartActivity(intent);
                        context.FinishAffinity();
                        context.Finish();
                    });

                    RunLogout = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static void TrimCache(Activity context)
        {
            try
            {
                File dir = context.CacheDir;
                if (dir != null && dir.IsDirectory)
                {
                    DeleteDir(dir);
                }

                context.DeleteDatabase("WoWonderMessenger.db");
                context.DeleteDatabase(SqLiteDatabase.PathCombine);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static bool DeleteDir(File dir)
        {
            try
            {
                if (dir == null || !dir.IsDirectory) return dir != null && dir.Delete();
                string[] children = dir.List();
                foreach (string child in children)
                {
                    bool success = DeleteDir(new File(dir, child));
                    if (!success)
                    {
                        return false;
                    }
                }

                // The directory is now empty so delete it
                return dir.Delete();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        private static async Task RemoveData(string type)
        {
            try
            {
                if (type == "Logout")
                {
                    if (Methods.CheckConnectivity())
                    {
                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { RequestsAsync.Global.Get_Delete_Token });
                    }
                }
                else if (type == "Delete")
                {
                    Methods.Path.DeleteAll_MyFolder();

                    if (Methods.CheckConnectivity())
                    {
                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => RequestsAsync.Global.Delete_User(UserDetails.Password) });
                    }
                }

                try
                {
                    if (AppSettings.ShowGoogleLogin && LoginActivity.MGoogleApiClient != null)
                        if (Auth.GoogleSignInApi != null)
                        {
                            Auth.GoogleSignInApi.SignOut(LoginActivity.MGoogleApiClient);
                            LoginActivity.MGoogleApiClient = null;
                        }

                    if (AppSettings.ShowFacebookLogin)
                    {
                        var accessToken = AccessToken.CurrentAccessToken;
                        var isLoggedIn = accessToken != null && !accessToken.IsExpired;
                        if (isLoggedIn && Profile.CurrentProfile != null)
                        {
                            LoginManager.Instance.LogOut();
                        }
                    }

                    OneSignalNotification.Un_RegisterNotificationDevice();

                    ListUtils.ClearAllList();

                    UserDetails.ClearAllValueUserDetails();

                    GC.Collect();
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}