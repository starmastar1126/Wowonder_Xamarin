﻿using System;
using AutoMapper;
using AutoMapper.Configuration;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;

namespace WoWonder.Helpers.Utils
{
    public static class ClassMapper
    {
        public static void SetMappers()
        {
            try
            {
                var cfg = new MapperConfigurationExpression
                {
                    AllowNullCollections = true
                };

                cfg.CreateMap<UserDataObject, DataTables.MyContactsTb>().ForMember(x => x.AutoIdMyFollowing, opt => opt.Ignore());
                cfg.CreateMap<UserDataObject, DataTables.MyFollowersTb>().ForMember(x => x.AutoIdMyFollowers, opt => opt.Ignore());
                cfg.CreateMap<UserDataObject, DataTables.MyProfileTb>().ForMember(x => x.AutoIdMyProfile, opt => opt.Ignore());

                Mapper.Initialize(cfg);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}