using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Newtonsoft.Json;
using WoWonder.Activities.DefaultUser;
using WoWonder.Helpers.Model;
using WoWonderClient.Classes.Global;
using MessageData = WoWonder.Helpers.Model.MessageData;

namespace WoWonder.Helpers.Utils
{
    public static class WoWonderTools
    {
        public static string GetNameFinal(UserDataObject dataUser)
        {
            try
            {
                if (!string.IsNullOrEmpty(dataUser.Name) && !string.IsNullOrWhiteSpace(dataUser.Name))
                    return dataUser.Name;

                string name = dataUser.Username;
                return Methods.FunString.DecodeString(name);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return dataUser?.Username;
            }
        }

        public static string GetAboutFinal(UserDataObject dataUser)
        {
            try
            {
                if (!string.IsNullOrEmpty(dataUser.About) && !string.IsNullOrWhiteSpace(dataUser.About))
                    return Methods.FunString.DecodeString(dataUser.About);

                return Application.Context.Resources.GetString(Resource.String.Lbl_DefaultAbout) + " " + AppSettings.ApplicationName;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Methods.FunString.DecodeString(dataUser.About);
            }
        }

        public static void OpenProfile(Activity activity, string userId, UserDataObject item = null)
        {
            try
            {
                if (userId != UserDetails.UserId)
                {
                    var Int = new Intent(activity, typeof(UserProfileActivity));
                    if (item != null) Int.PutExtra("UserObject", JsonConvert.SerializeObject(item));
                    Int.PutExtra("UserId", userId);
                    activity.StartActivity(Int);
                }
                else
                {
                    var intent = new Intent(activity, typeof(MyProfileActivity));
                    activity.StartActivity(intent);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static (string, string) GetCurrency(string idCurrency)
        {
            try
            {
                string currencyIcon, currency;
                bool success = int.TryParse(idCurrency, out var number);
                if (success)
                {
                    Console.WriteLine("Converted '{0}' to {1}.", idCurrency, number);
                    currency = ListUtils.SettingsSiteList.CurrencyArray.CurrencyList[number] ?? "";
                }
                else
                {
                    Console.WriteLine("Attempted conversion of '{0}' failed.", idCurrency ?? "<null>");
                    currency = idCurrency;
                }

                if (ListUtils.SettingsSiteList.CurrencySymbolArray != null)
                {
                    switch (currency)
                    {
                        case "USD":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Usd;
                            break;
                        case "EUR":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Eur;
                            break;
                        case "TRY":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Try;
                            break;
                        case "GBP":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Gbp;
                            break;
                        case "RUB":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Rub;
                            break;
                        case "PLN":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Pln;
                            break;
                        case "ILS":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Ils;
                            break;
                        case "BRL":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Brl;
                            break;
                        case "INR":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Inr;
                            break;
                        default:
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Usd;
                            break;
                    }
                }
                else
                {
                    return ("", "");
                }

                return (currency, currencyIcon);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return ("", "");
            }
        }

        public static MessageData MessageFilter(string userid, MessageData item)
        {
            try
            {
                if (item.Stickers == null)
                    item.Stickers = "";

                if (item.Text == null)
                    item.Text = "";

                item.Stickers = item.Stickers.Replace(".mp4", ".gif"); 

                item.Text = Methods.FunString.DecodeString(item.Text);

                if (item.Product != null && (item.Type == "right_product" || item.Type == "left_product"))
                {
                    string imageUrl = item.Product?.Images[0]?.Image ?? "";
                    var fileName = imageUrl.Split('/').Last();
                    item.Media = GetFile(userid, Methods.Path.FolderDcimImage, fileName, imageUrl);
                }
                else if (!string.IsNullOrEmpty(item.Stickers) && (item.Type == "right_gif" || item.Type == "left_gif" || (item.Text == "" && (item.Type == "right_text" || item.Type == "left_text") && item.Stickers.Contains(".gif"))))
                { 
                    string imageUrl = "";
                    if (!string.IsNullOrEmpty(item.MediaFileName))
                        imageUrl = item.MediaFileName;
                    else if (!string.IsNullOrEmpty(item.Media))
                        imageUrl = item.Media;
                    else if (!string.IsNullOrEmpty(item.Stickers))
                        imageUrl = item.Stickers;
                     
                    var fileName = imageUrl.Split('/').Last();
                    item.Media = GetFile(userid, Methods.Path.FolderDcimGif, fileName, imageUrl);
                }
                else if (item.Type == "right_text" || item.Type == "left_text")
                {
                    return item;
                }
                else if (item.Type == "right_image" || item.Type == "left_image")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(userid, Methods.Path.FolderDcimImage, fileName, item.Media);
                }
                else if (item.Type == "right_Audio" || item.Type == "left_Audio" || item.Type == "right_audio" || item.Type == "left_audio")
                { 
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile( userid, Methods.Path.FolderDcimSound, fileName, item.Media);

                    if (string.IsNullOrEmpty(item.MediaDuration))
                        item.MediaDuration = Methods.AudioRecorderAndPlayer.GetTimeString(Methods.AudioRecorderAndPlayer.Get_MediaFileDuration(item.Media));
                }
                else if (item.Type == "right_contact" || item.Type == "left_contact")
                {
                    if (item.Text.Contains("{&quot;Key&quot;") || item.Text.Contains("{key:") || item.Text.Contains("{key:^qu") ||item.Text.Contains("{^key:^qu") || item.Text.Contains("{Key:") || item.Text.Contains("&quot;"))
                    {
                        string[] stringSeparators = { "," };
                        var name = item.Text.Split(stringSeparators, StringSplitOptions.None);
                        var stringName = name[0].Replace("{key:", "").Replace("{Key:", "").Replace("Value:", "");
                        var stringNumber = name[1].Replace("{key:", "").Replace("{Key:", "").Replace("Value:", "");
                        item.ContactName = stringName;
                        item.ContactNumber = stringNumber;
                    } 
                }
                else if (item.Type == "right_video" || item.Type == "left_video")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(userid, Methods.Path.FolderDcimVideo, fileName, item.Media);
                    var fileNameWithoutExtension = fileName.Split('.').First();
                    item.ImageVideo = Methods.Path.FolderDcimVideo + userid + "/" + fileNameWithoutExtension + ".png";
                }
                else if (item.Type == "right_sticker" || item.Type == "left_sticker")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(userid, Methods.Path.FolderDcimSticker, fileName, item.Media);
                }
                else if (item.Type == "right_file" || item.Type == "left_file")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(userid, Methods.Path.FolderDcimFile, fileName, item.Media);
                }

                return item; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return item;
            }
        }
         
        // Functions Save Images
        private static void SaveFile(string userid, string folder, string fileName, string url)
        {
            try
            {
                if (url.Contains("http"))
                {
                    string folderDestination = folder + userid + "/";

                    if (!Directory.Exists(folderDestination))
                        Directory.CreateDirectory(folderDestination);

                    string filename = url.Split('/').Last();
                    string filePath = Path.Combine(folderDestination);
                    string mediaFile = filePath + "/" + filename;

                    var fileNameWithoutExtension = fileName.Split('.').First();

                    if (!File.Exists(mediaFile))
                    {
                        if (!File.Exists(mediaFile))
                        {
                            WebClient webClient = new WebClient();

                            webClient.DownloadDataAsync(new Uri(url));
                            webClient.DownloadDataCompleted += (s, e) =>
                            {
                                try
                                {
                                    File.WriteAllBytes(mediaFile, e.Result);
                                }
                                catch (Exception exception)
                                {
                                    Console.WriteLine(exception);
                                }

                                if (Methods.AttachmentFiles.Check_FileExtension(url) != "Video") return;
                                var bitmapImage = Methods.MultiMedia.Retrieve_VideoFrame_AsBitmap(mediaFile);
                                Methods.MultiMedia.Export_Bitmap_As_Image(bitmapImage, fileNameWithoutExtension, folderDestination);
                            };
                        }
                    } 
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            }
        }

        // Functions file from folder
        public static string GetFile(string userid, string folder, string filename, string url)
        {
            try
            { 
                string folderDestination = folder + userid + "/"; 

                if (!Directory.Exists(folderDestination))
                    Directory.CreateDirectory(folderDestination);

                string imageFile = Methods.MultiMedia.GetMediaFrom_Gallery(folderDestination, filename);
                if (imageFile == "File Dont Exists")
                {
                    //This code runs on a new thread, control is returned to the caller on the UI thread.
                    Task.Run(() => { SaveFile( userid, folder, filename, url); });
                    return url;
                }
                else
                {
                    return imageFile;
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return url;
            }
        }
           
        public static WoWonderClient.Classes.Message.MessageData MessageFilter(string groupId,WoWonderClient.Classes.Message.MessageData item)
        {
            try
            {
                if (item.Stickers == null)
                    item.Stickers = "";

                item.Stickers = item.Stickers.Replace(".mp4", ".gif");

                if (item.Text == null)
                    item.Text = "";

                item.Text = Methods.FunString.DecodeString(item.Text);
                
                if (!string.IsNullOrEmpty(item.Stickers) && (item.Type == "right_gif" || item.Type == "left_gif" || (item.Text == "" && (item.Type == "right_text" || item.Type == "left_text") && item.Stickers.Contains(".gif"))))
                {
                    string imageUrl = "";
                    if (!string.IsNullOrEmpty(item.MediaFileName))
                        imageUrl = item.MediaFileName;
                    else if (!string.IsNullOrEmpty(item.Media))
                        imageUrl = item.Media;
                    else if (!string.IsNullOrEmpty(item.Stickers))
                        imageUrl = item.Stickers;

                    var fileName = imageUrl.Split('/').Last();
                    item.Media = GetFile(groupId, Methods.Path.FolderDcimGif, fileName, imageUrl);
                }
                else if (item.Type == "right_text" || item.Type == "left_text")
                {
                    return item;
                }
                else if (item.Type == "right_image" || item.Type == "left_image")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(groupId, Methods.Path.FolderDcimImage, fileName, item.Media);
                }
                else if (item.Type == "right_Audio" || item.Type == "left_Audio" || item.Type == "right_audio" || item.Type == "left_audio")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(groupId, Methods.Path.FolderDcimSound, fileName, item.Media);

                    if (string.IsNullOrEmpty(item.MediaDuration))
                        item.MediaDuration = Methods.AudioRecorderAndPlayer.GetTimeString(Methods.AudioRecorderAndPlayer.Get_MediaFileDuration(item.Media));
                }
                else if (item.Type == "right_contact" || item.Type == "left_contact")
                {
                    if (item.Text.Contains("{&quot;Key&quot;") || item.Text.Contains("{key:") || item.Text.Contains("{key:^qu") || item.Text.Contains("{^key:^qu") || item.Text.Contains("{Key:") || item.Text.Contains("&quot;"))
                    {
                        string[] stringSeparators = { "," };
                        var name = item.Text.Split(stringSeparators, StringSplitOptions.None);
                        var stringName = name[0].Replace("{key:", "").Replace("{Key:", "").Replace("Value:", "");
                        var stringNumber = name[1].Replace("{key:", "").Replace("{Key:", "").Replace("Value:", "");
                        item.ContactName = stringName;
                        item.ContactNumber = stringNumber;
                    }
                }
                else if (item.Type == "right_video" || item.Type == "left_video")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(groupId, Methods.Path.FolderDcimVideo, fileName, item.Media);
                    var fileNameWithoutExtension = fileName.Split('.').First();
                    item.ImageVideo = Methods.Path.FolderDcimVideo + groupId + "/" + fileNameWithoutExtension + ".png";
                }
                else if (item.Type == "right_sticker" || item.Type == "left_sticker")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(groupId, Methods.Path.FolderDcimSticker, fileName, item.Media);
                }
                else if (item.Type == "right_file" || item.Type == "left_file")
                {
                    var fileName = item.Media.Split('/').Last();
                    item.Media = GetFile(groupId, Methods.Path.FolderDcimFile, fileName, item.Media);
                }

                return item;

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return item;
            }
        }
         
        //Get Shared Files Profile user in Right Side "images, Media, file"
        public static async Task GetSharedFiles(string userId)
        {
            try
            {
                await Task.Run(() =>
                { 
                    var imagePath = Methods.Path.FolderDcimImage + userId;
                    var stickerPath = Methods.Path.FolderDcimSticker + userId;
                    var gifPath = Methods.Path.FolderDcimGif + userId;
                    var soundsPath = Methods.Path.FolderDcimSound + userId;
                    var videoPath = Methods.Path.FolderDcimVideo + userId;
                    var otherPath = Methods.Path.FolderDcimFile + userId;

                    //Check for folder if exists
                    if (Directory.Exists(imagePath) == false)
                        Directory.CreateDirectory(imagePath);

                    if (Directory.Exists(stickerPath) == false)
                        Directory.CreateDirectory(stickerPath);
                    
                    if (Directory.Exists(gifPath) == false)
                        Directory.CreateDirectory(gifPath);

                    if (Directory.Exists(soundsPath) == false)
                        Directory.CreateDirectory(soundsPath);

                    if (Directory.Exists(videoPath) == false)
                        Directory.CreateDirectory(videoPath);

                    if (Directory.Exists(otherPath) == false)
                        Directory.CreateDirectory(otherPath);

                    var imageFiles = new DirectoryInfo(imagePath ).GetFiles().OrderByDescending(f => f.LastWriteTime).ToList();
                    var stickerFiles = new DirectoryInfo(stickerPath ).GetFiles().OrderByDescending(f => f.LastWriteTime).ToList();
                    var gifFiles = new DirectoryInfo(gifPath ).GetFiles().OrderByDescending(f => f.LastWriteTime).ToList();
                    var soundsFiles = new DirectoryInfo(soundsPath ).GetFiles().OrderByDescending(f => f.LastWriteTime).ToList();
                    var videoFiles = new DirectoryInfo(videoPath ).GetFiles().OrderByDescending(f => f.LastWriteTime).ToList();
                    var otherFiles = new DirectoryInfo(otherPath ).GetFiles().OrderByDescending(f => f.LastWriteTime).ToList();
                       
                    if (imageFiles.Count> 0)
                    {
                        foreach (var file in imageFiles.Select(dir => new Classes.SharedFile
                        {
                            FileType = "Image",
                            FileName = dir.Name,
                            FileDate = dir.LastWriteTime.Millisecond.ToString(),
                            FilePath = dir.FullName,
                            ImageExtra = dir.FullName,
                            FileExtension = dir.Extension,
                        }))
                        {
                            ListUtils.ListSharedFiles.Add(file);
                        }
                    }
                      
                    if (stickerFiles.Count> 0)
                    {
                        foreach (var file in stickerFiles.Select(dir => new Classes.SharedFile
                        {
                            FileType = "Sticker",
                            FileName = dir.Name,
                            FileDate = dir.LastWriteTime.Millisecond.ToString(),
                            FilePath = dir.FullName,
                            ImageExtra = dir.FullName,
                            FileExtension = dir.Extension,
                        }))
                        {
                            ListUtils.ListSharedFiles.Add(file);
                        }
                    }
                    
                    if (gifFiles.Count> 0)
                    {
                        foreach (var file in gifFiles.Select(dir => new Classes.SharedFile
                        {
                            FileType = "Gif",
                            FileName = dir.Name,
                            FileDate = dir.LastWriteTime.Millisecond.ToString(),
                            FilePath = dir.FullName,
                            ImageExtra = dir.FullName,
                            FileExtension = dir.Extension,
                        }))
                        {
                            ListUtils.ListSharedFiles.Add(file);
                        }
                    }

                    if (soundsFiles.Count > 0)
                    {
                        foreach (var file in soundsFiles.Select(dir => new Classes.SharedFile
                        {
                            FileType = "Sounds",
                            FileName = dir.Name,
                            FilePath = dir.FullName,
                            FileExtension = dir.Extension,
                            ImageExtra = "Audio_File",
                            FileDate = dir.LastWriteTime.Millisecond.ToString(),
                        }))
                        {
                            ListUtils.ListSharedFiles.Add(file);
                        }
                    }

                    if (videoFiles.Count > 0)
                    {
                        foreach (var file in videoFiles.Select(dir => new Classes.SharedFile
                        {
                            FileType = "Video",
                            FileName = dir.Name,
                            FilePath = dir.FullName,
                            FileExtension = dir.Extension,
                            ImageExtra = dir.FullName,
                            FileDate = dir.LastWriteTime.Millisecond.ToString(),
                        }))
                        {
                            ListUtils.ListSharedFiles.Add(file);
                        }
                    }

                    if (otherFiles.Count > 0)
                    {
                        foreach (var file in otherFiles.Select(dir => new Classes.SharedFile
                        {
                            FileType = "File",
                            FileName = dir.Name,
                            FilePath = dir.FullName,
                            FileExtension = dir.Extension,
                            ImageExtra = "Image_File",
                            FileDate = dir.LastWriteTime.Millisecond.ToString(),
                        }))
                        {
                            ListUtils.ListSharedFiles.Add(file);
                        }
                    }
                     
                    if (ListUtils.ListSharedFiles.Count > 0)
                    {
                        var orderByDateList = ListUtils.ListSharedFiles.OrderBy(T => T.FileDate).ToList();
                         
                        //Last 50 File
                        var lastSharedFiles = orderByDateList.Select(dir => new Classes.SharedFile
                        {
                            FileType = dir.FileType,
                            FileName = dir.FileName,
                            FileDate = dir.FileDate,
                            FilePath = dir.FilePath,
                            ImageExtra = dir.ImageExtra,
                            FileExtension = dir.FileExtension,
                        }).Take(50).ToList();

                        ListUtils.LastSharedFiles = new ObservableCollection<Classes.SharedFile>(lastSharedFiles);
                    }
                    
                    Console.WriteLine(ListUtils.ListSharedFiles);

                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }
}