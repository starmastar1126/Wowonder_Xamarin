﻿using System;
using Android.App;
using Android.Graphics;
using Android.Support.V4.View.Animation;
using Android.Widget;
using WoWonder.Activities.ChatWindow;
using WoWonder.Activities.ChatWindow.Adapters;
using WoWonder.Activities.GroupChat;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;

namespace WoWonder.Activities.StickersFragments
{
    public class StickerItemClickListener
    {
        private readonly StickerRecylerAdapter.StickerAdapter StickerAdapter;
        private readonly string Type;
        private readonly ChatWindowActivity ChatWindow;
        private readonly GroupChatWindowActivity MainActivityView;
        private readonly string TimeNow = DateTime.Now.ToString("hh:mm");

        public StickerItemClickListener(Activity activity, string type, StickerRecylerAdapter.StickerAdapter stickerAdapter)
        {
            try
            {
                Type = type;
                StickerAdapter = stickerAdapter;

                StickerAdapter.OnItemClick += StickerAdapterOnOnItemClick;

                // Create your fragment here
                if (Type != "GroupChatWindowActivity")
                {
                    ChatWindow = (ChatWindowActivity)activity;
                }
                else
                {
                    MainActivityView = (GroupChatWindowActivity)activity;
                }  
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void StickerAdapterOnOnItemClick(object sender, StickerRecylerAdapter.AdapterClickEvents adapterClickEvents)
        {
            try
            {
                var stickerUrl = StickerAdapter.GetItem(adapterClickEvents.Position);
                var unixTimestamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;

                if (Type == "ChatWindowActivity")
                {
                    MessageData m1 = new MessageData
                    {
                        Id = unixTimestamp.ToString(),
                        FromId = UserDetails.UserId,
                        ToId = ChatWindow.Userid,
                        Media = stickerUrl,
                        TimeText = TimeNow,
                        Position = "right",
                        Type = "right_sticker"
                    };

                    ChatWindow.MAdapter.MessageList.Add(m1);
                    var indexMes = ChatWindow.MAdapter.MessageList.IndexOf(m1);
                    if (indexMes > -1)
                    {
                        ChatWindow.MAdapter.NotifyItemInserted(indexMes);
                        //Scroll Down >> 
                        ChatWindow.MRecycler.ScrollToPosition(indexMes);
                    }

                    if (Methods.CheckConnectivity())
                    {
                        //Sticker Send Function
                        MessageController.SendMessageTask(ChatWindow, ChatWindow.Userid, unixTimestamp.ToString(), "", "", "", stickerUrl, "sticker" + adapterClickEvents.Position).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ChatWindow, ChatWindow.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    }

                    try
                    {
                        var interplator = new FastOutSlowInInterpolator();
                        ChatWindow.ChatStickerButton.Tag = "Closed";

                        ChatWindow.ResetButtonTags();
                        ChatWindow.ChatStickerButton.Drawable.SetTint(Color.ParseColor("#888888"));
                        ChatWindow.TopFragmentHolder.Animate().SetInterpolator(interplator).TranslationY(1200).SetDuration(300);
                        ChatWindow.SupportFragmentManager.BeginTransaction().Remove(ChatWindow.ChatStickersTabBoxFragment).Commit();
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    }
                }
                else if (Type == "GroupChatWindowActivity")
                {
                    MessageData m1 = new MessageData
                    {
                        Id = unixTimestamp.ToString(),
                        FromId = UserDetails.UserId,
                        GroupId = MainActivityView.GroupId,
                        Media = stickerUrl,
                        TimeText = TimeNow,
                        Position = "right",
                        Type = "right_sticker"
                    };

                    MainActivityView.MAdapter.Add(m1);

                    if (Methods.CheckConnectivity())
                    {
                        //Sticker Send Function
                        GroupMessageController.SendMessageTask(MainActivityView, MainActivityView.GroupId, unixTimestamp.ToString(), "", "", "", stickerUrl, "sticker" + adapterClickEvents.Position).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(MainActivityView, MainActivityView.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    }

                    try
                    {
                        var interplator = new FastOutSlowInInterpolator();
                        MainActivityView.ChatStickerButton.Tag = "Closed";

                        MainActivityView.ResetButtonTags();
                        MainActivityView.ChatStickerButton.Drawable.SetTint(Color.ParseColor("#888888"));
                        MainActivityView.TopFragmentHolder.Animate().SetInterpolator(interplator).TranslationY(1200).SetDuration(300);
                        MainActivityView.SupportFragmentManager.BeginTransaction().Remove(MainActivityView.ChatStickersTabBoxFragment).Commit();
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

    }
}