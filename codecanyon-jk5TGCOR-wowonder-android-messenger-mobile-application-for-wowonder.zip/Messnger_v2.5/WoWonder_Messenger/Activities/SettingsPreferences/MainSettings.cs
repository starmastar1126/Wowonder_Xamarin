using System;
using Android.App;
using Android.Content;
using Android.Preferences;

namespace WoWonder.Activities.SettingsPreferences
{
    public static class MainSettings
    {
        public static ISharedPreferences SharedData;

        public static void Init()
        {
            try
            { 
                SharedData = PreferenceManager.GetDefaultSharedPreferences(Application.Context);

                bool getValue = SharedData.GetBoolean("Night_Mode_key", AppSettings.SetTabDarkTheme);
                if (getValue)
                {
                    AppSettings.SetTabDarkTheme = true;
                }
                else
                {
                    AppSettings.SetTabDarkTheme = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}