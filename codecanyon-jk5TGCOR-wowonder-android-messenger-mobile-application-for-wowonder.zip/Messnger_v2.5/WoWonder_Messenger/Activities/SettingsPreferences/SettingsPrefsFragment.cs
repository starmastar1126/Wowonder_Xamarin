using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Preferences;
using Android.Views;
using Android.Widget;
using WoWonder.Activities.DefaultUser;
using WoWonder.Activities.SettingsPreferences.General;
using WoWonder.Activities.SettingsPreferences.InviteFriends;
using WoWonder.Activities.Tab;
using WoWonder.Frameworks.onesignal;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient;
using static WoWonderClient.Requests.RequestsAsync;
 
namespace WoWonder.Activities.SettingsPreferences
{
    public class SettingsPrefsFragment : PreferenceFragment, ISharedPreferencesOnSharedPreferenceChangeListener, MaterialDialog.ISingleButtonCallback
    {
        private Preference EditProfile;
        private Preference BlockedUsers;
        private Preference AccountPref;
        private Preference PasswordPref;
        private Preference GeneralInvitePref;
        private Preference GeneralCallPref;
        private Preference SupportHelpPref;
        private Preference SupportLogoutPref;
        private Preference SupportDeleteAccountPref;
        private Preference SupportReportPref;
        private EditTextPreference AboutMePref;
        //private ListPreference LangPref;
        private ListPreference PrivacyFollowPref;
        private ListPreference PrivacyBirthdayPref;
        private ListPreference PrivacyMessagePref;
        private SwitchPreference NotifcationPopupPref;
        private SwitchPreference ShowOnlineUsersPref;
        private CheckBoxPreference NotifcationPlaySoundPref;
        public SwitchPreference NightMode;

        private readonly Activity ActivityContext;
        private string SAbout = "",SWhoCanFollowMe = "0", SWhoCanMessageMe = "0", SWhoCanSeeMyBirthday = "0", TypeDialog = "";
        public static bool SSoundControl = true; 
        
        public SettingsPrefsFragment(Activity activity)
        {
            try
            {
                ActivityContext = activity;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                AddPreferencesFromResource(Resource.Xml.SettingsPrefs);

                MainSettings.SharedData = PreferenceManager.SharedPreferences;

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                PreferenceCategory mCategory = (PreferenceCategory)FindPreference("category_General");

                EditProfile = FindPreference("editprofile_key");
                BlockedUsers = FindPreference("blocked_key");
                AccountPref = FindPreference("editAccount_key");
                PasswordPref = FindPreference("editpassword_key");
                GeneralInvitePref = FindPreference("invite_key");
                GeneralCallPref = FindPreference("Call_key");

                NightMode = (SwitchPreference)FindPreference("Night_Mode_key");
                NightMode.Checked = MainSettings.SharedData.GetBoolean("Night_Mode_key", AppSettings.SetTabDarkTheme);

                if (!AppSettings.EnableAudioVideoCall)
                        mCategory.RemovePreference(GeneralCallPref);
                 
                if (!AppSettings.InvitationSystem)     
                        mCategory.RemovePreference(GeneralInvitePref);
                 
                SupportReportPref = FindPreference("Report_key");
                SupportHelpPref = FindPreference("help_key");
                SupportLogoutPref = FindPreference("logout_key");
                SupportDeleteAccountPref = FindPreference("deleteaccount_key");

                //LangPref = (ListPreference) FindPreference("Lang_key");
                AboutMePref = (EditTextPreference) FindPreference("about_me_key");

                //Privacy
                PrivacyFollowPref = (ListPreference) FindPreference("whocanfollow_key");
                PrivacyMessagePref = (ListPreference) FindPreference("whocanMessage_key");
                PrivacyBirthdayPref = (ListPreference) FindPreference("whocanseemybirthday_key");

                NotifcationPopupPref = (SwitchPreference) FindPreference("notifications_key");
                ShowOnlineUsersPref = (SwitchPreference) FindPreference("onlineuser_key");
                NotifcationPlaySoundPref = (CheckBoxPreference) FindPreference("checkBox_PlaySound_key");

                //Add Click event to Preferences
                EditProfile.Intent = new Intent(ActivityContext, typeof(MyProfileActivity));
                BlockedUsers.Intent = new Intent(ActivityContext, typeof(BlockedUsersActivity));
                AccountPref.Intent = new Intent(ActivityContext, typeof(MyAccountActivity));
                PasswordPref.Intent = new Intent(ActivityContext, typeof(PasswordActivity));
                GeneralInvitePref.Intent = new Intent(ActivityContext, typeof(InviteFriendsActivity));

                //Update Preferences data on Load
                OnSharedPreferenceChanged(MainSettings.SharedData, "about_me_key");
                OnSharedPreferenceChanged(MainSettings.SharedData, "whocanfollow_key");
                OnSharedPreferenceChanged(MainSettings.SharedData, "whocanMessage_key");
                OnSharedPreferenceChanged(MainSettings.SharedData, "whocanseemybirthday_key");
                OnSharedPreferenceChanged(MainSettings.SharedData, "notifications_key");
                OnSharedPreferenceChanged(MainSettings.SharedData, "onlineuser_key");
                OnSharedPreferenceChanged(MainSettings.SharedData, "checkBox_PlaySound_key");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnResume()
        {
            try
            {
                base.OnResume();

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                if (AppSettings.EnableAudioVideoCall)
                {
                    GeneralCallPref.PreferenceClick += GeneralCallPrefOnPreferenceClick;
                }

                //Support
                SupportReportPref.PreferenceClick += SupportReportPrefOnPreferenceClick;
                SupportHelpPref.PreferenceClick += SupportHelpPrefOnPreferenceClick;
                //Add OnChange event to Preferences
                AboutMePref.PreferenceChange += About_Me_Pref_PreferenceChange;
                //LangPref.PreferenceChange += Lang_Pref_PreferenceChange;
                PrivacyFollowPref.PreferenceChange += Privacy_Follow_Pref_PreferenceChange;
                PrivacyMessagePref.PreferenceChange += Privacy_Message_Pref_PreferenceChange;
                PrivacyBirthdayPref.PreferenceChange += Privacy_Birthday_Pref_PreferenceChange;
                NotifcationPopupPref.PreferenceChange += Notifcation_Popup_Pref_PreferenceChange;
                ShowOnlineUsersPref.PreferenceChange += ShowOnlineUsers_Pref_PreferenceChange; 
                NotifcationPlaySoundPref.PreferenceChange += Notifcation_PlaySound_Pref_PreferenceChange;
                //Event Click Items
                SupportLogoutPref.PreferenceClick += SupportLogout_OnPreferenceClick;
                SupportDeleteAccountPref.PreferenceClick += SupportDeleteAccountPrefOnPreferenceClick;
                NightMode.PreferenceChange += NightModeOnPreferenceChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnPause()
        {
            try
            {
                base.OnPause();
                PreferenceScreen.SharedPreferences.UnregisterOnSharedPreferenceChangeListener(this);

                if (AppSettings.EnableAudioVideoCall)
                {
                    GeneralCallPref.PreferenceClick -= GeneralCallPrefOnPreferenceClick;
                }

                //Support
                SupportReportPref.PreferenceClick -= SupportReportPrefOnPreferenceClick;
                SupportHelpPref.PreferenceClick -= SupportHelpPrefOnPreferenceClick;
                //Add OnChange event to Preferences
                AboutMePref.PreferenceChange -= About_Me_Pref_PreferenceChange;
                //LangPref.PreferenceChange -= Lang_Pref_PreferenceChange;
                PrivacyFollowPref.PreferenceChange -= Privacy_Follow_Pref_PreferenceChange;
                PrivacyMessagePref.PreferenceChange -= Privacy_Message_Pref_PreferenceChange;
                PrivacyBirthdayPref.PreferenceChange -= Privacy_Birthday_Pref_PreferenceChange;
                NotifcationPopupPref.PreferenceChange -= Notifcation_Popup_Pref_PreferenceChange;
                ShowOnlineUsersPref.PreferenceChange -= ShowOnlineUsers_Pref_PreferenceChange;
                NotifcationPlaySoundPref.PreferenceChange -= Notifcation_PlaySound_Pref_PreferenceChange;
                //Event Click Items
                SupportLogoutPref.PreferenceClick -= SupportLogout_OnPreferenceClick;
                SupportDeleteAccountPref.PreferenceClick -= SupportDeleteAccountPrefOnPreferenceClick;
                NightMode.PreferenceChange -= NightModeOnPreferenceChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void NightModeOnPreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            try
            {
                if (e.Handled)
                {
                    SwitchPreference etp = (SwitchPreference)sender;
                    var value = e.NewValue.ToString();
                    etp.Checked = Boolean.Parse(value);
                    if (etp.Checked)
                    {
                        //Set Dark Mode

                        AppSettings.SetTabDarkTheme = true;

                        MainSettings.SharedData.Edit().PutBoolean("Night_Mode_key", true).Commit();
                    }
                    else
                    {
                        //Set Light Mode

                        AppSettings.SetTabDarkTheme = false;

                        MainSettings.SharedData.Edit().PutBoolean("Night_Mode_key", false).Commit();
                    }

                    if (Build.VERSION.SdkInt >= BuildVersionCodes.Lollipop)
                    {
                        ActivityContext.Window.ClearFlags(WindowManagerFlags.TranslucentStatus);
                        ActivityContext.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
                    }

                    Intent intent = new Intent(ActivityContext, typeof(SplashScreenActivity));
                    intent.AddCategory(Intent.CategoryHome);
                    intent.SetAction(Intent.ActionMain);
                    intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                    ActivityContext.StartActivity(intent);
                    ActivityContext.FinishAffinity();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void OnSharedPreferenceChanged(ISharedPreferences sharedPreferences, string key)
        {
            try
            {
                var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (key.Equals("about_me_key"))
                {
                    // Set summary to be the user-description for the selected value
                    EditTextPreference etp = (EditTextPreference)FindPreference("about_me_key");

                    if (datauser != null)
                    {
                        SAbout = WoWonderTools.GetAboutFinal(datauser);

                        MainSettings.SharedData.Edit().PutString("about_me_key", SAbout).Commit();

                        etp.Text = SAbout;
                    }

                    string getvalue = MainSettings.SharedData.GetString("about_me_key", SAbout);
                    etp.Text = getvalue;
                    etp.Summary = getvalue;

                }
                else if (key.Equals("whocanfollow_key"))
                {
                    var valueAsText = PrivacyFollowPref.Entry;
                    if (string.IsNullOrEmpty(valueAsText))
                    {
                        if (datauser != null)
                        {
                            MainSettings.SharedData.Edit().PutString("whocanfollow_key", datauser.FollowPrivacy)
                                .Commit();
                            PrivacyFollowPref.SetValueIndex(int.Parse(datauser.FollowPrivacy));

                            SWhoCanFollowMe = datauser.FollowPrivacy;
                            if (SWhoCanFollowMe == "0")
                            {
                                PrivacyFollowPref.Summary = ActivityContext.GetText(Resource.String.Lbl_Everyone);
                            }
                            else if (SWhoCanFollowMe == "1")
                            {
                                PrivacyFollowPref.Summary = ActivityContext.GetText(Resource.String.Lbl_People_i_Follow);
                            }
                            else
                            {
                                PrivacyFollowPref.Summary = ActivityContext.GetText(Resource.String.Lbl_No_body);
                            }
                        }
                    }
                    else
                    {
                        PrivacyFollowPref.Summary = valueAsText;
                        SWhoCanFollowMe = PrivacyFollowPref.Value;
                        //Privacy_Follow_Pref.SetValueIndex(0);
                    }
                }
                else if (key.Equals("whocanMessage_key"))
                {
                    var valueAsText = PrivacyMessagePref.Entry;
                    if (string.IsNullOrEmpty(valueAsText))
                    {
                        if (datauser != null)
                        {
                            PrivacyMessagePref.SetValueIndex(int.Parse(datauser.MessagePrivacy));
                            MainSettings.SharedData.Edit().PutString("whocanMessage_key", datauser.MessagePrivacy)
                                .Commit();
                            SWhoCanMessageMe = datauser.MessagePrivacy;
                            if (SWhoCanMessageMe == "0")
                            {
                                PrivacyMessagePref.Summary = ActivityContext.GetText(Resource.String.Lbl_Everyone);
                            }
                            else if (SWhoCanMessageMe == "1")
                            {
                                PrivacyMessagePref.Summary = ActivityContext.GetText(Resource.String.Lbl_People_i_Follow);
                            }
                            else
                            {
                                PrivacyMessagePref.Summary = ActivityContext.GetText(Resource.String.Lbl_No_body);
                            }
                        }
                    }
                    else
                    {
                        PrivacyMessagePref.Summary = valueAsText;
                        SWhoCanMessageMe = PrivacyMessagePref.Value;
                    }
                }
                else if (key.Equals("whocanseemybirthday_key"))
                {
                    var valueAsText = PrivacyBirthdayPref.Entry;
                    if (string.IsNullOrEmpty(valueAsText))
                    {
                        if (datauser != null)
                        {
                            PrivacyBirthdayPref.SetValueIndex(int.Parse(datauser.BirthPrivacy));
                            MainSettings.SharedData.Edit()
                                .PutString("whocanseemybirthday_key", datauser.BirthPrivacy).Commit();

                            SWhoCanSeeMyBirthday = datauser.BirthPrivacy;
                            if (SWhoCanSeeMyBirthday == "0")
                            {
                                PrivacyBirthdayPref.Summary = GetText(Resource.String.Lbl_Everyone);
                            }
                            else if (SWhoCanSeeMyBirthday == "1")
                            {
                                PrivacyBirthdayPref.Summary = ActivityContext.GetText(Resource.String.Lbl_People_i_Follow);
                            }
                            else
                            {
                                PrivacyBirthdayPref.Summary = ActivityContext.GetText(Resource.String.Lbl_No_body);
                            }
                        }
                    }
                    else
                    {
                        PrivacyBirthdayPref.Summary = valueAsText;
                        SWhoCanSeeMyBirthday = PrivacyBirthdayPref.Value;
                    }
                }
                else if (key.Equals("notifications_key"))
                {
                    bool getvalue = MainSettings.SharedData.GetBoolean("notifications_key", true);
                    NotifcationPopupPref.Checked = getvalue;
                }
                else if (key.Equals("onlineuser_key"))
                {
                    bool getvalue = MainSettings.SharedData.GetBoolean("onlineuser_key", true);
                    ShowOnlineUsersPref.Checked = getvalue;
                }
                else if (key.Equals("checkBox_PlaySound_key"))
                {
                    bool getvalue = MainSettings.SharedData.GetBoolean("checkBox_PlaySound_key", true);
                    NotifcationPlaySoundPref.Checked = getvalue;

                    if (getvalue)
                    {
                        SSoundControl = true;
                    }
                    else
                    {
                        SSoundControl = false;
                    }

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        
        //Delete Account
        private void SupportDeleteAccountPrefOnPreferenceClick(object sender, Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                TypeDialog = "Delete";

                var dialog = new MaterialDialog.Builder(ActivityContext);

                dialog.Title(Resource.String.Lbl_Warning);
                dialog.Content(ActivityContext.GetText(Resource.String.Lbl_Are_you_DeleteAccount) + " " + AppSettings.ApplicationName);
                dialog.PositiveText(ActivityContext.GetText(Resource.String.Lbl_Ok)).OnPositive(this);
                dialog.NegativeText(ActivityContext.GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                dialog.Build().Show();
                dialog.AlwaysCallSingleChoiceCallback();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void GeneralCallPrefOnPreferenceClick(object sender, Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                dbDatabase.Clear_CallUser_List();
                TabbedMainActivity.GetInstance().LastCallsTab.MAdapter?.Clear();

                Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_Done), ToastLength.Long).Show();

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void ShowOnlineUsers_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            try
            {
                SwitchPreference etp = (SwitchPreference)sender;
                var value = e.NewValue.ToString();
                etp.Checked = Boolean.Parse(value);

                MainSettings.SharedData.Edit().PutBoolean("onlineuser_key", etp.Checked).Commit(); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        //Help
        private void SupportHelpPrefOnPreferenceClick(object sender,Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                SupportHelpPref.Intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                SupportHelpPref.Intent.PutExtra("Type", ActivityContext.GetText(Resource.String.Lbl_Help));
                SupportHelpPref.Intent.PutExtra("URL", Client.WebsiteUrl + "/terms/about-us");
                ActivityContext.StartActivity(SupportHelpPref.Intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Report >> Contact Us
        private void SupportReportPrefOnPreferenceClick(object sender,Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                SupportReportPref.Intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                SupportReportPref.Intent.PutExtra("Type", ActivityContext.GetText(Resource.String.Lbl_Report_Problem));
                SupportReportPref.Intent.PutExtra("URL", Client.WebsiteUrl + "/contact-us");
                ActivityContext.StartActivity(SupportReportPref.Intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Logout
        private void SupportLogout_OnPreferenceClick(object sender,Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                TypeDialog = "Logout";

                var dialog = new MaterialDialog.Builder(ActivityContext);

                dialog.Title(Resource.String.Lbl_Warning);
                dialog.Content(ActivityContext.GetText(Resource.String.Lbl_Are_you_logout));
                dialog.PositiveText(ActivityContext.GetText(Resource.String.Lbl_Ok)).OnPositive(this);
                dialog.NegativeText(ActivityContext.GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                dialog.AlwaysCallSingleChoiceCallback();
                dialog.Build().Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Notification >> Play Sound 
        private void Notifcation_PlaySound_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            if (e.Handled)
            {
                CheckBoxPreference etp = (CheckBoxPreference) sender;
                var value = e.NewValue.ToString();
                etp.Checked = Boolean.Parse(value);
                if (etp.Checked)
                {
                    SSoundControl = true;
                }
                else
                {
                    SSoundControl = false;
                }
            }
        }

        //Notifcation >> Popup 
        private void Notifcation_Popup_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            if (e.Handled)
            {
                SwitchPreference etp = (SwitchPreference) sender;
                var value = e.NewValue.ToString();
                etp.Checked = Boolean.Parse(value);
                if (etp.Checked)
                {
                    OneSignalNotification.RegisterNotificationDevice();
                }
                else
                {
                    OneSignalNotification.Un_RegisterNotificationDevice();
                }
            }
        }

        #region Privacy

        private void Privacy_Birthday_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            try
            {
                if (e.Handled)
                {
                    ListPreference etp = (ListPreference) sender;
                    var value = e.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[Int32.Parse(value)];
                    etp.Summary = valueAsText;

                    SWhoCanSeeMyBirthday = value;

                    if (Methods.CheckConnectivity())
                    {
                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"birth_privacy", SWhoCanSeeMyBirthday}
                        };

                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => Global.Update_User_Data(dataPrivacy) });
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                            ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Privacy_Message_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            try
            {
                if (e.Handled)
                {
                    ListPreference etp = (ListPreference) sender;
                    var value = e.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[Int32.Parse(value)];
                    etp.Summary = valueAsText;

                    SWhoCanMessageMe = value;

                    if (Methods.CheckConnectivity())
                    {
                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"message_privacy", SWhoCanMessageMe}
                        };

                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => Global.Update_User_Data(dataPrivacy) });
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                            ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Privacy_Follow_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            try
            {
                if (e.Handled)
                {
                    ListPreference etp = (ListPreference) sender;
                    var value = e.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[Int32.Parse(value)];
                    etp.Summary = valueAsText;

                    SWhoCanFollowMe = value;

                    if (Methods.CheckConnectivity())
                    {
                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"follow_privacy", SWhoCanFollowMe}
                        };

                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => Global.Update_User_Data(dataPrivacy) });
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                            ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        //Lang
        //private void Lang_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        //{
        //    try
        //    {
        //        if (e.Handled)
        //        {
        //            ListPreference etp = (ListPreference) sender;
        //            var value = e.NewValue;

        //            MainSettings.SetApplicationLang(value.ToString());

        //            Toast.MakeText(ActivityContext, GetText(Resource.String.Lbl_Closed_App), ToastLength.Long).Show();

        //            Intent intent = new Intent(ActivityContext, typeof(SplashScreenActivity));
        //            intent.AddCategory(Intent.CategoryHome);
        //            intent.SetAction(Intent.ActionMain);
        //            intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
        //            ActivityContext.StartActivity(intent);
        //            ActivityContext.FinishAffinity();
        //        }
        //    }
        //    catch (Exception exception)
        //    {
        //        Console.WriteLine(exception);
        //    }
        //}

        //About
        private void About_Me_Pref_PreferenceChange(object sender, Preference.PreferenceChangeEventArgs e)
        {
            try
            {
                EditTextPreference etp = (EditTextPreference) sender;
                var value = etp.EditText.Text;
                etp.Summary = value;

                var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (datauser != null)
                {
                    datauser.About = etp.EditText.Text;
                    SAbout = etp.EditText.Text;
                }

                if (Methods.CheckConnectivity())
                {
                    var dataPrivacy = new Dictionary<string, string>
                    {
                        {"about", value}
                    };

                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => Global.Update_User_Data(dataPrivacy) });
                }
                else
                {
                    Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                        ToastLength.Long).Show();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (TypeDialog == "Delete")
                {
                    if (p1 == DialogAction.Positive)
                    {
                        var intent = new Intent(ActivityContext, typeof(DeleteAccountActivity));
                        ActivityContext.StartActivity(intent);
                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }
                }
                else if (TypeDialog == "Logout")
                {
                    if (p1 == DialogAction.Positive)
                    {
                        // Check if we're running on Android 5.0 or higher
                        if ((int) Build.VERSION.SdkInt < 23)
                        {
                            Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_You_will_be_logged),ToastLength.Long).Show();
                            ApiRequest.Logout(ActivityContext);
                        }
                        else
                        {
                            if (ActivityContext.CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                                ActivityContext.CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            {
                                Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_You_will_be_logged),
                                    ToastLength.Long).Show();
                                ApiRequest.Logout(ActivityContext);
                            }
                            else
                                RequestPermissions(new[]
                                {
                                    Manifest.Permission.ReadExternalStorage,
                                    Manifest.Permission.WriteExternalStorage
                                }, 101);
                        }
                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

       
        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}