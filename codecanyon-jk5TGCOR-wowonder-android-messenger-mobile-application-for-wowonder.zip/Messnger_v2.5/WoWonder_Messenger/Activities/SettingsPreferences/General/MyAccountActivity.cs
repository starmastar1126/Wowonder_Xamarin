using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using AndroidHUD;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Requests;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.SettingsPreferences.General
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MyAccountActivity : AppCompatActivity
    {

        #region Variables Basic

        private AppCompatTextView TxtUsernameIcon;
        private EditText TxtUsernameText;

        private AppCompatTextView TxtEmailIcon;
        private EditText TxtEmailText;

        private AppCompatTextView TxtGenderIcon;
        private RadioButton RbMale;
        private RadioButton RbFemale;

        private string GenderStatus = "", PhoneNumber = "";

        #endregion

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                SetTheme(AppSettings.SetTabDarkTheme ? Resource.Style.MyTheme_Dark_Base : Resource.Style.MyTheme_Base);
                Methods.App.FullScreenApp(this);

                // Set our view from the "Settings_MyAccount_Layout" layout resource
                SetContentView(Resource.Layout.Settings_MyAccount_Layout);

                //Set ToolBar
                var toolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                toolBar.Title = GetText(Resource.String.Lbl_My_Account);
                

                SetSupportActionBar(toolBar);
                SupportActionBar.SetDisplayShowCustomEnabled(true);
                SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                SupportActionBar.SetHomeButtonEnabled(true);
                SupportActionBar.SetDisplayShowHomeEnabled(true);

                //Get values
                TxtUsernameIcon = FindViewById<AppCompatTextView>(Resource.Id.Username_icon);
                TxtUsernameText = FindViewById<EditText>(Resource.Id.Username_text);

                TxtEmailIcon = FindViewById<AppCompatTextView>(Resource.Id.Email_icon);
                TxtEmailText = FindViewById<EditText>(Resource.Id.Email_text);

                TxtGenderIcon = FindViewById<AppCompatTextView>(Resource.Id.Gendericon);
                RbMale = (RadioButton)FindViewById(Resource.Id.radioMale);
                RbFemale = (RadioButton)FindViewById(Resource.Id.radioFemale);

                if (AppSettings.SetTabDarkTheme)
                {
                    TxtUsernameText.SetTextColor(Android.Graphics.Color.White);
                    TxtUsernameText.SetHintTextColor(Android.Graphics.Color.White);

                    TxtEmailText.SetTextColor(Android.Graphics.Color.White);
                    TxtEmailText.SetHintTextColor(Android.Graphics.Color.White);


                    RbMale.SetTextColor(Android.Graphics.Color.White);
                    RbFemale.SetTextColor(Android.Graphics.Color.White);
                }
                else
                {
                    TxtUsernameText.SetTextColor(Android.Graphics.Color.Black);
                    TxtUsernameText.SetHintTextColor(Android.Graphics.Color.Black);

                    TxtEmailText.SetTextColor(Android.Graphics.Color.Black);
                    TxtEmailText.SetHintTextColor(Android.Graphics.Color.Black);

                    RbMale.SetTextColor(Android.Graphics.Color.Black);
                    RbFemale.SetTextColor(Android.Graphics.Color.Black);
                }
                Get_Data_User();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();

                //Event
                RbMale.CheckedChange += RbMaleOnCheckedChange;
                RbFemale.CheckedChange += RbFemaleOnCheckedChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                //Event
                RbMale.CheckedChange -= RbMaleOnCheckedChange;
                RbFemale.CheckedChange -= RbFemaleOnCheckedChange;

                base.OnPause();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        private void RbFemaleOnCheckedChange(object sender,
            CompoundButton.CheckedChangeEventArgs checkedChangeEventArgs)
        {
            try
            {
                bool isChecked = RbFemale.Checked;
                if (isChecked)
                {
                    RbMale.Checked = false;
                    GenderStatus = "female";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void RbMaleOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs checkedChangeEventArgs)
        {
            try
            {
                bool isChecked = RbMale.Checked;
                if (isChecked)
                {
                    RbFemale.Checked = false;
                    GenderStatus = "male";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void Get_Data_User()
        {
            try
            {
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, TxtUsernameIcon, IonIconsFonts.Person);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, TxtEmailIcon, IonIconsFonts.Email);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, TxtGenderIcon, IonIconsFonts.Male);

                var local = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (local != null)
                {
                    TxtUsernameText.Text = local.Username;
                    TxtEmailText.Text = local.Email;
                    PhoneNumber = local.PhoneNumber;

                    if (local.Gender == "male" || local.Gender == "Male")
                    {
                        RbMale.Checked = true;
                        RbFemale.Checked = false;
                        GenderStatus = "male";
                    }
                    else
                    {
                        RbMale.Checked = false;
                        RbFemale.Checked = true;
                        GenderStatus = "female";
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void SaveDataButtonOnClick()
        {
            try
            {

                if (Methods.CheckConnectivity())
                {
                    //Show a progress
                    AndHUD.Shared.Show(this, GetText(Resource.String.Lbl_Loading));

                    var dictionary = new Dictionary<string, string>
                        {
                            {"username", TxtUsernameText.Text},
                            {"email", TxtEmailText.Text},
                            {"gender", GenderStatus},
                            {"phone_number", PhoneNumber}
                        };

                    var (apiStatus, respond) = await RequestsAsync.Global.Update_User_Data(dictionary);
                    if (apiStatus == 200)
                    {
                        if (respond is MessageObject result)
                        {
                            if (result.Message.Contains("updated"))
                            {
                                Toast.MakeText(this, result.Message, ToastLength.Short).Show();
                                AndHUD.Shared.Dismiss(this);
                            }
                        }
                    }
                    else if (apiStatus == 400)
                    {
                        if (respond is ErrorObject error)
                        {
                            var errortext = error._errors.ErrorText;
                           

                            if (errortext.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);

                            //Show a Error image with a message
                            AndHUD.Shared.ShowError(this, errortext, MaskType.Clear, TimeSpan.FromSeconds(2));
                        }
                    }
                    else if (apiStatus == 404)
                    {
                        var error = respond.ToString();
                       

                        //Show a Error image with a message
                        AndHUD.Shared.ShowError(this, error, MaskType.Clear, TimeSpan.FromSeconds(2));
                    }

                    AndHUD.Shared.Dismiss(this);
                }
                else
                {
                    Toast.MakeText(this, GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            MenuInflater.Inflate(Resource.Menu.Profile_Menu, menu);
            return base.OnCreateOptionsMenu(menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;

                case Resource.Id.menue_SaveData:
                    SaveDataButtonOnClick();
                    break;
            }

            return base.OnOptionsItemSelected(item);
        }


        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                
                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}