using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AndroidHUD;
using WoWonder.Activities.Authentication;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Requests;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.SettingsPreferences.General
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class PasswordActivity : AppCompatActivity 
    {

        #region Variables Basic

        private  EditText TxtCurrentPassword;
        private  EditText TxtNewPassword;
        private  EditText TxtRepeatPassword;

        private TextView TxtLinkForget;
        private TextView TxtSave;

        #endregion

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                SetTheme(AppSettings.SetTabDarkTheme ? Resource.Style.MyTheme_Dark_Base : Resource.Style.MyTheme_Base);
                Methods.App.FullScreenApp(this);

                // Set our view from the "Settings_Password_Layout" layout resource
                SetContentView(Resource.Layout.Settings_Password_Layout);

                //Set ToolBar
                var toolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                toolBar.Title = GetText(Resource.String.Lbl_Change_Password);
                


                SetSupportActionBar(toolBar);
                SupportActionBar.SetDisplayShowCustomEnabled(true);
                SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                SupportActionBar.SetHomeButtonEnabled(true);
                SupportActionBar.SetDisplayShowHomeEnabled(true);

                //Get values
                TxtCurrentPassword = FindViewById<EditText>(Resource.Id.CurrentPassword_Edit);
                TxtNewPassword = FindViewById<EditText>(Resource.Id.NewPassword_Edit);
                TxtRepeatPassword = FindViewById<EditText>(Resource.Id.RepeatPassword_Edit);

                TxtLinkForget = FindViewById<TextView>(Resource.Id.linkText);
                TxtSave = FindViewById<TextView>(Resource.Id.toolbar_title);

                if (AppSettings.SetTabDarkTheme)
                {
                    TxtCurrentPassword.SetTextColor(Android.Graphics.Color.White);
                    TxtCurrentPassword.SetHintTextColor(Android.Graphics.Color.White);

                    TxtNewPassword.SetTextColor(Android.Graphics.Color.White);
                    TxtNewPassword.SetHintTextColor(Android.Graphics.Color.White);


                    TxtRepeatPassword.SetTextColor(Android.Graphics.Color.White);
                    TxtRepeatPassword.SetTextColor(Android.Graphics.Color.White);
                }
                else
                {
                    TxtCurrentPassword.SetTextColor(Android.Graphics.Color.Black);
                    TxtCurrentPassword.SetHintTextColor(Android.Graphics.Color.Black);

                    TxtNewPassword.SetTextColor(Android.Graphics.Color.Black);
                    TxtNewPassword.SetHintTextColor(Android.Graphics.Color.Black);

                    TxtRepeatPassword.SetTextColor(Android.Graphics.Color.Black);
                    TxtRepeatPassword.SetTextColor(Android.Graphics.Color.Black);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                //Event
                TxtLinkForget.Click += TxtLinkForget_OnClick;
                TxtSave.Click += SaveDataButtonOnClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();

                //Event
                TxtLinkForget.Click -= TxtLinkForget_OnClick;
                TxtSave.Click -= SaveDataButtonOnClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void SaveDataButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                if (TxtCurrentPassword.Text == "" || TxtNewPassword.Text == "" || TxtRepeatPassword.Text == "")
                {
                    Toast.MakeText(this, GetText(Resource.String.Lbl_Please_check_your_details), ToastLength.Long)
                        .Show();
                    return;
                }

                if (TxtNewPassword.Text != TxtRepeatPassword.Text)
                {
                    Toast.MakeText(this, GetText(Resource.String.Lbl_Your_password_dont_match), ToastLength.Long)
                        .Show();
                }
                else
                {
                    if (Methods.CheckConnectivity())
                    {
                        //Show a progress
                        AndHUD.Shared.Show(this, GetText(Resource.String.Lbl_Loading));

                        if (TxtCurrentPassword.Text != null && TxtNewPassword.Text != null &&
                            TxtRepeatPassword.Text != null)
                        {
                            var dataPrivacy = new Dictionary<string, string>
                            {
                                {"new_password", TxtNewPassword.Text},
                                {"current_password", TxtCurrentPassword.Text}
                            };

                            var (apiStatus, respond) =
                                await RequestsAsync.Global.Update_User_Data(dataPrivacy);
                            if (apiStatus == 200)
                            {
                                if (respond is MessageObject result)
                                {
                                    if (result.Message.Contains("updated"))
                                    {
                                        Toast.MakeText(this, result.Message, ToastLength.Short).Show();
                                        AndHUD.Shared.Dismiss(this);
                                    }
                                    else
                                    {
                                        //Show a Error image with a message
                                        AndHUD.Shared.ShowError(this, result.Message, MaskType.Clear,
                                            TimeSpan.FromSeconds(2));
                                    }
                                }
                            }
                            else Methods.DisplayReportResult(this,respond);
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_Please_check_your_details),
                                ToastLength.Long).Show();
                        }

                        AndHUD.Shared.Dismiss(this);
                    }
                    else
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection),
                            ToastLength.Short).Show();
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        private void TxtLinkForget_OnClick(object sender, EventArgs e)
        {
            try
            {
                StartActivity(typeof(ForgetPasswordActivity));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}