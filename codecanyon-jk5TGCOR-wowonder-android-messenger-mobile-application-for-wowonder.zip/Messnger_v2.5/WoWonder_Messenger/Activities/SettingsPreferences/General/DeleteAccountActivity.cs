using System;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Ads;
using Android.OS;
using Android.Provider;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Requests;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.SettingsPreferences.General
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class DeleteAccountActivity : AppCompatActivity
    {
        private AdView MAdView;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                SetTheme(AppSettings.SetTabDarkTheme ? Resource.Style.MyTheme_Dark_Base : Resource.Style.MyTheme_Base);
                Methods.App.FullScreenApp(this);

                SetContentView(Resource.Layout.Settings_DeleteAccount_layout);

                //Set ToolBar
                var toolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolBar != null)
                {
                    toolBar.Title = GetText(Resource.String.Lbl_DeleteAccount);

                    SetSupportActionBar(toolBar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);

                }

                //Get values
                TxtPassword = FindViewById<EditText>(Resource.Id.Password_Edit);
                ChkDelete = FindViewById<CheckBox>(Resource.Id.DeleteCheckBox);
                BtnDelete = FindViewById<Button>(Resource.Id.DeleteButton);

                ChkDelete.Text = GetText(Resource.String.Lbl_IWantToDelete1) + " " + UserDetails.Username + " " +
                                  GetText(Resource.String.Lbl_IWantToDelete2) + " " + AppSettings.ApplicationName + " " +
                                  GetText(Resource.String.Lbl_IWantToDelete3);

                MAdView = FindViewById<AdView>(Resource.Id.adView);
                if (AppSettings.ShowAdmobBanner)
                { 
                    MAdView.AdSize = AdSize.LargeBanner;
                    MAdView.Visibility = ViewStates.Visible;
                    string androidId = Settings.Secure.GetString(ContentResolver, Settings.Secure.AndroidId);
                    var adRequest = new AdRequest.Builder();
                    adRequest.AddTestDevice(androidId); 
                    MAdView.LoadAd(adRequest.Build());
                }
                else
                {
                    MAdView.Pause();
                    MAdView.Visibility = ViewStates.Gone;
                }
                if (AppSettings.SetTabDarkTheme)
                {
                    TxtPassword.SetTextColor(Android.Graphics.Color.White);
                    TxtPassword.SetHintTextColor(Android.Graphics.Color.White);

                    ChkDelete.SetTextColor(Android.Graphics.Color.White);
                    ChkDelete.SetHintTextColor(Android.Graphics.Color.White);

                }
                else
                {
                    TxtPassword.SetTextColor(Android.Graphics.Color.Black);
                    TxtPassword.SetHintTextColor(Android.Graphics.Color.Black);

                    ChkDelete.SetTextColor(Android.Graphics.Color.Black);
                    ChkDelete.SetHintTextColor(Android.Graphics.Color.Black);

                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();

                //Add Event
                BtnDelete.Click += BtnDeleteOnClick;

                MAdView?.Resume();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                MAdView?.Pause();

                //Close Event
                BtnDelete.Click -= BtnDeleteOnClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Delete
        private async void BtnDeleteOnClick(object sender, EventArgs e)
        {
            try
            {
                if (ChkDelete.Checked)
                {
                    if (!Methods.CheckConnectivity())
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_CheckYourInternetConnection),
                            ToastLength.Short).Show();
                    }
                    else
                    {
                        var localdata = ListUtils.DataUserLoginList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (localdata != null)
                        {
                            if (TxtPassword.Text == localdata.Password)
                            {
                                var (apiStatus, respond) = await RequestsAsync.Global.Delete_User(TxtPassword.Text);
                                if (apiStatus == 200)
                                {
                                    if (respond is MessageObject result)
                                    {
                                        Console.WriteLine(result.Message);
                                        ApiRequest.Delete(this);

                                        var dbDatabase = new SqLiteDatabase();
                                        dbDatabase.CheckTablesStatus();
                                        dbDatabase.Dispose();

                                        Methods.DialogPopup.InvokeAndShowDialog(this,
                                            GetText(Resource.String.Lbl_Deleted),
                                            GetText(Resource.String.Lbl_Your_account_was_successfully_deleted),
                                            GetText(Resource.String.Lbl_Ok));
                                    }
                                }
                                else Methods.DisplayReportResult(this, respond);
                            }
                            else
                            {
                                Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Warning),
                                    GetText(Resource.String.Lbl_Please_confirm_your_password),
                                    GetText(Resource.String.Lbl_Ok));
                            }
                        }
                    }
                }
                else
                {
                    Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Warning),
                        GetText(Resource.String.Lbl_Error_Terms),
                        GetText(Resource.String.Lbl_Ok));
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                MAdView?.Destroy();
                
                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic

        private EditText TxtPassword;
        private CheckBox ChkDelete;
        private Button BtnDelete;

        #endregion
    }
}