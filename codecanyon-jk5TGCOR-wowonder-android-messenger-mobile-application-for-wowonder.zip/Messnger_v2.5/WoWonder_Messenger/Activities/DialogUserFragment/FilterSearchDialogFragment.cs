﻿using System;
using System.Collections.Generic;
using AFollestad.MaterialDialogs;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Views;
using Android.Widget;
using Java.Lang;
using WoWonder.Activities.DefaultUser;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Library.RangeSlider;
using WoWonder.SQLite;
using Exception = System.Exception;

namespace WoWonder.Activities.DialogUserFragment
{
    public class FilterSearchDialogFragment : BottomSheetDialogFragment, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private SearchActivity ContextSearch;
        private TextView IconBack, IconGender, TxtAge, IconAge, IconLocation, LocationPlace, LocationMoreIcon, IconVerified, TxtVerified, VerifiedMoreIcon, IconStatus, TxtStatus, StatusMoreIcon;
        private Button ButtonMan, ButtonGirls, ButtonBothGender, BtnApply;
        private Switch AgeSwitch;
        private RangeSliderControl AgeSeekBar;
        private RelativeLayout LayoutLocation, LayoutVerified, LayoutStatus;
        private string Gender = "all", Status = "all", Verified = "all", Location = "all", TypeDialog = "";
        private int AgeMin = 10, AgeMax = 70;
        private bool SwitchState;

        #endregion

        #region General

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Create your fragment here
            ContextSearch = (SearchActivity)Activity;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                Context contextThemeWrapper = AppSettings.SetTabDarkTheme ? new ContextThemeWrapper(Activity, Resource.Style.MyTheme_Dark_Base) : new ContextThemeWrapper(Activity, Resource.Style.MyTheme_Base);
                // clone the inflater using the ContextThemeWrapper
                LayoutInflater localInflater = inflater.CloneInContext(contextThemeWrapper);

                View view = localInflater.Inflate(Resource.Layout.ButtomSheetSearchFilter, container, false);

            //    View view = inflater.Inflate(Resource.Layout.ButtomSheetSearchFilter, container, false);

                InitComponent(view);

                IconBack.Click += IconBackOnClick;
                ButtonMan.Click += ButtonManOnClick;
                ButtonGirls.Click += ButtonGirlsOnClick;
                ButtonBothGender.Click += ButtonBothOnClick;

                LayoutLocation.Click += LayoutLocationOnClick;
                LayoutVerified.Click += LayoutVerifiedOnClick;
                LayoutStatus.Click += LayoutStatusOnClick;
                AgeSwitch.CheckedChange += AgeSwitchOnCheckedChange;
                AgeSeekBar.DragCompleted += AgeSeekBarOnDragCompleted;
                BtnApply.Click += BtnApplyOnClick;

                AgeSeekBar.SetSelectedMinValue(10);
                AgeSeekBar.SetSelectedMaxValue(70);

                AgeSwitch.Checked = false;

                return view;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                IconBack = view.FindViewById<TextView>(Resource.Id.IconBack);
                IconGender = view.FindViewById<TextView>(Resource.Id.IconGender);
                ButtonMan = view.FindViewById<Button>(Resource.Id.ManButton);
                ButtonGirls = view.FindViewById<Button>(Resource.Id.GirlsButton);
                ButtonBothGender = view.FindViewById<Button>(Resource.Id.BothGenderButton);

                IconAge = view.FindViewById<TextView>(Resource.Id.IconAge);
                TxtAge = view.FindViewById<TextView>(Resource.Id.AgeTextView);

                IconLocation = view.FindViewById<TextView>(Resource.Id.IconLocation);
                LocationPlace = view.FindViewById<TextView>(Resource.Id.LocationPlace);
                LocationMoreIcon = view.FindViewById<TextView>(Resource.Id.LocationMoreIcon);

                IconVerified = view.FindViewById<TextView>(Resource.Id.IconVerified);
                TxtVerified = view.FindViewById<TextView>(Resource.Id.textVerified);
                VerifiedMoreIcon = view.FindViewById<TextView>(Resource.Id.VerifiedMoreIcon);
                IconStatus = view.FindViewById<TextView>(Resource.Id.IconStatus);
                TxtStatus = view.FindViewById<TextView>(Resource.Id.textStatus);
                StatusMoreIcon = view.FindViewById<TextView>(Resource.Id.StatusMoreIcon);

                LayoutLocation = view.FindViewById<RelativeLayout>(Resource.Id.LayoutLocation);
                LayoutVerified = view.FindViewById<RelativeLayout>(Resource.Id.LayoutVerified);
                LayoutStatus = view.FindViewById<RelativeLayout>(Resource.Id.LayoutStatus);

                AgeSeekBar = view.FindViewById<RangeSliderControl>(Resource.Id.seekbar);
                AgeSwitch = view.FindViewById<Switch>(Resource.Id.togglebutton);

                BtnApply = view.FindViewById<Button>(Resource.Id.ApplyButton);

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconBack, IonIconsFonts.ChevronLeft);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconGender, IonIconsFonts.IosPersonOutline);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconLocation, IonIconsFonts.IosLocationOutline);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconAge, IonIconsFonts.Calendar);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, IconVerified, FontAwesomeIcon.UserCheck);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconStatus, IonIconsFonts.Ionic);

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, LocationMoreIcon, IonIconsFonts.ChevronRight);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, VerifiedMoreIcon, IonIconsFonts.ChevronRight);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, StatusMoreIcon, IonIconsFonts.ChevronRight);

                

                GetFilter();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Event

        //Back
        private void IconBackOnClick(object sender, EventArgs e)
        {
            try
            {
                Dismiss();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Save data 
        private void BtnApplyOnClick(object sender, EventArgs e)
        {
            try
            {
                UserDetails.SearchGender = Gender;
                UserDetails.SearchCountry = Location;
                UserDetails.SearchStatus = Status;
                UserDetails.SearchVerified = Verified;
                UserDetails.SearchFilterByAge = SwitchState ? "on" : "off";
                UserDetails.SearchAgeFrom = AgeMin.ToString();
                UserDetails.SearchAgeTo = AgeMax.ToString();

                var dbDatabase = new SqLiteDatabase();
                var newSettingsFilter = new DataTables.SearchFilterTb()
                {
                    Gender = Gender,
                    Country = Location,
                    Status = Status,
                    Verified = Verified,
                    FilterByAge = SwitchState ? "on" : "off",
                    AgeFrom = AgeMin.ToString(),
                    AgeTo = AgeMax.ToString(),
                };
                dbDatabase.InsertOrUpdate_SearchFilter(newSettingsFilter);
                dbDatabase.Dispose();

                ContextSearch.Search();

                Dismiss();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select gender >> Both (0)
        private void ButtonBothOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonGirls.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonMan.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                Gender = "all";
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select gender >> Girls (2)
        private void ButtonGirlsOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonGirls.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonBothGender.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonMan.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));
                Gender = "female";
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select gender >> Man (1)
        private void ButtonManOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonMan.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonBothGender.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonGirls.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                Gender = "male";
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Status
        private void LayoutStatusOnClick(object sender, EventArgs e)
        {
            try
            {
                TypeDialog = "Status";

                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(Context);

                arrayAdapter.Add(GetText(Resource.String.Lbl_All));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Offline));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Online));

                dialogList.Title(GetText(Resource.String.Lbl_Status));
                dialogList.Items(arrayAdapter);
                dialogList.PositiveText(GetText(Resource.String.Lbl_Close)).OnPositive(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Verified
        private void LayoutVerifiedOnClick(object sender, EventArgs e)
        {
            try
            {
                TypeDialog = "Verified";

                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(Context);

                arrayAdapter.Add(GetText(Resource.String.Lbl_All));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Verified));
                arrayAdapter.Add(GetText(Resource.String.Lbl_UnVerified));

                dialogList.Title(GetText(Resource.String.Lbl_Verified));
                dialogList.Items(arrayAdapter);
                dialogList.PositiveText(GetText(Resource.String.Lbl_Close)).OnPositive(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Location
        private void LayoutLocationOnClick(object sender, EventArgs e)
        {
            try
            {
                TypeDialog = "Location";

                string[] countriesArray = Context.Resources.GetStringArray(Resource.Array.countriesArray);

                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(Context);

                foreach (var item in countriesArray)
                    arrayAdapter.Add(item);

                dialogList.Title(GetText(Resource.String.Lbl_Location));
                dialogList.Items(arrayAdapter);
                dialogList.PositiveText(GetText(Resource.String.Lbl_Close)).OnPositive(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Age
        private void AgeSeekBarOnDragCompleted(object sender, EventArgs e)
        {
            try
            {
                GC.Collect(GC.MaxGeneration);

                AgeMin = (int)AgeSeekBar.GetSelectedMinValue();
                AgeMax = (int)AgeSeekBar.GetSelectedMaxValue();

                TxtAge.Text = GetString(Resource.String.Lbl_Age) + " " + AgeMin + " - " + AgeMax;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Age Switch
        private void AgeSwitchOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                if (e.IsChecked)
                {
                    //Switch On
                    SwitchState = true;
                    AgeSeekBar.Visibility = ViewStates.Visible;
                }
                else
                {
                    //Switch Off
                    SwitchState = false;
                    AgeSeekBar.Visibility = ViewStates.Invisible;
                }

                TxtAge.Text = GetString(Resource.String.Lbl_Age);

                UserDetails.SearchFilterByAge = SwitchState ? "on" : "off";
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        private void GetFilter()
        {
            try
            {
                var dbDatabase = new SqLiteDatabase();

                var data = dbDatabase.GetSearchFilterById();
                if (data != null)
                {
                    Gender = data.Gender;

                    Location = data.Country;
                    Status = data.Status;
                    Verified = data.Verified;
                    SwitchState = data.FilterByAge == "on";
                    AgeMin = int.Parse(data.AgeFrom);
                    AgeMax = int.Parse(data.AgeTo);

                    //////////////////////////// Gender //////////////////////////////
                    switch (data.Gender)
                    {
                        case "all":
                            ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonGirls.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                            ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonMan.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                            Gender = "all";
                            break;
                        case "male":
                            ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonMan.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonBothGender.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                            ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonGirls.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                            Gender = "male";
                            break;
                        case "female":
                            ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonGirls.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonBothGender.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                            ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonMan.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));
                            Gender = "female";
                            break;
                    }

                }
                else
                {
                    UserDetails.SearchGender = "all";
                    UserDetails.SearchCountry = "all";
                    UserDetails.SearchStatus = "all";
                    UserDetails.SearchVerified = "all";
                    UserDetails.SearchFilterByAge = "off";
                    UserDetails.SearchAgeFrom = "10";
                    UserDetails.SearchAgeTo = "70";

                    Gender = UserDetails.SearchGender;
                    Location = UserDetails.SearchCountry;
                    Status = UserDetails.SearchStatus;
                    Verified = UserDetails.SearchVerified;
                    SwitchState = UserDetails.SearchFilterByAge == "on";
                    AgeMin = int.Parse(UserDetails.SearchAgeFrom);
                    AgeMax = int.Parse(UserDetails.SearchAgeTo);

                    ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                    ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                    ButtonGirls.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    ButtonGirls.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));

                    ButtonMan.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    ButtonMan.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));



                    var newSettingsFilter = new DataTables.SearchFilterTb
                    {
                        Gender = UserDetails.SearchGender,
                        Country = UserDetails.SearchCountry,
                        Status = UserDetails.SearchStatus,
                        Verified = UserDetails.SearchVerified,
                        FilterByAge = UserDetails.SearchFilterByAge,
                        AgeFrom = UserDetails.SearchAgeFrom,
                        AgeTo = UserDetails.SearchAgeTo,
                    };
                    dbDatabase.InsertOrUpdate_SearchFilter(newSettingsFilter);
                }

                dbDatabase.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();

                if (TypeDialog == "Status")
                {
                    TxtStatus.Text = text;
                    if (text == GetText(Resource.String.Lbl_All))
                        Status = "all";
                    else if (text == GetText(Resource.String.Lbl_Offline))
                        Status = "off";
                    else if (text == GetText(Resource.String.Lbl_Online))
                        Status = "on";
                }
                else if (TypeDialog == "Verified")
                {
                    TxtVerified.Text = text;
                    if (text == GetText(Resource.String.Lbl_All))
                        Verified = "all";
                    else if (text == GetText(Resource.String.Lbl_UnVerified))
                        Verified = "off";
                    else if (text == GetText(Resource.String.Lbl_Verified))
                        Verified = "on";
                }
                else if (TypeDialog == "Location")
                {
                    Location = text == "All" ? "all" : (itemId - 1).ToString();
                    LocationPlace.Text = text;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion

    }
}