using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Timers;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Provider;
using Android.Support.V4.Content;
using Android.Support.V4.View.Animation;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Text;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using Com.Theartofdev.Edmodo.Cropper;
using Hani.Momanii.Supernova_emoji_library.Actions;
using Hani.Momanii.Supernova_emoji_library.Helper;
using Java.IO;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.ChatWindow.Adapters;
using WoWonder.Activities.ChatWindow.Fragment;
using WoWonder.Activities.Gif;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Activities.Tab;
using WoWonder.Frameworks.Agora;
using WoWonder.Frameworks.Twilio;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using SupportFragment = Android.Support.V4.App.Fragment;
using ClipboardManager = Android.Content.ClipboardManager;
using Console = System.Console;
using Exception = System.Exception;
using String = System.String;
using Toolbar = Android.Support.V7.Widget.Toolbar;
using Uri = Android.Net.Uri;
using ActionMode = Android.Support.V7.View.ActionMode;
using Object = Java.Lang.Object;

namespace WoWonder.Activities.ChatWindow
{ 
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ResizeableActivity = true,ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class ChatWindowActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback, View.IOnLayoutChangeListener, IOnClickListenerSelectedMessages
    {
        #region Variables Basic

        private SwipeRefreshLayout SwipeRefreshLayout;
        private AppCompatImageView ChatEmojImage;
        private RelativeLayout RootView; 
        private EmojiconEditText EmojIconEditTextView;
        private CircleButton ChatContactButton,ChatMediaButton;
        public CircleButton ChatColorButton ,ChatStickerButton, ChatSendButton;
        public static Toolbar ToolBar;
        public RecyclerView MRecycler;
        private ChatColorsFragment ChatColorBoxFragment;
        private ChatRecordSoundFragment ChatRecourdSoundBoxFragment;
        public ChatStickersTabFragment ChatStickersTabBoxFragment;
        private FrameLayout ButtonFragmentHolder;
        public FrameLayout TopFragmentHolder;
        private LinearLayoutManager LayoutManager;
        public MessageAdapter MAdapter;
        private SupportFragment MainFragmentOpened;
        private Methods.AudioRecorderAndPlayer RecorderService;
        private FastOutSlowInInterpolator Interpolation;
        public static string MainChatColor = AppSettings.MainColor;
        private string TimeNow = DateTime.Now.ToString("hh:mm");
        private static int UnixTimestamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
        private string Time = Convert.ToString(UnixTimestamp);
        private string GifFile = "", PermissionsType = "", TypeChat, TaskWork, Notifier;
        private string LastSeen;
        private static Timer Timer;
        private bool IsRecording;
        public static bool ColorChanged;
        public GetUsersListObject.User DataUser;
        public UserDataObject UserData;
        public string Userid = ""; // to_id
        private static ChatWindowActivity Instance;
        private TabbedMainActivity GlobalContext; 
        private ActionModeCallback ModeCallback;
        private static ActionMode ActionMode;
        public static List<MessageData> AllItem;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                Window.SetSoftInputMode(SoftInput.AdjustResize);
               
                base.OnCreate(savedInstanceState);
                SetTheme(AppSettings.SetTabDarkTheme ? Resource.Style.MyTheme_Dark_Base : Resource.Style.MyTheme_Base);
                Userid = Intent.GetStringExtra("UserID") ?? "";
                TypeChat = Intent.GetStringExtra("TypeChat") ?? "";
                
                Methods.App.FullScreenApp(this);

                Window.SetBackgroundDrawableResource(AppSettings.SetTabDarkTheme
                    ? Resource.Drawable.chatBackground5
                    : Resource.Drawable.chatBackground);

                //Set ToolBar and data chat
                FirstLoadData_Item();

                Window.SetStatusBarColor(Color.ParseColor(MainChatColor));
                SetTheme(MainChatColor);

                // Set our view from the "ChatWindow" layout resource
                SetContentView(Resource.Layout.ChatWindow);

                Instance = this;
                GlobalContext = TabbedMainActivity.GetInstance();
                 
                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();
                 
                var dataNotfi = Intent.GetStringExtra("Notifier") ?? "Data not available";
                if (dataNotfi != "Data not available" && !string.IsNullOrEmpty(dataNotfi))
                {
                    Notifier = dataNotfi;
                    if (Notifier == "Notifier")
                    {
                        string dataApp = Intent.GetStringExtra("App");
                        if (dataApp == "Timeline")
                        {
                            string name = Intent.GetStringExtra("Name");
                            //string username = Intent.GetStringExtra("Username");
                            //string about = Intent.GetStringExtra("About");
                            //string address = Intent.GetStringExtra("Address");
                            //string phone = Intent.GetStringExtra("Phone");
                            //string website = Intent.GetStringExtra("Website");
                            //string working = Intent.GetStringExtra("Working");
                            string time = Intent.GetStringExtra("Time");
                            LastSeen = Intent.GetStringExtra("LastSeen") ?? "off";

                            SupportActionBar.Title = name;

                            //Online Or offline
                            if (LastSeen == "on")
                            {
                                SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Online);
                                LastSeen = GetString(Resource.String.Lbl_Online);
                            }
                            else
                            {
                                SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Last_seen) + " " + time;
                                LastSeen = GetString(Resource.String.Lbl_Last_seen) + " " + time;
                            }
                        }

                        Get_UserProfileData_Api();
                    }
                }

                LoadData_ItemUser();

                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);

                if (Timer != null)
                {
                    Timer.Enabled = true;
                    Timer.Start();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);

                if (Timer != null)
                {
                    Timer.Enabled = false;
                    Timer.Stop();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                if (Timer != null)
                {
                    Timer.Enabled = false;
                    Timer.Stop();
                    Timer.Dispose();
                }

                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Menu
         
        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    MainChatColor = AppSettings.MainColor;
                    ColorChanged = false;
                    Finish();
                    return true;

                case Resource.Id.menu_phonecall:
                    OnMenuPhoneCallIcon_Click();
                    break;
                case Resource.Id.menu_videocall:
                    OnMenuVideoCallIcon_Click();
                    break;
                case Resource.Id.menu_view_profile:
                    OnMenuViewProfile_Click();
                    break;
                case Resource.Id.menu_block:
                    OnMenuBlock_Click();
                    break;
                case Resource.Id.menu_clear_chat:
                    OnMenuClearChat_Click();
                    break;
            }

            return base.OnOptionsItemSelected(item);
        }

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            MenuInflater.Inflate(Resource.Menu.Chat_Window_Menu, menu);

            if (AppSettings.EnableAudioVideoCall == false)
            {
                if (AppSettings.EnableVideoCall == false)
                {
                    var video = menu.FindItem(Resource.Id.menu_videocall);
                    video.SetVisible(false);
                    video.SetEnabled(false);
                }

                if (AppSettings.EnableAudioCall == false)
                {
                    var phoneCall = menu.FindItem(Resource.Id.menu_phonecall);
                    phoneCall.SetVisible(false);
                    phoneCall.SetEnabled(false);
                }
            }

            return base.OnCreateOptionsMenu(menu);
        }
         
        private void OnMenuPhoneCallIcon_Click()
        {
            bool granted = ContextCompat.CheckSelfPermission(ApplicationContext, Manifest.Permission.RecordAudio) ==
                Permission.Granted;
            if (granted)
            {
                StartCall();
            }
            else
            {
                RequestPermissions(new[] 
                {
                    Manifest.Permission.RecordAudio,
                    Manifest.Permission.ModifyAudioSettings
                }, 1106);
            } 
        }

        private void StartCall()
        {
            Intent intentVideoCall = new Intent(this, typeof(TwilioVideoCallActivity));
            if (AppSettings.UseAgoraLibrary && AppSettings.UseTwilioLibrary == false)
            {
                intentVideoCall = new Intent(this, typeof(AgoraAudioCallActivity));
                intentVideoCall.PutExtra("type", "Agora_audio_calling_start");
            }
            else if (AppSettings.UseAgoraLibrary == false && AppSettings.UseTwilioLibrary)
            {
                intentVideoCall = new Intent(this, typeof(TwilioAudioCallActivity));
                intentVideoCall.PutExtra("type", "Twilio_audio_calling_start");
            }

            if (DataUser != null)
            {
                intentVideoCall.PutExtra("UserID", DataUser.UserId);
                intentVideoCall.PutExtra("avatar", DataUser.Avatar);
                intentVideoCall.PutExtra("name", DataUser.Name);
                intentVideoCall.PutExtra("time", TimeNow);
                intentVideoCall.PutExtra("CallID", Time);
                intentVideoCall.PutExtra("access_token", "YOUR_TOKEN");
                intentVideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                intentVideoCall.PutExtra("from_id", "0");
                intentVideoCall.PutExtra("active", "0");
                intentVideoCall.PutExtra("status", "0");
                intentVideoCall.PutExtra("room_name", "TestRoom");
            }
            else if (UserData != null)
            {
                intentVideoCall.PutExtra("UserID", UserData.UserId);
                intentVideoCall.PutExtra("avatar", UserData.Avatar);
                intentVideoCall.PutExtra("name", UserData.Name);
                intentVideoCall.PutExtra("time", TimeNow);
                intentVideoCall.PutExtra("CallID", Time);
                intentVideoCall.PutExtra("access_token", "YOUR_TOKEN");
                intentVideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                intentVideoCall.PutExtra("from_id", "0");
                intentVideoCall.PutExtra("active", "0");
                intentVideoCall.PutExtra("status", "0");
                intentVideoCall.PutExtra("room_name", "TestRoom");
            }
             
            StartActivity(intentVideoCall);
        }

        private void StartVideoCall()
        {

            TimeNow = DateTime.Now.ToString("hh:mm");
            int unixTimestamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            Time = Convert.ToString(unixTimestamp);

            Intent intentOfvideoCall = new Intent(this, typeof(TwilioVideoCallActivity));
            if (AppSettings.UseAgoraLibrary && AppSettings.UseTwilioLibrary == false)
            {
                intentOfvideoCall = new Intent(this, typeof(AgoraVideoCallActivity));
                intentOfvideoCall.PutExtra("type", "Agora_video_calling_start");
            }
            else if (AppSettings.UseAgoraLibrary == false && AppSettings.UseTwilioLibrary)
            {
                intentOfvideoCall = new Intent(this, typeof(TwilioVideoCallActivity));
                intentOfvideoCall.PutExtra("type", "Twilio_video_calling_start");
            }

            if (DataUser != null)
            {
                intentOfvideoCall.PutExtra("UserID", DataUser.UserId);
                intentOfvideoCall.PutExtra("avatar", DataUser.Avatar);
                intentOfvideoCall.PutExtra("name", DataUser.Name);
                intentOfvideoCall.PutExtra("time", TimeNow);
                intentOfvideoCall.PutExtra("CallID", Time);
                intentOfvideoCall.PutExtra("access_token", "YOUR_TOKEN");
                intentOfvideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                intentOfvideoCall.PutExtra("from_id", "0");
                intentOfvideoCall.PutExtra("active", "0");
                intentOfvideoCall.PutExtra("status", "0");
                intentOfvideoCall.PutExtra("room_name", "TestRoom");
            }
            else if (UserData != null)
            {
                intentOfvideoCall.PutExtra("UserID", UserData.UserId);
                intentOfvideoCall.PutExtra("avatar", UserData.Avatar);
                intentOfvideoCall.PutExtra("name", UserData.Name);
                intentOfvideoCall.PutExtra("time", TimeNow);
                intentOfvideoCall.PutExtra("CallID", Time);
                intentOfvideoCall.PutExtra("access_token", "YOUR_TOKEN");
                intentOfvideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                intentOfvideoCall.PutExtra("from_id", "0");
                intentOfvideoCall.PutExtra("active", "0");
                intentOfvideoCall.PutExtra("status", "0");
                intentOfvideoCall.PutExtra("room_name", "TestRoom");
            }

            StartActivity(intentOfvideoCall);
        }

        private void OnMenuVideoCallIcon_Click()
        {

            bool granted = ContextCompat.CheckSelfPermission(ApplicationContext, Manifest.Permission.Camera) == Permission.Granted && ContextCompat.CheckSelfPermission(ApplicationContext, Manifest.Permission.RecordAudio) == Permission.Granted;
            if (granted)
            {
                StartVideoCall();
            }
            else
            {
                RequestPermissions(new[] {
                    Manifest.Permission.Camera,
                    Manifest.Permission.RecordAudio,
                    Manifest.Permission.ModifyAudioSettings
                }, 1107);
            }
        }

        //view Profile action!
        private void OnMenuViewProfile_Click()
        {
            try
            {
                if (DataUser != null)
                {
                    UserDataObject data = new UserDataObject()
                    {
                        UserId = DataUser.UserId,
                        Username = DataUser.Username,
                        Name = DataUser.Name,
                        Avatar = DataUser.Avatar,
                        Cover = DataUser.Cover,
                        Verified = DataUser.Verified,
                        Lastseen = DataUser.Lastseen,
                        LastseenUnixTime = DataUser.LastseenUnixTime,
                        LastseenTimeText = DataUser.LastseenTimeText,
                        Url = DataUser.Url,
                        ChatColor = DataUser.ChatColor,
                    };
                    WoWonderTools.OpenProfile(this, Userid, data);
                }
                else if (UserData != null)
                {
                    WoWonderTools.OpenProfile(this, Userid, UserData);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void OnMenuBlock_Click()
        {
            try
            {
                if (Methods.CheckConnectivity())
                { 
                    (int apiStatus, var respond) = await RequestsAsync.Global.Block_User(Userid, true); //true >> "block" 
                    if (apiStatus == 200)
                    {
                        Console.WriteLine(respond);

                        var dbDatabase = new SqLiteDatabase();
                        dbDatabase.Delete_UsersContact(Userid);
                        dbDatabase.Dispose();

                        Toast.MakeText(this, GetString(Resource.String.Lbl_Blocked_successfully), ToastLength.Short).Show();
                    }
                }
                else
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void OnMenuClearChat_Click()
        {
            try
            {
                Android.App.AlertDialog.Builder builder = new Android.App.AlertDialog.Builder(this, Resource.Style.AlertDialogCustom);
                 
                builder.SetTitle(GetText(Resource.String.Lbl_Clear_chat));
                builder.SetMessage(GetText(Resource.String.Lbl_AreYouSureDeleteMessages));

                builder.SetPositiveButton(GetText(Resource.String.Lbl_Yes), delegate
                {
                    try
                    {
                        MAdapter.MessageList.Clear();
                        MAdapter.NotifyDataSetChanged();

                        var userToDelete = GlobalContext?.LastMessagesTab?.MAdapter?.MLastMessagesUser?.FirstOrDefault(a => a.UserId == Userid);
                        if (userToDelete != null)
                        {
                            var index = GlobalContext.LastMessagesTab.MAdapter.MLastMessagesUser.IndexOf(userToDelete);
                            if (index != -1)
                            {
                                GlobalContext?.LastMessagesTab.MAdapter.MLastMessagesUser.Remove(userToDelete);
                                GlobalContext?.LastMessagesTab.MAdapter.NotifyItemRemoved(index);
                            }
                        }

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();
                        dbDatabase.DeleteAllMessagesUser(UserDetails.UserId, Userid);
                        dbDatabase.Dispose();

                        if (Methods.CheckConnectivity())
                        {
                            PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => RequestsAsync.Global.Delete_Conversation(Userid) });
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                });

                builder.SetNegativeButton(GetText(Resource.String.Lbl_No), delegate
                {
                    
                });

                var alert = builder.Create();
                alert.Show();               
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                //Audio FrameWork initialize 
                RecorderService = new Methods.AudioRecorderAndPlayer(AppSettings.ApplicationName);

                Interpolation = new FastOutSlowInInterpolator();
                ModeCallback = new ActionModeCallback(this);
                AllItem = new List<MessageData>();

                ChatColorBoxFragment = new ChatColorsFragment();
                Bundle args = new Bundle();
                args.PutString("userid", Userid);
                ChatColorBoxFragment.Arguments = args;

                ChatRecourdSoundBoxFragment = new ChatRecordSoundFragment();
                ChatStickersTabBoxFragment = new ChatStickersTabFragment();

                RootView = FindViewById<RelativeLayout>(Resource.Id.rootChatWindowView);
              
                ChatEmojImage = FindViewById<AppCompatImageView>(Resource.Id.emojiicon);
                EmojIconEditTextView = FindViewById<EmojiconEditText>(Resource.Id.EmojiconEditText5);
                ChatSendButton = FindViewById<CircleButton>(Resource.Id.sendButton);
                MRecycler = FindViewById<RecyclerView>(Resource.Id.recyler);
                ChatColorButton = FindViewById<CircleButton>(Resource.Id.colorButton);
                ChatStickerButton = FindViewById<CircleButton>(Resource.Id.stickerButton);
                ChatMediaButton = FindViewById<CircleButton>(Resource.Id.mediaButton);
                ChatContactButton = FindViewById<CircleButton>(Resource.Id.contactButton);
                ButtonFragmentHolder = FindViewById<FrameLayout>(Resource.Id.ButtomFragmentHolder);
                TopFragmentHolder = FindViewById<FrameLayout>(Resource.Id.TopFragmentHolder);

                SwipeRefreshLayout = FindViewById<SwipeRefreshLayout>(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);

                SupportFragmentManager.BeginTransaction().Add(ButtonFragmentHolder.Id, ChatColorBoxFragment, "ChatColorBoxFragment");
                SupportFragmentManager.BeginTransaction().Add(TopFragmentHolder.Id, ChatRecourdSoundBoxFragment, "Chat_Recourd_Sound_Fragment");

                if (AppSettings.ShowButtonRecordSound)
                {
                    ChatSendButton.LongClickable = true;
                    ChatSendButton.Tag = "Free";
                    ChatSendButton.SetImageResource(Resource.Drawable.microphone);
                }
                else
                {
                    ChatSendButton.Tag = "Text";
                    ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);
                }

                ChatSendButton.SetColor(Color.ParseColor(MainChatColor));

                if (AppSettings.ShowButtonStickers)
                {
                    ChatStickerButton.Visibility = ViewStates.Visible;
                    ChatStickerButton.Tag = "Closed";
                }
                else
                {
                    ChatStickerButton.Visibility = ViewStates.Gone;
                }

                ChatContactButton.Visibility = AppSettings.ShowButtonContact ? ViewStates.Visible : ViewStates.Gone;

                if (AppSettings.ShowButtonColor)
                {
                    ChatColorButton.Visibility = ViewStates.Visible; 
                    ChatColorButton.Tag = "Closed";
                }
                else
                {
                    ChatColorButton.Visibility = ViewStates.Gone;
                }

                if (AppSettings.SetTabDarkTheme)
                {
                    EmojIconEditTextView.SetTextColor(Color.White);
                    EmojIconEditTextView.SetHintTextColor(Color.White);
                }
                else
                {
                    EmojIconEditTextView.SetTextColor(Color.ParseColor("#444444"));
                    EmojIconEditTextView.SetHintTextColor(Color.ParseColor("#444444"));
                }

                var emoticon = new EmojIconActions(this, RootView, EmojIconEditTextView, ChatEmojImage);
                emoticon.ShowEmojIcon();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                ToolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (ToolBar != null)
                {
                    ToolBar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(ToolBar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);

                    ToolBar.SetBackgroundColor(Color.ParseColor(MainChatColor));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {   
                MAdapter = new MessageAdapter(this, Userid) { MessageList = new ObservableCollection<MessageData>() };
                LayoutManager = new LinearLayoutManager(this);
                MRecycler.SetLayoutManager(LayoutManager);
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true;
                MRecycler.SetAdapter(MAdapter);

                MAdapter.SetOnClickListener(this);

                XamarinRecyclerViewOnScrollListener xamarinRecyclerViewOnScrollListener = new XamarinRecyclerViewOnScrollListener(LayoutManager, SwipeRefreshLayout);
                xamarinRecyclerViewOnScrollListener.LoadMoreEvent += OnScrollLoadMorefromTop_Event;
                MRecycler.AddOnScrollListener(xamarinRecyclerViewOnScrollListener);
            }   
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                { 
                    ChatSendButton.Touch += ChatSendButtonOnTouch;
                    ChatMediaButton.Click += ChatMediaButtonOnClick;
                    ChatStickerButton.Click += ChatStickerButtonOnClick;
                    ChatSendButton.LongClick += ChatSendButtonOnLongClick;
                    ChatContactButton.Click += ChatContactButtonOnClick;
                    EmojIconEditTextView.TextChanged += EmojIconEditTextViewOnTextChanged;
                    ChatColorButton.Click += ChatColorButtonOnClick;
                }
                else
                { 
                    ChatSendButton.Touch -= ChatSendButtonOnTouch;
                    ChatMediaButton.Click -= ChatMediaButtonOnClick;
                    ChatStickerButton.Click -= ChatStickerButtonOnClick;
                    ChatSendButton.LongClick -= ChatSendButtonOnLongClick;
                    ChatContactButton.Click -= ChatContactButtonOnClick;
                    EmojIconEditTextView.TextChanged -= EmojIconEditTextViewOnTextChanged;
                    ChatColorButton.Click -= ChatColorButtonOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void ChatColorButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                if (ChatColorButton.Tag.ToString() == "Closed")
                {
                    ResetButtonTags();
                    ChatColorButton.Tag = "Opened";
                    ChatColorButton.Drawable.SetTint(Color.ParseColor(AppSettings.MainColor));
                    ReplaceButtomFragment(ChatColorBoxFragment);
                }
                else
                {
                    ResetButtonTags();
                    ChatColorButton.Drawable.SetTint(Color.ParseColor("#888888"));
                    TopFragmentHolder.Animate().SetInterpolator(Interpolation).TranslationY(1200).SetDuration(300);
                    SupportFragmentManager.BeginTransaction().Remove(ChatColorBoxFragment).Commit();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public static ChatWindowActivity GetInstance()
        {
            try
            {
                return Instance;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region Events

        private void EmojIconEditTextViewOnTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (AppSettings.ShowButtonRecordSound)
                {
                    if (!ButtonFragmentHolder.TranslationY.Equals(1200))
                        ButtonFragmentHolder.TranslationY = 1200;

                    if (IsRecording && EmojIconEditTextView.Text == GetString(Resource.String.Lbl_Recording))
                    {
                        ChatSendButton.Tag = "Text";
                        ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);
                    }
                    else if (!string.IsNullOrEmpty(EmojIconEditTextView.Text))
                    {
                        ChatSendButton.Tag = "Text";
                        ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);
                    }
                    else if (IsRecording)
                    {
                        ChatSendButton.Tag = "Text";
                        ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);
                    }
                    else
                    {
                        ChatSendButton.Tag = "Free";
                        ChatSendButton.SetImageResource(Resource.Drawable.microphone);
                    }
                }
                else
                {
                    ChatSendButton.Tag = "Text";
                    ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Show Load More Event when scroll to the top Of Recycle
        private async void OnScrollLoadMorefromTop_Event(object sender, EventArgs e)
        {
            try
            {
                if (RunLoadMore)
                    return;

                //Start Loader Get from Database or API Request >>
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = true;

                //Code get first Message id where LoadMore >>
                var firstMessageId = MAdapter.MessageList.FirstOrDefault()?.Id;
                if (firstMessageId != "")
                {
                    //var local = LoadMore_Messages_Database();
                    //if (local != "1")
                        await LoadMoreMessages_API(); 
                }

                SwipeRefreshLayout.Refreshing = false;
                SwipeRefreshLayout.Enabled = false;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Run Timer
        private void TimerOnElapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                RunOnUiThread(MessageUpdater);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        //Open Intent Contact (result is 506 , Permissions is 101 )
        private void ChatContactButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    //request code of result is 506
                    new IntentController(this).OpenIntentGetContactNumberPhone();
                }
                else
                {
                    //Check to see if any permission in our group is available, if one, then all are
                    if (CheckSelfPermission(Manifest.Permission.ReadContacts) == Permission.Granted)
                    {
                        //request code of result is 506
                        new IntentController(this).OpenIntentGetContactNumberPhone();
                    }
                    else
                    {
                        //101 >> ReadContacts && ReadPhoneNumbers
                        new PermissionsController(this).RequestPermission(101);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Send Sticker
        private void ChatStickerButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                if (ChatStickerButton.Tag.ToString() == "Closed")
                {
                    ResetButtonTags();
                    ChatStickerButton.Tag = "Opened";
                    ChatStickerButton.Drawable.SetTint(Color.ParseColor(AppSettings.MainColor));
                    ReplaceButtomFragment(ChatStickersTabBoxFragment);
                }
                else
                {
                    ResetButtonTags();
                    ChatStickerButton.Drawable.SetTint(Color.ParseColor("#888888"));
                    TopFragmentHolder.Animate().SetInterpolator(Interpolation).TranslationY(1200).SetDuration(300);
                    SupportFragmentManager.BeginTransaction().Remove(ChatStickersTabBoxFragment).Commit();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //record voices ( Permissions is 102 )
        private async void ChatSendButtonOnLongClick(object sender, View.LongClickEventArgs e)
        {
            try
            {
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    if (ChatSendButton.Tag.ToString() == "Free")
                    {
                        //Set Record Style
                        IsRecording = true;

                        if (SettingsPrefsFragment.SSoundControl)
                            Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("RecourdVoiceButton.mp3");

                        if (EmojIconEditTextView.Text != GetString(Resource.String.Lbl_Recording))
                        {
                            EmojIconEditTextView.Text = GetString(Resource.String.Lbl_Recording);
                            EmojIconEditTextView.SetTextColor(Color.ParseColor("#FA3C4C"));
                        }

                        ChatSendButton.SetColor(Color.ParseColor("#FA3C4C"));
                        ChatSendButton.SetImageResource(Resource.Drawable.ic_stop_white_24dp);

                        RecorderService = new Methods.AudioRecorderAndPlayer(AppSettings.ApplicationName);
                        //Start Audio record
                        await Task.Delay(600);
                        RecorderService.StartRecourding();
                    }
                }
                else
                {
                    //Check to see if any permission in our group is available, if one, then all are
                    if (CheckSelfPermission(Manifest.Permission.RecordAudio) == Permission.Granted)
                    {
                        if (ChatSendButton.Tag.ToString() == "Free")
                        {
                            //Set Record Style
                            IsRecording = true;

                            if (SettingsPrefsFragment.SSoundControl)
                                Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("RecourdVoiceButton.mp3");

                            if (EmojIconEditTextView.Text != GetString(Resource.String.Lbl_Recording))
                            {
                                EmojIconEditTextView.Text = GetString(Resource.String.Lbl_Recording);
                                EmojIconEditTextView.SetTextColor(Color.ParseColor("#FA3C4C"));
                            }

                            ChatSendButton.SetColor(Color.ParseColor("#FA3C4C"));
                            ChatSendButton.SetImageResource(Resource.Drawable.ic_stop_white_24dp);

                            RecorderService = new Methods.AudioRecorderAndPlayer(AppSettings.ApplicationName);
                            //Start Audio record
                            await Task.Delay(600);
                            RecorderService.StartRecourding();
                        }
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(102);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        // Event sent media (image , Camera , video , file , music )
        private void ChatMediaButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    var arrayAdapter = new List<string>();
                    var dialogList = new MaterialDialog.Builder(this);

                    if (AppSettings.ShowButtonImage)
                        arrayAdapter.Add(GetText(Resource.String.Btn_Image));
                    if (AppSettings.ShowButtonCamera)
                        arrayAdapter.Add(GetText(Resource.String.Camera));
                    if (AppSettings.ShowButtonVideo)
                        arrayAdapter.Add(GetText(Resource.String.Btn_Video));
                    if (AppSettings.ShowButtonAttachFile)
                        arrayAdapter.Add(GetText(Resource.String.Lbl_File));
                    if (AppSettings.ShowButtonMusic)
                        arrayAdapter.Add(GetText(Resource.String.Lbl_Music));
                    if (AppSettings.ShowButtonGif)
                        arrayAdapter.Add(GetText(Resource.String.Lbl_Gif));

                    dialogList.Title(GetString(Resource.String.Lbl_Select_what_you_want));
                    dialogList.Items(arrayAdapter);
                    dialogList.PositiveText(GetText(Resource.String.Lbl_Close)).OnPositive(this);
                    dialogList.AlwaysCallSingleChoiceCallback();
                    dialogList.ItemsCallback(this).Build().Show();
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ChatSendButtonOnTouch(object sender, View.TouchEventArgs e)
        {
            try
            {
                var handled = false;

                if (e.Event.Action == MotionEventActions.Down)
                {
                    OnClick_OfSendButton();
                }

                if (e.Event.Action == MotionEventActions.Up)
                {
                    try
                    {
                        if (IsRecording)
                        {
                            RecorderService.StopRecourding();
                            var filePath = RecorderService.GetRecorded_Sound_Path();

                            ChatSendButton.SetColor(Color.ParseColor(MainChatColor));
                            ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);

                            if (EmojIconEditTextView.Text == GetString(Resource.String.Lbl_Recording))
                            {
                                if (!string.IsNullOrEmpty(filePath))
                                {
                                    Bundle bundle = new Bundle();
                                    bundle.PutString("FilePath", filePath);
                                    ChatRecourdSoundBoxFragment.Arguments = bundle;
                                    ReplaceTopFragment(ChatRecourdSoundBoxFragment);
                                }

                                EmojIconEditTextView.Text = "";
                                EmojIconEditTextView.SetTextColor(Color.ParseColor("#444444"));
                            }

                            IsRecording = false;
                        }
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    }

                    ChatSendButton.Pressed = false;
                    handled = true;
                }

                e.Handled = handled;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Send Message type => "right_audio" Or "right_text"
        private void OnClick_OfSendButton()
        {
            try
            {
                IsRecording = false;

                UnixTimestamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                var time2 = UnixTimestamp.ToString();

                if (ChatSendButton.Tag.ToString() == "Audio")
                {
                    var interPolator = new FastOutSlowInInterpolator();
                    TopFragmentHolder.Animate().SetInterpolator(interPolator).TranslationY(1200).SetDuration(300);
                    SupportFragmentManager.BeginTransaction().Remove(ChatRecourdSoundBoxFragment).Commit();

                    string filePath = RecorderService.GetRecorded_Sound_Path();
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        MessageData m1 = new MessageData
                        {
                            Id = time2,
                            FromId = UserDetails.UserId,
                            ToId = Userid,
                            Media = filePath,
                            Position = "right",
                            TimeText = GetText(Resource.String.Lbl_Uploading),
                            MediaDuration = Methods.AudioRecorderAndPlayer.GetTimeString(Methods.AudioRecorderAndPlayer.Get_MediaFileDuration(filePath)),
                            Type = "right_audio"
                        };

                        MAdapter.MessageList.Add(m1);
                        var index = MAdapter.MessageList.IndexOf(m1);
                        if (index > -1)
                        {
                            MAdapter.NotifyItemInserted(index);
                            //Scroll Down >> 
                            MRecycler.ScrollToPosition(index);
                        }
                         
                        //Here on This function will send Selected audio file to the user 
                        if (Methods.CheckConnectivity())
                        {
                            Task.Run(() =>
                            {
                                MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", filePath).ConfigureAwait(false);
                            });
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                        }
                    }

                    ChatSendButton.Tag = "Free";
                    ChatSendButton.SetImageResource(Resource.Drawable.microphone);

                }
                else if (ChatSendButton.Tag.ToString() == "Text")
                {
                    if (String.IsNullOrEmpty(EmojIconEditTextView.Text))
                    {

                    }
                    else
                    {
                        //Here on This function will send Text Messages to the user 

                        //remove \n in a string
                        string replacement = Regex.Replace(EmojIconEditTextView.Text, @"\t|\n|\r", "");

                        MessageData m1 = new MessageData
                        {
                            Id = time2,
                            FromId = UserDetails.UserId,
                            ToId = Userid,
                            Text = replacement,
                            Position = "right",
                            Type = "right_text",
                            TimeText = TimeNow,
                            ProductId = "0"
                        };

                        MAdapter.MessageList.Add(m1);
                        var index = MAdapter.MessageList.IndexOf(m1);
                        if (index > -1)
                        {
                            MAdapter.NotifyItemInserted(index);
                            //Scroll Down >> 
                            MRecycler.ScrollToPosition(index);
                        }

                        if (Methods.CheckConnectivity())
                        {
                            Task.Run(() =>
                            {
                                MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text).ConfigureAwait(false);
                            });
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                        }

                        EmojIconEditTextView.Text = "";
                    }

                    if (AppSettings.ShowButtonRecordSound)
                    {
                        ChatSendButton.SetImageResource(Resource.Drawable.microphone);
                        ChatSendButton.Tag = "Free";
                    }
                    else
                    {
                        ChatSendButton.Tag = "Text";
                        ChatSendButton.SetImageResource(Resource.Drawable.SendLetter);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                TimeNow = DateTime.Now.ToString("hh:mm");
                UnixTimestamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                var time2 = UnixTimestamp.ToString();

                base.OnActivityResult(requestCode, resultCode, data);
                if (requestCode == 506 && resultCode == Result.Ok) // right_contact
                {
                    var contact = Methods.PhoneContactManager.Get_ContactInfoBy_Id(data.Data.LastPathSegment);
                    if (contact != null)
                    {
                        var name = contact.UserDisplayName;
                        var phone = contact.PhoneNumber;

                        MessageData m1 = new MessageData
                        {
                            Id = time2,
                            FromId = UserDetails.UserId,
                            ToId = Userid,
                            ContactName = name,
                            ContactNumber = phone,
                            TimeText = TimeNow,
                            Position = "right",
                            Type = "right_contact"
                        };
                        MAdapter.MessageList.Add(m1);
                        var index = MAdapter.MessageList.IndexOf(m1);
                        if (index > -1)
                        {
                            MAdapter.NotifyItemInserted(index);
                            //Scroll Down >> 
                            MRecycler.ScrollToPosition(index);
                        }

                        var dictionary = new Dictionary<string, string>();

                        if (!dictionary.ContainsKey(name))
                        {
                            dictionary.Add(name, phone);
                        }

                        string dataContact = JsonConvert.SerializeObject(dictionary.ToArray().FirstOrDefault(a => a.Key == name));

                        if (Methods.CheckConnectivity())
                        {
                            //Send contact function
                            Task.Run(() =>
                            {
                                MessageController.SendMessageTask(this, Userid, time2, dataContact, "1").ConfigureAwait(false);
                            });
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                        }
                    }
                }
                else if (requestCode == 500 && resultCode == Result.Ok) // right_image 
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Image")
                        {
                            MessageData m1 = new MessageData
                            {
                                Id = time2,
                                FromId = UserDetails.UserId,
                                ToId = Userid,
                                Media = filepath,
                                Position = "right",
                                Type = "right_image",
                                TimeText = TimeNow
                            };
                            MAdapter.MessageList.Add(m1);
                            var index = MAdapter.MessageList.IndexOf(m1);
                            if (index > -1)
                            {
                                MAdapter.NotifyItemInserted(index);
                                //Scroll Down >> 
                                MRecycler.ScrollToPosition(index);
                            }

                            //Send image function
                            if (Methods.CheckConnectivity())
                            {
                                Task.Run(() =>
                                {
                                    MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", filepath).ConfigureAwait(false);
                                });
                            }
                            else
                            {
                                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_Please_check_your_details), ToastLength.Long).Show();
                        }
                    } 
                }
                else if (requestCode == CropImage.CropImageActivityRequestCode) // right_image 
                {
                    var result = CropImage.GetActivityResult(data);
                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                MessageData m1 = new MessageData
                                {
                                    Id = time2,
                                    FromId = UserDetails.UserId,
                                    ToId = Userid,
                                    Media = resultUri.Path,
                                    Position = "right",
                                    Type = "right_image",
                                    TimeText = TimeNow
                                };
                                MAdapter.MessageList.Add(m1);
                                var index = MAdapter.MessageList.IndexOf(m1);
                                if (index > -1)
                                {
                                    MAdapter.NotifyItemInserted(index);
                                    //Scroll Down >> 
                                    MRecycler.ScrollToPosition(index);
                                }

                                //Send image function
                                if (Methods.CheckConnectivity())
                                {
                                    Task.Run(() =>
                                    {
                                        MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", resultUri.Path).ConfigureAwait(false);
                                    });
                                }
                                else
                                {
                                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                            }
                        } 
                    } 
                }
                else if (requestCode == 503 && resultCode == Result.Ok) // Add right_image using camera   
                {
                    if (IntentController.ImageCameraUri == null)
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                        return;
                    }

                    var thumbnail = MediaStore.Images.Media.GetBitmap(ContentResolver, IntentController.ImageCameraUri);
                    Console.WriteLine(thumbnail);

                    var path = GetRealPathFromUri(IntentController.ImageCameraUri);
                    if (Methods.MultiMedia.CheckFileIfExits(path) != "File Dont Exists")
                    {
                        MessageData m1 = new MessageData
                        {
                            Id = time2,
                            FromId = UserDetails.UserId,
                            ToId = Userid,
                            Media = path,
                            Position = "right",
                            Type = "right_image",
                            TimeText = TimeNow
                        };
                        MAdapter.MessageList.Add(m1);
                        var index = MAdapter.MessageList.IndexOf(m1);
                        if (index > -1)
                        {
                            MAdapter.NotifyItemInserted(index);
                            //Scroll Down >> 
                            MRecycler.ScrollToPosition(index);
                        }

                        //Send image function
                        if (Methods.CheckConnectivity())
                        {
                            Task.Run(() =>
                            {
                                MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", path).ConfigureAwait(false);
                            });
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                        }
                    }
                }
                else if (requestCode == 501 && resultCode == Result.Ok) // right_video 
                {
                    string fullPath = Methods.MultiMedia.GetRealVideoPathFromUri(data.Data);
                    if (!string.IsNullOrEmpty(fullPath))
                    {
                        var newCopyedFilepath = Methods.MultiMedia.CopyMediaFileTo(fullPath, Methods.Path.FolderDcimVideo, false, true);
                        if (newCopyedFilepath != "Path File Dont exits")
                        {
                            MessageData m1 = new MessageData
                            {
                                Id = time2,
                                FromId = UserDetails.UserId,
                                ToId = Userid,
                                Media = newCopyedFilepath,
                                Position = "right",
                                Type = "right_video",
                                TimeText = TimeNow
                            };
                            MAdapter.MessageList.Add(m1);
                            var index = MAdapter.MessageList.IndexOf(m1);
                            if (index > -1)
                            {
                                MAdapter.NotifyItemInserted(index);
                                //Scroll Down >> 
                                MRecycler.ScrollToPosition(index);
                            }

                            //Send Video function
                            if (Methods.CheckConnectivity())
                            {
                                Task.Run(() =>
                                {
                                    MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", newCopyedFilepath).ConfigureAwait(false);
                                });
                            }
                            else
                            {
                                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_Please_check_your_details), ToastLength.Long).Show();
                        }
                    }
                }
                else if (requestCode == 504 && resultCode == Result.Ok) // right_file
                {
                    string filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        string totalSize = Methods.FunString.Format_byte_size(filepath);
                        MessageData m1 = new MessageData
                        {
                            Id = time2,
                            FromId = UserDetails.UserId,
                            ToId = Userid,
                            Media = filepath,
                            FileSize = totalSize,
                            TimeText = TimeNow,
                            Position = "right",
                            Type = "right_file"
                        };
                        MAdapter.MessageList.Add(m1);
                        var index = MAdapter.MessageList.IndexOf(m1);
                        if (index > -1)
                        {
                            MAdapter.NotifyItemInserted(index);
                            //Scroll Down >> 
                            MRecycler.ScrollToPosition(index);
                        }

                        //Send Video function
                        if (Methods.CheckConnectivity())
                        {
                            Task.Run(() =>
                            {
                                MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", filepath).ConfigureAwait(false);
                            });
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                        }
                    }
                    else
                    {
                        string src = GetPath(data.Data);
                        if (src != null)
                        { 
                            Toast.MakeText(this, GetString(Resource.String.Lbl_FileNotDeviceMemory), ToastLength.Long).Show();
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_Please_check_your_details), ToastLength.Long).Show(); 
                        } 
                    }
                }
                else if (requestCode == 505 && resultCode == Result.Ok) // right_audio
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Audio")
                        {
                            var newCopyedFilepath = Methods.MultiMedia.CopyMediaFileTo(filepath, Methods.Path.FolderDcimSound, false, true);
                            if (newCopyedFilepath != "Path File Dont exits")
                            {
                                string totalSize = Methods.FunString.Format_byte_size(filepath);
                                MessageData m1 = new MessageData
                                {
                                    Id = time2,
                                    FromId = UserDetails.UserId,
                                    ToId = Userid,
                                    Media = newCopyedFilepath,
                                    FileSize = totalSize,
                                    Position = "right",
                                    TimeText = GetText(Resource.String.Lbl_Uploading),
                                    MediaDuration = Methods.AudioRecorderAndPlayer.GetTimeString(Methods.AudioRecorderAndPlayer.Get_MediaFileDuration(filepath)),
                                    Type = "right_audio"
                                };

                                MAdapter.MessageList.Add(m1);
                                var index = MAdapter.MessageList.IndexOf(m1);
                                if (index > -1)
                                {
                                    MAdapter.NotifyItemInserted(index);
                                    //Scroll Down >> 
                                    MRecycler.ScrollToPosition(index);
                                }

                                //Send Video function
                                if (Methods.CheckConnectivity())
                                {
                                    Task.Run(() =>
                                    {
                                        MessageController.SendMessageTask(this, Userid, time2, "", "", filepath).ConfigureAwait(false);
                                    });
                                }
                                else
                                {
                                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                                }
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                    }
                }
                else if (requestCode == 300 && resultCode == Result.Ok) // right_gif
                {
                    // G_fixed_height_small_url, // UrlGif - view  >>  mediaFileName
                    // G_fixed_height_small_mp4, //MediaGif - sent >>  media

                    var gifLink = data.GetStringExtra("MediaGif") ?? "Data not available";
                    if (gifLink != "Data not available" && !string.IsNullOrEmpty(gifLink))
                    {
                        var gifUrl = data.GetStringExtra("UrlGif") ?? "Data not available";
                        GifFile = gifLink;

                        MessageData m1 = new MessageData
                        {
                            Id = time2,
                            FromId = UserDetails.UserId,
                            ToId = Userid,
                            Media = GifFile,
                            MediaFileName = gifUrl,
                            Position = "right",
                            Type = "right_gif",
                            TimeText = TimeNow,
                            Stickers = gifUrl,
                        };

                        MAdapter.MessageList.Add(m1);
                        var index = MAdapter.MessageList.IndexOf(m1);
                        if (index > -1)
                        {
                            MAdapter.NotifyItemInserted(index);
                            //Scroll Down >> 
                            MRecycler.ScrollToPosition(index);
                        }

                        //Send image function
                        if (Methods.CheckConnectivity())
                        {
                            Task.Run(() =>
                            {
                                MessageController.SendMessageTask(this, Userid, time2, EmojIconEditTextView.Text, "", "", "", "", gifUrl).ConfigureAwait(false);
                            });
                        }
                        else
                        {
                            Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_Please_check_your_details) + " ", ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private string GetPath(Uri uri)
        {
            try
            {
                string path;
                string[] projection = { MediaStore.Files.FileColumns.Data, "text/plain", "text/html", "application/pdf", "audio/mp3", "video/mp4", "text/plain", "application/msword", "image/jpeg", "image/png", "text/html" };
                var cursor = ContentResolver.Query(uri, projection, null, null, null);

                if (cursor == null)
                {
                    path = uri.Path;
                }
                else
                {
                    cursor.MoveToFirst();
                    int columnIndex = cursor.GetColumnIndexOrThrow(projection[0]);
                    path = cursor.GetString(columnIndex);
                    cursor.Close();
                }

                return ((path == null || string.IsNullOrEmpty(path)) ? (uri.Path) : path);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }


        //Permissions
        public override async void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        switch (PermissionsType)
                        {
                            //requestCode >> 500 => Image Gallery
                            case "Image" when AppSettings.ImageCropping:
                                OpenDialogGallery("Image");
                                break;
                            case "Image": //requestCode >> 500 => Image Gallery
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures), false);
                                break;
                            case "Video":
                                //requestCode >> 501 => video Gallery
                                new IntentController(this).OpenIntentVideoGallery();
                                break;
                            case "Camera":
                                //requestCode >> 503 => Camera
                                new IntentController(this).OpenIntentCamera();
                                break;
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 100)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        switch (PermissionsType)
                        {
                            case "File":
                                //requestCode >> 504 => File
                                new IntentController(this).OpenIntentFile(GetText(Resource.String.Lbl_SelectFile));
                                break;
                            case "Music":
                                //requestCode >> 505 => Music
                                new IntentController(this).OpenIntentAudio();
                                break;
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 101)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        //request code of result is 506
                        new IntentController(this).OpenIntentGetContactNumberPhone();
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 102)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        if (ChatSendButton.Tag.ToString() == "Free")
                        {
                            //Set Record Style
                            IsRecording = true;

                            if (SettingsPrefsFragment.SSoundControl)
                                Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("RecourdVoiceButton.mp3");

                            if (EmojIconEditTextView.Text != GetString(Resource.String.Lbl_Recording))
                            {
                                EmojIconEditTextView.Text = GetString(Resource.String.Lbl_Recording);
                                EmojIconEditTextView.SetTextColor(Color.ParseColor("#FA3C4C"));
                            }

                            ChatSendButton.SetColor(Color.ParseColor("#FA3C4C"));
                            ChatSendButton.SetImageResource(Resource.Drawable.ic_stop_white_24dp);

                            RecorderService = new Methods.AudioRecorderAndPlayer(AppSettings.ApplicationName);
                            //Start Audio record
                            await Task.Delay(600);
                            RecorderService.StartRecourding();
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 1106) //Audio Call
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        StartCall();
                    }
                    else
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 1107) //Video call
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        StartVideoCall();
                    }
                    else
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                if (itemString.ToString() == GetText(Resource.String.Btn_Image)) // image 
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        if (AppSettings.ImageCropping)
                            OpenDialogGallery("Image"); //requestCode >> 500 => Image Gallery
                        else
                            new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures), false); //requestCode >> 500 => Image Gallery
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                  && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            if (AppSettings.ImageCropping)
                                OpenDialogGallery("Image"); //requestCode >> 500 => Image Gallery
                            else
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures), false); //requestCode >> 500 => Image Gallery
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(108);
                        }
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.Camera)) // Camera 
                {
                    PermissionsType = "Camera";

                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        //requestCode >> 503 => Camera
                        new IntentController(this).OpenIntentCamera();
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                  && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            //requestCode >> 503 => Camera
                            new IntentController(this).OpenIntentCamera();
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(108);
                        }
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.Btn_Video)) // video  
                {
                    PermissionsType = "Video";

                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        //requestCode >> 501 => video Gallery
                        new IntentController(this).OpenIntentVideoGallery();
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                  && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            //requestCode >> 501 => video Gallery
                            new IntentController(this).OpenIntentVideoGallery();
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(108);
                        }
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.Lbl_File)) // File  
                {
                    PermissionsType = "File";

                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        //requestCode >> 504 => File
                        new IntentController(this).OpenIntentFile(GetText(Resource.String.Lbl_SelectFile));
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                            CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            //requestCode >> 504 => File
                            new IntentController(this).OpenIntentFile(GetText(Resource.String.Lbl_SelectFile));
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(100);
                        }
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.Lbl_Music)) // Music  
                {
                    PermissionsType = "Music";

                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                        new IntentController(this).OpenIntentAudio(); //505
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            new IntentController(this).OpenIntentAudio(); //505
                        else
                            new PermissionsController(this).RequestPermission(100);
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.Lbl_Gif)) // Gif  
                {
                    StartActivityForResult(new Intent(this, typeof(GifActivity)), 300);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region loadData
         
        private void FirstLoadData_Item()
        {
            try
            {
                Methods.Path.Chack_MyFolder();
                  
                if (TypeChat == "LastMessenger")
                {
                    DataUser = JsonConvert.DeserializeObject<GetUsersListObject.User>(Intent.GetStringExtra("UserItem")); 
                    if (DataUser != null)
                    {
                        if (DataUser.ChatColor == null)
                            DataUser.ChatColor = AppSettings.MainColor;

                        if (!ColorChanged)
                            MainChatColor = !string.IsNullOrEmpty(DataUser.ChatColor) ? DataUser.ChatColor.Contains("rgb") ? Methods.FunString.ConvertColorRgBtoHex(DataUser.ChatColor) : DataUser.ChatColor : AppSettings.MainColor ?? AppSettings.MainColor;

                    }
                    else
                    { 
                        if (!ColorChanged)
                            MainChatColor = AppSettings.MainColor;
                    }
                }
                else
                {
                    UserData = JsonConvert.DeserializeObject<UserDataObject>(Intent.GetStringExtra("UserItem"));
                    if (UserData != null)
                    {
                        if (UserData.ChatColor == null)
                            UserData.ChatColor = AppSettings.MainColor;

                        if (!ColorChanged)
                            MainChatColor = UserData.ChatColor.Contains("rgb") ? Methods.FunString.ConvertColorRgBtoHex(UserData.ChatColor) : UserData.ChatColor ?? AppSettings.MainColor;

                    }
                    else
                    {
                        if (!ColorChanged)
                            MainChatColor = AppSettings.MainColor; 
                    }
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadData_ItemUser()
        {
            try
            {
                if (TypeChat == "LastMessenger")
                {
                    if (DataUser != null)
                    {
                        SupportActionBar.Title = Methods.FunString.DecodeString(DataUser.Name);

                        //Online Or offline
                        if (DataUser.Lastseen == "on")
                        {
                            SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Online);
                            LastSeen = GetString(Resource.String.Lbl_Online);
                        }
                        else
                        {
                            SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Last_seen) + " " + Methods.Time.TimeAgo(int.Parse(DataUser.LastseenUnixTime),false);
                            LastSeen = GetString(Resource.String.Lbl_Last_seen) + " " + Methods.Time.TimeAgo(int.Parse(DataUser.LastseenUnixTime), false);
                        }
                    }
                }
                else
                {
                    if (UserData != null)
                    {
                        SupportActionBar.Title = Methods.FunString.DecodeString(UserData.Name);

                        //Online Or offline
                        if (UserData.Lastseen == "on")
                        {
                            SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Online);
                            LastSeen = GetString(Resource.String.Lbl_Online);
                        }
                        else
                        {
                            SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Last_seen) + " " + Methods.Time.TimeAgo(int.Parse(UserData.LastseenUnixTime), false);
                            LastSeen = GetString(Resource.String.Lbl_Last_seen) + " " + Methods.Time.TimeAgo(int.Parse(UserData.LastseenUnixTime), false);
                        }
                    }
                }

                GetMessages();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void GetMessages()
        {
            try
            {
                MAdapter.MessageList.Clear();
                MAdapter.NotifyDataSetChanged();

                var onScrollListener = new XamarinRecyclerViewOnScrollListener(LayoutManager, SwipeRefreshLayout);
                onScrollListener.LoadMoreEvent += OnScrollLoadMorefromTop_Event;
                MRecycler.AddOnScrollListener(onScrollListener);

                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                var localList = dbDatabase.GetMessages_CredentialsList(UserDetails.UserId, Userid, "0"); 
                if (localList == "1") //Database.. Get Messages Local
                {
                    MAdapter.NotifyDataSetChanged();

                    //Scroll Down >> 
                    MRecycler.ScrollToPosition(MAdapter.MessageList.IndexOf(MAdapter.MessageList.LastOrDefault()));
                    SwipeRefreshLayout.Refreshing = false;
                    SwipeRefreshLayout.Enabled = false;
                }
                else //Or server.. Get Messages Api
                {
                    SwipeRefreshLayout.Refreshing = true;
                    SwipeRefreshLayout.Enabled = true;
                    GetMessages_Api();
                }

                TaskWork = "Working";

                //Run timer
                Timer = new Timer();
                Timer.Interval = AppSettings.MessageRequestSpeed;
                Timer.Elapsed += TimerOnElapsed;
                Timer.Enabled = true;
                Timer.Start();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void GetMessages_Api()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    (int apiStatus, var respond) = await ApiRequest.FetchUserChatMessages(Userid);
                    if (apiStatus == 200)
                    {
                        if (respond is UserChatMessagesObject result)
                        {
                            var respondList = result.Messages.Count;
                            if (respondList > 0)
                            {
                                result.Messages.Reverse();
                                  
                                foreach (var item in from item in result.Messages let check = MAdapter.MessageList.FirstOrDefault(a => a.Id == item.Id) where check == null select item)
                                {
                                    MAdapter.MessageList.Add(WoWonderTools.MessageFilter(Userid,item));
                                }

                                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                                // Insert data user in database
                                dbDatabase.Insert_Or_Replace_MessagesTable(MAdapter.MessageList);
                                dbDatabase.Dispose();

                                RunOnUiThread(() =>
                                {
                                    try
                                    {
                                        MAdapter.NotifyDataSetChanged();
                                        //Scroll Down >> 
                                        MRecycler.ScrollToPosition(MAdapter.MessageList.IndexOf(MAdapter.MessageList.LastOrDefault()));
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine(e);
                                    }
                                }); 
                            } 
                        }
                    }
                    else Methods.DisplayReportResult(this, respond);
                     
                    SwipeRefreshLayout.Refreshing = false;
                    SwipeRefreshLayout.Enabled = false;
                }
                else Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private async void MessageUpdater()
        {
            try
            {
                if (TaskWork == "Working")
                {
                    TaskWork = "Stop";

                    if (Methods.CheckConnectivity())
                    {
                        var data = MAdapter.MessageList.LastOrDefault();
                        var lastMessageId = data?.Id;
                        (int apiStatus, var respond) = await ApiRequest.FetchUserChatMessages(Userid, "0", lastMessageId);
                        if (apiStatus == 200)
                        {
                            if (respond is UserChatMessagesObject result)
                            {
                                var respondList = result.Messages.Count;
                                if (respondList > 0)
                                { 
                                    foreach (var item in from item in result.Messages let check = MAdapter.MessageList.FirstOrDefault(a => a.Id == item.Id) where check == null select item)
                                    {
                                        MAdapter.MessageList.Add(WoWonderTools.MessageFilter(Userid, item)); 
                                        RunOnUiThread(() =>
                                        {
                                            MAdapter?.NotifyItemInserted(MAdapter.MessageList.IndexOf(MAdapter.MessageList.LastOrDefault()));

                                            var indexMes = MAdapter.MessageList.IndexOf(data);
                                            if (indexMes > -1)
                                            {
                                                //Scroll Down >> 
                                                MRecycler.ScrollToPosition(MAdapter.MessageList.IndexOf(MAdapter.MessageList.LastOrDefault()));
                                            } 
                                        });

                                        var dataUser = GlobalContext?.LastMessagesTab?.MAdapter?.MLastMessagesUser?.FirstOrDefault(a => a.UserId == item.FromId);
                                        if (dataUser != null)
                                        {
                                            if (item.UserData != null)
                                            {
                                                dataUser.UserId = item.UserData.UserId;
                                                dataUser.Avatar = item.UserData.Avatar;
                                            }
                                                 
                                            dataUser.ChatColor = MainChatColor;

                                            //last_message
                                            dataUser.LastMessage = new GetUsersListObject.LastMessage
                                            {
                                                Id = item.Id,
                                                FromId = item.FromId,
                                                GroupId = item.GroupId,
                                                ToId = item.ToId,
                                                Text = item.Text,
                                                Media = item.Media,
                                                MediaFileName = item.MediaFileName,
                                                MediaFileNames = item.MediaFileNames,
                                                Time = item.Time,
                                                Seen = "1",
                                                DeletedOne = item.DeletedOne,
                                                DeletedTwo = item.DeletedTwo,
                                                SentPush = item.SentPush,
                                                NotificationId = item.NotificationId,
                                                TypeTwo = item.TypeTwo,
                                                Stickers = item.Stickers
                                                // DateTime = dateTime,
                                            };

                                            var index = GlobalContext?.LastMessagesTab?.MAdapter?.MLastMessagesUser?.IndexOf(dataUser);
                                            if (index > -1 && index != 0)
                                            { 
                                                GlobalContext?.LastMessagesTab.MAdapter.MLastMessagesUser.Move(Convert.ToInt32(index), 0);
                                                GlobalContext?.LastMessagesTab.MAdapter.NotifyItemMoved(Convert.ToInt32(index), 0);
                                            }
                                        }

                                        if (SettingsPrefsFragment.SSoundControl)
                                            Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("Popup_GetMesseges.mp3");
                                    }
                                     
                                    SqLiteDatabase dbDatabase = new SqLiteDatabase();
                                    // Insert data user in database
                                    dbDatabase.Insert_Or_Replace_MessagesTable(MAdapter.MessageList);
                                    dbDatabase.Dispose();
                                }
                            }
                        }
                        else Methods.DisplayReportResult(this, respond);
                    }
                    else Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();

                    TaskWork = "Working";
                }
            }
            catch (Exception e)
            {
                TaskWork = "Working";
                Console.WriteLine(e);
            }
        }

        private string LoadMore_Messages_Database()
        {
            try
            {
                if (RunLoadMore)
                    return "";

                RunLoadMore = true;

                SqLiteDatabase dbDatabase = new SqLiteDatabase();

                var firstMessageId = MAdapter.MessageList.FirstOrDefault()?.Id ?? "0";
                var index = MAdapter.MessageList.IndexOf(MAdapter.MessageList.FirstOrDefault());

                var localList = dbDatabase.GetMessageList(UserDetails.UserId, Userid, firstMessageId);
                if (localList?.Count > 0) //Database.. Get Messages Local
                { 
                    foreach (var m in from message in localList let check = MAdapter.MessageList.FirstOrDefault(a => a.Id == message.Id) where check == null select new MessageData
                    {
                        Id = message.Id,
                        FromId = message.FromId,
                        GroupId = message.GroupId,
                        ToId = message.ToId,
                        Text = message.Text,
                        Media = message.Media,
                        MediaFileName = message.MediaFileName,
                        MediaFileNames = message.MediaFileNames,
                        Time = message.Time,
                        Seen = message.Seen,
                        DeletedOne = message.DeletedOne,
                        DeletedTwo = message.DeletedTwo,
                        SentPush = message.SentPush,
                        NotificationId = message.NotificationId,
                        TypeTwo = message.TypeTwo,
                        Stickers = message.Stickers,
                        TimeText = message.TimeText,
                        Position = message.Position,
                        Type = message.Type,
                        FileSize = message.FileSize,
                        MessageUser = JsonConvert.DeserializeObject<UserDataObject>(message.MessageUser),
                        ContactName = message.ContactName,
                        ContactNumber = message.ContactNumber,
                        ChatColor = MainChatColor
                    })
                    {
                        MAdapter.Insert(WoWonderTools.MessageFilter(Userid, m), firstMessageId);
                    }

                    if (SwipeRefreshLayout.Refreshing)
                    {
                        SwipeRefreshLayout.Refreshing = false;
                        SwipeRefreshLayout.Enabled = false;
                    }

                    dbDatabase.Dispose();
                    RunLoadMore = false;
                    return "1";
                }

                if (SwipeRefreshLayout.Refreshing)
                {
                    SwipeRefreshLayout.Refreshing = false;
                    SwipeRefreshLayout.Enabled = false;
                }

                dbDatabase.Dispose();
                RunLoadMore = false;
                return "0";
            }
            catch (Exception e)
            {
                RunLoadMore = false;
                Console.WriteLine(e);
                return "0";
            }
        }

        private bool RunLoadMore;
        private async Task LoadMoreMessages_API()
        {
            try
            { 
                if (Methods.CheckConnectivity())
                {
                    if (RunLoadMore)
                        return;

                    RunLoadMore = true;

                    var data = MAdapter.MessageList.FirstOrDefault();
                    var firstMessageId = data?.Id;

                    (int apiStatus, var respond) = await ApiRequest.FetchUserChatMessages(Userid, firstMessageId);
                    if (apiStatus == 200)
                    {
                        if (respond is UserChatMessagesObject result)
                        { 
                            var respondList = result.Messages.Count;
                            if (respondList > 0)
                            { 
                                foreach (var item in from item in result.Messages let check = MAdapter.MessageList.FirstOrDefault(a => a.Id == item.Id) where check == null select item)
                                {
                                    MAdapter.Insert(WoWonderTools.MessageFilter(Userid, item), firstMessageId);
                                }
                                
                                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                                // Insert data user in database
                                dbDatabase.Insert_Or_Replace_MessagesTable(MAdapter.MessageList);
                                dbDatabase.Dispose();
                            }
                        }
                    }
                    else Methods.DisplayReportResult(this, respond);

                    if (SwipeRefreshLayout.Refreshing)
                    {
                        SwipeRefreshLayout.Refreshing = false;
                        SwipeRefreshLayout.Enabled = false;
                    }

                    RunLoadMore = false;
                }
                else Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                RunLoadMore = false;
                Console.WriteLine(e);
            }
        }

        //Get Data User API
        private async void Get_UserProfileData_Api()
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    var (apiStatus, respond) = await RequestsAsync.Global.Get_User_Data(Userid);
                    if (apiStatus == 200)
                    {
                        if (respond is GetUserDataObject result)
                        {
                            //Add Data User
                            //=======================================
                            if (result.UserData != null)
                            { 
                                RunOnUiThread(() =>
                                {
                                    try
                                    {
                                        SupportActionBar.Title = Methods.FunString.DecodeString(result.UserData.Name);

                                        //Online Or offline
                                        if (result.UserData.LastseenStatus == "on")
                                        {
                                            SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Online);
                                            LastSeen = GetString(Resource.String.Lbl_Online);
                                        }
                                        else
                                        {
                                            SupportActionBar.Subtitle = GetString(Resource.String.Lbl_Last_seen) + " " + Methods.Time.TimeAgo(int.Parse(result.UserData.LastseenUnixTime), false);
                                            LastSeen = GetString(Resource.String.Lbl_Last_seen) + " " + Methods.Time.TimeAgo(int.Parse(result.UserData.LastseenUnixTime), false);
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine(e);
                                    }
                                });
                            }
                        }
                    }
                    else Methods.DisplayReportResult(this, respond);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Get_UserProfileData_Api();
            }
        }
         
        #endregion

        public void ResetButtonTags()
        {
            try
            {
                ChatStickerButton.Tag = "Closed";
                ChatColorButton.Tag = "Closed";
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnBackPressed()
        {
            try
            {
                int count = MAdapter.GetSelectedItemCount();
                if (SupportFragmentManager.BackStackEntryCount > 0)
                {
                    SupportFragmentManager.PopBackStack();
                    ResetButtonTags();
                    ChatColorButton.Drawable.SetTint(Color.ParseColor("#888888"));
                    ChatStickerButton.Drawable.SetTint(Color.ParseColor("#888888"));

                    if (SupportFragmentManager.Fragments.Count > 0)
                    {
                        var fragmentManager = SupportFragmentManager.BeginTransaction();
                        foreach (var vrg in SupportFragmentManager.Fragments)
                        {
                            Console.WriteLine(vrg);
                            if (SupportFragmentManager.Fragments.Contains(ChatColorBoxFragment))
                            {
                                fragmentManager.Remove(ChatColorBoxFragment);
                            }
                            else if (SupportFragmentManager.Fragments.Contains(ChatStickersTabBoxFragment))
                            {
                                fragmentManager.Remove(ChatStickersTabBoxFragment);
                            }
                        }

                        fragmentManager.Commit();
                    }
                }
                else if (count > 0)
                {
                    if (Timer != null)
                    {
                        Timer.Enabled = true;
                        Timer.Start();
                    }

                    ToolBar.Visibility = ViewStates.Visible;
                    ActionMode.Finish();
                }
                else
                {
                    MainChatColor = AppSettings.MainColor;
                    ColorChanged = false;
                    base.OnBackPressed();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            } 
        }
          
        #region Fragment

        private void ReplaceTopFragment(SupportFragment fragmentView)
        {
            try
            {
                if (fragmentView.IsVisible)
                    return;

                var trans = SupportFragmentManager.BeginTransaction();
                trans.Replace(TopFragmentHolder.Id, fragmentView);

                if (SupportFragmentManager.BackStackEntryCount == 0)
                {
                    trans.AddToBackStack(null);
                }

                trans.Commit();

                TopFragmentHolder.TranslationY = 1200;
                TopFragmentHolder.Animate().SetInterpolator(new FastOutSlowInInterpolator()).TranslationYBy(-1200)
                    .SetDuration(500);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void ReplaceButtomFragment(SupportFragment fragmentView)
        {
            try
            {
                if (fragmentView != MainFragmentOpened)
                {
                    if (MainFragmentOpened == ChatColorBoxFragment)
                    {
                        ChatColorButton.Drawable.SetTint(Color.ParseColor("#888888"));
                    }
                    else if (MainFragmentOpened == ChatStickersTabBoxFragment)
                    {
                        ChatStickerButton.Drawable.SetTint(Color.ParseColor("#888888"));
                    }
                }

                if (fragmentView.IsVisible)
                    return;

                var trans = SupportFragmentManager.BeginTransaction();
                trans.Replace(ButtonFragmentHolder.Id, fragmentView);

                if (SupportFragmentManager.BackStackEntryCount == 0)
                {
                    trans.AddToBackStack(null);
                }

                trans.Commit();

                ButtonFragmentHolder.TranslationY = 1200;
                ButtonFragmentHolder.Animate().SetInterpolator(new FastOutSlowInInterpolator()).TranslationYBy(-1200)
                    .SetDuration(500);
                MainFragmentOpened = fragmentView;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Toolbar & Selected

        private class ActionModeCallback : Object, ActionMode.ICallback
        {
            private readonly ChatWindowActivity Activity;
            public ActionModeCallback(ChatWindowActivity activity)
            {
                Activity = activity;
            }

            public bool OnActionItemClicked(ActionMode mode, IMenuItem item)
            {
                int id = item.ItemId;
                if (id == Resource.Id.action_copy)
                {
                    CopyItems();
                    mode.Finish();
                    return true;
                }
                else if (id == Resource.Id.action_forward)
                {
                    ForwardItems();
                    mode.Finish();
                    return true;
                }
                return false;
            }

            public bool OnCreateActionMode(ActionMode mode, IMenu menu)
            {
                SetSystemBarColor(Activity, Color.ParseColor(MainChatColor));
                mode.MenuInflater.Inflate(Resource.Menu.menuChat, menu);
                return true;
            }

            public void OnDestroyActionMode(ActionMode mode)
            {
                try
                {
                    Activity.MAdapter.ClearSelections();
                    ActionMode.Finish();
                    ActionMode = null;

                    SetSystemBarColor(Activity, Color.ParseColor(MainChatColor));

                    if (Timer != null)
                    {
                        Timer.Enabled = true;
                        Timer.Start();
                    }

                    ToolBar.Visibility = ViewStates.Visible;

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            private void SetSystemBarColor(Activity act, Color color)
            {
                try
                {
                    if (Build.VERSION.SdkInt >= BuildVersionCodes.Lollipop)
                    {
                        Window window = act.Window;
                        window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
                        window.ClearFlags(WindowManagerFlags.TranslucentStatus);
                        window.SetStatusBarColor(color);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public bool OnPrepareActionMode(ActionMode mode, IMenu menu)
            {
                return false;
            }

            //Copy Messages
            private void CopyItems()
            {
                try
                {
                    if (Timer != null)
                    {
                        Timer.Enabled = true;
                        Timer.Start();
                    }

                    if (ToolBar.Visibility != ViewStates.Visible)
                        ToolBar.Visibility = ViewStates.Visible;

                    string allText = "";
                    List<int> selectedItemPositions = Activity.MAdapter.GetSelectedItems();
                    for (int i = selectedItemPositions.Count - 1; i >= 0; i--)
                    {
                        var datItem = Activity.MAdapter.GetItem(selectedItemPositions[i]);
                        if (datItem != null)
                        {
                            if (!string.IsNullOrEmpty(datItem.Text))
                            {
                                allText += " \n" + datItem.Text;
                            }
                            else if (!string.IsNullOrEmpty(datItem.Media))
                            {
                                allText += " \n" + datItem.Media;
                            } 
                        }
                    }

                    ClipboardManager clipboard = (ClipboardManager)Activity.GetSystemService(ClipboardService);
                    ClipData clip = ClipData.NewPlainText("clipboard", allText);
                    clipboard.PrimaryClip = clip;

                    Activity.MAdapter.NotifyDataSetChanged();

                    Toast.MakeText(Activity, Activity.GetText(Resource.String.Lbl_Text_copied), ToastLength.Short).Show();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            //Forward Messages
            private void ForwardItems()
            {
                try
                {
                    if (Timer != null)
                    {
                        Timer.Enabled = true;
                        Timer.Start();
                    }

                    if (ToolBar.Visibility != ViewStates.Visible)
                        ToolBar.Visibility = ViewStates.Visible;

                    AllItem = new List<MessageData>();
                    List<int> selectedItemPositions = Activity.MAdapter.GetSelectedItems();
                    for (int i = selectedItemPositions.Count - 1; i >= 0; i--)
                    {
                        var datItem = Activity.MAdapter.GetItem(selectedItemPositions[i]);
                        if (datItem == null) continue;
                        AllItem.Add(datItem);
                    }

                    if (AllItem.Count > 0)
                    {
                        var Int = new Intent(Activity, typeof(ForwardMessagesActivity));
                        Int.PutExtra("UserId", Activity.Userid); 
                        Activity.StartActivity(Int); 
                    }
                     
                    Activity.MAdapter.NotifyDataSetChanged();

                   
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public void ItemClick(View view, MessageData obj, int pos)
        {
            try
            {
                if (MAdapter.GetSelectedItemCount() > 0) // Add Select New Item 
                {
                    EnableActionMode(pos);
                }
                else
                {
                    if (Timer != null)
                    {
                        Timer.Enabled = true;
                        Timer.Start();
                    }

                    if (ToolBar.Visibility != ViewStates.Visible)
                        ToolBar.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void ItemLongClick(View view, MessageData obj, int pos)
        {
            EnableActionMode(pos);
        }

        private void EnableActionMode(int position)
        {
            try
            {
                if (ActionMode == null)
                    ActionMode = StartSupportActionMode(ModeCallback);

                ToggleSelection(position);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            } 
        }

        private void ToggleSelection(int position)
        {
            try
            {
                MAdapter.ToggleSelection(position);
                int count = MAdapter.GetSelectedItemCount();

                if (count == 0)
                {
                    if (Timer != null)
                    {
                        Timer.Enabled = true;
                        Timer.Start();
                    }

                    ToolBar.Visibility = ViewStates.Visible;
                    ActionMode.Finish();
                }
                else
                {
                    if (Timer != null)
                    {
                        Timer.Enabled = false;
                        Timer.Stop();
                    }

                    ToolBar.Visibility = ViewStates.Gone;
                    ActionMode.SetTitle(count);
                    ActionMode.Invalidate();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        public void Update_One_Messeges(MessageData message)
        {
            try
            {
                var checker = MAdapter.MessageList.FirstOrDefault(a => a.Id == message.Id);
                if (checker != null)
                {
                    checker.Id = message.Id;
                    checker.FromId = message.FromId;
                    checker.GroupId = message.GroupId;
                    checker.ToId = message.ToId;
                    checker.Text = message.Text;
                    checker.Media = message.Media;
                    checker.MediaFileName = message.MediaFileName;
                    checker.MediaFileNames = message.MediaFileNames;
                    checker.Time = message.Time;
                    checker.Seen = message.Seen;
                    checker.DeletedOne = message.DeletedOne;
                    checker.DeletedTwo = message.DeletedTwo;
                    checker.SentPush = message.SentPush;
                    checker.NotificationId = message.NotificationId;
                    checker.TypeTwo = message.TypeTwo;
                    checker.Stickers = message.Stickers;
                    checker.TimeText = message.TimeText;
                    checker.Position = message.Position;
                    checker.Type = message.Type;
                    checker.FileSize = message.FileSize;
                    checker.UserData = message.UserData;
                    checker.MediaDuration = message.MediaDuration;
                    checker.MediaIsPlaying = message.MediaIsPlaying;
                    checker.ContactNumber = message.ContactNumber;
                    checker.ContactName = message.ContactName;

                    RunOnUiThread(() =>
                    {
                        try
                        {
                            if (MessageController.IsImageExtension(checker.MediaFileName))
                            {
                                MAdapter.NotifyItemChanged(MAdapter.MessageList.IndexOf(checker), "WithoutBlob");
                            }
                            else if (MessageController.IsVideoExtension(checker.MediaFileName))
                            {
                                MAdapter.NotifyItemChanged(MAdapter.MessageList.IndexOf(checker), "WithoutBlob");
                            }
                            else if (MessageController.IsAudioExtension(checker.MediaFileName))
                            {
                                MAdapter.NotifyItemChanged(MAdapter.MessageList.IndexOf(checker), "WithoutBlob");
                            }
                            else if (MessageController.IsFileExtension(checker.MediaFileName))
                            {
                                MAdapter.NotifyItemChanged(MAdapter.MessageList.IndexOf(checker), "WithoutBlob");
                            }
                            else if (checker.MediaFileName.Contains(".gif") || checker.MediaFileName.Contains(".GIF"))
                            {
                                MAdapter.NotifyItemChanged(MAdapter.MessageList.IndexOf(checker), "WithoutBlob");
                            }
                            else
                                MAdapter.NotifyItemChanged(MAdapter.MessageList.IndexOf(checker));

                            MRecycler.ScrollToPosition(MAdapter.MessageList.IndexOf(checker));
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    });
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom)
        {
            MRecycler.ScrollToPosition(MAdapter.MessageList.Count - 1);
        }

        private void SetTheme(string color)
        {
            try
            {
                if (color.Contains("b582af"))
                {
                    SetTheme(Resource.Style.Chatththemeb582af);
                }
                else if (color.Contains("a84849"))
                {
                    SetTheme(Resource.Style.Chatththemea84849);
                }
                else if (color.Contains("f9c270"))
                {
                    SetTheme(Resource.Style.Chatththemef9c270);
                }
                else if (color.Contains("70a0e0"))
                {
                    SetTheme(Resource.Style.Chatththeme70a0e0);
                }
                else if (color.Contains("56c4c5"))
                {
                    SetTheme(Resource.Style.Chatththeme56c4c5);
                }
                else if (color.Contains("f33d4c"))
                {
                    SetTheme(Resource.Style.Chatththemef33d4c);
                }
                else if (color.Contains("a1ce79"))
                {
                    SetTheme(Resource.Style.Chatththemea1ce79);
                }
                else if (color.Contains("a085e2"))
                {
                    SetTheme(Resource.Style.Chatththemea085e2);
                }
                else if (color.Contains("ed9e6a"))
                {
                    SetTheme(Resource.Style.Chatththemeed9e6a);
                }
                else if (color.Contains("2b87ce"))
                {
                    SetTheme(Resource.Style.Chatththeme2b87ce);
                }
                else if (color.Contains("f2812b"))
                {
                    SetTheme(Resource.Style.Chatththemef2812b);
                }
                else if (color.Contains("0ba05d"))
                {
                    SetTheme(Resource.Style.Chatththeme0ba05d);
                }
                else if (color.Contains("0e71ea"))
                {
                    SetTheme(Resource.Style.Chatththeme0e71ea);
                }
                else if (color.Contains("aa2294"))
                {
                    SetTheme(Resource.Style.Chatththemeaa2294);
                }
                else if (color.Contains("f9a722"))
                {
                    SetTheme(Resource.Style.Chatththemef9a722);
                }
                else if (color.Contains("008484"))
                {
                    SetTheme(Resource.Style.Chatththeme008484);
                }
                else if (color.Contains("5462a5"))
                {
                    SetTheme(Resource.Style.Chatththeme5462a5);
                }
                else if (color.Contains("fc9cde"))
                {
                    SetTheme(Resource.Style.Chatththemefc9cde);
                }
                else if (color.Contains("fc9cde"))
                {
                    SetTheme(Resource.Style.Chatththemefc9cde);
                }
                else if (color.Contains("51bcbc"))
                {
                    SetTheme(Resource.Style.Chatththeme51bcbc);
                }
                else if (color.Contains("c9605e"))
                {
                    SetTheme(Resource.Style.Chatththemec9605e);
                }
                else if (color.Contains("01a5a5"))
                {
                    SetTheme(Resource.Style.Chatththeme01a5a5);
                }
                else if (color.Contains("056bba"))
                {
                    SetTheme(Resource.Style.Chatththeme056bba);
                }
                else
                {
                    //Default Color >> AppSettings.MainColor
                    //SetTheme(Resource.Style.Chatththemedefault);
                    SetTheme(AppSettings.SetTabDarkTheme ? Resource.Style.MyTheme_Dark_Base : Resource.Style.MyTheme_Base);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void OpenDialogGallery(string typeImage)
        {
            try
            {
                PermissionsType = typeImage;
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Done))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Done))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private string GetRealPathFromUri(Uri contentUri)
        {
            try
            {
                string[] proj = { MediaStore.Images.Media.InterfaceConsts.Data };
                var cursor = ContentResolver.Query(contentUri, proj, null, null, null);
                int columnIndex = cursor.GetColumnIndexOrThrow(MediaStore.Images.Media.InterfaceConsts.Data);
                cursor.MoveToNext();
                return cursor.GetString(columnIndex);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }
          
        private class XamarinRecyclerViewOnScrollListener : RecyclerView.OnScrollListener
        {
            public delegate void LoadMoreEventHandler(object sender, EventArgs e);
           
            public event LoadMoreEventHandler LoadMoreEvent;

            private LinearLayoutManager LayoutManager;
            private SwipeRefreshLayout SwipeRefreshLayout;

            public XamarinRecyclerViewOnScrollListener(LinearLayoutManager layoutManager, SwipeRefreshLayout swipeRefreshLayout)
            { 
                LayoutManager = layoutManager;
                SwipeRefreshLayout = swipeRefreshLayout;
            }

            public override void OnScrolled(RecyclerView recyclerView, int dx, int dy)
            {
                try
                {
                    base.OnScrolled(recyclerView, dx, dy);

                    var visibleItemCount = recyclerView.ChildCount;
                    var totalItemCount = recyclerView.GetAdapter().ItemCount;

                    var pastVisiblesItems = LayoutManager.FindFirstVisibleItemPosition();
                    if (pastVisiblesItems == 0 && (visibleItemCount != totalItemCount))
                    {
                        //Load More  from API Request
                        LoadMoreEvent?.Invoke(this, null);
                        //Start Load More messages From Database
                    }
                    else
                    {
                        if (SwipeRefreshLayout.Refreshing)
                        {
                            SwipeRefreshLayout.Refreshing = false;
                            SwipeRefreshLayout.Enabled = false;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }
    } 
}