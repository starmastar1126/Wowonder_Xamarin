using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.OS;
using Android.Support.V4.View.Animation;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using WoWonder.Activities.Tab;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using WoWonderClient.Requests;

namespace WoWonder.Activities.ChatWindow.Fragment
{
    public class ChatColorsFragment : Android.Support.V4.App.Fragment
    {
        private CircleButton Closebutton;
        private View ChatColorsFragmentView;

        private string UserId;

        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                UserId = Arguments.GetString("userid");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            { 
                // Use this to return your custom view for this Fragment
                View ChatColorsFragmentView = inflater.Inflate(Resource.Layout.Chat_Colors_Fragment, container, false);
                Closebutton = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.closebutton);

                Closebutton = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.closebutton);
                Closebutton.Click += Closebutton_Click;

                var colorbutton1 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton1);
                var colorbutton2 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton2);
                var colorbutton3 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton3);
                var colorbutton4 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton4);
                var colorbutton5 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton5);
                var colorbutton6 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton6);
                var colorbutton7 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton7);
                var colorbutton8 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton8);
                var colorbutton9 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton9);
                var colorbutton10 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton10);
                var colorbutton11 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton11);
                var colorbutton12 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton12);
                var colorbutton13 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton13);
                var colorbutton14 = ChatColorsFragmentView.FindViewById<CircleButton>(Resource.Id.colorbutton14);

                colorbutton1.Click += SetColorbutton_Click;
                colorbutton2.Click += SetColorbutton_Click;
                colorbutton3.Click += SetColorbutton_Click;
                colorbutton4.Click += SetColorbutton_Click;
                colorbutton5.Click += SetColorbutton_Click;
                colorbutton6.Click += SetColorbutton_Click;
                colorbutton7.Click += SetColorbutton_Click;
                colorbutton8.Click += SetColorbutton_Click;
                colorbutton9.Click += SetColorbutton_Click;
                colorbutton10.Click += SetColorbutton_Click;
                colorbutton11.Click += SetColorbutton_Click;
                colorbutton12.Click += SetColorbutton_Click;
                colorbutton13.Click += SetColorbutton_Click;
                colorbutton14.Click += SetColorbutton_Click;

                return ChatColorsFragmentView;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        private void SetColorbutton_Click(object sender, EventArgs e)
        {
            try
            {
                CircleButton btn = (CircleButton) sender;
                string colorCssode = (string) btn.Tag;

                var mainActivityview = ((ChatWindowActivity) Activity);
                ChatWindowActivity.ToolBar.SetBackgroundColor(Android.Graphics.Color.ParseColor(colorCssode));
                mainActivityview.ChatSendButton.SetColor(Android.Graphics.Color.ParseColor(colorCssode));

                ChatWindowActivity.MainChatColor = colorCssode; 
                ChatWindowActivity.ColorChanged = true;

                SetTheme(Activity, colorCssode);

                if (Build.VERSION.SdkInt >= BuildVersionCodes.Lollipop)
                {
                    mainActivityview.Window.ClearFlags(WindowManagerFlags.TranslucentStatus);
                    mainActivityview.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
                    mainActivityview.Window.SetStatusBarColor(Android.Graphics.Color.ParseColor(colorCssode));
                }

                mainActivityview.Recreate();
                var colorFragmentHolder = Activity.FindViewById<FrameLayout>(Resource.Id.ButtomFragmentHolder);
                var interplator = new FastOutSlowInInterpolator();
                colorFragmentHolder.Animate().SetInterpolator(interplator).TranslationY(1200).SetDuration(500);
                Activity.SupportFragmentManager.BeginTransaction().Remove(this).Commit();
                mainActivityview.ChatColorButton.Tag = "Closed";
                mainActivityview.ChatColorButton.Drawable.SetTint(Android.Graphics.Color.ParseColor("#888888")); 

                if (Methods.CheckConnectivity())
                {
                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => RequestsAsync.Message.Change_Chat_Color(UserId, colorCssode) });
                }
                else
                {
                    Toast.MakeText(Context, GetText(Resource.String.Lbl_CheckYourInternetConnection),ToastLength.Short).Show();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //private Color DarkerColor(Android.Graphics.Color color, float correctionfactory = 50f)
        //{
        //    const float hundredpercent = 100f;
        //    return Color.FromArgb((int)((color.R / hundredpercent) * correctionfactory),(int)((color.G / hundredpercent) * correctionfactory), (int)((color.B / hundredpercent) * correctionfactory));
        //}

        //public static Color ChangeColorBrightness(Android.Graphics.Color color, float correctionFactor)
        //{
        //    float red = color.R;
        //    float green = color.G;
        //    float blue = color.B;

        //    if (correctionFactor < 0)
        //    {
        //        correctionFactor = 1 + correctionFactor;
        //        red *= correctionFactor;
        //        green *= correctionFactor;
        //        blue *= correctionFactor;
        //    }
        //    else
        //    {
        //        red = (255 - red) * correctionFactor + red;
        //        green = (255 - green) * correctionFactor + green;
        //        blue = (255 - blue) * correctionFactor + blue;
        //    }

        //    return Color.FromArgb(color.A, (int)red, (int)green, (int)blue);
        //}

        private void Closebutton_Click(object sender, EventArgs e)
        {
            try
            {
                var colorFragmentHolder = Activity.FindViewById<FrameLayout>(Resource.Id.ButtomFragmentHolder);
                var interplator = new FastOutSlowInInterpolator();
                colorFragmentHolder.Animate().SetInterpolator(interplator).TranslationY(1200).SetDuration(500);
                Activity.SupportFragmentManager.BeginTransaction().Remove(this).Commit();

                var mainActivityview = ((ChatWindowActivity)Activity);

                mainActivityview.ChatColorButton.Tag = "Closed";
                mainActivityview.ChatColorButton.Drawable.SetTint(Android.Graphics.Color.ParseColor("#888888"));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void SetTheme(Activity activity, string color)
        {
            try
            {
                if (color.Contains("b582af"))
                {
                    activity.SetTheme(Resource.Style.Chatththemeb582af);
                }
                else if (color.Contains("a84849"))
                {
                    activity.SetTheme(Resource.Style.Chatththemea84849);
                }
                else if (color.Contains("f9c270"))
                {
                    activity.SetTheme(Resource.Style.Chatththemef9c270);
                }
                else if (color.Contains("70a0e0"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme70a0e0);
                }
                else if (color.Contains("56c4c5"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme56c4c5);
                }
                else if (color.Contains("f33d4c"))
                {
                    activity.SetTheme(Resource.Style.Chatththemef33d4c);
                }
                else if (color.Contains("a1ce79"))
                {
                    activity.SetTheme(Resource.Style.Chatththemea1ce79);
                }
                else if (color.Contains("a085e2"))
                {
                    activity.SetTheme(Resource.Style.Chatththemea085e2);
                }
                else if (color.Contains("ed9e6a"))
                {
                    activity.SetTheme(Resource.Style.Chatththemeed9e6a);
                }
                else if (color.Contains("2b87ce"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme2b87ce);
                }
                else if (color.Contains("f2812b"))
                {
                    activity.SetTheme(Resource.Style.Chatththemef2812b);
                }
                else if (color.Contains("0ba05d"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme0ba05d);
                }
                else if (color.Contains("0e71ea"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme0e71ea);
                }
                else if (color.Contains("aa2294"))
                {
                    activity.SetTheme(Resource.Style.Chatththemeaa2294);
                }
                else if (color.Contains("f9a722"))
                {
                    activity.SetTheme(Resource.Style.Chatththemef9a722);
                }
                else if (color.Contains("008484"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme008484);
                }
                else if (color.Contains("5462a5"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme5462a5);
                }
                else if (color.Contains("fc9cde"))
                {
                    activity.SetTheme(Resource.Style.Chatththemefc9cde);
                }
                else if (color.Contains("fc9cde"))
                {
                    activity.SetTheme(Resource.Style.Chatththemefc9cde);
                }
                else if (color.Contains("51bcbc"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme51bcbc);
                }
                else if (color.Contains("c9605e"))
                {
                    activity.SetTheme(Resource.Style.Chatththemec9605e);
                }
                else if (color.Contains("01a5a5"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme01a5a5);
                }
                else if (color.Contains("056bba"))
                {
                    activity.SetTheme(Resource.Style.Chatththeme056bba);
                }
                else
                {
                    //Default Color >> AppSettings.MainColor
                    activity.SetTheme(Resource.Style.Chatththemedefault);
                }

                var dataUser = TabbedMainActivity.GetInstance().LastMessagesTab.MAdapter.MLastMessagesUser?.FirstOrDefault(a => a.UserId == UserId);
                if (dataUser != null)
                {        
                    dataUser.ChatColor = color;
                }

                var mainActivityview = ((ChatWindowActivity)Activity);
                if (mainActivityview.DataUser != null) mainActivityview.DataUser.ChatColor = color;
                if (mainActivityview.UserData != null) mainActivityview.UserData.ChatColor = color;

                ChatWindowActivity.MainChatColor = color;

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnDestroy()
        {
            try
            {
                
                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}