using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.App;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Refractored.Controls;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;

namespace WoWonder.Activities.Call.Adapters
{
    public class AddNewCallAdapter : RecyclerView.Adapter
    {
        public event EventHandler<AddNewCallAdapterClickEventArgs> ItemClick;
        public event EventHandler<AddNewCallAdapterClickEventArgs> ItemLongClick;
        public event EventHandler<AddNewCallAdapterClickEventArgs> AudioCallClick;
        public event EventHandler<AddNewCallAdapterClickEventArgs> VideoCallClick;
        private readonly Activity ActivityContext;

        public ObservableCollection<UserDataObject> UserList = new ObservableCollection<UserDataObject>();
        private readonly List<string> ListOnline = new List<string>();

        public AddNewCallAdapter(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> AddNewCall_view
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.AddNewCall_view, parent, false);
                var holder = new AddNewCallAdapterViewHolder(itemView, OnClick, OnLongClick, AudioCallOnClick, VideoCallOnClick);
                return holder;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder is AddNewCallAdapterViewHolder holder)
                {
                    var item = UserList[position];
                    if (item != null)
                    {
                        if (AppSettings.FlowDirectionRightToLeft)
                        {
                            holder.RelativeLayoutMain.LayoutDirection = LayoutDirection.Rtl;
                            holder.TxtUsername.TextDirection = TextDirection.Rtl;
                            holder.TxtPlatform.TextDirection = TextDirection.Rtl;
                        }
                       
                    } 
                    Initialize(holder, item); 
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void Initialize(AddNewCallAdapterViewHolder holder, UserDataObject item)
        {
            try
            {
                GlideImageLoader.LoadImage(ActivityContext,item.Avatar, holder.ImageAvatar,ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                 
                string name = Methods.FunString.DecodeString(item.Name);
                holder.TxtUsername.Text = Methods.FunString.SubStringCutOf(name, 25);

                //wael
                //if (item.UserPlatform == null)
                //    item.UserPlatform = "web";

                ////User platform
                //if (item.UserPlatform.Contains("phone"))
                //{
                //    holder.Txt_platform.Text = Activity_Context.GetString(Resource.String.Lbl_Phone);
                //}
                //else if (item.UserPlatform.Contains("web"))
                //{
                //    holder.Txt_platform.Text = Activity_Context.GetString(Resource.String.Lbl_Web);
                //}
                //else
                //{
                //    holder.Txt_platform.Text = Activity_Context.GetString(Resource.String.Lbl_Web);
                //}

                //Online Or offline
                if (item.Lastseen == "on")
                {
                    holder.ImageLastseen.SetImageResource(Resource.Drawable.Green_Online);
                    if (AppSettings.ShowOnlineOfflineMessage)
                    {
                        var data = ListOnline.Contains(item.Name);
                        if (data == false)
                        {
                            ListOnline.Add(item.Name);

                            Toast toast = Toast.MakeText(ActivityContext, item.Name + " " + ActivityContext.GetString(Resource.String.Lbl_Online), ToastLength.Short);
                            toast.SetGravity(GravityFlags.Center, 0, 0);
                            toast.Show();
                        }
                    }
                }
                else
                {
                    holder.ImageLastseen.SetImageResource(Resource.Drawable.Grey_Offline);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                try
                {
                    if (UserList == null || UserList.Count <= 0)
                        return 0;
                    return UserList.Count;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return 0;
                }
            }
        }

        public UserDataObject GetItem(int position)
        {
            return UserList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        void OnClick(AddNewCallAdapterClickEventArgs args) => ItemClick?.Invoke(this, args);
        void OnLongClick(AddNewCallAdapterClickEventArgs args) => ItemLongClick?.Invoke(this, args);
        void AudioCallOnClick(AddNewCallAdapterClickEventArgs args) => AudioCallClick?.Invoke(this, args);
        void VideoCallOnClick(AddNewCallAdapterClickEventArgs args) => VideoCallClick?.Invoke(this, args);

    }

    public class AddNewCallAdapterViewHolder : RecyclerView.ViewHolder
    {
        #region Variables Basic

        public View MainView { get; set; }

        public RelativeLayout RelativeLayoutMain { get; set; }
        public TextView TxtUsername { get; set; }
        public TextView TxtPlatform { get; set; }
        public ImageView ImageAvatar { get; set; }
        public CircleImageView ImageLastseen { get; set; }
        public AppCompatTextView TxtIconAudioCall { get; set; }
        public AppCompatTextView TxtIconVideoCall { get; set; }

        #endregion 

        public AddNewCallAdapterViewHolder(View itemView, Action<AddNewCallAdapterClickEventArgs> clickListener, Action<AddNewCallAdapterClickEventArgs> longClickListener
            , Action<AddNewCallAdapterClickEventArgs> audioCallclickListener, Action<AddNewCallAdapterClickEventArgs> videoCallclickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                //Get values
                RelativeLayoutMain = (RelativeLayout)MainView.FindViewById(Resource.Id.main);
                TxtUsername = (TextView)MainView.FindViewById(Resource.Id.Txt_Username);
                TxtPlatform = (TextView)MainView.FindViewById(Resource.Id.Txt_Userplatform);
                ImageAvatar = (ImageView)MainView.FindViewById(Resource.Id.Img_Avatar);
                ImageLastseen = (CircleImageView)MainView.FindViewById(Resource.Id.Img_Lastseen);
                TxtIconAudioCall = (AppCompatTextView)MainView.FindViewById(Resource.Id.IconAudioCall);
                TxtIconVideoCall = (AppCompatTextView)MainView.FindViewById(Resource.Id.IconVideoCall);

                itemView.Click += (sender, e) => clickListener(new AddNewCallAdapterClickEventArgs { View = itemView, Position = AdapterPosition });
                itemView.LongClick += (sender, e) => longClickListener(new AddNewCallAdapterClickEventArgs { View = itemView, Position = AdapterPosition });
                TxtIconAudioCall.Click += (sender, e) => audioCallclickListener(new AddNewCallAdapterClickEventArgs { View = itemView, Position = AdapterPosition });
                TxtIconVideoCall.Click += (sender, e) => videoCallclickListener(new AddNewCallAdapterClickEventArgs { View = itemView, Position = AdapterPosition });


                FontUtils.SetFont(TxtUsername, Fonts.SfRegular);
                FontUtils.SetFont(TxtPlatform, Fonts.SfMedium);

                if (AppSettings.EnableVideoCall)
                {
                    TxtIconVideoCall.Visibility = ViewStates.Visible;
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, TxtIconVideoCall, IonIconsFonts.IosVideocam);
                    TxtIconVideoCall.SetTextColor(AppSettings.SetTabDarkTheme ? Color.ParseColor("#ffffff") : Color.ParseColor("#444444"));
                }
                else
                {
                    TxtIconVideoCall.Visibility = ViewStates.Gone;
                }

                if (AppSettings.EnableAudioCall)
                {
                    TxtIconAudioCall.Visibility = ViewStates.Visible;
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, TxtIconAudioCall, IonIconsFonts.AndroidCall);
                    TxtIconAudioCall.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                }
                else
                {
                    TxtIconAudioCall.Visibility = ViewStates.Gone;
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }

    public class AddNewCallAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}