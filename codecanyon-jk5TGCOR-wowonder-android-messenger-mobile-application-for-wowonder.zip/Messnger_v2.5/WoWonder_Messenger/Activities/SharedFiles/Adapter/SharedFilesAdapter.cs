﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using Object = Java.Lang.Object;
using Java.IO;
using Console = System.Console;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.SharedFiles.Adapter
{
    public class SharedFilesAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<SharedFilesAdapterViewHolderClickEventArgs> ItemClick;
        public event EventHandler<SharedFilesAdapterViewHolderClickEventArgs> ItemLongClick;

        private readonly Activity ActivityContext; 
        public ObservableCollection<Classes.SharedFile> SharedFilesList = new ObservableCollection<Classes.SharedFile>();
        private readonly RequestOptions Options;
        private readonly string UserId;
        public SharedFilesAdapter(Activity context, string userId)
        {
            try
            {
                ActivityContext = context; 
                UserId = userId;
                Options = new RequestOptions().Apply(RequestOptions.CircleCropTransform()
                    .CenterCrop()
                    .SetPriority(Priority.High).Override(200)
                    .SetUseAnimationPool(false).SetDiskCacheStrategy(DiskCacheStrategy.All)
                    .Error(Resource.Drawable.ImagePlacholder)
                    .Placeholder(Resource.Drawable.ImagePlacholder));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_LastActivities_View
                View itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_SharedFiles_View, parent, false);
                var vh = new SharedFilesAdapterViewHolder(itemView, OnClick, OnLongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder is SharedFilesAdapterViewHolder holder)
                {
                    var item = SharedFilesList[position];
                    if (item != null)
                    { 
                        if (item.FileType == "Video")
                        {
                            var fileName = item.FilePath.Split('/').Last();
                            var fileNameWithoutExtension = fileName.Split('.').First();

                            FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.PlayIcon, IonIconsFonts.Play);
                            holder.PlayIcon.Visibility = ViewStates.Visible;

                            FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.TypeIcon, IonIconsFonts.Videocamera);
                            holder.TypeIcon.Visibility = ViewStates.Visible;

                            var videoPlaceHolderImage = Methods.MultiMedia.GetMediaFrom_Gallery(Methods.Path.FolderDcimVideo + "/" + UserId, fileNameWithoutExtension + ".png");
                            if (videoPlaceHolderImage == "File Dont Exists")
                            {
                                var bitmapImage = Methods.MultiMedia.Retrieve_VideoFrame_AsBitmap(item.FilePath);
                                Methods.MultiMedia.Export_Bitmap_As_Image(bitmapImage, fileNameWithoutExtension, Methods.Path.FolderDcimVideo + "/" + UserId);

                                var imageVideo = Methods.Path.FolderDcimVideo + "/" + UserId + "/" + fileNameWithoutExtension + ".png";

                                var file = Uri.FromFile(new File(imageVideo));
                                Glide.With(ActivityContext).Load(file.Path).Apply(Options).Into(holder.Image);
                            }
                            else
                            {
                                var file = Uri.FromFile(new File(videoPlaceHolderImage));
                                Glide.With(ActivityContext).Load(file.Path).Apply(Options).Into(holder.Image);
                            } 
                        }
                        else if (item.FileType == "Gif")
                        { 
                            holder.TypeIcon.Text = ActivityContext.GetText(Resource.String.Lbl_Gif);
                            FontUtils.SetFont(holder.TypeIcon, Fonts.SfSemibold);

                            holder.PlayIcon.Visibility = ViewStates.Gone; 
                            holder.TypeIcon.Visibility = ViewStates.Visible;

                            var file = Uri.FromFile(new File(item.FilePath));
                            Glide.With(ActivityContext).Load(file.Path).Apply(Options).Into(holder.Image);
                        }
                        else if (item.FileType == "Sticker")
                        {  
                            holder.PlayIcon.Visibility = ViewStates.Gone; 
                            holder.TypeIcon.Visibility = ViewStates.Gone;

                            var file = Uri.FromFile(new File(item.FilePath));
                            Glide.With(ActivityContext).Load(file.Path).Apply(Options).Into(holder.Image);
                        }
                        else if (item.FileType == "Image")
                        { 
                            holder.PlayIcon.Visibility = ViewStates.Gone;
                            holder.TypeIcon.Visibility = ViewStates.Gone;

                            var file = Uri.FromFile(new File(item.FilePath));
                            Glide.With(ActivityContext).Load(file.Path).Apply(Options).Into(holder.Image); 
                        }
                        else if (item.FileType == "Sounds")
                        {
                            holder.PlayIcon.Visibility = ViewStates.Gone;
                            holder.TypeIcon.Visibility = ViewStates.Gone;

                            GlideImageLoader.LoadImage(ActivityContext, item.ImageExtra, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color);
                        }
                        else if (item.FileType == "File")
                        {
                            holder.PlayIcon.Visibility = ViewStates.Gone;
                            holder.TypeIcon.Visibility = ViewStates.Gone;

                            GlideImageLoader.LoadImage(ActivityContext, item.ImageExtra, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        public override int ItemCount => SharedFilesList?.Count ?? 0;


        public Classes.SharedFile GetItem(int position)
        {
            return SharedFilesList[position];
        }


        void OnClick(SharedFilesAdapterViewHolderClickEventArgs args) => ItemClick?.Invoke(this, args);
        void OnLongClick(SharedFilesAdapterViewHolderClickEventArgs args) => ItemLongClick?.Invoke(this, args);


        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = SharedFilesList[p0];
                if (item == null)
                    return d;

                d.Add(item.ImageExtra);

                return d;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                var d = new List<string>();
                return d;
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.CenterCrop);
        } 
    }

    public class SharedFilesAdapterViewHolder : RecyclerView.ViewHolder
    {
        #region Variables Basic
        public View MainView { get; set; }
         
        public ImageView Image { get; private set; }
        public TextView PlayIcon { get; private set; }
        public TextView TypeIcon { get; private set; }
        #endregion

        public SharedFilesAdapterViewHolder(View itemView, Action<SharedFilesAdapterViewHolderClickEventArgs> clickListener, Action<SharedFilesAdapterViewHolderClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;
                Image = (ImageView)MainView.FindViewById(Resource.Id.Image);
                TypeIcon = (TextView)MainView.FindViewById(Resource.Id.typeicon);
                PlayIcon = (TextView)MainView.FindViewById(Resource.Id.playicon);

                //Create an Event
                MainView.Click += (sender, e) => clickListener(new SharedFilesAdapterViewHolderClickEventArgs { View = itemView, Position = AdapterPosition });
                itemView.LongClick += (sender, e) => longClickListener(new SharedFilesAdapterViewHolderClickEventArgs { View = itemView, Position = AdapterPosition });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }

    public class SharedFilesAdapterViewHolderClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}