using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Clans.Fab;
using Com.Theartofdev.Edmodo.Cropper;
using Java.IO;
using Newtonsoft.Json;
using WoWonder.Activities.Call;
using WoWonder.Activities.ChatWindow;
using WoWonder.Activities.DefaultUser;
using WoWonder.Activities.GroupChat;
using WoWonder.Activities.NearBy;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Activities.Story;
using WoWonder.Activities.Tab.Fragment;
using WoWonder.Adapters;
using WoWonder.Frameworks;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using Console = System.Console;
using FloatingActionButton = Android.Support.Design.Widget.FloatingActionButton;
using Toolbar = Android.Support.V7.Widget.Toolbar;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Tab
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.Keyboard | ConfigChanges.KeyboardHidden | ConfigChanges.ScreenLayout | ConfigChanges.ScreenSize | ConfigChanges.SmallestScreenSize | ConfigChanges.UiMode)]
    public class TabbedMainActivity : AppCompatActivity, ServiceResultReceiver.IReceiver
    { 
        #region Variables  

        private TabLayout Tabs;
        private ViewPager ViewPager;
        private FloatingActionButton FloatingActionButtonView;
        public LastMessagesFragment LastMessagesTab;
        public LastGroupChatsFragment LastGroupChatsTab;
        public LastStoriesFragment LastStoriesTab;
        public LastCallsFragment LastCallsTab;
        private FloatingActionMenu StoryMultiButtons;
        private static TabbedMainActivity Instance;
        private string ImageType;
        private ServiceResultReceiver Receiver;
        public static bool RunCall;
        private PowerManager.WakeLock Wl;
        private readonly Handler ExitHandler = new Handler();
        private bool RecentlyBackPressed;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);
                SetTheme(AppSettings.SetTabDarkTheme ? Resource.Style.MyTheme_Dark_Base : Resource.Style.MyTheme_Base);
                Methods.App.FullScreenApp(this);

                AddFlagsWakeLock();

                // Create your application here
                SetContentView(Resource.Layout.Tabbed_Main_Page);

                Instance = this;

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();

                LoadConfigSettings();

                RunCall = false;

                SetService(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
               
                base.OnResume();
                AddOrRemoveEvent(true);
                SetWakeLock();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
                OffWakeLock();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
          
        #region Menu

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            MenuInflater.Inflate(Resource.Menu.Main_Menu, menu);

            return base.OnCreateOptionsMenu(menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.searchMainbutton)
            {
                var intent = new Intent(this, typeof(SearchActivity));
                intent.PutExtra("Key", "");
                StartActivity(intent);
            }
            else if (item.ItemId == Resource.Id.menue_blockList)
            {
                StartActivity(new Intent(this, typeof(BlockedUsersActivity)));
            }
            else if (item.ItemId == Resource.Id.menue_Settings)
            {
                StartActivity(new Intent(this, typeof(SettingsActivity)));
            }
            else if (item.ItemId == Resource.Id.NearByMainButton)
            {
                StartActivity(new Intent(this, typeof(PeopleNearByActivity)));
            }

            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            try
            {
                if (RecentlyBackPressed)
                {
                    ExitHandler.RemoveCallbacks(() => { RecentlyBackPressed = false; });
                    RecentlyBackPressed = false;
                    MoveTaskToBack(true);
                }
                else
                {
                    RecentlyBackPressed = true;
                    Toast.MakeText(this, GetString(Resource.String.press_again_exit), ToastLength.Long).Show();
                    ExitHandler.PostDelayed(() => { RecentlyBackPressed = false; }, 2000L);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
               
                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);
                FloatingActionButtonView.Tag = "lastMessages";

                StoryMultiButtons = FindViewById<FloatingActionMenu>(Resource.Id.multistroybutton);
                StoryMultiButtons.Visibility = ViewStates.Invisible; 
                StoryMultiButtons.GetChildAt(0).Click += OnImage_Button_Click;
                StoryMultiButtons.GetChildAt(1).Click += OnVideo_Button_Click;

                Tabs = FindViewById<TabLayout>(Resource.Id.tabs);
                ViewPager = FindViewById<ViewPager>(Resource.Id.viewpager);
                ViewPager.PageScrolled += ViewPager_PageScrolled;  
                ViewPager.PageSelected += ViewPagerOnPageSelected;  
                ViewPager.OffscreenPageLimit = 3;
                SetUpViewPager(ViewPager); 
                Tabs.SetupWithViewPager(ViewPager); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = AppSettings.ShowTitleUsername ? UserDetails.Username : AppSettings.ApplicationName;
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    FloatingActionButtonView.Click += FloatingActionButtonView_Click;
                }
                else
                {
                    FloatingActionButtonView.Click -= FloatingActionButtonView_Click;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static TabbedMainActivity GetInstance()
        {
            try
            {
                return Instance;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region Events

        private void OnVideo_Button_Click(object sender, EventArgs e)
        {
            try
            {
                ImageType = "Video";

                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    //requestCode >> 501 => video Gallery
                    new IntentController(this).OpenIntentVideoGallery();
                }
                else
                {
                    if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                      && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                    {
                        //requestCode >> 501 => video Gallery
                        new IntentController(this).OpenIntentVideoGallery();
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void OnImage_Button_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    if (AppSettings.ImageCropping)
                        OpenDialogGallery("Image"); //requestCode >> 500 => Image Gallery
                    else
                        new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                }
                else
                {
                    if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                      && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                    {
                        if (AppSettings.ImageCropping)
                            OpenDialogGallery("Image"); //requestCode >> 500 => Image Gallery
                        else
                            new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }
        }

        private void FloatingActionButtonView_Click(object sender, EventArgs e)
        {
            if (FloatingActionButtonView.Tag.ToString() == "lastMessages")
            {
                var intent = new Intent(this, typeof(UserContactsActivity));
                intent.PutExtra("ContactsType", "Following");
                intent.PutExtra("UserId", UserDetails.UserId);
                StartActivity(intent);
            }
            else if (FloatingActionButtonView.Tag.ToString() == "GroupChats")
            {
                StartActivity(new Intent(this, typeof(CreateGroupActivity)));
            }
            else if (FloatingActionButtonView.Tag.ToString() == "Story")
            {

            }
            else if (FloatingActionButtonView.Tag.ToString() == "Call")
            {
                StartActivity(new Intent(this, typeof(AddNewCallActivity)));
            }
        }

        #endregion

        #region Permissions && Result
         
        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

               if (requestCode == 501) // Add video story
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    { 
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Video")
                        {
                            Intent Int = new Intent(this, typeof(AddStoryActivity));
                            Int.PutExtra("Uri", filepath);
                            Int.PutExtra("Type", "video");
                            StartActivity(Int);
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                    }
                }
                else if (requestCode == 500) // Add image story
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Image")
                        {
                            if (!string.IsNullOrEmpty(filepath))
                            {
                                //Do something with your Uri
                                Intent Int = new Intent(this, typeof(AddStoryActivity));
                                Int.PutExtra("Uri", filepath);
                                Int.PutExtra("Type", "image");
                                StartActivity(Int);
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                    }
                }
                else //If its from Camera or Gallery
                if (requestCode == CropImage.CropImageActivityRequestCode)
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                //Do something with your Uri
                                Intent Int = new Intent(this, typeof(AddStoryActivity));
                                Int.PutExtra("Uri", resultUri.Path);
                                Int.PutExtra("Type", "image");
                                StartActivity(Int);
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        switch (ImageType)
                        {
                            //requestCode >> 500 => Image Gallery
                            case "Image" when AppSettings.ImageCropping:
                                OpenDialogGallery("Image");
                                break;
                            case "Image": //requestCode >> 500 => Image Gallery
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures));
                                break;
                            case "Video":
                                //requestCode >> 501 => video Gallery
                                new IntentController(this).OpenIntentVideoGallery();
                                break; 
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 110)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        Window.AddFlags(WindowManagerFlags.KeepScreenOn);
                    }
                    else
                    {
                        Toast.MakeText(this, this.GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Set Tab

        private void ViewPagerOnPageSelected(object sender, ViewPager.PageSelectedEventArgs e)
        {
            try
            {
                var position = e.Position;
                if (position == 0) // lastMessages
                {

                }
                else if (position == 1) // GroupChats
                {
                    if (AppSettings.EnableChatGroup)
                    {
                        LastGroupChatsTab.StartApiService();
                    }
                    else
                    {
                        LastStoriesTab.StartApiService();
                    }
                }
                else if (position == 2) // Story
                {
                    if (AppSettings.EnableChatGroup)
                    {
                        LastStoriesTab.StartApiService();
                    }
                    else
                    {
                        LastCallsTab.Get_CallUser();
                    } 
                }
                else if (position == 3) // Call
                {
                    LastCallsTab.Get_CallUser();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ViewPager_PageScrolled(object sender, ViewPager.PageScrolledEventArgs e)
        {
            try
            {
                var position = e.Position;
                if (position == 0) // lastMessages
                {
                    if (FloatingActionButtonView.Tag.ToString() != "lastMessages")
                    {
                        FloatingActionButtonView.Tag = "lastMessages";
                        FloatingActionButtonView.SetImageResource(Resource.Drawable.ic_contacts);
                        FloatingActionButtonView.Visibility = ViewStates.Visible;
                        StoryMultiButtons.Visibility = ViewStates.Invisible;
                    }
                }
                else if (position == 1) // GroupChats
                {
                    if (AppSettings.EnableChatGroup)
                    {
                        if (FloatingActionButtonView.Tag.ToString() != "GroupChats")
                        {
                            FloatingActionButtonView.Tag = "GroupChats";
                            FloatingActionButtonView.SetImageResource(Resource.Drawable.ic_add);
                            FloatingActionButtonView.Visibility = ViewStates.Visible;
                            StoryMultiButtons.Visibility = ViewStates.Invisible;
                        }
                    }
                    else
                    {
                        if (FloatingActionButtonView.Tag.ToString() != "Story")
                        {
                            FloatingActionButtonView.Tag = "Story";
                            FloatingActionButtonView.SetImageResource(Resource.Drawable.ic_story_camera);
                            FloatingActionButtonView.Visibility = ViewStates.Invisible;
                            StoryMultiButtons.Visibility = ViewStates.Visible;
                        }
                    }
                }
                else if (position == 2) // Story
                {
                    if (AppSettings.EnableChatGroup)
                    {
                        if (FloatingActionButtonView.Tag.ToString() != "Story")
                        {
                            FloatingActionButtonView.Tag = "Story";
                            FloatingActionButtonView.SetImageResource(Resource.Drawable.ic_story_camera);
                            FloatingActionButtonView.Visibility = ViewStates.Invisible;
                            StoryMultiButtons.Visibility = ViewStates.Visible;
                        }
                    } 
                    else
                    {
                        if (FloatingActionButtonView.Tag.ToString() != "Call")
                        {
                            FloatingActionButtonView.Tag = "Call";
                            FloatingActionButtonView.SetImageResource(Resource.Drawable.ic_phone_user);
                            FloatingActionButtonView.Visibility = ViewStates.Visible;
                            StoryMultiButtons.Visibility = ViewStates.Invisible;
                        }
                    } 
                }
                else if (position == 3) // Call
                {
                    if (FloatingActionButtonView.Tag.ToString() != "Call")
                    {
                        FloatingActionButtonView.Tag = "Call";
                        FloatingActionButtonView.SetImageResource(Resource.Drawable.ic_phone_user);
                        FloatingActionButtonView.Visibility = ViewStates.Visible;
                        StoryMultiButtons.Visibility = ViewStates.Invisible;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        private void SetUpViewPager(ViewPager viewPager)
        {
            try
            {
                LastMessagesTab = new LastMessagesFragment();
                LastGroupChatsTab = new LastGroupChatsFragment();
                LastStoriesTab = new LastStoriesFragment();
                LastCallsTab = new LastCallsFragment();

                MainTabAdapter adapter = new MainTabAdapter(SupportFragmentManager);
                adapter.AddFragment(LastMessagesTab, GetText(Resource.String.Lbl_Tab_Chats));

                if (AppSettings.EnableChatGroup)
                    adapter.AddFragment(LastGroupChatsTab, GetText(Resource.String.Lbl_Tab_GroupChats));
                adapter.AddFragment(LastStoriesTab, GetText(Resource.String.Lbl_Tab_Stories));

                if (AppSettings.EnableAudioVideoCall)
                    adapter.AddFragment(LastCallsTab, GetText(Resource.String.Lbl_Tab_Calls));

                viewPager.OffscreenPageLimit = adapter.Count;
                viewPager.Adapter = adapter;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region WakeLock System

        public void AddFlagsWakeLock()
        {
            try
            {
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Window.AddFlags(WindowManagerFlags.KeepScreenOn);
                }
                else
                {
                    if (CheckSelfPermission(Manifest.Permission.WakeLock) == Permission.Granted)
                    {
                        Window.AddFlags(WindowManagerFlags.KeepScreenOn);
                    }
                    else
                    {
                        //request Code 110
                        new PermissionsController(this).RequestPermission(110);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void SetWakeLock()
        {
            try
            {
                if (Wl == null)
                {
                    PowerManager pm = (PowerManager)GetSystemService(PowerService);
                    Wl = pm.NewWakeLock(WakeLockFlags.ScreenBright, "My Tag");
                    Wl.Acquire();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 

        public void SetOnWakeLock()
        {
            try
            {
                PowerManager pm = (PowerManager)GetSystemService(PowerService);
                Wl = pm.NewWakeLock(WakeLockFlags.ScreenBright, "My Tag");
                Wl.Acquire();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void SetOffWakeLock()
        {
            try
            {
                PowerManager pm = (PowerManager)GetSystemService(PowerService);
                Wl = pm.NewWakeLock(WakeLockFlags.ProximityScreenOff, "My Tag");
                Wl.Acquire();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OffWakeLock()
        {
            try
            {
                // ..screen will stay on during this section..
                Wl?.Release();
                Wl = null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void OpenDialogGallery(string typeImage)
        {
            try
            {
                ImageType = typeImage;
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Done))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Done))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }

               
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadConfigSettings()
        {
            try
            {
                var dbDatabase = new SqLiteDatabase();
                var data = ListUtils.DataUserLoginList.FirstOrDefault();
                if (data != null && data.Status != "Active")
                {
                    data.Status = "Active";
                    UserDetails.Status = "Active";
                    dbDatabase.InsertOrUpdateLogin_Credentials(data); 
                }

                var settingsData = dbDatabase.GetSettings();
                if (settingsData != null)
                    ListUtils.SettingsSiteList = settingsData;

                dbDatabase.Dispose();

                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => ApiRequest.GetSettings_Api(this) , () => ApiRequest.Get_MyProfileData_Api(this) }); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetService()
        {
            try
            {
                try
                {
                    Receiver = new ServiceResultReceiver(new Handler());
                    Receiver.SetReceiver(this);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                var intent = new Intent(this, typeof(ScheduledApiService));
                intent.PutExtra("receiverTag", Receiver);
                StartService(intent); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnReceiveResult(int resultCode, Bundle resultData)
        {
            //Toast.MakeText(Application.Context, "Result got ", ToastLength.Short).Show();

            try
            {
                var result = JsonConvert.DeserializeObject<GetUsersListObject>(resultData.GetString("Json")); 
                if (result != null)
                {
                    LoadDataJsonLastChat(result);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);

               // Toast.MakeText(Application.Context, "Exception  " + e, ToastLength.Short).Show();
            }
        }

        public void LoadDataJsonLastChat(GetUsersListObject result)
        {
            try
            {
                if (LastMessagesTab.MAdapter == null) return;

                if (LastMessagesTab.FirstRun && LastMessagesTab.MAdapter.MLastMessagesUser.Count > 0)
                {
                    LastMessagesTab.FirstRun = false;
                }

                #region Last Messeges >> users

                try
                {
                    int countList = LastMessagesTab.MAdapter.MLastMessagesUser.Count;

                    var respondList = result.Users?.Count;
                    if (respondList > 0)
                    {
                        if (countList > 0)
                        {
                            foreach (var item in result.Users)
                            {
                                var checkUser = LastMessagesTab.MAdapter.MLastMessagesUser.FirstOrDefault(a => a.UserId == item.UserId);
                                if (checkUser == null)
                                {
                                    //checkUser.ChatTime = item.ChatTime;
                                     LastMessagesTab.MAdapter.MLastMessagesUser.Insert(0, item);

                                     RunOnUiThread(() =>
                                     {
                                         LastMessagesTab.MAdapter.NotifyItemInserted(0);
                                         LastMessagesTab?.MRecycler.ScrollToPosition(LastMessagesTab.MAdapter.MLastMessagesUser.IndexOf(item));
                                     }); 
                                }
                                else
                                {
                                    var index = LastMessagesTab.MAdapter.MLastMessagesUser.IndexOf(checkUser);
                                    checkUser.ChatTime = item.ChatTime;
                                    checkUser.UserId = item.UserId;
                                    checkUser.Username = item.Username;
                                    checkUser.Avatar = item.Avatar;
                                    checkUser.Cover = item.Cover;
                                    checkUser.LastseenTimeText = item.LastseenTimeText;
                                    checkUser.Lastseen = item.Lastseen;
                                    checkUser.Url = item.Url;
                                    checkUser.Name = item.Name;
                                    checkUser.LastseenUnixTime = item.LastseenUnixTime;
                                    checkUser.ChatColor = item.ChatColor ?? AppSettings.MainColor;
                                    checkUser.Verified = item.Verified;
                                   
                                    //last_message
                                    if (checkUser.LastMessage == null)
                                        checkUser.LastMessage = new GetUsersListObject.LastMessage();

                                    if (checkUser.LastMessage.Stickers == null)
                                        checkUser.LastMessage.Stickers = "";

                                    checkUser.LastMessage.Id = item.LastMessage.Id;
                                    checkUser.LastMessage.FromId = item.LastMessage.FromId;
                                    checkUser.LastMessage.GroupId = item.LastMessage.GroupId;
                                    checkUser.LastMessage.ToId = item.LastMessage.ToId;
                                    checkUser.LastMessage.MediaFileName = item.LastMessage.MediaFileName;
                                    checkUser.LastMessage.MediaFileNames = item.LastMessage.MediaFileNames;
                                    checkUser.LastMessage.Time = item.LastMessage.Time;
                                     
                                    if (checkUser.LastMessage.Seen != "2")
                                    {
                                        checkUser.LastMessage.Seen = item.LastMessage.Seen;
                                    }
                                    else if(item.LastMessage.Seen=="0" && checkUser.LastMessage.Seen == "2")
                                    {
                                        checkUser.LastMessage.Seen = "0";
                                    }
                                    else if (item.LastMessage.Seen == "1" && checkUser.LastMessage.Seen == "2")
                                    {
                                        checkUser.LastMessage.Seen = "0";
                                    }

                                    checkUser.LastMessage.DeletedOne = item.LastMessage.DeletedOne;
                                    checkUser.LastMessage.DeletedTwo = item.LastMessage.DeletedTwo;
                                    checkUser.LastMessage.SentPush = item.LastMessage.SentPush;
                                    checkUser.LastMessage.NotificationId = item.LastMessage.NotificationId;
                                    checkUser.LastMessage.TypeTwo = item.LastMessage.TypeTwo;
                                    checkUser.LastMessage.Stickers = item.LastMessage.Stickers?.Replace(".mp4",".gif") ?? "";

                                    checkUser.OldAvatar = item.OldAvatar;
                                    checkUser.OldCover = item.OldCover;
                                     
                                    if (checkUser.LastMessage.Text != item.LastMessage.Text & string.IsNullOrEmpty(checkUser.LastMessage.MediaFileName))
                                    {
                                        checkUser.UserId = item.UserId;
                                        checkUser.Username = item.Username;
                                        checkUser.Avatar = item.Avatar;
                                        checkUser.Cover = item.Cover;
                                        checkUser.Lastseen = item.Lastseen;
                                        checkUser.Url = item.Url;
                                        checkUser.Name = item.Name;
                                        checkUser.ChatColor = item.ChatColor ?? AppSettings.MainColor;
                                        checkUser.Verified = item.Verified;
                                        checkUser.LastMessage.Text = item.LastMessage.Text;
                                        if (index > -1)
                                        {
                                            MessageController.UpdateRecyclerLastMessageView(checkUser.LastMessage, checkUser, index, this);

                                            LastMessagesTab.MAdapter.MLastMessagesUser.Move(index, 0);
                                            RunOnUiThread(() => { LastMessagesTab.MAdapter.NotifyItemMoved(index, 0); });
                                        }
                                    }

                                    if (checkUser.LastMessage.Media != item.LastMessage.Media) 
                                    {
                                        checkUser.LastMessage.Media = item.LastMessage.Media;
                                        if (index > -1)
                                        {
                                            checkUser.UserId = item.UserId;
                                            checkUser.Username = item.Username;
                                            checkUser.Avatar = item.Avatar;
                                            checkUser.Cover = item.Cover;
                                            checkUser.Lastseen = item.Lastseen;
                                            checkUser.Url = item.Url;
                                            checkUser.Name = item.Name;
                                            checkUser.ChatColor = item.ChatColor ?? AppSettings.MainColor;
                                            checkUser.Verified = item.Verified;
                                            MessageController.UpdateRecyclerLastMessageView(checkUser.LastMessage, checkUser, index, this);
                                        
                                            RunOnUiThread(() =>
                                            {
                                                LastMessagesTab.MAdapter.MLastMessagesUser.Move(index, 0);
                                                LastMessagesTab.MAdapter.NotifyItemMoved(index, 0);
                                            }); 
                                        }
                                    } 
                                }
                            }
                        }
                        else
                        {
                            LastMessagesTab.MAdapter.MLastMessagesUser = new ObservableCollection<GetUsersListObject.User>(result.Users);
                            RunOnUiThread(() => { LastMessagesTab.MAdapter.NotifyDataSetChanged(); });
                        }
                    }
                    else
                    {
                        if (LastMessagesTab.MAdapter.MLastMessagesUser.Count > 10 && !LastMessagesTab.MRecycler.CanScrollVertically(1))
                            Toast.MakeText(this, GetText(Resource.String.Lbl_No_more_users), ToastLength.Short).Show();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                #endregion

                #region Call >> Video_Call_User

                try
                {
                    if (AppSettings.EnableAudioVideoCall)
                    {
                        if (AppSettings.UseTwilioLibrary)
                        {
                            bool twilioVideoCall = result.VideoCall ?? false;
                            bool twilioAudioCall = result.AudioCall ?? false;

                            if (AppSettings.EnableVideoCall)
                            { 
                                #region Twilio Video call

                                if (twilioVideoCall && LastMessagesTab.SecondPassed >= 5 && !RunCall)
                                {
                                    var callUser = result.VideoCallUser?.CallUserClass;
                                    if (callUser != null)
                                    {
                                        RunCall = true;

                                        var userId = callUser.UserId;
                                        var avatar = callUser.Avatar;
                                        var name = callUser.Name;

                                        var videosData = callUser.data;
                                        if (videosData != null)
                                        {
                                            var id = videosData.Id; //call_id
                                            var accessToken = videosData.AccessToken;
                                            var accessToken2 = videosData.AccessToken2;
                                            var fromId = videosData.FromId;
                                            var active = videosData.Active;
                                            var time = videosData.Called;
                                            var declined = videosData.Declined;
                                            var roomName = videosData.RoomName;

                                            Intent intent = new Intent(this, typeof(VideoAudioComingCallActivity));
                                            intent.PutExtra("UserID", userId);
                                            intent.PutExtra("avatar", avatar);
                                            intent.PutExtra("name", name);
                                            intent.PutExtra("access_token", accessToken);
                                            intent.PutExtra("access_token_2", accessToken2);
                                            intent.PutExtra("from_id", fromId);
                                            intent.PutExtra("active", active);
                                            intent.PutExtra("time", time);
                                            intent.PutExtra("CallID", id);
                                            intent.PutExtra("status", declined);
                                            intent.PutExtra("room_name", roomName);
                                            intent.PutExtra("declined", declined);
                                            intent.PutExtra("type", "Twilio_video_call");

                                            string avatarSplit = avatar.Split('/').Last();
                                            var getImg =Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage,avatarSplit);
                                            if (getImg == "File Dont Exists")
                                                Methods.MultiMedia.DownloadMediaTo_DiskAsync(Methods.Path.FolderDiskImage, avatar);

                                            if (LastMessagesTab.SecondPassed < 5)
                                                LastMessagesTab.TimerCallingTimePassed.Start();
                                            else
                                            {
                                                RunCall = false;
                                                LastMessagesTab.TimerCallingTimePassed.Stop();

                                                LastMessagesTab.SecondPassed = 0;

                                                RunOnUiThread(() =>
                                                {
                                                    if (!VideoAudioComingCallActivity.IsActive)
                                                    {
                                                        intent.AddFlags(ActivityFlags.NewTask);
                                                        StartActivity(intent);
                                                    }
                                                });
                                            }
                                        }
                                    }
                                }
                                else if (twilioVideoCall == false && twilioAudioCall == false )
                                {
                                    if (LastMessagesTab.SecondPassed > 5)
                                    {
                                        RunCall = false;

                                        LastMessagesTab.SecondPassed = 0;

                                        if (VideoAudioComingCallActivity.IsActive)
                                            VideoAudioComingCallActivity.CallActivity?.Finish();
                                    }
                                }
                                else
                                {
                                    RunCall = false;
                                }

                                #endregion
                            }

                            if (AppSettings.EnableAudioCall)
                            {
                                #region Twilio Audio call

                                if (twilioAudioCall && !RunCall)
                                {
                                    var callUser = result.AudioCallUser?.CallUserClass;
                                    if (callUser != null)
                                    {
                                        RunCall = true;

                                        var userId = callUser.UserId;
                                        var avatar = callUser.Avatar;
                                        var name = callUser.Name;

                                        var videosData = callUser.data;
                                        if (videosData != null)
                                        {
                                            var id = videosData.Id; //call_id
                                            var accessToken = videosData.AccessToken;
                                            var accessToken2 = videosData.AccessToken2;
                                            var fromId = videosData.FromId;
                                            var active = videosData.Active;
                                            var time = videosData.Called;
                                            var declined = videosData.Declined;
                                            var roomName = videosData.RoomName;

                                            Intent intent = new Intent(this, typeof(VideoAudioComingCallActivity));
                                            intent.PutExtra("UserID", userId);
                                            intent.PutExtra("avatar", avatar);
                                            intent.PutExtra("name", name);
                                            intent.PutExtra("access_token", accessToken);
                                            intent.PutExtra("access_token_2", accessToken2);
                                            intent.PutExtra("from_id", fromId);
                                            intent.PutExtra("active", active);
                                            intent.PutExtra("time", time);
                                            intent.PutExtra("CallID", id);
                                            intent.PutExtra("status", declined);
                                            intent.PutExtra("room_name", roomName);
                                            intent.PutExtra("declined", declined);
                                            intent.PutExtra("type", "Twilio_audio_call");

                                            string avatarSplit = avatar.Split('/').Last();
                                            var getImg =
                                                Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage,
                                                    avatarSplit);
                                            if (getImg == "File Dont Exists")
                                                Methods.MultiMedia.DownloadMediaTo_DiskAsync(
                                                    Methods.Path.FolderDiskImage, avatar);

                                            if (LastMessagesTab.SecondPassed < 5)
                                                LastMessagesTab.TimerCallingTimePassed.Start();
                                            else
                                            {
                                                RunCall = false;

                                                LastMessagesTab.TimerCallingTimePassed.Stop();

                                                LastMessagesTab.SecondPassed = 0;

                                                RunOnUiThread(() =>
                                                {
                                                    if (!VideoAudioComingCallActivity.IsActive)
                                                    {
                                                        intent.AddFlags(ActivityFlags.NewTask);
                                                        StartActivity(intent);
                                                    }
                                                });
                                            }
                                        }
                                    }
                                }
                                else if (twilioAudioCall == false && twilioVideoCall == false)
                                {
                                    if (LastMessagesTab.SecondPassed >= 5)
                                    {
                                        RunCall = false;

                                        if (VideoAudioComingCallActivity.IsActive)
                                            VideoAudioComingCallActivity.CallActivity?.Finish();
                                    }
                                } 
                                else
                                {
                                    RunCall = false;
                                }

                                #endregion
                            }
                        }
                        else if (AppSettings.UseAgoraLibrary)
                        {
                            #region Agora Audio/Video call

                            var agoraCall = result.AgoraCall ?? false;
                            if (agoraCall && LastMessagesTab.SecondPassed >= 5 && !RunCall)
                            {
                                var callUser = result.AgoraCallData?.CallUserClass;

                                if (callUser != null)
                                {
                                    RunCall = true;

                                    var userId = callUser.UserId;
                                    var avatar = callUser.Avatar;
                                    var name = callUser.Name;

                                    var videosData = callUser.data;
                                    if (videosData != null)
                                    {
                                        var id = videosData.Id; //call_id
                                        //var accessToken = videosData.AccessToken;
                                        //var accessToken2 = videosData.AccessToken2;
                                        var fromId = videosData.FromId;
                                        //var active = videosData.Active;
                                        var time = videosData.Called;
                                        //var declined = videosData.Declined;
                                        var roomName = videosData.RoomName;
                                        var type = videosData.Type;
                                        var status = videosData.Status;

                                        string avatarSplit = avatar.Split('/').Last();
                                        var getImg =Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage,avatarSplit);
                                        if (getImg == "File Dont Exists")
                                            Methods.MultiMedia.DownloadMediaTo_DiskAsync(Methods.Path.FolderDiskImage, avatar);

                                        if (type == "video")
                                        {
                                            if (AppSettings.EnableVideoCall)
                                            {
                                                Intent intent = new Intent(this, typeof(VideoAudioComingCallActivity));
                                                intent.PutExtra("UserID", userId);
                                                intent.PutExtra("avatar", avatar);
                                                intent.PutExtra("name", name);
                                                intent.PutExtra("from_id", fromId);
                                                intent.PutExtra("status", status);
                                                intent.PutExtra("time", time);
                                                intent.PutExtra("CallID", id);
                                                intent.PutExtra("room_name", roomName);
                                                intent.PutExtra("type", "Agora_video_call_recieve");
                                                intent.PutExtra("declined", "0");

                                                if (!VideoAudioComingCallActivity.IsActive)
                                                {
                                                    intent.AddFlags(ActivityFlags.NewTask);
                                                    StartActivity(intent);
                                                }
                                            }
                                        }
                                        else if (type == "audio")
                                        {
                                            if (AppSettings.EnableAudioCall)
                                            {
                                                Intent intent = new Intent(this, typeof(VideoAudioComingCallActivity));
                                                intent.PutExtra("UserID", userId);
                                                intent.PutExtra("avatar", avatar);
                                                intent.PutExtra("name", name);
                                                intent.PutExtra("from_id", fromId);
                                                intent.PutExtra("status", status);
                                                intent.PutExtra("time", time);
                                                intent.PutExtra("CallID", id);
                                                intent.PutExtra("room_name", roomName);
                                                intent.PutExtra("type", "Agora_audio_call_recieve");
                                                intent.PutExtra("declined", "0");

                                                if (LastMessagesTab.SecondPassed < 5)
                                                    LastMessagesTab.TimerCallingTimePassed.Start();
                                                else
                                                {
                                                    RunCall = false;
                                                    LastMessagesTab.TimerCallingTimePassed.Stop();

                                                    LastMessagesTab.SecondPassed = 0;


                                                    if (!VideoAudioComingCallActivity.IsActive)
                                                    {
                                                        intent.AddFlags(ActivityFlags.NewTask);
                                                        StartActivity(intent);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (agoraCall == false)
                            {
                                if (LastMessagesTab.SecondPassed >= 5)
                                {
                                    RunCall = false;

                                    LastMessagesTab.SecondPassed = 0;
                                   
                                        if (VideoAudioComingCallActivity.IsActive)
                                            VideoAudioComingCallActivity.CallActivity?.Finish();
                                    
                                }
                            }

                            #endregion
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                #endregion

                try
                {
                    if (LastMessagesTab.SwipeRefreshLayout.Refreshing)
                        LastMessagesTab.SwipeRefreshLayout.Refreshing = false;

                    LastMessagesTab.MainScrollEvent.IsLoading = false;

                    if (LastMessagesTab.MAdapter.MLastMessagesUser.Count > 0)
                    {
                        SqLiteDatabase dbDatabase = new SqLiteDatabase();
                        ListUtils.UserList = LastMessagesTab.MAdapter.MLastMessagesUser;

                        LastMessagesTab.MRecycler.Visibility = ViewStates.Visible;
                        LastMessagesTab.EmptyStateLayout.Visibility = ViewStates.Gone;

                        //Insert All data users to database
                        dbDatabase.Insert_Or_Update_LastUsersChat(LastMessagesTab.MAdapter.MLastMessagesUser);
                        dbDatabase.Dispose();
                    }
                    else
                    {
                        LastMessagesTab.MRecycler.Visibility = ViewStates.Gone; 
                        LastMessagesTab.MRecycler.Visibility = ViewStates.Gone;

                        if (LastMessagesTab.Inflated == null)
                            LastMessagesTab.Inflated = LastMessagesTab.EmptyStateLayout.Inflate();

                        EmptyStateInflater x = new EmptyStateInflater();
                        x.InflateLayout(LastMessagesTab.Inflated, EmptyStateInflater.Type.NoMessages);
                        if (!x.EmptyStateButton.HasOnClickListeners)
                        {
                            x.EmptyStateButton.Click += null;
                        }

                        LastMessagesTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void LoadUserMessagesDuringScroll(GetUsersListObject result)
        {
            try
            {
                int countList = LastMessagesTab.MAdapter.MLastMessagesUser.Count;

                var respondList = result.Users?.Count;
                if (respondList > 0)
                {
                    if (countList > 5)
                    {
                        foreach (var item in result.Users)
                        {
                            if (LastMessagesTab.MAdapter.MLastMessagesUser.FirstOrDefault(a => a.UserId == item.UserId) == null)
                                LastMessagesTab.MAdapter.MLastMessagesUser.Add(item);
                        }

                        RunOnUiThread(() => { LastMessagesTab.MAdapter.NotifyItemRangeInserted(countList, LastMessagesTab.MAdapter.ItemCount); });
                    }
                    else
                    {
                        LastMessagesTab.MAdapter.MLastMessagesUser = new ObservableCollection<GetUsersListObject.User>(result.Users);
                        RunOnUiThread(() => { LastMessagesTab.MAdapter.NotifyDataSetChanged(); });
                    }

                    ListUtils.UserList = LastMessagesTab.MAdapter.MLastMessagesUser;
                }
                else
                {
                    if (LastMessagesTab.MAdapter.MLastMessagesUser.Count > 10 && !LastMessagesTab.MRecycler.CanScrollVertically(1))
                        Toast.MakeText(this, GetText(Resource.String.Lbl_No_more_users), ToastLength.Short).Show();
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void GetOneSignalNotification()
        {
            try
            {
                string userId = Intent.GetStringExtra("UserID") ?? "Don't have type";
                if (!string.IsNullOrEmpty(userId) && userId != "Don't have type")
                {
                    var dataUser = LastMessagesTab?.MAdapter?.MLastMessagesUser?.FirstOrDefault(a => a.UserId == userId);

                    Intent intent = new Intent(this, typeof(ChatWindowActivity));
                    intent.PutExtra("UserID", userId);

                    if (dataUser != null)
                    {
                        intent.PutExtra("TypeChat", "LastMessenger");
                        intent.PutExtra("ColorChat", dataUser.ChatColor);
                        intent.PutExtra("UserItem", JsonConvert.SerializeObject(dataUser));
                    }
                    else
                    {
                        intent.PutExtra("TypeChat", "OneSignalNotification");
                        intent.PutExtra("ColorChat", AppSettings.MainColor);
                    }
                    StartActivity(intent);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}