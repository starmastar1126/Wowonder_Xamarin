﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using Android;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Ads;
using Android.Gms.Ads.Formats;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using Newtonsoft.Json;
using WoWonder.Activities.ChatWindow;
using WoWonder.Activities.DialogUserFragment;
using WoWonder.Activities.FriendRequest;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Activities.Tab.Adapter;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Requests;
using Timer = System.Timers.Timer;

namespace WoWonder.Activities.Tab.Fragment
{
    public class LastMessagesFragment : Android.Support.V4.App.Fragment, UnifiedNativeAd.IOnUnifiedNativeAdLoadedListener
    {
        #region Variables Basic

        public LastMessagesAdapter MAdapter;
        private TabbedMainActivity GlobalContext;
        public SwipeRefreshLayout SwipeRefreshLayout;
        public RecyclerView MRecycler;
        private LinearLayoutManager LayoutManager;
        public ViewStub EmptyStateLayout;
        public View Inflated;
        private bool OnlineUsers = true;
        public bool FirstRun = true;
        private string UserId = "";

        public Timer TimerCallingTimePassed;
        public int SecondPassed;
        public RecyclerViewOnScrollListener MainScrollEvent;

        private RelativeLayout LayoutFriendRequest;
        private ImageView FriendRequestImage1, FriendRequestImage2, FriendRequestImage3;

        #endregion

        #region General

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Create your fragment here
            GlobalContext = (TabbedMainActivity)Activity;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.LastMessagesLayout, container, false);
                 
                try
                {
                    OnlineUsers = MainSettings.SharedData.GetBoolean("notifications_key", true);
                }
                catch (Exception e)
                { 
                    Console.WriteLine(e);
                }
                 
                InitComponent(view);
                SetRecyclerViewAdapters();
                BindAdMob(view);

                Get_LastChat();

                // Run timer 
                TimerCallingTimePassed = new Timer { Interval = 1000 };
                TimerCallingTimePassed.Elapsed += TimerCallingTimePassed_Elapsed;
                TimerCallingTimePassed.Enabled = true;

                GlobalContext.GetOneSignalNotification();

                return view;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        private void TimerCallingTimePassed_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                SecondPassed++;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                MRecycler = (RecyclerView)view.FindViewById(Resource.Id.recyler);
                EmptyStateLayout = view.FindViewById<ViewStub>(Resource.Id.viewStub);

                SwipeRefreshLayout = (SwipeRefreshLayout)view.FindViewById(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = false;
                SwipeRefreshLayout.Enabled = true;
                SwipeRefreshLayout.Refresh += SwipeRefreshLayoutOnRefresh;

                LayoutFriendRequest = (RelativeLayout)view.FindViewById(Resource.Id.layout_friend_Request);

                FriendRequestImage1 = (ImageView)view.FindViewById(Resource.Id.image_page_1);
                FriendRequestImage2 = (ImageView)view.FindViewById(Resource.Id.image_page_2);
                FriendRequestImage3 = (ImageView)view.FindViewById(Resource.Id.image_page_3);

                LayoutFriendRequest.Click += LayoutFriendRequestOnClick;
                LayoutFriendRequest.Visibility = ViewStates.Gone; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                MAdapter = new LastMessagesAdapter(Activity, OnlineUsers) { MLastMessagesUser = new ObservableCollection<GetUsersListObject.User>(ListUtils.UserList) };
                MAdapter.ItemClick += MAdapterOnItemClick;
                MAdapter.ItemLongClick += MAdapterOnItemLongClick;
                LayoutManager = new LinearLayoutManager(Activity);
                MRecycler.SetLayoutManager(LayoutManager);
                MRecycler.SetAdapter(MAdapter);
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true;

                var sizeProvider = new FixedPreloadSizeProvider(10, 10);
                var preLoader = new RecyclerViewPreloader<GetUsersListObject.User>(Activity, MAdapter, sizeProvider, 8);
                MRecycler.AddOnScrollListener(preLoader);

                RecyclerViewOnScrollListener xamarinRecyclerViewOnScrollListener = new RecyclerViewOnScrollListener(LayoutManager);
                MainScrollEvent = xamarinRecyclerViewOnScrollListener;
                MainScrollEvent.LoadMoreEvent += MainScrollEventOnLoadMoreEvent;
                MRecycler.AddOnScrollListener(xamarinRecyclerViewOnScrollListener);
                MainScrollEvent.IsLoading = false;
                IsChatMessageLoaded = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private TemplateView Template;
        private void BindAdMob(View view)
        {
            try
            {
                Template = view.FindViewById<TemplateView>(Resource.Id.my_template);
                Template.Visibility = ViewStates.Gone;

                if (AppSettings.ShowAdmobNative)
                {
                    AdLoader.Builder builder = new AdLoader.Builder(Context, AppSettings.AdAdmobNativeKey);
                    builder.ForUnifiedNativeAd(this);
                    VideoOptions videoOptions = new VideoOptions.Builder()
                        .SetStartMuted(true)
                        .Build();
                    NativeAdOptions adOptions = new NativeAdOptions.Builder()
                        .SetVideoOptions(videoOptions)
                        .Build();

                    builder.WithNativeAdOptions(adOptions);

                    AdLoader adLoader = builder.WithAdListener(new AdListener()).Build();
                    adLoader.LoadAd(new AdRequest.Builder().Build());
                }
                else
                {
                    Template.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnUnifiedNativeAdLoaded(UnifiedNativeAd ad)
        {
            try
            {
                NativeTemplateStyle styles = new NativeTemplateStyle.Builder().Build();

                if (Template.GetTemplateTypeName() == TemplateView.BigTemplate)
                {
                    Template.PopulateUnifiedNativeAdView(ad);
                }
                else
                {
                    Template.SetStyles(styles);
                    Template.SetNativeAd(ad);
                }

                Template.Visibility = ViewStates.Visible; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion

        #region Event

        //Scroll
        private void MainScrollEventOnLoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                //Code get last id where LoadMore >>
                var item = MAdapter.MLastMessagesUser.LastOrDefault();
                if (item != null && !string.IsNullOrEmpty(item.ChatTime))
                   PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => LoadLastMessagesApi(item.ChatTime) },3);

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void SwipeRefreshLayoutOnRefresh(object sender, EventArgs e)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Context, Context.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();

                    if (SwipeRefreshLayout.Refreshing)
                        SwipeRefreshLayout.Refreshing = false;
                }
                else
                {
                    MAdapter.MLastMessagesUser.Clear();
                    MAdapter.NotifyDataSetChanged();
                    ListUtils.UserList.Clear();

                    SqLiteDatabase dbDatabase = new SqLiteDatabase();
                    dbDatabase.ClearAll_LastUsersChat();
                    dbDatabase.ClearAll_Messages();
                    dbDatabase.Dispose();

                    UserDetails.OffsetLastChat = "0";

                    if (MAdapter.MLastMessagesUser.Count == 0)
                    {
                       // GlobalContext?.SetService();
                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { LoadDataApiLastChat }, 3);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void MAdapterOnItemLongClick(object sender, LastMessagesAdapterClickEventArgs e)
        {
            try
            {
                var position = e.Position;
                if (position >= 0)
                {
                    var item = MAdapter.GetItem(position);
                    if (item != null)
                    {
                        //Pull up dialog 
                        DialogDeleteMessage userDialog = new DialogDeleteMessage(item.UserId, item);
                        userDialog.Show(Activity.SupportFragmentManager, userDialog.Tag);
                        userDialog.OnDeleteMessageUpComplete += UserDialogOnOnDeleteMessageUpComplete;
                    }
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void MAdapterOnItemClick(object sender, LastMessagesAdapterClickEventArgs e)
        {
            try
            {
                var position = e.Position;
                if (position >= 0)
                {
                    var item = MAdapter.GetItem(position);
                    if (item != null)
                    {
                        UserId = item.UserId;
                        Activity.RunOnUiThread(() =>
                        {
                            item.LastMessage.Seen = "2";
                            MAdapter.NotifyItemChanged(position);
                        });
                        

                        

                        if (item.ChatColor == null)
                            item.ChatColor = AppSettings.MainColor;

                        var mainChatColor = item.ChatColor.Contains("rgb") ? Methods.FunString.ConvertColorRgBtoHex(item.ChatColor) : item.ChatColor ?? AppSettings.MainColor;

                        Intent intent = new Intent(Context, typeof(ChatWindowActivity));
                        intent.PutExtra("UserID", item.UserId);
                        intent.PutExtra("TypeChat", "LastMessenger");
                        intent.PutExtra("ColorChat", mainChatColor);
                        intent.PutExtra("UserItem", JsonConvert.SerializeObject(item));

                        // Check if we're running on Android 5.0 or higher
                        if ((int)Build.VERSION.SdkInt < 23)
                        { 
                            StartActivity(intent);
                        }
                        else
                        {
                            //Check to see if any permission in our group is available, if one, then all are
                            if (Context.CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted && Context.CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            { 
                                StartActivity(intent);
                            }
                            else
                            {
                                RequestPermissions(new[]
                                {
                                    Manifest.Permission.ReadExternalStorage,
                                    Manifest.Permission.WriteExternalStorage
                                }, 101);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void UserDialogOnOnDeleteMessageUpComplete(object sender, DialogDeleteMessage.OnDeleteMessageUpEventArgs args)
        {
            try
            {
                Thread th = new Thread(ActLikeARequest);
                th.Start();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void ActLikeARequest()
        {
            int x = Resource.Animation.slide_right;
            Console.WriteLine(x);
        }

        private void LayoutFriendRequestOnClick(object sender, EventArgs e)
        {
            try
            {
                if (ListUtils.FriendRequestsList.Count > 0)
                {
                    var Int = new Intent(Context, typeof(FriendRequestActivity));
                    Context.StartActivity(Int);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        #endregion

        #region Permissions

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 101)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        var data = MAdapter.MLastMessagesUser.FirstOrDefault(a => a.UserId == UserId);
                        if (data != null)
                        {
                            Intent intent = new Intent(Context, typeof(ChatWindowActivity));
                            intent.PutExtra("UserID", data.UserId);
                            intent.PutExtra("TypeChat", "LastMessenger");
                            intent.PutExtra("UserItem", JsonConvert.SerializeObject(data));
                            StartActivity(intent);
                        }
                    }
                    else
                    {
                        Toast.MakeText(Context, Context.GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void Get_LastChat()
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                }
                else
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt >= 23)
                    {
                        if (Activity.CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                            Activity.CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted &&
                            Activity.CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted &&
                            Activity.CheckSelfPermission(Manifest.Permission.RecordAudio) == Permission.Granted &&
                            Activity.CheckSelfPermission(Manifest.Permission.ModifyAudioSettings) == Permission.Granted)
                        {
                        }
                        else
                        {
                            Activity.RequestPermissions(new[]
                            {
                                Manifest.Permission.ReadExternalStorage,
                                Manifest.Permission.WriteExternalStorage,
                                Manifest.Permission.Camera,
                                Manifest.Permission.RecordAudio,
                                Manifest.Permission.ModifyAudioSettings,
                            }, 1234);
                        }
                    }
                }

                if (MAdapter.MLastMessagesUser?.Count == 0)
                {
                    SwipeRefreshLayout.Refreshing = true;
                    SwipeRefreshLayout.Enabled = true;
                }


                if (ListUtils.UserList.Count > 0)
                {
                    MAdapter.MLastMessagesUser = new ObservableCollection<GetUsersListObject.User>(ListUtils.UserList);
                    MAdapter.NotifyDataSetChanged();
                    EmptyStateLayout.Visibility = ViewStates.Gone;
                    MRecycler.Visibility = ViewStates.Visible;
                    SwipeRefreshLayout.Refreshing = false;
                }


                //var chatList = dbDatabase.Get_LastUsersChat_List();
                //if (MAdapter?.MLastMessagesUser?.Count > 0) 
                //{
                //    MAdapter.MLastMessagesUser = new ObservableCollection<GetUsersListObject.User>(chatList);
                //    ListUtils.UserList = MAdapter.MLastMessagesUser;
                //    if (chatList?.Count > 0)
                //    {
                //        MAdapter.NotifyDataSetChanged();

                //        EmptyStateLayout.Visibility = ViewStates.Gone;
                //        MRecycler.Visibility = ViewStates.Visible;

                //        SwipeRefreshLayout.Refreshing = false;
                //        //SwipeRefreshLayout.Enabled = false;
                //    }
                //}

                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { LoadDataApiLastChat, LoadGeneralData }, 3);
               
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                SwipeRefreshLayout.Refreshing = false;
                //SwipeRefreshLayout.Enabled = false;
            }
        }

        //Get General Data Using Api >> Friend Requests
        private async Task LoadGeneralData()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    (int apiStatus, var respond) = await RequestsAsync.Global.Get_General_Data(false, UserDetails.DeviceId, "", "friend_requests");
                    if (apiStatus == 200)
                    {
                        if (respond is GetGeneralDataObject result)
                        {
                            Activity.RunOnUiThread(() =>
                            {
                                try
                                {
                                    // Friend Requests
                                    if (result.FriendRequests.Count > 0)
                                    {
                                        ListUtils.FriendRequestsList = new ObservableCollection<UserDataObject>(result.FriendRequests);

                                        LayoutFriendRequest.Visibility = ViewStates.Visible;
                                        try
                                        {
                                            for (var i = 0; i < 4; i++)
                                                switch (i)
                                                {
                                                    case 0:
                                                        GlideImageLoader.LoadImage(Activity, ListUtils.FriendRequestsList[i].Avatar, FriendRequestImage1, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                        break;
                                                    case 1:
                                                        GlideImageLoader.LoadImage(Activity, ListUtils.FriendRequestsList[i].Avatar, FriendRequestImage2, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                        break;
                                                    case 2:
                                                        GlideImageLoader.LoadImage(Activity, ListUtils.FriendRequestsList[i].Avatar, FriendRequestImage3, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                        break;
                                                }
                                        }
                                        catch (Exception e)
                                        {
                                            Console.WriteLine(e);
                                        }
                                    }
                                    else
                                    {
                                        LayoutFriendRequest.Visibility = ViewStates.Gone;
                                    }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e);
                                }
                            });
                        }
                    }
                    else Methods.DisplayReportResult(Activity, respond);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private bool IsChatMessageLoaded;

        private async Task LoadLastMessagesApi(string x)
        {
            if (IsChatMessageLoaded)
                return;

            UserDetails.OffsetLastChat = MAdapter.MLastMessagesUser.Count > 0 ? MAdapter.MLastMessagesUser.LastOrDefault()?.ChatTime ?? "0" : "0";

            var (apiStatus, respond) = await ApiRequest.Get_users_list_Async("35", x);
            if (apiStatus == 200 && respond is GetUsersListObject result)
            {
                if (result.Users.Count > 0)
                {
                    GlobalContext.LoadUserMessagesDuringScroll(result);
                    IsChatMessageLoaded = false;
                }
                else
                    IsChatMessageLoaded = true;
            }
            else
                Methods.DisplayReportResult(Activity, respond);
        }

        private async Task LoadDataApiLastChat()
        {
            var (apiStatus, respond) = await ApiRequest.Get_users_list_Async();
            if (apiStatus == 200 && respond is GetUsersListObject result)
            {
                if (result.Users.Count > 0)
                    GlobalContext.LoadDataJsonLastChat(result);
                else
                    IsChatMessageLoaded = true;
            }
            else
                Methods.DisplayReportResult(Activity, respond); 
        } 
    }
}