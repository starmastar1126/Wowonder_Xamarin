using System;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Views;
using WoWonder.Activities.Tab.Adapter;
using WoWonder.Frameworks.Agora;
using WoWonder.Frameworks.Twilio;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;

namespace WoWonder.Activities.Tab.Fragment
{
    public class LastCallsFragment : Android.Support.V4.App.Fragment
    { 
        #region Variables Basic

        public LastCallsAdapter MAdapter;
        private SwipeRefreshLayout SwipeRefreshLayout;
        public RecyclerView MRecycler;
        private LinearLayoutManager LayoutManager;
        private ViewStub EmptyStateLayout;
        private View Inflated;

        private string TimeNow = DateTime.Now.ToString("hh:mm");
        private static readonly int UnixTimestamp = (int) (DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
        private string Time = Convert.ToString(UnixTimestamp);
        
        #endregion

        #region General

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            { 
               View view = inflater.Inflate(Resource.Layout.MainFragmentLayout, container, false);

                InitComponent(view); 
                SetRecyclerViewAdapters(); 
                 
                return view;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                MRecycler = (RecyclerView)view.FindViewById(Resource.Id.recyler);
                EmptyStateLayout = view.FindViewById<ViewStub>(Resource.Id.viewStub);

                SwipeRefreshLayout = (SwipeRefreshLayout)view.FindViewById(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = false;
                SwipeRefreshLayout.Enabled = false; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
          
        private void SetRecyclerViewAdapters()
        {
            try
            {
                MAdapter = new LastCallsAdapter(Activity){MCallUser = new ObservableCollection<Classes.CallUser>()};
                MAdapter.CallClick += MAdapterOnCallClick;
                LayoutManager = new LinearLayoutManager(Activity);
                MRecycler.SetLayoutManager(LayoutManager);
                MRecycler.SetAdapter(MAdapter);
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
          
        #endregion

        #region Events 

        private void MAdapterOnCallClick(object sender, LastCallsAdapterClickEventArgs adapterClickEvents)
        {
            try
            {
                TimeNow = DateTime.Now.ToString("hh:mm");
                Int32 unixTimestamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                Time = Convert.ToString(unixTimestamp);

                if (AppSettings.EnableAudioCall && AppSettings.EnableVideoCall)
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Activity, Resource.Style.AlertDialogCustom);
                     
                    builder.SetTitle(GetText(Resource.String.Lbl_Call));
                    builder.SetMessage(GetText(Resource.String.Lbl_Select_Type_Call));

                    builder.SetPositiveButton(GetText(Resource.String.Lbl_Voice_call), delegate
                    {
                        try
                        {
                            var position = adapterClickEvents.Position;
                            if (position >= 0)
                            {
                                var item = MAdapter.GetItem(position);
                                if (item != null)
                                {
                                    Intent intentOfvideoCall =
                                        new Intent(Context, typeof(TwilioVideoCallActivity));
                                    if (AppSettings.UseAgoraLibrary && AppSettings.UseTwilioLibrary == false)
                                    {
                                        intentOfvideoCall = new Intent(Context, typeof(AgoraAudioCallActivity));
                                        intentOfvideoCall.PutExtra("type", "Agora_audio_calling_start");
                                    }
                                    else if (AppSettings.UseAgoraLibrary == false && AppSettings.UseTwilioLibrary)
                                    {
                                        intentOfvideoCall = new Intent(Context, typeof(TwilioAudioCallActivity));
                                        intentOfvideoCall.PutExtra("type", "Twilio_audio_calling_start");
                                    }

                                    intentOfvideoCall.PutExtra("UserID", item.UserId);
                                    intentOfvideoCall.PutExtra("avatar", item.Avatar);
                                    intentOfvideoCall.PutExtra("name", item.Name);
                                    intentOfvideoCall.PutExtra("time", TimeNow);
                                    intentOfvideoCall.PutExtra("CallID", Time);
                                    StartActivity(intentOfvideoCall);
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    });

                    builder.SetNegativeButton(GetText(Resource.String.Lbl_Video_call), delegate
                    {
                        try
                        {
                            var position = adapterClickEvents.Position;
                            if (position >= 0)
                            {
                                var item = MAdapter.GetItem(position);
                                if (item != null)
                                {
                                    Intent intentOfvideoCall =
                                        new Intent(Context, typeof(TwilioVideoCallActivity));
                                    if (AppSettings.UseAgoraLibrary && AppSettings.UseTwilioLibrary == false)
                                    {
                                        intentOfvideoCall = new Intent(Context, typeof(AgoraVideoCallActivity));
                                        intentOfvideoCall.PutExtra("type", "Agora_video_calling_start");
                                    }
                                    else if (AppSettings.UseAgoraLibrary == false && AppSettings.UseTwilioLibrary)
                                    {
                                        intentOfvideoCall = new Intent(Context, typeof(TwilioVideoCallActivity));
                                        intentOfvideoCall.PutExtra("type", "Twilio_video_calling_start");
                                    }

                                    intentOfvideoCall.PutExtra("UserID", item.UserId);
                                    intentOfvideoCall.PutExtra("avatar", item.Avatar);
                                    intentOfvideoCall.PutExtra("name", item.Name);
                                    intentOfvideoCall.PutExtra("time", TimeNow);
                                    intentOfvideoCall.PutExtra("CallID", Time);
                                    intentOfvideoCall.PutExtra("access_token", "YOUR_TOKEN");
                                    intentOfvideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                                    intentOfvideoCall.PutExtra("from_id", "0");
                                    intentOfvideoCall.PutExtra("active", "0");
                                    intentOfvideoCall.PutExtra("status", "0");
                                    intentOfvideoCall.PutExtra("room_name", "TestRoom");
                                    StartActivity(intentOfvideoCall);
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    });

                    var alert = builder.Create();
                    alert.Show();
                }
                else if (AppSettings.EnableAudioCall == false && AppSettings.EnableVideoCall) // Video Call On
                {
                    try
                    {
                        var position = adapterClickEvents.Position;
                        if (position >= 0)
                        {
                            var item = MAdapter.GetItem(position);
                            if (item != null)
                            {
                                Intent intentOfvideoCall = new Intent(Context, typeof(TwilioVideoCallActivity));
                                if (AppSettings.UseAgoraLibrary && AppSettings.UseTwilioLibrary == false)
                                {
                                    intentOfvideoCall = new Intent(Context, typeof(AgoraVideoCallActivity));
                                    intentOfvideoCall.PutExtra("type", "Agora_video_calling_start");
                                }
                                else if (AppSettings.UseAgoraLibrary == false && AppSettings.UseTwilioLibrary)
                                {
                                    intentOfvideoCall = new Intent(Context, typeof(TwilioVideoCallActivity));
                                    intentOfvideoCall.PutExtra("type", "Twilio_video_calling_start");
                                }

                                intentOfvideoCall.PutExtra("UserID", item.UserId);
                                intentOfvideoCall.PutExtra("avatar", item.Avatar);
                                intentOfvideoCall.PutExtra("name", item.Name);
                                intentOfvideoCall.PutExtra("time", TimeNow);
                                intentOfvideoCall.PutExtra("CallID", Time);
                                intentOfvideoCall.PutExtra("access_token", "YOUR_TOKEN");
                                intentOfvideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                                intentOfvideoCall.PutExtra("from_id", "0");
                                intentOfvideoCall.PutExtra("active", "0");
                                intentOfvideoCall.PutExtra("status", "0");
                                intentOfvideoCall.PutExtra("room_name", "TestRoom");
                                StartActivity(intentOfvideoCall);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (AppSettings.EnableAudioCall && AppSettings.EnableVideoCall == false) // Audio Call On
                {
                    try
                    {
                        var position = adapterClickEvents.Position;
                        if (position >= 0)
                        {
                            var item = MAdapter.GetItem(position);
                            if (item != null)
                            {
                                Intent intentOfvideoCall = new Intent(Context, typeof(TwilioVideoCallActivity));
                                if (AppSettings.UseAgoraLibrary && AppSettings.UseTwilioLibrary == false)
                                {
                                    intentOfvideoCall = new Intent(Context, typeof(AgoraAudioCallActivity));
                                    intentOfvideoCall.PutExtra("type", "Agora_audio_calling_start");
                                }
                                else if (AppSettings.UseAgoraLibrary == false && AppSettings.UseTwilioLibrary)
                                {
                                    intentOfvideoCall = new Intent(Context, typeof(TwilioAudioCallActivity));
                                    intentOfvideoCall.PutExtra("type", "Twilio_audio_calling_start");
                                }

                                intentOfvideoCall.PutExtra("UserID", item.UserId);
                                intentOfvideoCall.PutExtra("avatar", item.Avatar);
                                intentOfvideoCall.PutExtra("name", item.Name);
                                intentOfvideoCall.PutExtra("time", TimeNow);
                                intentOfvideoCall.PutExtra("CallID", Time);
                                intentOfvideoCall.PutExtra("access_token", "YOUR_TOKEN");
                                intentOfvideoCall.PutExtra("access_token_2", "YOUR_TOKEN");
                                intentOfvideoCall.PutExtra("from_id", "0");
                                intentOfvideoCall.PutExtra("active", "0");
                                intentOfvideoCall.PutExtra("status", "0");
                                intentOfvideoCall.PutExtra("room_name", "TestRoom");
                                StartActivity(intentOfvideoCall);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion
         
        public void Get_CallUser()
        {
            try
            {
                var dbDatabase = new SqLiteDatabase(); 
                var localList = dbDatabase.Get_CallUserList();
                if (localList?.Count > 0)
                {
                    if (MAdapter.MCallUser.Count > 0)
                    {
                        //Bring new users
                        var listNew = localList.Where(c => !MAdapter.MCallUser.Select(fc => fc.Id).Contains(c.Id)).ToList(); // id >> Call_Id
                        if (listNew.Count > 0)
                        {
                            //Results differ
                            ListUtils.AddRange(MAdapter.MCallUser, listNew);

                            var callUser = new ObservableCollection<Classes.CallUser>(MAdapter.MCallUser.OrderBy(a => a.Id));
                            MAdapter.MCallUser = new ObservableCollection<Classes.CallUser>(callUser);
                            MAdapter.BindEnd();
                        } 
                    }
                    else
                    {
                        MAdapter.MCallUser = new ObservableCollection<Classes.CallUser>(localList.OrderBy(a => a.Id));
                        MAdapter.BindEnd();
                    }
                }

                ShowEmptyPage();

                dbDatabase.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void ShowEmptyPage()
        {
            try
            {
                SwipeRefreshLayout.Refreshing = false;

                if (MAdapter.MCallUser.Count > 0)
                {
                    MRecycler.Visibility = ViewStates.Visible;
                    EmptyStateLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    MRecycler.Visibility = ViewStates.Gone;

                    if (Inflated == null)
                        Inflated = EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(Inflated, EmptyStateInflater.Type.NoCall);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                    }
                    EmptyStateLayout.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception e)
            {
                SwipeRefreshLayout.Refreshing = false;
                Console.WriteLine(e);
            }
        } 
    }
}