﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using Java.IO;
using Refractored.Controls;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using Console = System.Console;
using Object = Java.Lang.Object;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Tab.Adapter
{
    public class LastMessagesAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<LastMessagesAdapterClickEventArgs> ItemClick;
        public event EventHandler<LastMessagesAdapterClickEventArgs> ItemLongClick;

        public ObservableCollection<GetUsersListObject.User> MLastMessagesUser = new ObservableCollection<GetUsersListObject.User>();

        private readonly Activity ActivityContext;
        private readonly List<string> ListOnline = new List<string>();
        private bool OnlineUsers { get; set; }
        private readonly RequestOptions Options;

        public LastMessagesAdapter(Activity context,bool onlineUsers)
        {
            try
            {
                ActivityContext = context; 
                OnlineUsers = onlineUsers;
                Options = new RequestOptions().Apply(RequestOptions.CircleCropTransform()
                    .CenterCrop().CircleCrop()
                    .SetPriority(Priority.High).Override(200)
                    .SetUseAnimationPool(false).SetDiskCacheStrategy(DiskCacheStrategy.All)
                    .Error(Resource.Drawable.ImagePlacholder_circle)
                    .Placeholder(Resource.Drawable.ImagePlacholder_circle));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
               
                //Setup your layout here >> Last_Message_view
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Last_Message_view, parent, false);

                var holder = new LastMessagesAdapterViewHolder(itemView, OnClick, OnLongClick);
                return holder;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder is LastMessagesAdapterViewHolder holder)
                {
                    var item = MLastMessagesUser[position];
                    if (item != null)
                    {
                        if (AppSettings.FlowDirectionRightToLeft)
                        {
                            holder.RelativeLayoutMain.LayoutDirection = LayoutDirection.Rtl;
                            holder.TxtUsername.TextDirection = TextDirection.Rtl;
                            holder.TxtLastMessages.TextDirection = TextDirection.Rtl;
                        }

                        Initialize(holder, item);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Initialize(LastMessagesAdapterViewHolder holder, GetUsersListObject.User item)
        {
            try
            {
                var image = !string.IsNullOrEmpty(item.OldAvatar) ? item.OldAvatar : item.Avatar ?? "";
                if (!string.IsNullOrEmpty(image))
                {
                    var avatarSplit = image.Split('/').Last();
                    var getImageAvatar = Methods.MultiMedia.GetMediaFrom_Disk(Methods.Path.FolderDiskImage, avatarSplit);
                    if (getImageAvatar != "File Dont Exists")
                    {
                        var file = Uri.FromFile(new File(getImageAvatar));
                        Glide.With(ActivityContext).Load(file.Path).Apply(Options).Into(holder.ImageAvatar);
                    }
                    else
                    {
                        Methods.MultiMedia.DownloadMediaTo_DiskAsync(Methods.Path.FolderDiskImage, image);
                        GlideImageLoader.LoadImage(ActivityContext, image, holder.ImageAvatar, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                    } 
                }
                 
                holder.TxtUsername.Text = WoWonderTools.GetNameFinal(item);

                if (item.LastMessage.Stickers != null)
                    item.LastMessage.Stickers = item.LastMessage.Stickers.Replace(".mp4", ".gif");

                //If message contains Media files 
                if (item.LastMessage.Media.Contains("image"))
                {
                  //  if (holder.LastMessagesIcon.Text != IonIconsFonts.Images)
                    //{
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LastMessagesIcon, IonIconsFonts.Images);
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendImageFile);
                  //  }
                }
                else if (item.LastMessage.Media.Contains("video"))
                {
                   // if (holder.LastMessagesIcon.Text != IonIconsFonts.Videocamera)
                   // {
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LastMessagesIcon, IonIconsFonts.Videocamera);
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendVideoFile);
                   // }
                }
                else if (item.LastMessage.Media.Contains("sticker"))
                {
                    //if (holder.LastMessagesIcon.Text != IonIconsFonts.Happy)
                   // {
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LastMessagesIcon, IonIconsFonts.Happy);
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendStickerFile);
                   // }
                }
                else if (item.LastMessage.Media.Contains("sounds"))
                {
                    //if (holder.LastMessagesIcon.Text != IonIconsFonts.IosMusicalNote)
                    //{
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LastMessagesIcon, IonIconsFonts.IosMusicalNote);
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendAudioFile);
                  //  }
                }
                else if (item.LastMessage.Media.Contains("file"))
                {
                   // if (holder.LastMessagesIcon.Text != IonIconsFonts.IosMusicalNote)
                  //  {
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LastMessagesIcon, IonIconsFonts.Document);
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendFile);
                   // }
                }
                else if (item.LastMessage?.Stickers != null && item.LastMessage.Stickers.Contains(".gif"))
                {
                    //if (holder.LastMessagesIcon.Text != "\uf06b")
                    //{
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.LastMessagesIcon, "\uf06b");
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendGifFile);
                    //}
                }
                else if (!string.IsNullOrEmpty(item.LastMessage.ProductId) && item.LastMessage.ProductId != "0")
                {
                    //if (holder.LastMessagesIcon.Text != FontAwesomeIcon.ShoppingCart)
                    //{
                        holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.LastMessagesIcon, FontAwesomeIcon.ShoppingCart);
                        holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendProductFile);
                   // }
                }
                else
                {
                    holder.LastMessagesIcon.Visibility = ViewStates.Gone;

                    if (item.LastMessage.Text.Contains("http"))
                    {
                        holder.TxtLastMessages.Text = Methods.FunString.SubStringCutOf(item.LastMessage.Text, 30);
                    }
                    else if (item.LastMessage.Text.Contains("{&quot;Key&quot;") || item.LastMessage.Text.Contains("{key:^qu") || item.LastMessage.Text.Contains("{^key:^qu") || item.LastMessage.Text.Contains("{key:"))
                    {
                        if (holder.LastMessagesIcon.Text != IonIconsFonts.IosContact)
                        {
                            holder.LastMessagesIcon.Visibility = ViewStates.Visible;
                            FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LastMessagesIcon, IonIconsFonts.IosContact);
                            holder.TxtLastMessages.Text = ActivityContext.GetText(Resource.String.Lbl_SendContactnumber);
                        }
                    }
                    else
                    {
                        holder.TxtLastMessages.Text = Methods.FunString.DecodeString(Methods.FunString.SubStringCutOf(item.LastMessage.Text, 30));
                    }
                }

                //last seen time  
                holder.TxtTimestamp.Text = Methods.Time.TimeAgo(int.Parse(item.LastseenUnixTime), true);
                 
                //Online Or offline
                if (item.Lastseen == "on" && OnlineUsers.Equals(true))
                {
                    holder.TxtTimestamp.Text = ActivityContext.GetText(Resource.String.Lbl_Online);
                    holder.ImageLastseen.SetImageResource(Resource.Drawable.Green_Online);

                    if (AppSettings.ShowOnlineOfflineMessage)
                    {
                        var data = ListOnline.Contains(item.Name);
                        if (data == false)
                        {
                            ListOnline.Add(item.Name);

                            Toast toast = Toast.MakeText(ActivityContext, item.Name + " " + ActivityContext.GetText(Resource.String.Lbl_Online), ToastLength.Short);
                            toast.SetGravity(GravityFlags.Center, 0, 0);
                            toast.Show();
                        }
                    }
                }
                else
                {
                    holder.ImageLastseen.SetImageResource(Resource.Drawable.Grey_Offline);
                }

                //Check read message
                if (item.LastMessage.ToId != UserDetails.UserId && item.LastMessage.FromId == UserDetails.UserId)
                {
                    if (item.LastMessage.Seen == "0" || item.LastMessage.Seen == "")
                    {
                        holder.Checkicon.Visibility = ViewStates.Invisible;
                        holder.TxtUsername.SetTypeface(Typeface.Default, TypefaceStyle.Normal);
                        holder.TxtLastMessages.SetTypeface(Typeface.Default, TypefaceStyle.Normal);
                    }
                    else
                    {
                        holder.Checkicon.Visibility = ViewStates.Visible;
                        holder.TxtUsername.SetTypeface(Typeface.Default, TypefaceStyle.Normal);
                        holder.TxtLastMessages.SetTypeface(Typeface.Default, TypefaceStyle.Normal);
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Checkicon, IonIconsFonts.AndroidDoneAll);
                    }
                }
                else
                {
                    if (item.LastMessage.Seen == "0" || item.LastMessage.Seen == "")
                    {
                        holder.Checkicon.Visibility = ViewStates.Visible;
                        holder.TxtUsername.SetTypeface(Typeface.Default, TypefaceStyle.Bold);
                        holder.TxtLastMessages.SetTypeface(Typeface.Default, TypefaceStyle.Bold);
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Checkicon, IonIconsFonts.ChatbubbleWorking);
                    }
                    else
                    {
                        holder.Checkicon.Visibility = ViewStates.Invisible;
                        holder.TxtUsername.SetTypeface(Typeface.Default, TypefaceStyle.Normal);
                        holder.TxtLastMessages.SetTypeface(Typeface.Default, TypefaceStyle.Normal);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override int ItemCount
        {

            get
            {
                try
                {
                    return MLastMessagesUser?.Count ?? 0;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return 0;
                } 
            }
        }
         
        public GetUsersListObject.User GetItem(int position)
        {
            return MLastMessagesUser[position];
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override int GetItemViewType(int position)
        {
            return position;
        }

        void OnClick(LastMessagesAdapterClickEventArgs args) => ItemClick?.Invoke(this, args);
        void OnLongClick(LastMessagesAdapterClickEventArgs args) => ItemLongClick?.Invoke(this, args);

        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = MLastMessagesUser[p0];
                if (item == null)
                    return d;
                else
                {
                    var image = !string.IsNullOrEmpty(item.OldAvatar) ? item.OldAvatar : item.Avatar ?? item.Cover;
                    if (!string.IsNullOrEmpty(image))
                        d.Add(image);
                    return d;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                var d = new List<string>();
                return d;
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.CircleCrop);
        }
    }

    public class LastMessagesAdapterViewHolder : RecyclerView.ViewHolder
    {
        #region Variables Basic

        public View MainView { get; private set; }

        public RelativeLayout RelativeLayoutMain { get; private set; }
        public AppCompatTextView Checkicon { get; private set; }
        public AppCompatTextView LastMessagesIcon { get; private set; }
        public TextView TxtUsername { get; private set; }
        public TextView TxtLastMessages { get; private set; }
        public TextView TxtTimestamp { get; private set; }
        public ImageView ImageAvatar { get; private set; } //ImageView
        public CircleImageView ImageLastseen { get; private set; }

        #endregion

        public LastMessagesAdapterViewHolder(View itemView, Action<LastMessagesAdapterClickEventArgs> clickListener, Action<LastMessagesAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                //Get values
                RelativeLayoutMain = (RelativeLayout)MainView.FindViewById(Resource.Id.main);
                Checkicon = (AppCompatTextView)MainView.FindViewById(Resource.Id.IconCheckRead);
                LastMessagesIcon = (AppCompatTextView)MainView.FindViewById(Resource.Id.LastMessages_icon);
                TxtUsername = (TextView)MainView.FindViewById(Resource.Id.Txt_Username);
                TxtLastMessages = (TextView)MainView.FindViewById(Resource.Id.Txt_LastMessages);
                TxtTimestamp = (TextView)MainView.FindViewById(Resource.Id.Txt_timestamp);
                ImageAvatar = (ImageView)MainView.FindViewById(Resource.Id.ImageAvatar);
                ImageLastseen = (CircleImageView)MainView.FindViewById(Resource.Id.ImageLastseen);

                //Create an Event
                itemView.Click += (sender, e) => clickListener(new LastMessagesAdapterClickEventArgs { View = itemView, Position = AdapterPosition });
                itemView.LongClick += (sender, e) => longClickListener(new LastMessagesAdapterClickEventArgs { View = itemView, Position = AdapterPosition });

                //Dont Remove this code #####
                FontUtils.SetFont(TxtUsername, Fonts.SfRegular);
                FontUtils.SetFont(TxtLastMessages, Fonts.SfMedium);
                //##### 
            }
            catch (Exception e)
            {
                Console.WriteLine(e + "Error");
            }
        } 
    }

    public class LastMessagesAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}