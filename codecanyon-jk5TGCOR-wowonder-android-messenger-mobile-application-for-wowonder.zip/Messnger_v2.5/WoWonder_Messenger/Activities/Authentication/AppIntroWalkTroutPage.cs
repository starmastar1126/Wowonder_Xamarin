using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Widget;
using AppIntro;
using WoWonder.Activities.SuggestedUsers;
using WoWonder.Activities.Tab;
using WoWonder.Helpers.Controller;

namespace WoWonder.Activities.Authentication
{
    [Activity(Theme = "@style/Theme.AppCompat.Light.NoActionBar", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.Orientation)]
    public class AppIntroWalkTroutPage : AppIntro2
    {
        private int Count = 1;

        private string Caller = "";

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                AddSlide(AppIntroFragment.NewInstance(GetText(Resource.String.Lbl_Title_page1), GetText(Resource.String.Lbl_Description_page1),Resource.Drawable.rocket, Color.ParseColor("#2d4155")));
                AddSlide(AppIntroFragment.NewInstance(GetText(Resource.String.Lbl_Title_page2), GetText(Resource.String.Lbl_Description_page2),Resource.Drawable.Search_WA, Color.ParseColor("#fcb840")));
                AddSlide(AppIntroFragment.NewInstance(GetText(Resource.String.Lbl_Title_page3), GetText(Resource.String.Lbl_Description_page3),Resource.Drawable.paper_plane, Color.ParseColor("#2485c3")));
                AddSlide(AppIntroFragment.NewInstance(GetText(Resource.String.Lbl_Title_page4), GetText(Resource.String.Lbl_Description_page4),Resource.Drawable.speech_bubble, Color.ParseColor("#9244b1")));
                //SetSkipText(GetText(Resource.String.Lbl_Skip));
                //SetDoneText(GetText(Resource.String.Lbl_Done));
                 
                if (AppSettings.WalkThroughSetFlowAnimation)
                {
                    SetFlowAnimation();
                }
                else if (AppSettings.WalkThroughSetZoomAnimation)
                {
                    SetZoomAnimation();
                }
                else if (AppSettings.WalkThroughSetSlideOverAnimation)
                {
                    SetSlideOverAnimation();
                }
                else if (AppSettings.WalkThroughSetDepthAnimation)
                {
                    SetDepthAnimation();
                }
                else if (AppSettings.WalkThroughSetFadeAnimation)
                {
                    SetFadeAnimation();
                }
                  
                ShowStatusBar(false);

                SetNavBarColor(Color.ParseColor("#333639"));
                // SetSeparatorColor(Color.ParseColor("#2196f3"));

                Caller = Intent.GetStringExtra("class");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions,
            Permission[] grantResults)
        {
            try
            {
                if (grantResults[0] == Permission.Granted)
                {

                }
                else
                {
                    //Permission Denied :(
                    Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnSlideChanged()
        {
            try
            {
                base.OnSlideChanged();
                Pressed();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnNextPressed()
        {
            try
            {
                base.OnNextPressed();
                Pressed();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void Pressed()
        {
            try
            {
                if (Count == 1)
                {
                    //Get data profile
                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => ApiRequest.Get_MyProfileData_Api(this) });

                    if ((int)Build.VERSION.SdkInt < 23)
                    {

                    }
                    else
                    {
                        if (AppSettings.ShowButtonContact)
                        {
                            RequestPermissions(new[]
                            {
                                Manifest.Permission.ReadContacts,
                                Manifest.Permission.ReadPhoneNumbers,

                                Manifest.Permission.Camera
                            }, 208);
                        }
                        else
                        {
                            RequestPermissions(new[]
                            {
                                Manifest.Permission.Camera
                            }, 208);
                        }

                    }

                    Count++;
                }
                else if (Count == 2)
                {
                    Count++;
                }
                else if (Count == 3)
                {
                    if ((int)Build.VERSION.SdkInt < 23)
                    {

                    }
                    else
                    {
                        if (AppSettings.ShowButtonRecordSound)
                        {
                            RequestPermissions(new[]
                            {
                                Manifest.Permission.RecordAudio,
                                Manifest.Permission.ModifyAudioSettings
                            }, 103);
                        }
                    }

                    Count++;
                }
                else if (Count == 4)
                {
                    Count++;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Do something when users tap on Done button.
        public override void OnDonePressed()
        {
            if (Caller.Equals("register"))
            {
                StartActivity(AppSettings.ShowSuggestedUsersOnRegister? new Intent(this, typeof(SuggestionsUsersActivity)) : new Intent(this, typeof(TabbedMainActivity)));
            }
            else
                StartActivity(new Intent(this, typeof(TabbedMainActivity)));

            Finish();
        }

        // Do something when users tap on Skip button.
        public override void OnSkipPressed()
        { 
            if (Caller.Equals("register"))
            {  
                StartActivity(AppSettings.ShowSuggestedUsersOnRegister? new Intent(this, typeof(SuggestionsUsersActivity)): new Intent(this, typeof(TabbedMainActivity)));

            }
            else
                StartActivity(new Intent(this, typeof(TabbedMainActivity)));

            Finish();
        }

    }
}