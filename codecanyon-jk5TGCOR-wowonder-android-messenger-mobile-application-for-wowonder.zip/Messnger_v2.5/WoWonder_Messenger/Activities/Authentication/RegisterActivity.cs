using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;

namespace WoWonder.Activities.Authentication
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/ProfileTheme",ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation )]
    public class RegisterActivity : AppCompatActivity, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private Button RegisterButton;
        private EditText EmailEditText,UsernameEditText, PasswordEditText, PasswordRepeatEditText;
        private LinearLayout MainLinearLayout; 
        private TextView TxtTermsOfService, TxtPrivacy;
        private CheckBox ChkAgree; 
        private ProgressBar ProgressBar;
 
        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Register_Layout);

                //Get Value And Set Toolbar
                InitComponent(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Functions

        private void InitComponent()
        {
            try
            {
                Typeface regularTxt = Typeface.CreateFromAsset(Assets, "fonts/SF-UI-Display-Regular.ttf");


                EmailEditText = FindViewById<EditText>(Resource.Id.emailfield);
                UsernameEditText = FindViewById<EditText>(Resource.Id.usernamefield);
                PasswordEditText = FindViewById<EditText>(Resource.Id.passwordfield);
                PasswordRepeatEditText = FindViewById<EditText>(Resource.Id.passwordrepeatfield);
                RegisterButton = FindViewById<Button>(Resource.Id.registerButton);
                MainLinearLayout = FindViewById<LinearLayout>(Resource.Id.mainLinearLayout);
                ProgressBar = FindViewById<ProgressBar>(Resource.Id.progressBar);

                ProgressBar.Visibility = ViewStates.Gone;
                RegisterButton.Visibility = ViewStates.Visible;

                ChkAgree = FindViewById<CheckBox>(Resource.Id.termCheckBox);
                TxtTermsOfService = FindViewById<TextView>(Resource.Id.secTermTextView);
                TxtPrivacy = FindViewById<TextView>(Resource.Id.secPrivacyTextView);

                EmailEditText.SetTypeface(regularTxt, TypefaceStyle.Normal);
                UsernameEditText.SetTypeface(regularTxt, TypefaceStyle.Normal);
                PasswordEditText.SetTypeface(regularTxt, TypefaceStyle.Normal);
                PasswordRepeatEditText.SetTypeface(regularTxt, TypefaceStyle.Normal);
                TxtTermsOfService.SetTypeface(regularTxt, TypefaceStyle.Normal);
                TxtPrivacy.SetTypeface(regularTxt, TypefaceStyle.Normal);

                FontUtils.SetFont(RegisterButton, Fonts.SfRegular);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    MainLinearLayout.Click += Main_LoginPage_Click;
                    RegisterButton.Click += RegisterButton_Click;
                    TxtTermsOfService.Click += TxtTermsOfServiceOnClick;
                    TxtPrivacy.Click += TxtPrivacyOnClick;
                }
                else
                {
                    MainLinearLayout.Click -= Main_LoginPage_Click;
                    RegisterButton.Click -= RegisterButton_Click;
                    TxtTermsOfService.Click -= TxtTermsOfServiceOnClick;
                    TxtPrivacy.Click -= TxtPrivacyOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Events

        private void TxtPrivacyOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                string url = Client.WebsiteUrl + "/terms/privacy-policy";
                Methods.App.OpenbrowserUrl(this, url);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void TxtTermsOfServiceOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                string url = Client.WebsiteUrl + "/terms/terms";
                Methods.App.OpenbrowserUrl(this, url);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Main_LoginPage_Click(object sender, EventArgs e)
        {
            if (ChkAgree.Checked)
            {
                InputMethodManager inputManager =(InputMethodManager)GetSystemService(InputMethodService);
                inputManager.HideSoftInputFromWindow(CurrentFocus.WindowToken, HideSoftInputFlags.None);
            }
            else
            {
                Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Warning),GetText(Resource.String.Lbl_Error_Terms), GetText(Resource.String.Lbl_Ok));
            }
        }

        private async void RegisterButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (ChkAgree.Checked)
                {
                    if (Methods.CheckConnectivity())
                    {
                        if (!string.IsNullOrEmpty(UsernameEditText.Text.Replace(" ", "")) ||
                            !string.IsNullOrEmpty(PasswordEditText.Text) ||
                            !string.IsNullOrEmpty(PasswordRepeatEditText.Text) ||
                            !string.IsNullOrEmpty(EmailEditText.Text.Replace(" ", "")))
                        { 
                            var check = Methods.FunString.IsEmailValid(EmailEditText.Text);
                            if (!check)
                            {
                                Methods.DialogPopup.InvokeAndShowDialog(this,
                                    GetText(Resource.String.Lbl_VerificationFailed),
                                    GetText(Resource.String.Lbl_IsEmailValid), GetText(Resource.String.Lbl_Ok));
                            }
                            else
                            {
                                if (PasswordRepeatEditText.Text == PasswordEditText.Text)
                                {
                                    ProgressBar.Visibility = ViewStates.Visible;
                                    RegisterButton.Visibility = ViewStates.Gone;

                                    var (apiStatus, respond) = await RequestsAsync.Global.Get_Create_Account(UsernameEditText.Text,PasswordEditText.Text, PasswordRepeatEditText.Text, EmailEditText.Text,
                                            UserDetails.DeviceId);
                                    if (apiStatus == 200)
                                    {
                                        if (respond is CreatAccountObject result)
                                        {
                                            SetDataLogin(result);

                                            Intent newIntent = new Intent(this, typeof(AppIntroWalkTroutPage));
                                            newIntent.PutExtra("class", "register");
                                            StartActivity(newIntent);
                                        }

                                        ProgressBar.Visibility = ViewStates.Gone;
                                        RegisterButton.Visibility = ViewStates.Visible;
                                        Finish();
                                    }
                                    else if (apiStatus == 220)
                                    {
                                        var dialog = new MaterialDialog.Builder(this);

                                        dialog.Title(GetText(Resource.String.Lbl_ActivationSent));
                                        dialog.Content(GetText(Resource.String.Lbl_ActivationDetails).Replace("@", EmailEditText.Text));
                                        dialog.PositiveText(GetText(Resource.String.Lbl_Ok)).OnPositive(this);
                                        dialog.AlwaysCallSingleChoiceCallback();
                                        dialog.Build().Show();
                                    }
                                    else if (apiStatus == 400)
                                    {
                                        if (respond is ErrorObject error)
                                        {
                                            var errortext = error._errors.ErrorText;
                                            var errorid = error._errors.ErrorId;
                                            if (errorid == "3")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_ErrorRegister_3),GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "4")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_ErrorRegister_4),
                                                    GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "5")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),
                                                    GetText(Resource.String.Lbl_Something_went_wrong),GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "6")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),
                                                    GetText(Resource.String.Lbl_ErrorRegister_6),GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "7")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),
                                                    GetText(Resource.String.Lbl_ErrorRegister_7),GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "8")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_ErrorRegister_8),
                                                    GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "9")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),
                                                    GetText(Resource.String.Lbl_ErrorRegister_9),GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "10")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),
                                                    GetText(Resource.String.Lbl_ErrorRegister_10),GetText(Resource.String.Lbl_Ok));
                                            else if (errorid == "11")
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),
                                                    GetText(Resource.String.Lbl_ErrorRegister_11),GetText(Resource.String.Lbl_Ok));
                                            else
                                                Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security), errortext,GetText(Resource.String.Lbl_Ok));
                                        }

                                        ProgressBar.Visibility = ViewStates.Gone;
                                        RegisterButton.Visibility = ViewStates.Visible;
                                    }
                                    else if (apiStatus == 404)
                                    {

                                        ProgressBar.Visibility = ViewStates.Gone;
                                        RegisterButton.Visibility = ViewStates.Visible;
                                        Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_Error_Login),GetText(Resource.String.Lbl_Ok));
                                    }
                                }
                                else
                                {
                                    ProgressBar.Visibility = ViewStates.Gone;
                                    RegisterButton.Visibility = ViewStates.Visible;

                                    Methods.DialogPopup.InvokeAndShowDialog(this,GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_Error_Register_password),GetText(Resource.String.Lbl_Ok));
                                }
                            }
                        }
                        else
                        {
                            ProgressBar.Visibility = ViewStates.Gone;
                            RegisterButton.Visibility = ViewStates.Visible;
                            Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_Please_enter_your_data), GetText(Resource.String.Lbl_Ok));
                        }
                    }
                    else
                    {
                        ProgressBar.Visibility = ViewStates.Gone;
                        RegisterButton.Visibility = ViewStates.Visible;

                        Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Security),GetText(Resource.String.Lbl_CheckYourInternetConnection),GetText(Resource.String.Lbl_Ok));
                    }
                }
                else
                {
                    Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Warning),GetText(Resource.String.Lbl_Error_Terms), GetText(Resource.String.Lbl_Ok));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                ProgressBar.Visibility = ViewStates.Gone;
                RegisterButton.Visibility = ViewStates.Visible;
                Methods.DialogPopup.InvokeAndShowDialog(this, GetText(Resource.String.Lbl_Authentication_failed),ex.Message, GetText(Resource.String.Lbl_Ok));
            }
        }

        #endregion

        #region MaterialDialog
         
        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            if (p1 == DialogAction.Positive)
            {
                Finish();
            }
            else if (p1 == DialogAction.Negative)
            {
                p0.Dismiss();
            }
        }

        #endregion

        private void SetDataLogin(CreatAccountObject auth)
        {
            try
            {
                Current.AccessToken = auth.AccessToken;

                UserDetails.Username = UsernameEditText.Text;
                UserDetails.FullName = UsernameEditText.Text;
                UserDetails.Password = PasswordEditText.Text;
                UserDetails.AccessToken = auth.AccessToken;
                UserDetails.UserId = auth.UserId;
                UserDetails.Status = "Pending";
                UserDetails.Cookie = auth.AccessToken;
                UserDetails.Email = EmailEditText.Text;
                //Insert user data to database
                var user = new DataTables.LoginTb
                {
                    UserId = UserDetails.UserId,
                    AccessToken = UserDetails.AccessToken,
                    Cookie = UserDetails.Cookie,
                    Username = UsernameEditText.Text,
                    Password = PasswordEditText.Text,
                    Status = "Pending",
                    Lang = "",
                    DeviceId = UserDetails.DeviceId,

                };

                ListUtils.DataUserLoginList.Add(user);

                var dbDatabase = new SqLiteDatabase();
                dbDatabase.InsertOrUpdateLogin_Credentials(user);
                dbDatabase.Dispose();

                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => ApiRequest.Get_MyProfileData_Api(this) });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }
}