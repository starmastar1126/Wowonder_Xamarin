using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Ads;
using Android.OS;
using Android.Widget;
using WoWonder.Activities.Authentication;
using WoWonder.Activities.ChatWindow;
using WoWonder.Activities.Tab;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient;

namespace WoWonder.Activities
{
    [Activity(Icon = "@drawable/icon", MainLauncher = true, Theme = "@style/SplashScreenTheme", NoHistory = true, ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.Orientation, LaunchMode = LaunchMode.SingleInstance)]
    public class SplashScreenActivity : Activity
    {
        private SqLiteDatabase DbDatabase = new SqLiteDatabase();
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            { 
                base.OnCreate(savedInstanceState);

                Client a = new Client(AppSettings.TripleDesAppServiceProvider);
                Console.WriteLine(a);
                if (AppSettings.Lang != "")
                {
                    LangController.SetApplicationLang(this, AppSettings.Lang);
                }
                else
                {
                    UserDetails.LangName = Resources.Configuration.Locale.DisplayLanguage.ToLower();
                    LangController.SetAppLanguage(this);
                }

                if (AppSettings.ShowAdmobBanner || AppSettings.ShowAdmobInterstitial || AppSettings.ShowAdmobRewardVideo || AppSettings.ShowAdmobNative)
                    MobileAds.Initialize(this, GetString(Resource.String.admob_app_id));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            base.OnResume();

            if ((int) Build.VERSION.SdkInt < 23)
            {
               
                DbDatabase.CheckTablesStatus();
                DbDatabase.Dispose();

                Task startupWork = new Task(SimulateStartup);
                startupWork.Start();
            }
            else
            {
                if ((CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted) &&
                    (CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted))
                {
                    DbDatabase = new SqLiteDatabase();
                    DbDatabase.CheckTablesStatus();

                    Task startupWork = new Task(SimulateStartup);
                    startupWork.Start();
                }
                else
                {
                    RequestPermissions(new[]
                    {
                        Manifest.Permission.ReadExternalStorage,
                        Manifest.Permission.WriteExternalStorage
                    }, 101);
                }
            }
        }

        private void SimulateStartup()
        {
            try
            {
                FirstRunExcute();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions,
            Permission[] grantResults)
        {
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            if (requestCode == 101)
            {
                if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                {
                    DbDatabase = new SqLiteDatabase();
                    DbDatabase.CheckTablesStatus();
                     
                    FirstRunExcute();
                }
                else
                {
                    Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    Finish();
                }
            }
        }

        private void FirstRunExcute()
        {
            try
            {  
                var result = DbDatabase.Get_data_Login_Credentials();
                if (result != null)
                { 
                    Task.Run(() =>
                    {
                        DbDatabase = new SqLiteDatabase();
                        ListUtils.UserList = new ObservableCollection<GetUsersListObject.User>();
                        var list = DbDatabase.Get_LastUsersChat_List();
                        ListUtils.UserList = new ObservableCollection<GetUsersListObject.User>(list);
                    });
                      
                    var data = Intent.GetStringExtra("UserID") ?? "Data not available";
                    if (data != "Data not available" && !string.IsNullOrEmpty(data))
                    {
                        Intent intent = new Intent(this, typeof(ChatWindowActivity));
                        intent.PutExtra("UserID", data); // to_id
                        intent.PutExtra("Notifier", "Notifier");
                        intent.PutExtra("App", "Timeline");
                        intent.PutExtra("Name", Intent.GetStringExtra("Name"));
                        intent.PutExtra("Username", Intent.GetStringExtra("Username"));
                        intent.PutExtra("Time", Intent.GetStringExtra("Time"));
                        intent.PutExtra("LastSeen", Intent.GetStringExtra("LastSeen"));
                        intent.PutExtra("About", Intent.GetStringExtra("About"));
                        intent.PutExtra("Address", Intent.GetStringExtra("Address"));
                        intent.PutExtra("Phone", Intent.GetStringExtra("Phone"));
                        intent.PutExtra("Website", Intent.GetStringExtra("Website"));
                        intent.PutExtra("Working", Intent.GetStringExtra("Working"));
                        StartActivity(intent);
                    }
                    else
                    {
                        switch (result.Status)
                        {
                            case "Active":
                                StartActivity(new Intent(this, typeof(TabbedMainActivity)));
                                break;
                            default:
                                StartActivity(new Intent(this, typeof(LoginActivity)));
                                break;
                        } 
                    } 
                }
                else
                {  
                    var data = Intent.GetStringExtra("UserID") ?? "Data not available";
                    if (data != "Data not available" && !string.IsNullOrEmpty(data))
                    {
                        Intent intent = new Intent(this, typeof(ChatWindowActivity));
                        intent.PutExtra("UserID", data); // to_id
                        intent.PutExtra("Notifier", "Notifier");
                        intent.PutExtra("App", "Timeline");
                        intent.PutExtra("Name", Intent.GetStringExtra("Name"));
                        intent.PutExtra("Username", Intent.GetStringExtra("Username"));
                        intent.PutExtra("Time", Intent.GetStringExtra("Time"));
                        intent.PutExtra("LastSeen", Intent.GetStringExtra("LastSeen"));
                        intent.PutExtra("About", Intent.GetStringExtra("About"));
                        intent.PutExtra("Address", Intent.GetStringExtra("Address"));
                        intent.PutExtra("Phone", Intent.GetStringExtra("Phone"));
                        intent.PutExtra("Website", Intent.GetStringExtra("Website"));
                        intent.PutExtra("Working", Intent.GetStringExtra("Working"));
                        StartActivity(intent);
                    }
                    else
                    {
                        StartActivity(new Intent(this, typeof(LoginActivity)));
                    }
                }

                DbDatabase.Dispose();
            }
            catch (Exception e)
            {
               
                Console.WriteLine(e);
            }
        }
    } 
}