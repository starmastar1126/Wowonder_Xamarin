﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Timers;
using Android.App;
using Android.Content;
using Android.Media;
using Android.Support.V4.Content;
using Android.Support.V7.Widget;
using Android.Views;
using Bumptech.Glide;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using Com.Luseen.Autolinklibrary;
using Java.IO;
using WoWonder.Activities.DefaultUser;
using WoWonder.Adapters;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient;
using Console = System.Console;
using Object = Java.Lang.Object;
using MessageData = WoWonderClient.Classes.Message.MessageData;
using Uri = Android.Net.Uri;


namespace WoWonder.Activities.GroupChat.Adapter
{
    public class GroupMessagesAdapter : RecyclerView.Adapter
    {
        public event EventHandler<Holders.TextClickEventArgs> ItemClick;
        public event EventHandler<Holders.TextClickEventArgs> ItemLongClick;

        public ObservableCollection<MessageData> MessageList = new ObservableCollection<MessageData>();
        private readonly Activity MainActivity;
        private readonly RequestOptions Options;
        private string GroupId;

        public GroupMessagesAdapter(Activity activity,string groupId)
        {
            try
            {
                HasStableIds = true;
                MainActivity = activity;
                GroupId = groupId;
                Options = new RequestOptions().Apply(RequestOptions.CircleCropTransform()
                    .CenterCrop()
                    .SetPriority(Priority.High).Override(200)
                    .SetUseAnimationPool(false).SetDiskCacheStrategy(DiskCacheStrategy.All)
                    .Error(Resource.Drawable.ImagePlacholder)
                    .Placeholder(Resource.Drawable.ImagePlacholder));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position, IList<Object> payloads)
        {
            if (payloads.Count > 0)
            {
                var item = MessageList[position];

                if (item == null)
                    return;

                if (payloads[0].ToString() == "WithoutBlob")
                {
                    Holders.ImageViewHolder holderViewer = holder as Holders.ImageViewHolder;
                    LoadImageOfChatItem(holderViewer, item);
                }

            }
            else
            {
                base.OnBindViewHolder(holder, position, payloads);
            } 
        }


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                var itemView = MessageList[viewType];
                if (itemView != null)
                {
                    if (itemView.FromId == UserDetails.UserId && itemView.Stickers != null && (itemView.Type == "right_gif" || (itemView.Text == "" && (itemView.Type == "right_text") && itemView.Stickers.Contains(".gif"))))
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_gif, parent, false);
                        Holders.GifViewHolder viewHolder = new Holders.GifViewHolder(row, true);
                        return viewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId &&  itemView.Stickers != null && (itemView.Type == "left_gif" || (itemView.Text == "" && (itemView.Type == "left_text") && itemView.Stickers.Contains(".gif"))))
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_gif, parent, false);
                        Holders.GifViewHolder viewHolder = new Holders.GifViewHolder(row, true);
                        return viewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId &&  itemView.Type == "right_text")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_view, parent, false);
                        Holders.TextViewHolder textViewHolder = new Holders.TextViewHolder(row, OnLongClick, true);
                        return textViewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId && itemView.Type == "left_text")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_view, parent, false);
                        Holders.TextViewHolder textViewHolder = new Holders.TextViewHolder(row, OnLongClick, true);
                        return textViewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId && itemView.Type == "right_image")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_image, parent, false);
                        Holders.ImageViewHolder imageViewHolder = new Holders.ImageViewHolder(row, true);
                        return imageViewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId && itemView.Type == "left_image")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_image, parent, false);
                        Holders.ImageViewHolder imageViewHolder = new Holders.ImageViewHolder(row, true);
                        return imageViewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId && itemView.Type == "right_Audio" || itemView.Type == "right_audio")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_Audio, parent, false);
                        Holders.SoundViewHolder soundViewHolder = new Holders.SoundViewHolder(row, true);

                        return soundViewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId &&  itemView.Type == "left_Audio" || itemView.Type == "left_audio")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_Audio, parent, false);
                        Holders.SoundViewHolder soundViewHolder = new Holders.SoundViewHolder(row, true);
                        return soundViewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId && itemView.Type == "right_contact")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_Contact, parent, false);
                        Holders.ContactViewHolder contactViewHolder = new Holders.ContactViewHolder(row, true);
                        return contactViewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId && itemView.Type == "left_contact")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_Contact, parent, false);
                        Holders.ContactViewHolder contactViewHolder = new Holders.ContactViewHolder(row, true);
                        return contactViewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId && itemView.Type == "right_video")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_Video, parent, false);
                        Holders.VideoViewHolder videoViewHolder = new Holders.VideoViewHolder(row, true);
                        return videoViewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId && itemView.Type == "left_video")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_Video, parent, false);
                        Holders.VideoViewHolder videoViewHolder = new Holders.VideoViewHolder(row, true);
                        return videoViewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId && itemView.Type == "right_sticker")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_sticker, parent, false);
                        Holders.StickerViewHolder stickerViewHolder = new Holders.StickerViewHolder(row, true);
                        return stickerViewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId && itemView.Type == "left_sticker")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_sticker, parent, false);
                        Holders.StickerViewHolder stickerViewHolder = new Holders.StickerViewHolder(row, true);
                        return stickerViewHolder;
                    }

                    if (itemView.FromId == UserDetails.UserId && itemView.Type == "right_file")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Right_MS_file, parent, false);
                        Holders.FileViewHolder viewHolder = new Holders.FileViewHolder(row, true);
                        return viewHolder;
                    }

                    if (itemView.FromId != UserDetails.UserId && itemView.Type == "left_file")
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_file, parent, false);
                        Holders.FileViewHolder viewHolder = new Holders.FileViewHolder(row, true);
                        return viewHolder;
                    }
                    else
                    {
                        View row = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Left_MS_notsupported, parent, false);
                        Holders.NotsupportedViewHolder viewHolder = new Holders.NotsupportedViewHolder(row);
                        return viewHolder;
                    }
                }

                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder vh, int position)
        {
            try
            {
                int type = GetItemViewType(position);
                var item = MessageList[type];

                if (item != null)
                {
                    if (item.Stickers != null && (item.Type == "right_gif" || item.Type == "left_gif" || (item.Text == "" && (item.Type == "right_text" || item.Type == "left_text") && item.Stickers.Contains(".gif"))))
                    {
                        Holders.GifViewHolder holder = vh as Holders.GifViewHolder;
                        LoadGifOfChatItem(holder, item);
                    }
                    else if (item.Type == "right_text" || item.Type == "left_text")
                    {
                        Holders.TextViewHolder holder = vh as Holders.TextViewHolder;
                        LoadTextOfchatItem(holder, item);
                    }
                    else if (item.Type == "right_image" || item.Type == "left_image")
                    {
                        Holders.ImageViewHolder holder = vh as Holders.ImageViewHolder;
                        LoadImageOfChatItem(holder, item);
                    }
                    else if (item.Type == "right_Audio" || item.Type == "left_Audio" || item.Type == "right_audio" || item.Type == "left_audio")
                    {
                        Holders.SoundViewHolder holder = vh as Holders.SoundViewHolder;
                        LoadAudioOfChatItem(holder, item);
                    }
                    else if (item.Type == "right_contact" || item.Type == "left_contact")
                    {
                        Holders.ContactViewHolder holder = vh as Holders.ContactViewHolder;
                        LoadContactOfChatItem(holder, item);
                    }
                    else if (item.Type == "right_video" || item.Type == "left_video")
                    {
                        Holders.VideoViewHolder holder = vh as Holders.VideoViewHolder;
                        LoadVideoOfChatItem(holder, item);
                    }
                    else if (item.Type == "right_sticker" || item.Type == "left_sticker")
                    {
                        Holders.StickerViewHolder holder = vh as Holders.StickerViewHolder;
                        LoadStickerOfChatItem(holder, item);
                    }
                    else if (item.Type == "right_file" || item.Type == "left_file")
                    {
                        Holders.FileViewHolder holder = vh as Holders.FileViewHolder;
                        LoadFileOfChatItem(holder, item);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(item.Text))
                        {
                            if (vh is Holders.TextViewHolder holderText)
                            {
                                holderText.AutoLinkTextView.Text = item.Text;
                                holderText.Time.Text = item.TimeText;
                            }
                        }
                        else
                        {
                            if (vh is Holders.NotsupportedViewHolder holder)
                                holder.AutoLinkNotsupportedView.Text = MainActivity.GetText(Resource.String.Lbl_TextChatNotSupported);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //============================== Function Message ==============================

        #region Function Message

        public void Add(MessageData message)
        {
            try
            {
                var check = MessageList.FirstOrDefault(a => a.Id == message.Id);
                if (check == null)
                {
                    MessageList.Add(message);
                    NotifyItemInserted(MessageList.IndexOf(MessageList.Last()));
                    //Scroll Down >> 
                    GroupChatWindowActivity.GetInstance()?.MRecycler.ScrollToPosition(MessageList.IndexOf(MessageList.Last()));

                    NotifyDataSetChanged();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void Insert(MessageData message, string firstid)
        {
            try
            {
                var check = MessageList.FirstOrDefault(a => a.Id == message.Id);
                if (check == null)
                {
                    MessageList.Insert(0, message);
                    NotifyItemInserted(MessageList.IndexOf(MessageList.FirstOrDefault()));

                    var dd = MessageList.FirstOrDefault(a => a.Id == firstid);
                    if (dd != null)
                    {
                        //Scroll Down >> 
                        GroupChatWindowActivity.GetInstance()?.MRecycler.ScrollToPosition(MessageList.IndexOf(dd));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public void Update(MessageData message)
        {
            try
            {
                var cheker = MessageList.FirstOrDefault(a => a.Id == message.Id);
                if (cheker != null)
                {
                    cheker.Id = message.Id;
                    cheker.FromId = message.FromId;
                    cheker.GroupId = message.GroupId;
                    cheker.ToId = message.ToId;
                    cheker.Text = message.Text;
                    cheker.Media = message.Media;
                    cheker.MediaFileName = message.MediaFileName;
                    cheker.MediaFileNames = message.MediaFileNames;
                    cheker.Time = message.Time;
                    cheker.Seen = message.Seen;
                    cheker.DeletedOne = message.DeletedOne;
                    cheker.DeletedTwo = message.DeletedTwo;
                    cheker.SentPush = message.SentPush;
                    cheker.NotificationId = message.NotificationId;
                    cheker.TypeTwo = message.TypeTwo;
                    cheker.Stickers = message.Stickers;
                    cheker.TimeText = message.TimeText;
                    cheker.Position = message.Position;
                    cheker.Type = message.Type;
                    cheker.FileSize = message.FileSize;
                    cheker.UserData = message.UserData;
                    cheker.MediaDuration = message.MediaDuration;
                    cheker.MediaIsPlaying = message.MediaIsPlaying;
                    cheker.ContactNumber = message.ContactNumber;
                    cheker.ContactName = message.ContactName;

                    MainActivity.RunOnUiThread(() =>
                    {
                        NotifyItemChanged(MessageList.IndexOf(cheker));
                        GroupChatWindowActivity.GetInstance()?.MRecycler.ScrollToPosition(MessageList.IndexOf(MessageList.Last()));
                    });
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        //==============================

        #region Function Load Message

        private void LoadTextOfchatItem(Holders.TextViewHolder holder, MessageData message)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                holder.Time.Text = message.TimeText;

                if (message.Position == "left")
                {
                    holder.AutoLinkTextView.AddAutoLinkMode(AutoLinkMode.ModePhone, AutoLinkMode.ModeEmail, AutoLinkMode.ModeHashtag, AutoLinkMode.ModeUrl, AutoLinkMode.ModeMention);
                    holder.AutoLinkTextView.SetPhoneModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.left_ModePhone_color));
                    holder.AutoLinkTextView.SetEmailModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.left_ModeEmail_color));
                    holder.AutoLinkTextView.SetHashtagModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.left_ModeHashtag_color));
                    holder.AutoLinkTextView.SetUrlModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.left_ModeUrl_color));
                    holder.AutoLinkTextView.SetMentionModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.left_ModeMention_color));
                    holder.AutoLinkTextView.AutoLinkOnClick += AutoLinkTextViewOnAutoLinkOnClick;
                }
                else
                {
                    holder.AutoLinkTextView.AddAutoLinkMode(AutoLinkMode.ModePhone, AutoLinkMode.ModeEmail, AutoLinkMode.ModeHashtag, AutoLinkMode.ModeUrl, AutoLinkMode.ModeMention);
                    holder.AutoLinkTextView.SetPhoneModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.right_ModePhone_color));
                    holder.AutoLinkTextView.SetEmailModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.right_ModeEmail_color));
                    holder.AutoLinkTextView.SetHashtagModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.right_ModeHashtag_color));
                    holder.AutoLinkTextView.SetUrlModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.right_ModeUrl_color));
                    holder.AutoLinkTextView.SetMentionModeColor(ContextCompat.GetColor(MainActivity, Resource.Color.right_ModeMention_color));
                    holder.AutoLinkTextView.AutoLinkOnClick += AutoLinkTextViewOnAutoLinkOnClick;
                }

                holder.AutoLinkTextView.SetAutoLinkText(message.Text);
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AutoLinkTextViewOnAutoLinkOnClick(object sender1, AutoLinkOnClickEventArgs autoLinkOnClickEventArgs)
        {
            try
            {
                var typetext = Methods.FunString.Check_Regex(autoLinkOnClickEventArgs.P1);
                if (typetext == "Email")
                {
                    Methods.App.SendEmail(MainActivity, autoLinkOnClickEventArgs.P1);
                }
                else if (typetext == "Website")
                {
                    var url = autoLinkOnClickEventArgs.P1;
                    if (!autoLinkOnClickEventArgs.P1.Contains("http"))
                    {
                        url = "http://" + autoLinkOnClickEventArgs.P1;
                    }

                    Methods.App.OpenWebsiteUrl(MainActivity, url);
                }
                else if (typetext == "Hashtag")
                {

                }
                else if (typetext == "Mention")
                {
                    var intent = new Intent(MainActivity, typeof(SearchActivity));
                    intent.PutExtra("Key", autoLinkOnClickEventArgs.P1.Replace("@", ""));
                    MainActivity.StartActivity(intent);
                }
                else if (typetext == "Number")
                {
                    Methods.App.SaveContacts(MainActivity, autoLinkOnClickEventArgs.P1, "", "2");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadImageOfChatItem(Holders.ImageViewHolder holder, MessageData message)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                string imageUrl = message.Media;

                holder.Time.Text = message.TimeText;

                if (imageUrl.Contains("http://") || imageUrl.Contains("https://"))
                {
                    GlideImageLoader.LoadImage(MainActivity, imageUrl, holder.ImageView, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
                }
                else
                {
                    var file = Uri.FromFile(new File(imageUrl));
                    Glide.With(MainActivity).Load(file.Path).Apply(Options).Into(holder.ImageView);
                }

                holder.LoadingProgressview.Indeterminate = false;
                holder.LoadingProgressview.Visibility = ViewStates.Gone;

                if (!holder.ImageView.HasOnClickListeners)
                {
                    holder.ImageView.Click += (sender, args) =>
                    {
                        try
                        {
                            string imageFile = Methods.MultiMedia.CheckFileIfExits(imageUrl);
                            if (imageFile != "File Dont Exists")
                            {
                                File file2 = new File(imageUrl);
                                var photoUri = FileProvider.GetUriForFile(MainActivity, MainActivity.PackageName + ".fileprovider", file2);
                                Intent intent = new Intent();
                                intent.SetAction(Intent.ActionView);
                                intent.AddFlags(ActivityFlags.GrantReadUriPermission);
                                intent.SetDataAndType(photoUri, "image/*");
                                MainActivity.StartActivity(intent);
                            }
                            else
                            {
                                Intent intent = new Intent(Intent.ActionView, Uri.Parse(imageUrl));
                                MainActivity.StartActivity(intent);

                                //Toast.MakeText(MainActivity, MainActivity.GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private MediaPlayer MediaPlayer = new MediaPlayer();
        private void LoadAudioOfChatItem(Holders.SoundViewHolder soundViewHolder, MessageData message)
        {
            try
            {
                if (soundViewHolder.UserName != null) soundViewHolder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                if (message.SoundViewHolder == null)
                    message.SoundViewHolder = soundViewHolder;

                if (message.TimeText == MainActivity.GetText(Resource.String.Lbl_Uploading))
                {
                    soundViewHolder.LoadingProgressview.Visibility = ViewStates.Visible;
                    soundViewHolder.PlayButton.Visibility = ViewStates.Gone;
                }
                else
                {
                    soundViewHolder.LoadingProgressview.Visibility = ViewStates.Gone;
                    soundViewHolder.PlayButton.Visibility = ViewStates.Visible;
                }

                soundViewHolder.MsgTimeTextView.Text = message.TimeText;

                var fileName = message.Media.Split('/').Last();

                var mediaFile = WoWonderTools.GetFile(GroupId, Methods.Path.FolderDcimSound, fileName, message.Media);
                if (string.IsNullOrEmpty(message.MediaDuration))
                    soundViewHolder.DurationTextView.Text = Methods.AudioRecorderAndPlayer.GetTimeString(Methods.AudioRecorderAndPlayer.Get_MediaFileDuration(mediaFile));
                else
                    soundViewHolder.DurationTextView.Text = message.MediaDuration;

                soundViewHolder.LoadingProgressview.Visibility = ViewStates.Gone;
                soundViewHolder.PlayButton.Visibility = ViewStates.Visible;

                if (!soundViewHolder.PlayButton.HasOnClickListeners)
                {
                    soundViewHolder.PlayButton.Click += (o, args) =>
                    {
                        try
                        {
                            if (MediaPlayer == null)
                            {
                                MediaPlayer = new MediaPlayer();
                                MediaPlayer.SetAudioAttributes(new AudioAttributes.Builder().SetUsage(AudioUsageKind.Media).SetContentType(AudioContentType.Music).Build());
                            }

                            if (soundViewHolder.PlayButton.Tag.ToString() == "Play")
                            {
                                try
                                {
                                    if (message.Type == "left_Audio" || message.Type == "left_audio")
                                    {
                                        soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_play_dark_arrow);
                                    }
                                    else
                                    {
                                        soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_play_arrow);
                                    }

                                    try
                                    {
                                        if (message.MediaIsPlaying)
                                        {
                                            message.MediaIsPlaying = false;

                                            MediaPlayer.Stop();
                                            MediaPlayer.Release();
                                            MediaPlayer.Reset();
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine(e);
                                        MediaPlayer.Reset();
                                    }

                                    soundViewHolder.PlayButton.Tag = "Stop";
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e);
                                }

                                try
                                {
                                    if (message.Type == "left_Audio" || message.Type == "left_audio")
                                    {
                                        soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_stop_dark_arrow);
                                    }
                                    else
                                    {
                                        soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_stop_white_24dp);
                                    }

                                    if (MediaPlayer != null)
                                    {
                                        MediaPlayer.Completion += (sender, e) =>
                                        {
                                            MediaPlayer.Reset();
                                        };

                                        if (mediaFile.Contains("http"))
                                        {
                                            MediaPlayer.SetDataSource(Application.Context, Uri.Parse(mediaFile));
                                            MediaPlayer.PrepareAsync();
                                        }
                                        else
                                        {
                                            FileInputStream stream = new FileInputStream(mediaFile);
                                            MediaPlayer.SetDataSource(stream.FD);
                                            MediaPlayer.Prepare();
                                        }

                                        MediaPlayer.Prepared += (s, ee) =>
                                        {
                                            message.MediaIsPlaying = true;
                                            soundViewHolder.PlayButton.Tag = "Stop";

                                            if (message.MediaTimer == null)
                                                message.MediaTimer = new Timer();

                                            message.MediaTimer.Interval = 1000;
                                            MediaPlayer.Start();
                                            var durationofSound = MediaPlayer.Duration;

                                            message.MediaTimer.Elapsed += (sender, eventArgs) =>
                                            {
                                                if (message.MediaTimer.Enabled)
                                                {
                                                    if (MediaPlayer.CurrentPosition < MediaPlayer.Duration)
                                                    {
                                                        soundViewHolder.DurationTextView.Text = Methods.AudioRecorderAndPlayer.GetTimeString(MediaPlayer.CurrentPosition);
                                                    }
                                                    else
                                                    {
                                                        soundViewHolder.DurationTextView.Text = Methods.AudioRecorderAndPlayer.GetTimeString(durationofSound);
                                                        soundViewHolder.PlayButton.Tag = "Play";
                                                        if (message.Type == "left_Audio")
                                                        {
                                                            soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_play_dark_arrow);
                                                        }
                                                        else
                                                        {
                                                            soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_play_arrow);
                                                            message.MediaTimer.Enabled = false;
                                                            message.MediaTimer.Stop();
                                                            try
                                                            {
                                                                if (MediaPlayer.IsPlaying)
                                                                {
                                                                    message.MediaIsPlaying = false;
                                                                    MediaPlayer.Stop();
                                                                    MediaPlayer.Release();

                                                                    soundViewHolder.PlayButton.Tag = "Play";
                                                                }
                                                            }
                                                            catch (Exception e)
                                                            {
                                                                soundViewHolder.PlayButton.Tag = "Play";
                                                                Console.WriteLine(e);
                                                            }
                                                        }
                                                    }
                                                }
                                            };
                                            message.MediaTimer.Start();
                                        };
                                    }
                                    else
                                    {
                                        var audioRecordAndPlayer = new Methods.AudioRecorderAndPlayer(AppSettings.ApplicationName);
                                        audioRecordAndPlayer.PlayAudioFromPath(fileName);
                                    }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e);
                                }
                            }
                            else
                            {
                                soundViewHolder.PlayButton.Tag = "Play";
                                if (message.Type == "left_Audio" || message.Type == "left_audio")
                                {
                                    soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_play_dark_arrow);
                                }
                                else
                                {
                                    soundViewHolder.PlayButton.SetImageResource(Resource.Drawable.ic_play_arrow);
                                }

                                message.MediaIsPlaying = false;
                                message.MediaTimer.Enabled = false;
                                message.MediaTimer.Stop();
                                soundViewHolder.DurationTextView.Text = Methods.AudioRecorderAndPlayer.GetTimeString(MediaPlayer.Duration);
                                try
                                {
                                    if (MediaPlayer.IsPlaying)
                                    {
                                        message.MediaIsPlaying = false;
                                        message.MediaTimer.Enabled = false;
                                        message.MediaTimer.Stop();
                                        MediaPlayer.Stop();
                                        MediaPlayer.Release();
                                        MediaPlayer = null;
                                    }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e);
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };
                }

                if (message.SoundViewHolder == null)
                    message.SoundViewHolder = soundViewHolder;
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadContactOfChatItem(Holders.ContactViewHolder holder, MessageData message)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                holder.MsgTimeTextView.Text = message.TimeText;

                if (!string.IsNullOrEmpty(message.ContactName))
                {
                    holder.UserContactNameTextView.Text = message.ContactName;
                    holder.UserNumberTextView.Text = message.ContactNumber;
                }

                if (!holder.MainView.HasOnClickListeners)
                {
                    if (message.Position == "left")
                    {
                        holder.MainView.Click += (sender, args) =>
                        {
                            try
                            {
                                Methods.App.SaveContacts(MainActivity, holder.UserNumberTextView.Text,
                                    holder.UserContactNameTextView.Text, "2");
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        };
                    }
                    else
                    {
                        holder.MainView.Click += (sender, args) =>
                        {
                            try
                            {
                                Methods.App.SaveContacts(MainActivity, holder.UserNumberTextView.Text,
                                    holder.UserContactNameTextView.Text, "2");
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        };
                    }
                }
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadVideoOfChatItem(Holders.VideoViewHolder holder, MessageData message)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                var fileName = message.Media.Split('/').Last();
                var fileNameWithoutExtension = fileName.Split('.').First();
                var mediaFile = WoWonderTools.GetFile(GroupId, Methods.Path.FolderDcimVideo, fileName, message.Media);

                holder.MsgTimeTextView.Text = message.TimeText;
                holder.FilenameTextView.Text = Methods.FunString.SubStringCutOf(fileNameWithoutExtension, 10) + ".mp4";

                if (message.Media.Contains("http://") || message.Media.Contains("https://"))
                {
                    var videoPlaceHolderImage = Methods.MultiMedia.GetMediaFrom_Gallery(Methods.Path.FolderDcimVideo + "/" + GroupId, fileNameWithoutExtension + ".png");
                    if (videoPlaceHolderImage == "File Dont Exists")
                    {
                        var bitmapImage = Methods.MultiMedia.Retrieve_VideoFrame_AsBitmap(mediaFile);
                        Methods.MultiMedia.Export_Bitmap_As_Image(bitmapImage, fileNameWithoutExtension, Methods.Path.FolderDcimVideo + "/" + GroupId);

                        message.ImageVideo = Methods.Path.FolderDcimVideo + "/" + GroupId + "/" + fileNameWithoutExtension + ".png";

                        var file = Uri.FromFile(new File(message.ImageVideo));
                        Glide.With(MainActivity).Load(file.Path).Apply(Options).Into(holder.ImageView);
                    }
                    else
                    {
                        var file = Uri.FromFile(new File(message.ImageVideo));
                        Glide.With(MainActivity).Load(file.Path).Apply(Options).Into(holder.ImageView);
                    }

                    holder.LoadingProgressview.Indeterminate = false;
                    holder.LoadingProgressview.Visibility = ViewStates.Gone;
                    holder.PlayButton.Visibility = ViewStates.Visible;
                }
                else
                {
                    var videoPlaceHolderImage = Methods.MultiMedia.GetMediaFrom_Gallery(Methods.Path.FolderDcimVideo + "/" + GroupId, fileNameWithoutExtension + ".png");
                    if (videoPlaceHolderImage == "File Dont Exists")
                    {
                        var bitmapImage = Methods.MultiMedia.Retrieve_VideoFrame_AsBitmap(mediaFile);
                        Methods.MultiMedia.Export_Bitmap_As_Image(bitmapImage, fileNameWithoutExtension, Methods.Path.FolderDcimVideo + "/" + GroupId);

                        message.ImageVideo = Methods.Path.FolderDcimVideo + "/" + GroupId + "/" + fileNameWithoutExtension + ".png";

                        var file = Uri.FromFile(new File(message.ImageVideo));
                        Glide.With(MainActivity).Load(file.Path).Apply(Options).Into(holder.ImageView);
                    }
                    else
                    {
                        var file = Uri.FromFile(new File(message.ImageVideo));
                        Glide.With(MainActivity).Load(file.Path).Apply(Options).Into(holder.ImageView);
                    }
                }

                if (!holder.PlayButton.HasOnClickListeners)
                {
                    holder.PlayButton.Click += (sender, args) =>
                    {
                        try
                        {
                            string imageFile = Methods.MultiMedia.CheckFileIfExits(mediaFile);
                            if (imageFile != "File Dont Exists")
                            {
                                File file2 = new File(mediaFile);
                                var mediaUri = FileProvider.GetUriForFile(MainActivity, MainActivity.PackageName + ".fileprovider", file2);

                                Intent intent = new Intent();
                                intent.SetAction(Intent.ActionView);
                                intent.AddFlags(ActivityFlags.GrantReadUriPermission);
                                intent.SetDataAndType(mediaUri, "video/*");
                                MainActivity.StartActivity(intent);
                            }
                            else
                            {
                                Intent intent = new Intent(Intent.ActionView);
                                intent.SetData(Uri.Parse(mediaFile));
                                intent.AddFlags(ActivityFlags.GrantReadUriPermission);
                                intent.SetType("video/*");
                                MainActivity.StartActivity(intent);

                                //Toast.MakeText(MainActivity,MainActivity.GetText(Resource.String.Lbl_Something_went_wrong),ToastLength.Long).Show();
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadStickerOfChatItem(Holders.StickerViewHolder holder, MessageData message)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                string imageUrl = message.Media;

                holder.Time.Text = message.TimeText;
                if (imageUrl.Contains("http://") || imageUrl.Contains("https://"))
                {
                    Glide.With(MainActivity).Load(imageUrl).Apply(new RequestOptions().Placeholder(Resource.Drawable.ImagePlacholder)).Into(holder.ImageView);
                }
                else
                {
                    var file = Uri.FromFile(new File(imageUrl));
                    Glide.With(MainActivity).Load(file.Path).Apply(new RequestOptions().Placeholder(Resource.Drawable.ImagePlacholder)).Into(holder.ImageView);
                }

                holder.LoadingProgressview.Indeterminate = false;
                holder.LoadingProgressview.Visibility = ViewStates.Gone;
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadFileOfChatItem(Holders.FileViewHolder holder, MessageData message)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(message.UserData);

                var fileName = message.Media.Split('/').Last();
                var fileNameWithoutExtension = fileName.Split('.').First();
                var fileNameExtension = fileName.Split('.').Last();

                holder.MsgTimeTextView.Text = message.TimeText;
                holder.FileNameTextView.Text = Methods.FunString.SubStringCutOf(fileNameWithoutExtension, 10) + fileNameExtension;
                holder.SizeFileTextView.Text = message.FileSize;

                if (fileNameExtension.Contains("rar") || fileNameExtension.Contains("RAR") ||
                    fileNameExtension.Contains("zip") || fileNameExtension.Contains("ZIP"))
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.IconTypefile, "\uf1c6"); //ZipBox
                }
                else if (fileNameExtension.Contains("txt") || fileNameExtension.Contains("TXT"))
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.IconTypefile, "\uf15c"); //NoteText
                }
                else if (fileNameExtension.Contains("docx") || fileNameExtension.Contains("DOCX") ||
                         fileNameExtension.Contains("doc") || fileNameExtension.Contains("DOC"))
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.IconTypefile, "\uf1c2"); //FileWord
                }
                else if (fileNameExtension.Contains("pdf") || fileNameExtension.Contains("PDF"))
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.IconTypefile, "\uf1c1"); //FilePdf
                }
                else if (fileNameExtension.Contains("apk") || fileNameExtension.Contains("APK"))
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.IconTypefile, "\uf17b"); //Fileandroid
                }
                else
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.IconTypefile, "\uf15b"); //file
                }

                if (!holder.MainView.HasOnClickListeners)
                {
                    holder.MainView.Click += (sender, args) =>
                    {
                        string imageFile = Methods.MultiMedia.CheckFileIfExits(message.Media);
                        if (imageFile != "File Dont Exists")
                        {
                            try
                            {
                                var extension = fileName.Split('.').Last();
                                string mimeType = MimeTypeMap.GetMimeType(extension);

                                Intent openFile = new Intent();
                                openFile.SetFlags(ActivityFlags.NewTask);
                                openFile.SetFlags(ActivityFlags.GrantReadUriPermission);
                                openFile.SetAction(Intent.ActionView);
                                openFile.SetDataAndType(Uri.Parse(imageFile), mimeType);
                                MainActivity.StartActivity(openFile);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        }
                        else
                        {
                            var extension = fileName.Split('.').Last();
                            string mimeType = MimeTypeMap.GetMimeType(extension);

                            Intent i = new Intent(Intent.ActionView);
                            i.SetData(Uri.Parse(message.Media));
                            i.SetType(mimeType);
                            MainActivity.StartActivity(i);
                            // Toast.MakeText(MainActivity, MainActivity.GetText(Resource.String.Lbl_Something_went_wrong), ToastLength.Long).Show();
                        }
                    };
                }
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadGifOfChatItem(Holders.GifViewHolder holder, MessageData item)
        {
            try
            {
                if (holder.UserName != null) holder.UserName.Text = WoWonderTools.GetNameFinal(item.UserData);

                // G_fixed_height_small_url, // UrlGif - view  >>  mediaFileName
                // G_fixed_height_small_mp4, //MediaGif - sent >>  media

                string imageUrl = "";
                if (!string.IsNullOrEmpty(item.MediaFileName))
                    imageUrl = item.MediaFileName;
                else if (!string.IsNullOrEmpty(item.Media))
                    imageUrl = item.Media;
                else if (!string.IsNullOrEmpty(item.Stickers))
                    imageUrl = item.Stickers;

                if (imageUrl != null && (imageUrl.Contains("http://") || imageUrl.Contains("https://")))
                {
                    GlideImageLoader.LoadImage(MainActivity, imageUrl, holder.ImageGifView, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
                }
                else
                {
                    var file = Uri.FromFile(new File(imageUrl));
                    Glide.With(MainActivity).Load(file.Path).Apply(Options).Into(holder.ImageGifView);
                }

                holder.LoadingProgressview.Indeterminate = false;
                holder.LoadingProgressview.Visibility = ViewStates.Gone;
                 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        //==============================
        
        public void Clear()
        {
            try
            {
                MessageList.Clear();
                NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                try
                {
                    if (MessageList == null || MessageList.Count <= 0)
                        return 0;
                    return MessageList.Count;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return 0;
                }
            }
        }

        public MessageData GetItem(int position)
        {
            return MessageList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        void OnClick(Holders.TextClickEventArgs args) => ItemClick?.Invoke(this, args);
        void OnLongClick(Holders.TextClickEventArgs args) => ItemLongClick?.Invoke(this, args);

    } 
}