﻿using System;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using Com.Luseen.Autolinklibrary;
using Refractored.Controls;
using WoWonder.Helpers.Fonts;

namespace WoWonder.Adapters
{
    public class Holders
    {

        public class TextClickEventArgs : EventArgs
        {
            public View View { get; set; }
            public int Position { get; set; }
        }
         
        public class TextViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public TextView Time { get; private set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public AutoLinkTextView AutoLinkTextView { get; set; }

            public TextView UserName { get; private set; }

            #endregion

            public TextViewHolder(View itemView, Action<TextClickEventArgs> longClickListener, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    AutoLinkTextView = itemView.FindViewById<AutoLinkTextView>(Resource.Id.active);
                    Time = itemView.FindViewById<TextView>(Resource.Id.time);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;

                    AutoLinkTextView.LongClick += (sender, args) => longClickListener(new TextClickEventArgs { View = itemView, Position = AdapterPosition });
                    itemView.LongClick += (sender, args) => longClickListener(new TextClickEventArgs { View = itemView, Position = AdapterPosition });
                }
                catch (Exception e)
                {
                    Console.WriteLine(e + "Error");
                }
            }
        }

        public class ImageViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public ImageView ImageView { get; private set; }
            public ProgressBar LoadingProgressview { get; set; }
            public TextView Time { get; private set; }

            public TextView UserName { get; private set; }

            #endregion

            public ImageViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    ImageView = itemView.FindViewById<ImageView>(Resource.Id.imgDisplay);
                    LoadingProgressview = itemView.FindViewById<ProgressBar>(Resource.Id.loadingProgressview);
                    Time = itemView.FindViewById<TextView>(Resource.Id.time);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class SoundViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public TextView DurationTextView { get; set; }
            public TextView MsgTimeTextView { get; set; }
            public CircleButton PlayButton { get; set; }
            public ProgressBar LoadingProgressview { get; set; }
            public TextView UserName { get; private set; }
            #endregion

            public SoundViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    DurationTextView = itemView.FindViewById<TextView>(Resource.Id.Duration);
                    PlayButton = itemView.FindViewById<CircleButton>(Resource.Id.playButton);
                    MsgTimeTextView = itemView.FindViewById<TextView>(Resource.Id.time);
                    LoadingProgressview = itemView.FindViewById<ProgressBar>(Resource.Id.loadingProgressview);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class ContactViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public TextView UserContactNameTextView { get; set; }
            public TextView UserNumberTextView { get; set; }
            public TextView MsgTimeTextView { get; set; }
            public CircleImageView ProfileImage { get; set; }

            public TextView UserName { get; private set; }

            #endregion

            public ContactViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    UserContactNameTextView = itemView.FindViewById<TextView>(Resource.Id.contactName);
                    UserNumberTextView = itemView.FindViewById<TextView>(Resource.Id.numberText);
                    MsgTimeTextView = itemView.FindViewById<TextView>(Resource.Id.time);
                    ProfileImage = itemView.FindViewById<CircleImageView>(Resource.Id.profile_image);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class VideoViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public ImageView ImageView { get; private set; }
            public ProgressBar LoadingProgressview { get; private set; }
            public TextView MsgTimeTextView { get; private set; }
            public TextView IconView { get; private set; }
            public TextView FilenameTextView { get; private set; }
            public CircleButton PlayButton { get; private set; }

            public TextView UserName { get; private set; }

            #endregion

            public VideoViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    ImageView = itemView.FindViewById<ImageView>(Resource.Id.imgDisplay);
                    LoadingProgressview = itemView.FindViewById<ProgressBar>(Resource.Id.loadingProgressview);
                    MsgTimeTextView = itemView.FindViewById<TextView>(Resource.Id.time);
                    IconView = itemView.FindViewById<TextView>(Resource.Id.icon);
                    FilenameTextView = itemView.FindViewById<TextView>(Resource.Id.fileName);
                    PlayButton = itemView.FindViewById<CircleButton>(Resource.Id.playButton);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                     
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconView, IonIconsFonts.Videocamera);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class StickerViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public ImageView ImageView { get; private set; }
            public ProgressBar LoadingProgressview { get; private set; }
            public TextView Time { get; private set; }
            public TextView UserName { get; private set; }

            #endregion

            public StickerViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    ImageView = itemView.FindViewById<ImageView>(Resource.Id.imgDisplay);
                    LoadingProgressview = itemView.FindViewById<ProgressBar>(Resource.Id.loadingProgressview);
                    Time = itemView.FindViewById<TextView>(Resource.Id.time);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class GifViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public ImageView ImageGifView { get; private set; }
            public ProgressBar LoadingProgressview { get; set; }
            public TextView Time { get; private set; }
            public TextView UserName { get; private set; }

            #endregion

            public GifViewHolder(View itemView,bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;

                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    ImageGifView = itemView.FindViewById<ImageView>(Resource.Id.imggifdisplay);
                    LoadingProgressview = itemView.FindViewById<ProgressBar>(Resource.Id.loadingProgressview);
                    Time = itemView.FindViewById<TextView>(Resource.Id.time);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class NotsupportedViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public AutoLinkTextView AutoLinkNotsupportedView { get; set; }

            #endregion

            public NotsupportedViewHolder(View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    AutoLinkNotsupportedView = itemView.FindViewById<AutoLinkTextView>(Resource.Id.active);
                    AutoLinkNotsupportedView.Text = itemView.Context.GetText(Resource.String.Lbl_TextChatNotSupported);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e + "Error");
                }
            }
        }

        public class FileViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public TextView FileNameTextView { get; private set; }
            public TextView SizeFileTextView { get; private set; }
            public TextView MsgTimeTextView { get; private set; }
            public AppCompatTextView IconTypefile { get; private set; }
            public TextView UserName { get; private set; }
            #endregion

            public FileViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    FileNameTextView = itemView.FindViewById<TextView>(Resource.Id.fileName);
                    SizeFileTextView = itemView.FindViewById<TextView>(Resource.Id.sizefileText);
                    MsgTimeTextView = itemView.FindViewById<TextView>(Resource.Id.time);
                    IconTypefile = itemView.FindViewById<AppCompatTextView>(Resource.Id.Icontypefile);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }
         
        public class ProductViewHolder : RecyclerView.ViewHolder
        {
            #region Variables Basic

            public LinearLayout LytParent { get; set; }
            public View MainView { get; private set; }
            public EventHandler ClickHandler { get; set; }
            public ImageView ImageView { get; private set; }
            public TextView Time { get; private set; }

            public TextView Title { get; private set; }
            public TextView Cat { get; private set; }
            public TextView Price { get; private set; }

            public TextView UserName { get; private set; }

            #endregion

            public ProductViewHolder(View itemView, bool showName) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    LytParent = itemView.FindViewById<LinearLayout>(Resource.Id.main);
                    ImageView = itemView.FindViewById<ImageView>(Resource.Id.imgDisplay);
                    Time = itemView.FindViewById<TextView>(Resource.Id.time);

                    Title = itemView.FindViewById<TextView>(Resource.Id.title);
                    Cat = itemView.FindViewById<TextView>(Resource.Id.cat);
                    Price = itemView.FindViewById<TextView>(Resource.Id.price);

                    UserName = itemView.FindViewById<TextView>(Resource.Id.name);
                    if (UserName != null) UserName.Visibility = showName ? ViewStates.Visible : ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }


    }
}