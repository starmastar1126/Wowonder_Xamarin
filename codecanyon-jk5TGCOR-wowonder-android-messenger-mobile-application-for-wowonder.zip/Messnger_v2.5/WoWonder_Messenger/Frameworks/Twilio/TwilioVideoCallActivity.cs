using System;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using Android;
using Android.App;
using Android.Content.PM;
using Android.Content.Res;
using Android.Hardware;
using Android.Media;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.App;
using Android.Support.V4.Content;
using Android.Support.V7.App;
using Android.Util;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using TwilioVideo;
using WoWonder.Activities.Tab;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using VideoView = TwilioVideo.VideoView;

namespace WoWonder.Frameworks.Twilio
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.SmallestScreenSize | ConfigChanges.ScreenLayout | ConfigChanges.Orientation, LaunchMode = LaunchMode.SingleInstance, ResizeableActivity = true, SupportsPictureInPicture = true)]
    public class TwilioVideoCallActivity : AppCompatActivity, TwilioVideoHelper.IListener, ISensorEventListener
    {
        #region Variables Basic

        private TwilioVideoHelper TwilioVideo { get; set; }

        private string TwilioAccessToken = "YOUR_TOKEN";
        private string TwilioAccessTokenUser2 = "YOUR_TOKEN";
        private string RoomName = "TestRoom";
        private string CallId = "0";
        private string CallType = "0";
        private string UserId = "";
        private string Avatar = "0";
        private string Name = "0";
        private string FromId = "0";
        private string Active = "0";
        private string Status = "0";

        private RelativeLayout MainUserViewProfile;
        private string LocalVideoTrackId;
        private string RemoteVideoTrackId;
        private const int PermissionsRequestCode = 1;
        private bool DataUpdated;
        private int CountSecoundsOfOutgoingCall;

        private VideoView UserprimaryVideo;
        private VideoView ThumbnailVideo;
        private LocalVideoTrack LocalvideoTrack;
        private VideoTrack UserVideoTrack;
        private Button SwitchCamButton;
        private CircleButton EndCallButton;
        private CircleButton MuteVideoButton;
        private CircleButton MuteAudioButton;
        private ImageView UserImageView, PictureInToPictureButton;
        private TextView UserNameTextView;
        private TextView NoteTextView;

        private Timer TimerRequestWaiter = new Timer();

        private TabbedMainActivity GlobalContext;

        private SensorManager SensorManager;
        private Sensor Proximity;
        private readonly int SensorSensitivity = 4;

        #endregion

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                // Create your application here
                SetContentView(Resource.Layout.TwilioVideoCallActivityLayout);
                Window.AddFlags(WindowManagerFlags.KeepScreenOn);

                GlobalContext = TabbedMainActivity.GetInstance();

                SensorManager = (SensorManager)GetSystemService(SensorService);
                Proximity = SensorManager.GetDefaultSensor(SensorType.Proximity);

                UserId = Intent.GetStringExtra("UserID");
                Avatar = Intent.GetStringExtra("avatar");
                Name = Intent.GetStringExtra("name");

                var dataCallId = Intent.GetStringExtra("CallID") ?? "Data not available";
                if (dataCallId != "Data not available" && !String.IsNullOrEmpty(dataCallId))
                {
                    CallId = dataCallId;

                    TwilioAccessToken = Intent.GetStringExtra("access_token");
                    TwilioAccessTokenUser2 = Intent.GetStringExtra("access_token_2");
                    FromId = Intent.GetStringExtra("from_id");
                    Active = Intent.GetStringExtra("active");
                    var time = Intent.GetStringExtra("time");
                    Status = Intent.GetStringExtra("status");
                    RoomName = Intent.GetStringExtra("room_name");
                    CallType = Intent.GetStringExtra("type");
                    Console.WriteLine(time);
                }

                //Get values
                MainUserViewProfile = FindViewById<RelativeLayout>(Resource.Id.userInfoview_container);
                UserprimaryVideo = FindViewById<VideoView>(Resource.Id.userthumbnailVideo); // userthumbnailVideo
                ThumbnailVideo = FindViewById<VideoView>(Resource.Id.local_video_view_container); //local_video_view_container
                SwitchCamButton = FindViewById<Button>(Resource.Id.switch_cam_button);
                MuteVideoButton = FindViewById<CircleButton>(Resource.Id.mute_video_button);
                EndCallButton = FindViewById<CircleButton>(Resource.Id.end_call_button);
                MuteAudioButton = FindViewById<CircleButton>(Resource.Id.mute_audio_button);
                //UserInfoviewContainer = FindViewById<RelativeLayout>(Resource.Id.userInfoview_container);
                UserImageView = FindViewById<ImageView>(Resource.Id.userImageView);
                UserNameTextView = FindViewById<TextView>(Resource.Id.userNameTextView);
                NoteTextView = FindViewById<TextView>(Resource.Id.noteTextView);
                PictureInToPictureButton = FindViewById<ImageView>(Resource.Id.pictureintopictureButton);

                if (!PackageManager.HasSystemFeature(PackageManager.FeaturePictureInPicture))
                    PictureInToPictureButton.Visibility = ViewStates.Gone;

                //Event
                SwitchCamButton.Click += Switch_cam_button_Click;
                MuteVideoButton.Click += Mute_video_button_Click;
                EndCallButton.Click += End_call_button_Click;
                MuteAudioButton.Click += Mute_audio_button_Click;
                PictureInToPictureButton.Click += PictureInToPictureButton_Click;
                VolumeControlStream = Stream.VoiceCall;

                bool granted =
                    ContextCompat.CheckSelfPermission(ApplicationContext, Manifest.Permission.Camera) ==
                    Permission.Granted &&
                    ContextCompat.CheckSelfPermission(ApplicationContext, Manifest.Permission.RecordAudio) ==
                    Permission.Granted;

                CheckVideoCallPermissions(granted);
                MuteVideoButton.Selected = true;

                if (CallType == "Twilio_video_call")
                {
                    if (!string.IsNullOrEmpty(TwilioAccessToken))
                    {
                        TwilioVideo = TwilioVideoHelper.GetOrCreate(ApplicationContext);
                        UpdateState();
                        NoteTextView.Text = GetText(Resource.String.Lbl_Waiting_for_answer);
                        var checkForResponseDate = ApiRequest.Send_Twilio_Video_Call_Answer_Async("answer", CallId);
                        Console.WriteLine(checkForResponseDate);
                        ConnectToRoom();
                        var ckd = GlobalContext?.LastCallsTab?.MAdapter?.MCallUser?.FirstOrDefault(a => a.Id == CallId); // id >> Call_Id
                        if (ckd == null)
                        {
                            Classes.CallUser cv = new Classes.CallUser
                            {
                                Id = CallId,
                                UserId = UserId,
                                Avatar = Avatar,
                                Name = Name,
                                FromId = FromId,
                                Active = Active,
                                Time = "Answered call",
                                Status = Status,
                                RoomName = RoomName,
                                Type = CallType,
                                TypeIcon = "Accept",
                                TypeColor = "#008000"
                            };

                            GlobalContext?.LastCallsTab?.MAdapter?.Insert(cv);

                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.Insert_CallUser(cv);
                            dbDatabase.Dispose();
                        }
                    }
                }
                else if (CallType == "Twilio_video_calling_start")
                {
                    if (!string.IsNullOrEmpty(UserId))
                        LoadProfileFromUserId(UserId);

                    NoteTextView.Text = GetText(Resource.String.Lbl_Calling_video);
                    TwilioVideo = TwilioVideoHelper.GetOrCreate(ApplicationContext);

                    Methods.AudioRecorderAndPlayer.PlayAudioFromAsset("mystic_call.mp3");

                    UpdateState();
                }


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void PictureInToPictureButton_Click(object sender, EventArgs e)
        {
            try
            {
                //var actions = new List<RemoteAction>();
                //.SetActions(new List<RemoteAction>().Add(new RemoteAction().Title = "")
                if (Build.VERSION.SdkInt >= BuildVersionCodes.O)
                {
                    var param = new PictureInPictureParams.Builder().SetAspectRatio(new Rational(9, 16)).Build();
                    EnterPictureInPictureMode(param);
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }


        }

        public override void OnPictureInPictureModeChanged(bool isInPictureInPictureMode, Configuration newConfig)
        {
            try
            {
                if (isInPictureInPictureMode)
                {
                    EndCallButton.Visibility = ViewStates.Gone;
                    MuteAudioButton.Visibility = ViewStates.Gone;
                    MuteVideoButton.Visibility = ViewStates.Gone;
                    UserNameTextView.Visibility = ViewStates.Gone;
                    NoteTextView.Visibility = ViewStates.Gone;
                    ThumbnailVideo.Visibility = ViewStates.Gone;
                    PictureInToPictureButton.Visibility = ViewStates.Gone;
                    MainUserViewProfile.Visibility = ViewStates.Gone;
                    FindViewById(Resource.Id.local_video_container).Visibility = ViewStates.Gone;
                }
                else
                {
                    EndCallButton.Visibility = ViewStates.Visible;
                    MuteAudioButton.Visibility = ViewStates.Visible;
                    UserNameTextView.Visibility = ViewStates.Visible;
                    NoteTextView.Visibility = ViewStates.Visible;
                    ThumbnailVideo.Visibility = ViewStates.Visible;
                    MuteVideoButton.Visibility = ViewStates.Visible;
                    PictureInToPictureButton.Visibility = ViewStates.Visible;
                    FindViewById(Resource.Id.local_video_container).Visibility = ViewStates.Visible;
                }

                base.OnPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);

            }

        }

        protected override void OnUserLeaveHint()
        {
            if (Build.VERSION.SdkInt >= BuildVersionCodes.O)
            {
                var param = new PictureInPictureParams.Builder().SetAspectRatio(new Rational(9, 16)).Build();
                EnterPictureInPictureMode(param);
            }
            base.OnUserLeaveHint();



        }

        private async void LoadProfileFromUserId(string userId)
        {
            try
            {
                MainUserViewProfile.Visibility = ViewStates.Visible;

                UserNameTextView.Text = Name;

                //profile_picture
                GlideImageLoader.LoadImage(this, Avatar, UserImageView, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);

                var callResultGeneration = await ApiRequest.Create_Twilio_Video_Call_Answer_Async(userId);
                if (callResultGeneration != null)
                {

                    CallId = callResultGeneration.Id;
                    TwilioAccessToken = callResultGeneration.AccessToken;
                    TwilioAccessTokenUser2 = callResultGeneration.AccessToken2;
                    RoomName = callResultGeneration.RoomName;


                    TimerRequestWaiter = new Timer();
                    TimerRequestWaiter.Interval = 5000;
                    TimerRequestWaiter.Elapsed += TimerCallRequestAnswer_Waiter_Elapsed;
                    TimerRequestWaiter.Start();
                }
                else
                {
                    FinishCall(true);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void TimerCallRequestAnswer_Waiter_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                var callResultGeneration = await ApiRequest.Check_Twilio_Call_Answer_Async(CallId, "video");

                if (string.IsNullOrEmpty(callResultGeneration))
                    return;

                Methods.AudioRecorderAndPlayer.StopAudioFromAsset();

                if (callResultGeneration == "200")
                {
                    if (!string.IsNullOrEmpty(TwilioAccessToken))
                    {
                        TimerRequestWaiter.Enabled = false;
                        TimerRequestWaiter.Stop();
                        TimerRequestWaiter.Close();

                        RunOnUiThread(async () =>
                        {
                            await Task.Delay(1000);

                            TwilioVideo.UpdateToken(TwilioAccessTokenUser2);
                            TwilioVideo.JoinRoom(ApplicationContext, RoomName);

                            Classes.CallUser cv = new Classes.CallUser
                            {
                                Id = CallId,
                                UserId = UserId,
                                Avatar = Avatar,
                                Name = Name,
                                FromId = FromId,
                                Active = Active,
                                Time = "Answered call",
                                Status = Status,
                                RoomName = RoomName,
                                Type = CallType,
                                TypeIcon = "Accept",
                                TypeColor = "#008000"
                            };

                            GlobalContext?.LastCallsTab?.MAdapter?.Insert(cv);

                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.Insert_CallUser(cv);
                            dbDatabase.Dispose();
                        });
                    }
                }
                else if (callResultGeneration == "300")
                {
                    if (CountSecoundsOfOutgoingCall < 70)
                    {
                        CountSecoundsOfOutgoingCall += 10;
                    }
                    else
                    {
                        //Call Is inactive 
                        TimerRequestWaiter.Enabled = false;
                        TimerRequestWaiter.Stop();
                        TimerRequestWaiter.Close();

                        var ckd = GlobalContext?.LastCallsTab?.MAdapter?.MCallUser?.FirstOrDefault(a =>
                            a.Id == CallId); // id >> Call_Id
                        if (ckd == null)
                        {
                            Classes.CallUser cv = new Classes.CallUser
                            {
                                Id = CallId,
                                UserId = UserId,
                                Avatar = Avatar,
                                Name = Name,
                                FromId = FromId,
                                Active = Active,
                                Time = "Missed call",
                                Status = Status,
                                RoomName = RoomName,
                                Type = CallType,
                                TypeIcon = "Cancel",
                                TypeColor = "#FF0000"
                            };

                            GlobalContext?.LastCallsTab?.MAdapter?.Insert(cv);

                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.Insert_CallUser(cv);
                            dbDatabase.Dispose();
                        }

                        FinishCall(true);
                    }
                }
                else
                {
                    //Call Is inactive 
                    TimerRequestWaiter.Enabled = false;
                    TimerRequestWaiter.Stop();
                    TimerRequestWaiter.Close();

                    var ckd = GlobalContext?.LastCallsTab?.MAdapter?.MCallUser?.FirstOrDefault(a =>
                        a.Id == CallId); // id >> Call_Id
                    if (ckd == null)
                    {
                        Classes.CallUser cv = new Classes.CallUser
                        {
                            Id = CallId,
                            UserId = UserId,
                            Avatar = Avatar,
                            Name = Name,
                            FromId = FromId,
                            Active = Active,
                            Time = "Declined call",
                            Status = Status,
                            RoomName = RoomName,
                            Type = CallType,
                            TypeIcon = "Declined",
                            TypeColor = "#FF8000"
                        };

                        GlobalContext?.LastCallsTab?.MAdapter?.Insert(cv);

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();
                        dbDatabase.Insert_CallUser(cv);
                        dbDatabase.Dispose();
                    }

                    FinishCall(true);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Mute_audio_button_Click(object sender, EventArgs e)
        {
            try
            {
                if (MuteAudioButton.Selected)
                {
                    MuteAudioButton.Selected = false;
                    MuteAudioButton.SetImageResource(Resource.Drawable.ic_camera_mic_open);
                }
                else
                {
                    MuteAudioButton.Selected = true;
                    MuteAudioButton.SetImageResource(Resource.Drawable.ic_camera_mic_mute);
                }

                var visibleMutedLayers = MuteAudioButton.Selected ? ViewStates.Visible : ViewStates.Invisible;
                FindViewById(Resource.Id.local_video_overlay).Visibility = visibleMutedLayers;
                FindViewById(Resource.Id.local_video_muted).Visibility = visibleMutedLayers;
                TwilioVideo.Mute(MuteAudioButton.Selected);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void End_call_button_Click(object sender, EventArgs e)
        {
            try
            {
                FinishCall(true);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Mute_video_button_Click(object sender, EventArgs e)
        {
            try
            {
                if (MuteVideoButton.Selected)
                {
                    MuteVideoButton.SetImageResource(Resource.Drawable.ic_camera_video_mute);

                    MuteVideoButton.Selected = false;
                }
                else
                {
                    MuteVideoButton.SetImageResource(Resource.Drawable.ic_camera_video_open);
                    MuteVideoButton.Selected = true;
                }

                var isVideoEnabled = MuteVideoButton.Selected;
                FindViewById(Resource.Id.local_video_container).Visibility =
                    isVideoEnabled ? ViewStates.Visible : ViewStates.Gone;
                LocalvideoTrack.Enable(isVideoEnabled);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Switch_cam_button_Click(object sender, EventArgs e)
        {
            try
            {
                TwilioVideo.FlipCamera();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ConnectToRoom()
        {
            TwilioVideo.UpdateToken(TwilioAccessToken);
            TwilioVideo.JoinRoom(ApplicationContext, RoomName);
        }

        public override bool OnSupportNavigateUp()
        {
            TryCancelCall();
            return true;
        }

        public override void OnBackPressed()
        {
            FinishCall(true);
        }

        protected override void OnStart()
        {
            try
            {
                base.OnStart();
                UpdateState();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                UpdateState();
                SensorManager.RegisterListener(this, Proximity, SensorDelay.Normal);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {

                DataUpdated = false;

                base.OnPause();
                SensorManager.UnregisterListener(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        protected override void OnRestart()
        {
            try
            {
                base.OnRestart();
                if (!IsInPictureInPictureMode)
                {
                    TwilioVideo = TwilioVideoHelper.GetOrCreate(ApplicationContext);
                    UpdateState();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        protected override void OnStop()
        {
            try
            {
                base.OnStop();
                if (IsInPictureInPictureMode)
                {
                    //FinishCall(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }


        }

        private void UpdateState()
        {
            try
            {
                if (DataUpdated)
                    return;
                DataUpdated = true;
                TwilioVideo.Bind(this);
                UpdatingState();

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void UpdatingState()
        {
        }

        private void TryCancelCall()
        {
            CloseScreen();
        }


        private void CloseScreen()
        {
            Finish();
        }

        private void FinishCall(bool hangup)
        {
            try
            {
                if (TwilioVideo.ClientIsReady)
                {
                    TwilioVideo.Unbind(this);
                    TwilioVideo.FinishCall();
                }

                Methods.AudioRecorderAndPlayer.StopAudioFromAsset();
                Finish();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        void RequestCameraAndMicrophonePermissions()
        {
            if (ActivityCompat.ShouldShowRequestPermissionRationale(this, Manifest.Permission.Camera) ||
                ActivityCompat.ShouldShowRequestPermissionRationale(this, Manifest.Permission.RecordAudio))
                Toast.MakeText(this, GetText(Resource.String.Lbl_Need_Camera), ToastLength.Long).Show();
            else
                ActivityCompat.RequestPermissions(this,
                    new[] { Manifest.Permission.Camera, Manifest.Permission.RecordAudio }, PermissionsRequestCode);
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions,
            [GeneratedEnum] Permission[] grantResults)
        {
            if (requestCode == PermissionsRequestCode)
                CheckVideoCallPermissions(grantResults.Any(p => p == Permission.Denied));
        }

        void CheckVideoCallPermissions(bool granted)
        {
            if (!granted)
                RequestCameraAndMicrophonePermissions();
        }

        #region TwilioVideo.IListener

        public void SetLocalVideoTrack(LocalVideoTrack videoTracklocal)
        {
            try
            {
                if (LocalvideoTrack == null)
                {
                    LocalvideoTrack = videoTracklocal;
                    var trackId = videoTracklocal?.TrackId;
                    if (LocalVideoTrackId == trackId)
                    {
                    }
                    else
                    {
                        LocalVideoTrackId = trackId;
                        LocalvideoTrack.AddRenderer(ThumbnailVideo);
                        ThumbnailVideo.Visibility =
                            LocalvideoTrack == null ? ViewStates.Invisible : ViewStates.Visible;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void SetRemoteVideoTrack(VideoTrack videoTrack)
        {
            var trackId = videoTrack?.TrackId;

            if (RemoteVideoTrackId == trackId)
                return;

            RemoteVideoTrackId = trackId;
            if (UserVideoTrack == null)
            {
                UserVideoTrack = videoTrack;


                UserVideoTrack?.AddRenderer(UserprimaryVideo);

                ThumbnailVideo.Visibility = LocalvideoTrack == null ? ViewStates.Invisible : ViewStates.Visible;
            }
        }

        public void RemoveLocalVideoTrack(LocalVideoTrack track)
        {
            SetLocalVideoTrack(null);
        }

        public void RemoveRemoteVideoTrack(VideoTrack track)
        {
            try
            {
                MainUserViewProfile.Visibility = ViewStates.Visible;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnRoomConnected(string roomId)
        {

        }

        public void OnRoomDisconnected(TwilioVideoHelper.StopReason reason)
        {

            Toast.MakeText(this, GetText(Resource.String.Lbl_Room_Disconnected), ToastLength.Short).Show();

        }

        public void OnParticipantConnected(string participantId)
        {
            try
            {
                MainUserViewProfile.Visibility = ViewStates.Gone;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnParticipantDisconnected(string participantId)
        {

            FinishCall(true);
        }

        #endregion

        public void SetCallTime(int seconds)
        {

        }

        #region Sensor System

        public void OnAccuracyChanged(Sensor sensor, SensorStatus accuracy)
        {
            try
            {
                // Do something here if sensor accuracy changes.
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void OnSensorChanged(SensorEvent e)
        {
            try
            {
                if (e.Sensor.Type == SensorType.Proximity)
                {
                    if (e.Values[0] >= -SensorSensitivity && e.Values[0] <= SensorSensitivity)
                    {
                        //near 
                        TabbedMainActivity.GetInstance()?.SetOffWakeLock();
                    }
                    else
                    {
                        //far 
                        TabbedMainActivity.GetInstance()?.SetOnWakeLock();
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion
    }
}