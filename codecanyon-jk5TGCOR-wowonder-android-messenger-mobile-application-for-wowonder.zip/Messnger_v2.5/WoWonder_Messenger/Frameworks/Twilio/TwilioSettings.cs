namespace WoWonder.Frameworks.Twilio {
    public class TwilioSettings {
        public static string TwilioAccessToken = "YOUR_TOKEN";
        public static string RoomName = "TestRoom";
    }
}