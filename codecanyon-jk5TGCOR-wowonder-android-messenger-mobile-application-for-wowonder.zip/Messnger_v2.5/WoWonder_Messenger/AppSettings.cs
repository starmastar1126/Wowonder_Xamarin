﻿//Use DoughouzChecker last version 3.0 to 
//build your own certifcate 
//For Full Documention 
//https://paper.dropbox.com/doc/WoWonder-Messenger-2.0--ARqO4OoLf_KXGWT63gNm0pOuAQ-M6qrJYGQ0C0NZlhZ3PqI7
//CopyRight DoughouzLight

namespace WoWonder
{
    public static class AppSettings
    {
        public static string TripleDesAppServiceProvider = "NFYnA2qriwLLUe74dlNM90fBmeMKm8QuEm2TgU8DdI0iiV8/7rUmdfeSr8kyg3IhGohvfbsEUEgYhdr3Q1gMhwCvLMZBC8A/kuQkC1cxMOBZXly5MKi6PhMS61VDxBcKu9oYCWckSjrlsvKX6VldLq7Prw7kszdSOxAfNVAJKBPxgxoejEC62RQEGB80ICdoBJQQfRl9xs+VdmZNJ7LjH07wHqsLaDxqKYRXl6sHKqupnU2t+paYBOadjeabLY2Dac2Z553tGLrNpGdArD5+Fg==";

        //Main Settings >>>>>
        //*********************************************************

        public static string Version = "2.5"; 
        public static string ApplicationName = "WoWonder Messenger";

        // Friend system = 0 , follow system = 1
        public static int ConnectivitySystem = 1;
         
        //Main Colors >>
        //*********************************************************
        public static string MainColor = "#a84849"; 
        public static string StoryReadColor = "#808080";

        //Language Settings >> http://www.lingoes.net/en/translator/langcode.htm
        //*********************************************************
        public static bool FlowDirectionRightToLeft = false;
        public static string Lang = ""; //Default language ar_AE

        //Notification Settings >>
        //*********************************************************
        public static bool ShowNotification = true;
        public static string OneSignalAppId = "340536ea-0006-4f3e-83bd-2a039d2ecc88"; 
         
        //Error Report Mode
        //*********************************************************
        public static bool SetApisReportMode = true; 

        //Code Time Zone (true => Get from Internet , false => Get From #CodeTimeZone )
        //*********************************************************
        public static bool AutoCodeTimeZone = true;  
        public static string CodeTimeZone = "UTC"; 

        //Set Theme Full Screen App
        //*********************************************************
        public static bool EnableFullScreenApp = false;

        //ADMOB >> Please add the code ad in the Here and analytic.xml 
        //*********************************************************
        public static bool ShowAdmobBanner = true;
        public static bool ShowAdmobInterstitial = true;
        public static bool ShowAdmobRewardVideo = true;
        public static bool ShowAdmobNative = true; 

        public static string AdInterstitialKey = "ca-app-pub-5135691635931982/4466434529";
        public static string AdRewardVideoKey = "ca-app-pub-5135691635931982/7731317149";
        public static string AdAdmobNativeKey = "ca-app-pub-5135691635931982/7916685759"; 

        //Three times after entering the ad is displayed
        public static int ShowAdmobInterstitialCount = 3;
        public static int ShowAdmobRewardedVideoCount = 3;
        public static int ShowAdmobNativeCount = 3; 

        //Social Logins >>
        //If you want login with facebook or google you should change id key in the analytic.xml file or AndroidManifest.xml
        //Facebook >> ../values/analytic.xml .. 
        //Google >> ../Properties/AndroidManifest.xml .. line 37
        //*********************************************************
        public static bool ShowFacebookLogin = false;
        public static bool ShowGoogleLogin = false;

        public static readonly string ClientId = "127961853161-sp4678loj9o67i7594vl2asjnj77uafi.apps.googleusercontent.com";
        public static readonly string ClientSecret = "mj3nDDfOy0Hrdkq03cJy930I";
         
        //ChatWindow_Activity >>
        //*********************************************************
        //if you want this feature enabled go to Properties -> AndroidManefist.xml and remove comments from below code
        //Just replace it with this 5 lines of code
        /*
         <uses-permission android:name="android.permission.READ_CONTACTS" />
         <uses-permission android:name="android.permission.READ_PHONE_NUMBERS" /> 
         <uses-permission android:name="android.permission.READ_PHONE_NUMBERS" /> 
         <uses-permission android:name="android.permission.GET_ACCOUNTS" />
         <uses-permission android:name="android.permission.SEND_SMS" />
         */
        public static bool ShowButtonContact = false;
        public static bool InvitationSystem = false;  //Invite friends section 
        /////////////////////////////////////

        public static bool ShowButtonCamera = true;  
        public static bool ShowButtonImage = true;
        public static bool ShowButtonVideo = true;
        public static bool ShowButtonAttachFile = true;
        public static bool ShowButtonColor = true;
        public static bool ShowButtonStickers = true;
        public static bool ShowButtonMusic = true;
        public static bool ShowButtonGif = true; 
        
        //Record Sound Style & Text
        ///*********************************************************
        public static bool ShowButtonRecordSound = true;
 
        //Tabbed_Main_Page >>
        //*********************************************************
        public static bool ShowTitleUsername = false;

        // Chat Group >>
        //*********************************************************
        public static bool EnableChatGroup = true;  
         
        // User Profile >>
        //*********************************************************
        public static bool EnableShowPhoneNumber = true;  
         
        // Video/Audio Call Settings >>
        //*********************************************************
        public static bool EnableAudioVideoCall = true;

        public static bool EnableAudioCall = true;
        public static bool EnableVideoCall = true;

        public static bool UseAgoraLibrary = false;
        public static bool UseTwilioLibrary = true;

        // Walkthrough Settings >>
        //*********************************************************
        public static bool ShowWalkTroutPage = true;

        public static bool WalkThroughSetFlowAnimation = true;
        public static bool WalkThroughSetZoomAnimation = false;
        public static bool WalkThroughSetSlideOverAnimation = false;
        public static bool WalkThroughSetDepthAnimation = false;
        public static bool WalkThroughSetFadeAnimation = false;

        //Last_Messages Page >>
        ///*********************************************************
        public static bool ShowOnlineOfflineMessage = true;
         
        public static int RefreshChatActivitiesSeconds = 6000; // 6 Seconds
        public static int MessageRequestSpeed = 3000; // 3 Seconds

        public static bool RenderPriorityFastPostLoad = true;

        //Bypass Web Erros 
        ///*********************************************************
        public static bool TurnTrustFailureOnWebException = false;
        public static bool TurnSecurityProtocolType3072On = false;

        // Stickers Packs Settings >>
        //*********************************************************
        public static int StickersOnEachRow = 3;
        public static string StickersBarColor = "#efefef";
        public static string StickersBarColorDark = "#282828";

        public static bool ShowStickerStack0  = true;
        public static bool ShowStickerStack1 = true;
        public static bool ShowStickerStack2 = true;
        public static bool ShowStickerStack3 = true;
        public static bool ShowStickerStack4 = true;
        public static bool ShowStickerStack5 = true;
        public static bool ShowStickerStack6 = false;

        public static bool SetTabDarkTheme = false; //#New

        public static bool ShowSuggestedUsersOnRegister = true;  
        public static bool ImageCropping = true; 
    }
}
