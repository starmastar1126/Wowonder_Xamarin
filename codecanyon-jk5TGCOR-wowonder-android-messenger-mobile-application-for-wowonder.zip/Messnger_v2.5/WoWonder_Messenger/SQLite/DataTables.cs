using SQLite;
using WoWonderClient.Classes.Global;

namespace WoWonder.SQLite
{
    public class DataTables
    {
        public class LoginTb
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdLogin { get; set; }

            public string UserId { get; set; }
            public string Username { get; set; }
            public string Password { get; set; }
            public string AccessToken { get; set; }
            public string Cookie { get; set; }
            public string Email { get; set; }
            public string Status { get; set; }
            public string Lang { get; set; }
            public string DeviceId { get; set; }
        }

        public class SettingsTb : GetSiteSettingsObject.Config
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdSettings { get; set; }

            public new string CurrencyArray { get; set; }
            public new string CurrencySymbolArray { get; set; }
            public new string PageCategories { get; set; }
            public new string GroupCategories { get; set; }
            public new string BlogCategories { get; set; }
            public new string ProductsCategories { get; set; }
            public new string Genders { get; set; }
            public new string Family { get; set; }
            public new string PostColors { get; set; }
            public new string PostReactionsTypes { get; set; }
        }


        public class MyContactsTb : UserDataObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMyFollowing { get; set; }

            public new string Details { get; set; }
            public new string MutualFriendsData { get; set; }
        }

        public class MyFollowersTb : UserDataObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMyFollowers { get; set; }

            public new string Details { get; set; }
            public new string MutualFriendsData { get; set; }
        }

        public class MyProfileTb : UserDataObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMyProfile { get; set; }

            public new string Details { get; set; }
            public new string MutualFriendsData { get; set; }
        }

        public class SearchFilterTb
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdSearchFilter { get; set; }

            public string Gender { get; set; }
            public string Country { get; set; }
            public string Status { get; set; }
            public string Verified { get; set; }
            public string FilterByAge { get; set; }
            public string AgeFrom { get; set; }
            public string AgeTo { get; set; }
        }

        public class NearByFilterTb
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdNearByFilter { get; set; }

            public int DistanceValue { get; set; }
            public string Gender { get; set; }
            public int Status { get; set; }
        }

        public class LastUsersTb
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdLastUsers { get; set; }
            public string OrderId { get; set; }
            public string UserData { get; set; } //UserDataObject
            public string LastMessageData { get; set; }  //SendMessageObject.MessageData
        }

        public class MessageTb
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMessage { get; set; }

            public string Id { get; set; }
            public string FromId { get; set; }
            public string GroupId { get; set; }
            public string ToId { get; set; }
            public string Text { get; set; }
            public string Media { get; set; }
            public string MediaFileName { get; set; }
            public string MediaFileNames { get; set; }
            public string Time { get; set; }
            public string Seen { get; set; }
            public string DeletedOne { get; set; }
            public string DeletedTwo { get; set; }
            public string SentPush { get; set; }
            public string NotificationId { get; set; }
            public string TypeTwo { get; set; }
            public string Stickers { get; set; }
            public string ProductId { get; set; }
            public string MessageUser { get; set; }
            public string TimeText { get; set; }
            public string Position { get; set; }
            public string Type { get; set; }
            public string Product { get; set; }
            public string FileSize { get; set; }



            //style
            public string MediaDuration { get; set; }
            public bool MediaIsPlaying { get; set; }
            public string ContactNumber { get; set; }
            public string ContactName { get; set; }

        }

        public class CallUserTb
        {
            [PrimaryKey, AutoIncrement] public int Id { get; set; }

            public string VideoCall { get; set; }

            public string UserId { get; set; }
            public string Avatar { get; set; }
            public string Name { get; set; }

            //Data
            public string CallId { get; set; }
            public string AccessToken { get; set; }
            public string AccessToken2 { get; set; }
            public string FromId { get; set; }
            public string ToId { get; set; }
            public string Active { get; set; }
            public string Called { get; set; }
            public string Time { get; set; }
            public string Declined { get; set; }
            public string Url { get; set; }
            public string Status { get; set; }
            public string RoomName { get; set; }
            public string Type { get; set; }

            //Style       
            public string TypeIcon { get; set; }
            public string TypeColor { get; set; }
        }

    }
}
