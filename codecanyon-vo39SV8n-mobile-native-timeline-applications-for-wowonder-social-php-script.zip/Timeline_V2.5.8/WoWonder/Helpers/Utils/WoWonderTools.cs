﻿using System;
using Android.App;
using Android.Content;
using WoWonder.Activities.MyProfile;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.UserProfile;
using WoWonder.Helpers.Model;
using WoWonderClient.Classes.Global;

namespace WoWonder.Helpers.Utils
{
    public static class WoWonderTools
    {
        public static string GetNameFinal(UserDataObject dataUser)
        {
            try
            {
                if (!string.IsNullOrEmpty(dataUser.Name) && !string.IsNullOrWhiteSpace(dataUser.Name))
                    return Methods.FunString.DecodeString(dataUser.Name);

                if (!string.IsNullOrEmpty(dataUser.Username) && !string.IsNullOrWhiteSpace(dataUser.Username))
                    return Methods.FunString.DecodeString(dataUser.Username);

                return Methods.FunString.DecodeString(dataUser.Username);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Methods.FunString.DecodeString(dataUser.Username);
            }
        }

        public static string GetAboutFinal(UserDataObject dataUser)
        {
            try
            {
                if (!string.IsNullOrEmpty(dataUser.About) && !string.IsNullOrWhiteSpace(dataUser.About))
                    return Methods.FunString.DecodeString(dataUser.About);

                return Application.Context.Resources.GetString(Resource.String.Lbl_DefaultAbout) + " " + AppSettings.ApplicationName;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Methods.FunString.DecodeString(dataUser.About);
            }
        }

        public static (string, string) GetCurrency(string idCurrency)
        {
            try
            {
                string currencyIcon, currency;
                bool success = int.TryParse(idCurrency, out var number);
                if (success)
                {
                    Console.WriteLine("Converted '{0}' to {1}.", idCurrency, number);
                    currency = ListUtils.SettingsSiteList.CurrencyArray.CurrencyList[number] ?? "";
                }
                else
                {
                    Console.WriteLine("Attempted conversion of '{0}' failed.", idCurrency ?? "<null>");
                    currency = idCurrency;
                }

                if (ListUtils.SettingsSiteList.CurrencySymbolArray != null)
                {
                    switch (currency)
                    {
                        case "USD":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Usd;
                            break;
                        case "EUR":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Eur;
                            break;
                        case "TRY":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Try;
                            break;
                        case "GBP":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Gbp;
                            break;
                        case "RUB":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Rub;
                            break;
                        case "PLN":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Pln;
                            break;
                        case "ILS":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Ils;
                            break;
                        case "BRL":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Brl;
                            break;
                        case "INR":
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Inr;
                            break;
                        default:
                            currencyIcon = ListUtils.SettingsSiteList.CurrencySymbolArray.Usd;
                            break;
                    } 
                }
                else
                {
                    return ("", "");
                }

                return (currency, currencyIcon);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return ("", "");
            }
        }

        public static void OpenProfile(Activity activity, string userId, UserDataObject item)
        {
            try
            {
                if (userId != UserDetails.UserId)
                {
                    MainApplication.GetInstance()?.NavigateTo(activity, typeof(UserProfileActivity), item);

                    //var Int = new Intent(activity, typeof(UserProfileActivity));
                    //Int.PutExtra("UserObject", JsonConvert.SerializeObject(item));
                    //Int.PutExtra("UserId", item.UserId);
                    //activity.StartActivity(Int);
                }
                else
                {
                    if (PostClickListener.OpenMyProfile) return;
                    var intent = new Intent(activity, typeof(MyProfileActivity));
                    activity.StartActivity(intent);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static bool GetStatusOnline(int lastSeen, string isShowOnline)
        {
            try
            {
                string time = Methods.Time.TimeAgo(lastSeen);
                bool status = isShowOnline == "on" && time == Methods.Time.LblJustNow ? true : false;
                return status;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        } 
    }
}