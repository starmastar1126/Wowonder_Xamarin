﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Gms.Auth.Api;
using Android.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.AddPost.Adapters;
using WoWonder.Activities.Default;
using WoWonder.Activities.SettingsPreferences;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.Library.OneSignal;
using WoWonder.SQLite;
using WoWonderClient;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using Xamarin.Facebook;
using Xamarin.Facebook.Login;
using Console = System.Console;
using Exception = System.Exception;
using File = Java.IO.File;

namespace WoWonder.Helpers.Controller
{
    public static class ApiRequest
    {
        private static readonly string ApiAddNewPost = Client.WebsiteUrl + "/app_api.php?application=phone&type=new_post";
        private static string ApiGetSearchGifs = "https://api.giphy.com/v1/gifs/search?api_key=b9427ca5441b4f599efa901f195c9f58&q=";
        private static readonly string ApiGetTimeZone = "http://ip-api.com/json/";

        public static async Task<GetSiteSettingsObject.Config> GetSettings_Api(Activity context)
        {
            if (Methods.CheckConnectivity())
            {
                await SetLangUserAsync().ConfigureAwait(false);

                (var apiStatus, dynamic respond) = await Current.GetSettings();

                if (apiStatus != 200 || !(respond is GetSiteSettingsObject result) || result.config == null)
                    return Methods.DisplayReportResult(context, respond);

                ListUtils.SettingsSiteList = result.config;

                UserDetails.PlayTubeUrl = result.config.PlaytubeUrl;

                AppSettings.OneSignalAppId = result.config.AndroidNPushId;
                OneSignalNotification.RegisterNotificationDevice();

                //Page Categories
                var listPage = result.config.PageCategories.Select(cat => new Classes.Categories
                {
                    CategoriesId = cat.Key,
                    CategoriesName = cat.Value,
                    CategoriesColor = "#ffffff"
                }).ToList();

                CategoriesController.ListCategoriesPage.Clear();
                CategoriesController.ListCategoriesPage = new ObservableCollection<Classes.Categories>(listPage);

                //Group Categories
                var listGroup = result.config.GroupCategories.Select(cat => new Classes.Categories
                {
                    CategoriesId = cat.Key,
                    CategoriesName = cat.Value,
                    CategoriesColor = "#ffffff"
                }).ToList();

                CategoriesController.ListCategoriesGroup.Clear();
                CategoriesController.ListCategoriesGroup = new ObservableCollection<Classes.Categories>(listGroup);

                //Products Categories
                var listProducts = result.config.ProductsCategories.Select(cat => new Classes.Categories
                {
                    CategoriesId = cat.Key,
                    CategoriesName = cat.Value,
                    CategoriesColor = "#ffffff"
                }).ToList();

                CategoriesController.ListCategoriesProducts.Clear();
                CategoriesController.ListCategoriesProducts = new ObservableCollection<Classes.Categories>(listProducts);

                //Family
                var listFamily = result.config.Family.Select(cat => new Classes.Family
                {
                    FamilyId = cat.Key,
                    FamilyName = cat.Value,
                }).ToList();

                ListUtils.FamilyList.Clear();
                ListUtils.FamilyList = new ObservableCollection<Classes.Family>(listFamily);

                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                dbDatabase.InsertOrUpdateSettings(result.config);
                dbDatabase.Dispose();

                try
                {
                    if (CategoriesController.ListCategoriesPage.Count == 0)
                    {
                        Methods.DialogPopup.InvokeAndShowDialog(context, "ReportMode", "List Categories Page Not Found, Please check api get_site_settings ", "Close");
                    }

                    if (CategoriesController.ListCategoriesGroup.Count == 0)
                    {
                        Methods.DialogPopup.InvokeAndShowDialog(context, "ReportMode", "List Categories Group Not Found, Please check api get_site_settings ", "Close");
                    }

                    if (CategoriesController.ListCategoriesProducts.Count == 0)
                    {
                        Methods.DialogPopup.InvokeAndShowDialog(context, "ReportMode", "List Categories Products Not Found, Please check api get_site_settings ", "Close");
                    }

                    if (ListUtils.FamilyList.Count == 0)
                    {
                        Methods.DialogPopup.InvokeAndShowDialog(context, "ReportMode", "Family List Not Found, Please check api get_site_settings ", "Close");
                    }

                    if (AppSettings.SetApisReportMode && AppSettings.ShowColor)
                    {
                        if (ListUtils.SettingsSiteList.PostColors != null && ListUtils.SettingsSiteList.PostColors.Value.PostColorsList != null && ListUtils.SettingsSiteList.PostColors.Value.PostColorsList.Count == 0)
                        {
                            Methods.DialogPopup.InvokeAndShowDialog(context, "ReportMode", "PostColors Not Found, Please check api get_site_settings ", "Close");
                        }
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                return result.config;

            }
            else
            {
                Toast.MakeText(Application.Context, Application.Context.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                return null;
            }
        }

        public static async Task GetGifts()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    var (apiStatus, respond) = await RequestsAsync.Global.FetchGiftAsync().ConfigureAwait(false);
                    if (apiStatus == 200)
                    {
                        if (respond is GiftObject result)
                        {
                            if (result.Data.Count > 0)
                            {
                                ListUtils.GiftsList.Clear();
                                ListUtils.GiftsList = new ObservableCollection<GiftObject.DataGiftObject>(result.Data);

                                SqLiteDatabase sqLiteDatabase = new SqLiteDatabase();
                                sqLiteDatabase.InsertAllGifts(ListUtils.GiftsList);
                                sqLiteDatabase.Dispose();

                                foreach (var item in result.Data)
                                {
                                    Methods.MultiMedia.DownloadMediaTo_DiskAsync(Methods.Path.FolderDiskGif, item.MediaFile);
                                }
                            }
                        }
                    }
                }
                else
                {
                    Toast.MakeText(Application.Context, Application.Context.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public static async Task<string> GetTimeZoneAsync()
        {
            try
            {
                if (AppSettings.AutoCodeTimeZone)
                {
                    var client = new HttpClient();
                    var response = await client.GetAsync(ApiGetTimeZone);
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<TimeZoneObject>(json);
                    return data?.Timezone;
                }
                else
                {
                    return AppSettings.CodeTimeZone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return AppSettings.CodeTimeZone;
            }
        }

        private static async Task SetLangUserAsync()
        {
            try
            {
                string lang;
                if (UserDetails.LangName.Contains("en"))
                    lang = "english";
                else if (UserDetails.LangName.Contains("ar"))
                    lang = "arabic";
                else if (UserDetails.LangName.Contains("de"))
                    lang = "german";
                else if (UserDetails.LangName.Contains("el"))
                    lang = "greek";
                else if (UserDetails.LangName.Contains("es"))
                    lang = "spanish";
                else if (UserDetails.LangName.Contains("fr"))
                    lang = "french";
                else if (UserDetails.LangName.Contains("it"))
                    lang = "italian";
                else if (UserDetails.LangName.Contains("ja"))
                    lang = "japanese";
                else if (UserDetails.LangName.Contains("nl"))
                    lang = "dutch";
                else if (UserDetails.LangName.Contains("pt"))
                    lang = "portuguese";
                else if (UserDetails.LangName.Contains("ro"))
                    lang = "romanian";
                else if (UserDetails.LangName.Contains("ru"))
                    lang = "russian";
                else if (UserDetails.LangName.Contains("sq"))
                    lang = "albanian";
                else if (UserDetails.LangName.Contains("sr"))
                    lang = "serbian";
                else if (UserDetails.LangName.Contains("tr"))
                    lang = "turkish";
                else
                    lang = string.IsNullOrEmpty(UserDetails.LangName) ? AppSettings.Lang : "";

                if (lang != "")
                {
                    var dataPrivacy = new Dictionary<string, string>
                    {
                        {"language", lang}
                    };

                    if (Methods.CheckConnectivity())
                        await RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    else
                        Toast.MakeText(Application.Context, Application.Context.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public static async Task<ObservableCollection<GifGiphyClass.Datum>> Search_Gifs_Web(string searchKey)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Application.Context, Application.Context.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    return null;
                }
                else
                {
                    var client = new HttpClient();
                    var response = await client.GetAsync(ApiGetSearchGifs + searchKey);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<GifGiphyClass>(json);

                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        if (data.meta.Status == 200)
                        {
                            return new ObservableCollection<GifGiphyClass.Datum>(data.Data);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<List<Classes.Geocoding.Result>> GetNameLocation(string address)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Application.Context, Application.Context.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    return null;
                }
                else
                {
                    var client = new HttpClient();
                    string url = $"https://maps.googleapis.com/maps/api/geocode/json?address={address}";
                    var response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Classes.Geocoding.GeoClass>(json);

                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        if (data.Status == "OK")
                        {
                            return new List<Classes.Geocoding.Result>(data.Results);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static async Task<(int, dynamic)> AddNewPost_Async(string postId, string postPage, string textContent, string privacy, string feelingType, string feeling, string location,
            ObservableCollection<Attachments> postAttachments, ObservableCollection<PollAnswers> pollAnswersList, string idColor)
        {
            try
            {
                var client = new HttpClient();
                var multi = new MultipartFormDataContent(Guid.NewGuid().ToString())
                {
                    { new StringContent(textContent), $"\"postText\"" },
                    { new StringContent(privacy), $"\"postPrivacy\"" },
                    { new StringContent(UserDetails.AccessToken), $"\"s\""},
                    { new StringContent(UserDetails.UserId), $"\"user_id\"" },
                };

                if (!string.IsNullOrEmpty(feelingType))
                    multi.Add(new StringContent(feelingType), $"\"feeling_type\"");

                if (!string.IsNullOrEmpty(feeling))
                    multi.Add(new StringContent(feeling), $"\"feeling\"");

                if (!string.IsNullOrEmpty(location))
                    multi.Add(new StringContent(location), $"\"postMap\"");

                if (!string.IsNullOrEmpty(idColor))
                    multi.Add(new StringContent(idColor), $"\"post_color\"");

                if (pollAnswersList != null)
                {
                    foreach (var item in pollAnswersList)
                    {
                        multi.Add(new StringContent(item.Answer), $"\"answer[]\"");
                    }
                }

                if (postPage == "SocialGroup")
                    multi.Add(new StringContent(postId), $"\"group_id\"");
                else if (postPage == "SocialPage")
                    multi.Add(new StringContent(postId), $"\"page_id\"");
                else if (postPage == "SocialEvent")
                    multi.Add(new StringContent(postId), $"\"event_id\"");

                //var multi2 = new MultipartFormDataContent(Guid.NewGuid().ToString());

                if (postAttachments.Count > 0)
                {
                    foreach (var attachment in postAttachments)
                    {
                        if (!attachment.FileUrl.Contains(".gif"))
                        {
                            FileStream fs = System.IO.File.OpenRead(attachment.FileUrl);
                            StreamContent scontent = new StreamContent(fs);
                            scontent.Headers.ContentType = new MediaTypeHeaderValue(MimeTypeMap.GetMimeType(attachment.FileUrl?.Split('.').LastOrDefault()));
                            scontent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
                            {
                                Name = attachment.TypeAttachment,
                                FileName = attachment.FileUrl?.Split('\\').LastOrDefault()?.Split('/').LastOrDefault()
                            };

                            //video thumbnail
                            if (attachment.Thumb != null)
                            {
                                FileStream fs2 = System.IO.File.OpenRead(attachment.Thumb.FileUrl);
                                StreamContent scontent2 = new StreamContent(fs2);
                                scontent2.Headers.ContentType = new MediaTypeHeaderValue(MimeTypeMap.GetMimeType(attachment.Thumb.FileUrl?.Split('.').LastOrDefault()));
                                scontent2.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
                                {
                                    Name = attachment.Thumb.TypeAttachment,
                                    FileName = attachment.Thumb.FileUrl?.Split('\\').LastOrDefault()?.Split('/').LastOrDefault()
                                };

                                multi.Add(scontent2);
                            }

                            //multi2.Add(scontent);
                            multi.Add(scontent);
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(textContent) && !string.IsNullOrWhiteSpace(textContent))
                            {
                                var text = textContent;
                                multi.Add(new StringContent(text), $"\"postText\"");

                                multi.Add(new StringContent(attachment.FileUrl), $"\"postSticker\"");
                            }
                            else
                            {
                                multi.Add(new StringContent(attachment.FileUrl), $"\"postSticker\"");
                            }
                        }
                    }
                }

                HttpResponseMessage response = await client.PostAsync(ApiAddNewPost, multi).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                string json = await response.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<AddPostObject>(json);
                if (data.ApiStatus == "200")
                {
                    return (200, data);
                }

                var error = JsonConvert.DeserializeObject<ErrorObject>(json);
                return (400, error);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return (404, e.Message);
            }
        }


        public static async Task Get_MyProfileData_Api(Activity context)
        {
            if (Methods.CheckConnectivity())
            {
                (int apiStatus, var respond) = await RequestsAsync.Global.Get_User_Data(UserDetails.UserId);

                if (apiStatus == 200)
                {
                    if (respond is GetUserDataObject result)
                    {
                        UserDetails.Avatar = result.UserData.Avatar;
                        UserDetails.Cover = result.UserData.Cover;
                        UserDetails.Username = result.UserData.Username;
                        UserDetails.FullName = result.UserData.Name;
                        UserDetails.Email = result.UserData.Email;

                        ListUtils.MyProfileList = new ObservableCollection<UserDataObject>();
                        ListUtils.MyProfileList.Clear();
                        ListUtils.MyProfileList.Add(result.UserData);

                        Glide.With(context).Load(UserDetails.Avatar).Apply(new RequestOptions().SetDiskCacheStrategy(DiskCacheStrategy.All).CircleCrop()).Preload();

                        if (result.JoinedGroups.Count > 0)
                        {
                            var listGroup = result.JoinedGroups.Where(a => a.UserId == UserDetails.UserId).ToList();
                            if (listGroup.Count > 0)
                            {
                                ListUtils.MyGroupList = new ObservableCollection<GroupClass>(listGroup);
                            }
                        }

                        if (result.LikedPages.Count > 0)
                        {
                            var listPage = result.LikedPages.Where(a => a.UserId == UserDetails.UserId).ToList();
                            if (listPage.Count > 0)
                            {
                                ListUtils.MyPageList = new ObservableCollection<PageClass>(listPage);
                            }
                        }

                        context.RunOnUiThread(() =>
                        {
                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.Insert_Or_Update_To_MyProfileTable(result.UserData);
                            dbDatabase.Insert_Or_Replace_MyFollowersTable(new ObservableCollection<UserDataObject>(result.Followers));
                            dbDatabase.Insert_Or_Replace_MyContactTable(new ObservableCollection<UserDataObject>(result.Following));
                            dbDatabase.Dispose();
                        });
                    }
                }
            }
        }

        /////////////////////////////////////////////////////////////////
        private static bool RunLogout;

        public static async void Delete(Activity context)
        {
            try
            {
                if (RunLogout == false)
                {
                    RunLogout = true;

                    await RemoveData("Delete");

                    context.RunOnUiThread(() =>
                    {
                        Methods.Path.DeleteAll_MyFolderDisk();

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();

                        Runtime.GetRuntime().RunFinalization();
                        Runtime.GetRuntime().Gc();
                        TrimCache(context);

                        dbDatabase.ClearAll();
                        dbDatabase.DropAll();

                        ListUtils.ClearAllList();

                        UserDetails.ClearAllValueUserDetails();

                        dbDatabase.CheckTablesStatus();
                        dbDatabase.Dispose();

                        WowTimeMainSettings.SharedData.Edit().Clear().Commit();

                        Intent intent = new Intent(context, typeof(FirstActivity));
                        intent.AddCategory(Intent.CategoryHome);
                        intent.SetAction(Intent.ActionMain);
                        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                        context.StartActivity(intent);
                        context.FinishAffinity();
                        context.Finish();
                    });

                    RunLogout = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static async void Logout(Activity context)
        {
            try
            {
                if (RunLogout == false)
                {
                    RunLogout = true;

                    await RemoveData("Logout");

                    context.RunOnUiThread(async () =>
                    {
                        Methods.Path.DeleteAll_MyFolderDisk();

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();

                        Runtime.GetRuntime().RunFinalization();
                        Runtime.GetRuntime().Gc();
                        TrimCache(context);

                        dbDatabase.ClearAll();
                        dbDatabase.DropAll();

                        ListUtils.ClearAllList();

                        UserDetails.ClearAllValueUserDetails();

                        dbDatabase.CheckTablesStatus();
                        dbDatabase.Dispose();

                        WowTimeMainSettings.SharedData.Edit().Clear().Commit();

                        Intent intent = new Intent(context, typeof(FirstActivity));
                        intent.AddCategory(Intent.CategoryHome);
                        intent.SetAction(Intent.ActionMain);
                        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                        context.StartActivity(intent);
                        context.FinishAffinity();
                        context.Finish();
                    });

                    RunLogout = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void TrimCache(Activity context)
        {
            try
            {
                File dir = context.CacheDir;
                if (dir != null && dir.IsDirectory)
                {
                    DeleteDir(dir);
                }

                context.DeleteDatabase("WowonderSocial.db");
                context.DeleteDatabase(SqLiteDatabase.PathCombine);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static bool DeleteDir(File dir)
        {
            try
            {
                if (dir == null || !dir.IsDirectory) return dir != null && dir.Delete();
                string[] children = dir.List();
                foreach (string child in children)
                {
                    bool success = DeleteDir(new File(dir, child));
                    if (!success)
                    {
                        return false;
                    }
                }

                // The directory is now empty so delete it
                return dir.Delete();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public static async Task RemoveData(string type)
        {
            try
            {
                if (type == "Logout")
                {
                    if (Methods.CheckConnectivity())
                    {
                        await RequestsAsync.Global.Get_Delete_Token();
                    }
                }
                else if (type == "Delete")
                {
                    Methods.Path.DeleteAll_MyFolder();

                    if (Methods.CheckConnectivity())
                    {
                        await RequestsAsync.Global.Delete_User(UserDetails.Password);
                    }
                }

                try
                {
                    if (AppSettings.ShowGoogleLogin && LoginActivity.MGoogleApiClient != null)
                        if (Auth.GoogleSignInApi != null)
                        {
                            Auth.GoogleSignInApi.SignOut(LoginActivity.MGoogleApiClient);
                            LoginActivity.MGoogleApiClient = null;
                        }

                    if (AppSettings.ShowFacebookLogin)
                    {
                        var accessToken = AccessToken.CurrentAccessToken;
                        var isLoggedIn = accessToken != null && !accessToken.IsExpired;
                        if (isLoggedIn && Profile.CurrentProfile != null)
                        {
                            LoginManager.Instance.LogOut();
                        }
                    }

                    OneSignalNotification.Un_RegisterNotificationDevice();

                    UserDetails.ClearAllValueUserDetails();

                    GC.Collect();
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}