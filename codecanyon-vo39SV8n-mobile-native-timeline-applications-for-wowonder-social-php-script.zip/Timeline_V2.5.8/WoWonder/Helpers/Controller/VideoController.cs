﻿using System;
using System.Collections.Generic;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using Com.Google.Android.Exoplayer2;
using Com.Google.Android.Exoplayer2.Ext.Ima;
using Com.Google.Android.Exoplayer2.Extractor;
using Com.Google.Android.Exoplayer2.Source;
using Com.Google.Android.Exoplayer2.Trackselection;
using Com.Google.Android.Exoplayer2.UI;
using Com.Google.Android.Exoplayer2.Upstream;
using Com.Google.Android.Exoplayer2.Upstream.Cache;
using Com.Google.Android.Exoplayer2.Util;
using Com.Luseen.Autolinklibrary;
using Java.Lang;
using Java.Net;
using Plugin.Share;
using Plugin.Share.Abstractions;
using WoWonder.Activities.Videos;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonder.MediaPlayer;
using WoWonderClient.Classes.Movies;
using Exception = System.Exception;


namespace WoWonder.Helpers.Controller
{
    public class VideoController : Java.Lang.Object, View.IOnClickListener, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private Activity ActivityContext { get; set; }
        private string ActivityName { get; set; }

        public Player Factory;
        private IDataSourceFactory DefaultDatamediaFactory;
        private static SimpleExoPlayer Player { get; set; }

        private ImaAdsLoader ImaAdsLoader;
        private AdsController ImAdsController;
        private PlayerEvents PlayerLitsener;
        private static PlayerView FullscreenplayerView;

        private PlayerView SimpleExoPlayerView;
        private FrameLayout PlayerframeLyout;
        private TextView QualityiconView;
        private TextView ViewsiconView;
        private TextView ShareiconView;
        private TextView MoreiconView;
        private TextView ShowMoreDiscriptioniconView;
        private LinearLayout VideoDescriptionLayout;
        private Button RetryButton;
        private FrameLayout MainvideoFrameLayout;
        private PlayerControlView ControlView;
        private ProgressBar LoadingprogressBar;
        private ImageButton VideoPlayButton;
        private ImageButton VideoResumeButton;

        private ImageView MFullScreenIcon;
        private FrameLayout MFullScreenButton;

       private LinearLayout ShareButton;
        private LinearLayout MoreButton;

        //Dragble video player info
        private TextView VideoTitile;

        private TextView VideoQualityTextView;
        private TextView VideoViewsNumber;
        private TextView VideoVideoDate;
        private AutoLinkTextView VideoVideoDescription;
        private TextView VideoVideoCategory;
        private TextView VideoStars;
        private TextView VideoTag;

        private static ViewGroup AdOverlayViewGroup;
        private static IMediaSource VideoSource;
        private static readonly DefaultBandwidthMeter BandwidthMeter = new DefaultBandwidthMeter();
        private static CookieManager DefaultCookieManager;
        private static Handler MainHandler;
        private static ExctractorMediaListener EventLogger;

        private static int ResumeWindow;
        private static long ResumePosition;

        private TextSanitizer TextSanitizerAutoLink;
        public static VideoDownloadAsyncControler VideoControler;

        public GetMoviesObject.Movie Videodata;

        #endregion

        public VideoController(Activity activity, string activtyName)
        {
            try
            {
                DefaultCookieManager = new CookieManager();
                DefaultCookieManager.SetCookiePolicy(CookiePolicy.AcceptOriginalServer);

                ActivityName = activtyName;
                ActivityContext = activity;

                Initialize();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void Initialize()
        {
            try
            {
                PlayerLitsener = new PlayerEvents(ActivityContext, ControlView);

                if (ActivityName != "FullScreen")
                {
                    SimpleExoPlayerView = ActivityContext.FindViewById<PlayerView>(Resource.Id.player_view);
                    SimpleExoPlayerView.SetControllerVisibilityListener(PlayerLitsener);
                    SimpleExoPlayerView.RequestFocus();

                    //Player initialize
                    ControlView = SimpleExoPlayerView.FindViewById<PlayerControlView>(Resource.Id.exo_controller);
                    PlayerLitsener = new PlayerEvents(ActivityContext, ControlView);

                    MFullScreenIcon = ControlView.FindViewById<ImageView>(Resource.Id.exo_fullscreen_icon);
                    MFullScreenButton = ControlView.FindViewById<FrameLayout>(Resource.Id.exo_fullscreen_button);
                    VideoPlayButton = ControlView.FindViewById<ImageButton>(Resource.Id.exo_play);
                    VideoResumeButton = ControlView.FindViewById<ImageButton>(Resource.Id.exo_pause);

                    MainvideoFrameLayout = ActivityContext.FindViewById<FrameLayout>(Resource.Id.root);
                    MainvideoFrameLayout.SetOnClickListener(this);

                    LoadingprogressBar = ActivityContext.FindViewById<ProgressBar>(Resource.Id.progress_bar);

                    QualityiconView = ActivityContext.FindViewById<TextView>(Resource.Id.Qualityicon);
                    ViewsiconView = ActivityContext.FindViewById<TextView>(Resource.Id.Viewsicon);
                    ShareiconView = ActivityContext.FindViewById<TextView>(Resource.Id.Shareicon);
                    MoreiconView = ActivityContext.FindViewById<TextView>(Resource.Id.Moreicon);
                    ShowMoreDiscriptioniconView =ActivityContext.FindViewById<TextView>(Resource.Id.video_ShowDiscription);
                    VideoDescriptionLayout =ActivityContext.FindViewById<LinearLayout>(Resource.Id.videoDescriptionLayout);
                    
                    ShareButton = ActivityContext.FindViewById<LinearLayout>(Resource.Id.ShareButton);
                    ShareButton.Click += ShareIcon_Click;

                    MoreButton = ActivityContext.FindViewById<LinearLayout>(Resource.Id.moreButton);
                    MoreButton.Click += MoreButton_OnClick;

                    VideoTitile = ActivityContext.FindViewById<TextView>(Resource.Id.video_Titile);
                    VideoQualityTextView = ActivityContext.FindViewById<TextView>(Resource.Id.QualityTextView);
                    VideoViewsNumber = ActivityContext.FindViewById<TextView>(Resource.Id.ViewsNumber);
                    VideoVideoDate = ActivityContext.FindViewById<TextView>(Resource.Id.videoDate);
                    VideoVideoDescription =ActivityContext.FindViewById<AutoLinkTextView>(Resource.Id.videoDescriptionTextview);
                    VideoVideoCategory = ActivityContext.FindViewById<TextView>(Resource.Id.videoCategorytextview);

                    VideoStars = ActivityContext.FindViewById<TextView>(Resource.Id.videoStarstextview);
                    VideoTag   = ActivityContext.FindViewById<TextView>(Resource.Id.videoTagtextview);

                    TextSanitizerAutoLink = new TextSanitizer(VideoVideoDescription, ActivityContext);

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, QualityiconView, IonIconsFonts.RibbonA);
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, ViewsiconView, IonIconsFonts.Eye);
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, ShareiconView, IonIconsFonts.ReplyAll);
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, MoreiconView, IonIconsFonts.PlusCircled);
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, ShowMoreDiscriptioniconView, IonIconsFonts.ArrowDownB);
                     
                    ShowMoreDiscriptioniconView.Visibility = ViewStates.Gone;

                    VideoDescriptionLayout.Visibility = ViewStates.Visible;

                    if (!MFullScreenButton.HasOnClickListeners)
                        MFullScreenButton.SetOnClickListener(this);
                }
                else
                {
                    FullscreenplayerView = ActivityContext.FindViewById<PlayerView>(Resource.Id.player_view2);
                    ControlView = FullscreenplayerView.FindViewById<PlayerControlView>(Resource.Id.exo_controller);
                    PlayerLitsener = new PlayerEvents(ActivityContext, ControlView);
                   
                    MFullScreenIcon = ControlView.FindViewById<ImageView>(Resource.Id.exo_fullscreen_icon);
                    MFullScreenButton = ControlView.FindViewById<FrameLayout>(Resource.Id.exo_fullscreen_button);
                    VideoPlayButton = ControlView.FindViewById<ImageButton>(Resource.Id.exo_play);
                    VideoResumeButton = ControlView.FindViewById<ImageButton>(Resource.Id.exo_pause);

                    if (!MFullScreenButton.HasOnClickListeners)
                        MFullScreenButton.SetOnClickListener(this);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

       
        public void PlayVideo(string videoUrL, GetMoviesObject.Movie videoObject)
        {
            try
            {
                if (videoObject != null)
                {
                    Videodata = videoObject;

                    LoadVideo_Data(videoObject);

                    ReleaseVideo();

                    MFullScreenIcon.SetImageDrawable(ActivityContext.GetDrawable(Resource.Drawable.ic_action_ic_fullscreen_expand));

                    Android.Net.Uri videoUrl;
                    if (!string.IsNullOrEmpty(videoUrL))
                    {
                        videoUrl = Android.Net.Uri.Parse(videoUrL);
                    }
                    else
                    {
                        videoUrl = Android.Net.Uri.Parse(Videodata.Source);
                    }

                    MainHandler = new Handler();

                    AdaptiveTrackSelection.Factory videoTrackSelectionFactory =new AdaptiveTrackSelection.Factory(BandwidthMeter);
                    DefaultTrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);

                    Player = ExoPlayerFactory.NewSimpleInstance(ActivityContext, trackSelector);
                    DefaultDatamediaFactory = new DefaultDataSourceFactory(ActivityContext,Util.GetUserAgent(ActivityContext, AppSettings.ApplicationName), BandwidthMeter);

                    // Produces DataSource instances through which media data is loaded.
                    ExtractorMediaSource defaultSource = new ExtractorMediaSource(videoUrl, DefaultDatamediaFactory,new DefaultExtractorsFactory(), MainHandler, EventLogger);

                    VideoSource = null;

                    //Set Interactive Media Ads 
                    if (PlayerSettings.ShowInteractiveMediaAds)
                        VideoSource = CreateAdsMediaSource(defaultSource, PlayerSettings.ImAdsUri);

                    if (SimpleExoPlayerView == null)
                        Initialize();

                    //Set Cache Media Load
                    if (PlayerSettings.EnableOfflineMode)
                    {
                        VideoSource = VideoSource == null? CreateCacheMediaSource(defaultSource, videoUrl): CreateCacheMediaSource(VideoSource, videoUrl);
                        if (VideoSource != null)
                        {
                            SimpleExoPlayerView.Player = Player;
                            Player.Prepare(VideoSource);
                            Player.AddListener(PlayerLitsener);
                            Player.PlayWhenReady = true;

                            bool haveResumePosition = ResumeWindow != C.IndexUnset;
                            if (haveResumePosition)
                                Player.SeekTo(ResumeWindow, ResumePosition);

                            return;
                        }
                    }

                    if (VideoSource == null)
                    {
                        if (!string.IsNullOrEmpty(videoUrL))
                        {
                            if (videoUrL.Contains("youtube") || videoUrL.Contains("Youtube") || videoUrL.Contains("youtu"))
                            {
                                //Task.Run(async () =>
                                //{
                                //    var newurl = await VideoInfoRetriever.GetEmbededVideo(Videodata.source);
                                //    videoSource = CreateDefaultMediaSource(Android.Net.Uri.Parse(newurl));
                                //});
                            }
                            else
                            {
                                VideoSource = CreateDefaultMediaSource(Android.Net.Uri.Parse(videoUrL));

                                SimpleExoPlayerView.Player = Player;
                                Player.Prepare(VideoSource);
                                Player.AddListener(PlayerLitsener);
                                Player.PlayWhenReady = true;

                                bool haveResumePosition = ResumeWindow != C.IndexUnset;
                                if (haveResumePosition)
                                    Player.SeekTo(ResumeWindow, ResumePosition);
                            }
                        }
                    }
                    else
                    {
                        SimpleExoPlayerView.Player = Player;
                        Player.Prepare(VideoSource);
                        Player.AddListener(PlayerLitsener);
                        Player.PlayWhenReady = true;

                        bool haveResumePosition = ResumeWindow != C.IndexUnset;
                        if (haveResumePosition)
                            Player.SeekTo(ResumeWindow, ResumePosition);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void ReleaseVideo()
        {
            try
            {
                if (Player != null)
                {
                    Player?.Release();
                    Player = null;

                    //GC Collecter
                    GC.Collect();
                }

                
                VideoDescriptionLayout.Visibility = ViewStates.Visible;
                
                if (Videodata != null)
                {
                    VideoTitile.Text = Videodata.Name;
                }

                SimpleExoPlayerView.Player = null;

             }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void SetStopvideo()
        {
            try
            {
                if (SimpleExoPlayerView.Player != null)
                {
                    if (SimpleExoPlayerView.Player.PlaybackState == Com.Google.Android.Exoplayer2.Player.StateReady)
                    {
                        SimpleExoPlayerView.Player.PlayWhenReady = false;
                    }

                    //GC Collecter
                    GC.Collect();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void LoadVideo_Data(GetMoviesObject.Movie videoObject)
        {
            try
            {
                if (videoObject != null)
                {
                    VideoTitile.Text = videoObject.Name;

                    VideoQualityTextView.Text = videoObject.Quality.ToUpperInvariant(); 
                    VideoViewsNumber.Text = videoObject.Views + " " + ActivityContext.GetText(Resource.String.Lbl_Views);
                    VideoVideoDate.Text = ActivityContext.GetText(Resource.String.Lbl_Published_on) + " " + videoObject.Release;
                    VideoVideoDescription.Text = Methods.FunString.DecodeString(videoObject.Description);
                    VideoVideoCategory.Text = videoObject.Genre;
                    VideoStars.Text = videoObject.Stars;
                    VideoTag.Text = videoObject.Producer;
                    
                    TextSanitizerAutoLink.Load(videoObject.Description);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Video player

        public IMediaSource CreateCacheMediaSource(IMediaSource videoSource, Android.Net.Uri videoUrL)
        {
            try
            {
                if (PlayerSettings.EnableOfflineMode)
                {
                    //Set the video for offline mode 
                    if (!string.IsNullOrEmpty(Videodata.Id))
                    {
                        string file = VideoDownloadAsyncControler.GetDownloadedDiskVideoUri(Videodata.Id);

                        SimpleCache cache = new SimpleCache(ActivityContext.CacheDir,new LeastRecentlyUsedCacheEvictor(1024 * 1024 * 10));
                        CacheDataSourceFactory cacheDataSource =new CacheDataSourceFactory(cache, DefaultDatamediaFactory);

                        if (file != null)
                        {
                            videoUrL = Android.Net.Uri.Parse(file);
                            videoSource = new ExtractorMediaSource(videoUrL, cacheDataSource,new DefaultExtractorsFactory(), MainHandler, EventLogger);
                            return videoSource;
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public IMediaSource CreateAdsMediaSource(IMediaSource mediaSource, Android.Net.Uri adTagUri)
        {
            if (ImaAdsLoader == null)
            {
                ImaAdsLoader = new ImaAdsLoader(ActivityContext, adTagUri);
                AdOverlayViewGroup = new FrameLayout(ActivityContext);
                SimpleExoPlayerView.OverlayFrameLayout.AddView(AdOverlayViewGroup);
                AdsController cont = new AdsController(ActivityContext);
            }
            return new ImaAdsMediaSource(mediaSource, DefaultDatamediaFactory, ImaAdsLoader, AdOverlayViewGroup);
        }

        public IMediaSource CreateDefaultMediaSource(Android.Net.Uri videoUrL)
        {
            try
            {
                if (videoUrL != null)
                {
                    ExtractorMediaSource defaultSource = new ExtractorMediaSource(videoUrL, DefaultDatamediaFactory,new DefaultExtractorsFactory(), MainHandler, EventLogger);

                    ActivityContext.RunOnUiThread(() =>
                    {
                        if (SimpleExoPlayerView != null)
                        {
                            SimpleExoPlayerView.Player = Player;
                            Player.Prepare(VideoSource);
                            Player.AddListener(PlayerLitsener);
                            Player.PlayWhenReady = true;
                        }
                        else
                        {
                            Initialize();
                            SimpleExoPlayerView.Player = Player;
                            Player.Prepare(VideoSource);
                            Player.AddListener(PlayerLitsener);
                            Player.PlayWhenReady = true;
                        }

                        bool haveResumePosition = ResumeWindow != C.IndexUnset;
                        if (haveResumePosition)
                        {
                            Player.SeekTo(ResumeWindow, ResumePosition);
                        }
                    });
                    return defaultSource;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public void OnClick(View v)
        {
            try
            {
                if (v.Id == MFullScreenIcon.Id || v.Id == MFullScreenButton.Id)
                {
                    InitFullscreenDialog();
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void ReleaseAdsLoader()
        {
            try
            {
                if (ImaAdsLoader != null)
                {
                    ImaAdsLoader.Release();
                    ImaAdsLoader = null;
                    SimpleExoPlayerView.OverlayFrameLayout.RemoveAllViews();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void PlayerStateChanged(bool playWhenReady, int playbackState)
        {
            try
            {
                if (playbackState == Com.Google.Android.Exoplayer2.Player.StateEnded)
                {
                    if (playWhenReady == false)
                    {
                        VideoResumeButton.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        VideoResumeButton.Visibility = ViewStates.Gone;
                        VideoPlayButton.Visibility = ViewStates.Visible;

                    }

                    LoadingprogressBar.Visibility = ViewStates.Invisible;
                }
                else if (playbackState == Com.Google.Android.Exoplayer2.Player.StateReady)
                {
                    if (playWhenReady == false)
                    {
                        VideoResumeButton.Visibility = ViewStates.Gone;
                        VideoPlayButton.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        VideoResumeButton.Visibility = ViewStates.Visible;
                    }

                    LoadingprogressBar.Visibility = ViewStates.Invisible;
                }
                else if (playbackState == Com.Google.Android.Exoplayer2.Player.StateBuffering)
                {
                    LoadingprogressBar.Visibility = ViewStates.Visible;
                    VideoResumeButton.Visibility = ViewStates.Invisible;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void RestartPlayAfterShrinkScreen()
        {
            try
            {
                SimpleExoPlayerView.Player = null;
                SimpleExoPlayerView.Player = Player;
                SimpleExoPlayerView.Player.PlayWhenReady = true;
                MFullScreenIcon.SetImageDrawable(ActivityContext.GetDrawable(Resource.Drawable.ic_action_ic_fullscreen_expand));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void PlayFullScreen()
        {
            try
            {
                if (FullscreenplayerView != null)
                {
                    Player?.AddListener(PlayerLitsener);
                    FullscreenplayerView.Player = Player;
                    if (FullscreenplayerView.Player != null) FullscreenplayerView.Player.PlayWhenReady = true;
                    MFullScreenIcon.SetImageDrawable(ActivityContext.GetDrawable(Resource.Drawable.ic_action_ic_fullscreen_skrink));
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Event 
         
        //Full Screen
        public void InitFullscreenDialog(string action = "Open")
        {
            try
            {
                if (ActivityName != "FullScreen" && action == "Open")
                {
                    Intent intent = new Intent(ActivityContext, typeof(FullScreenVideoActivity));
                    //intent.PutExtra("Downloaded", DownloadIcon.Tag.ToString());
                    intent.PutExtra("Type", "Movies");
                    ActivityContext.StartActivityForResult(intent, 2000);
                }
                else
                {
                    Intent intent = new Intent();
                    ActivityContext.SetResult(Result.Ok, intent);
                    ActivityContext.Finish();
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        //Menu More >>  
        public void MoreButton_OnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(ActivityContext);

                arrayAdapter.Add(ActivityContext.GetString(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(ActivityContext.GetString(Resource.String.Lbl_Share));

                dialogList.Title(ActivityContext.GetString(Resource.String.Lbl_More));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(ActivityContext.GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
                 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Menu >> Share
        public async void OnMenu_ShareIcon_Click(GetMoviesObject.Movie video)
        {
            try
            {
                //Share Plugin same as flame
                if (!CrossShare.IsSupported)
                {
                    return;
                }

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = Videodata.Name,
                    Text = Videodata.Description,
                    Url = Videodata.Url
                });
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Menu >> Cope Link
        public void OnMenu_CopeLink_Click(GetMoviesObject.Movie video)
        {
            try
            {
                var clipboardManager = (ClipboardManager)ActivityContext.GetSystemService(Context.ClipboardService);

                ClipData clipData = ClipData.NewPlainText("text", video.Url);
                clipboardManager.PrimaryClip = clipData;

                Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Share
        public  void ShareIcon_Click(object sender, EventArgs e)
        {
            try
            {
                OnMenu_ShareIcon_Click(Videodata);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Download
        public void Download_icon_Click(object sender, EventArgs e)
        {
            try
            {
                //if (DownloadIcon.Tag.ToString() == "false")
                //{
                //    DownloadIcon.SetImageDrawable(ActivityContext.GetDrawable(Resource.Drawable.ic_action_download_stop));
                //    DownloadIcon.Tag = "true";

                //    string urlVideo = string.Empty;
                //    if (Videodata.Source.Contains("youtube") || Videodata.Source.Contains("Youtube") || Videodata.Source.Contains("youtu"))
                //    {
                //        //urlVideo = VideoInfoRetriever.VideoDownloadstring;
                //        if (!string.IsNullOrEmpty(urlVideo))
                //        {
                //            VideoControler = new VideoDownloadAsyncControler(urlVideo, Videodata.Source, ActivityContext);
                //            if (!VideoControler.CheckDownloadLinkIfExits())
                //                VideoControler.StartDownloadManager(Videodata.Name, Videodata);
                //        }
                //        else
                //        {
                //            Methods.DialogPopup.InvokeAndShowDialog(ActivityContext, ActivityContext.GetString(Resource.String.Lbl_Error), ActivityContext.GetString(Resource.String.Lbl_You_can_not_Download_video), ActivityContext.GetString(Resource.String.Lbl_Ok));
                //        }
                //    }
                //    else
                //    {
                //        urlVideo = Videodata.Source;

                //        VideoControler = new VideoDownloadAsyncControler(urlVideo, Videodata.Id, ActivityContext);
                //        if (!VideoControler.CheckDownloadLinkIfExits())
                //            VideoControler.StartDownloadManager(Videodata.Name, Videodata);
                //    }
                //}
                //else if (DownloadIcon.Tag.ToString() == "Downloaded")
                //{
                //    try
                //    {
                //        AlertDialog.Builder builder = new AlertDialog.Builder(ActivityContext);
                //        builder.SetTitle(ActivityContext.GetString(Resource.String.Lbl_Delete_video));
                //        builder.SetMessage(ActivityContext.GetString(Resource.String.Lbl_Do_You_want_to_remove_video));

                //        builder.SetPositiveButton(ActivityContext.GetString(Resource.String.Lbl_Yes), delegate (object o, DialogClickEventArgs args)
                //        {
                //            try
                //            {
                //                VideoDownloadAsyncControler.RemoveDiskVideoFile(Videodata.Id + ".mp4");
                //                DownloadIcon.SetImageDrawable(ActivityContext.GetDrawable(Resource.Drawable.ic_action_download));
                //                DownloadIcon.Tag = "false";
                //            }
                //            catch (Exception exception)
                //            {
                //                Console.WriteLine(exception);
                //            }
                //        });

                //        builder.SetNegativeButton(ActivityContext.GetString(Resource.String.Lbl_No), delegate (object o, DialogClickEventArgs args)
                //        {

                //        });

                //        var alert = builder.Create();
                //        alert.Show();
                //    }
                //    catch (Exception exception)
                //    {
                //        Console.WriteLine(exception);
                //    }
                //}
                //else
                //{
                //    DownloadIcon.SetImageDrawable(ActivityContext.GetDrawable(Resource.Drawable.ic_action_download));
                //    DownloadIcon.Tag = "false";
                //    VideoControler.StopDownloadManager();
                //}
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Back
        public void BackIcon_Click(object sender, EventArgs e)
        {
            try
            {
                if (ActivityName == "FullScreen")
                {
                    Intent intent = new Intent();
                    ActivityContext.SetResult(Result.Ok, intent);
                    ActivityContext.Finish();
                }
                else if (ActivityName == "Viewer_Video")
                {
                    ReleaseVideo();
                    ActivityContext.Finish();
                }
                SetStopvideo();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == ActivityContext.GetString(Resource.String.Lbl_CopeLink))
                {
                    OnMenu_CopeLink_Click(Videodata);
                }
                else if (text == ActivityContext.GetString(Resource.String.Lbl_Share))
                {
                    OnMenu_ShareIcon_Click(Videodata);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
    }
}