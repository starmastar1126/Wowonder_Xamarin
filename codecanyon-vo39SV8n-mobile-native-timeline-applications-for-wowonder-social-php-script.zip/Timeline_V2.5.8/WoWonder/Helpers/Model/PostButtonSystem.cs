﻿namespace WoWonder.Helpers.Model
{
    public enum PostButtonSystem
    {
        Wonder,
        DisLike,
        Like,
        Reaction
    }
}