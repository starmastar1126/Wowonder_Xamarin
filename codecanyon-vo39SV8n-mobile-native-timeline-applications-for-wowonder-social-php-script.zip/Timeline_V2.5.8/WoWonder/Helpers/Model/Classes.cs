﻿using System.Collections.Generic;

namespace WoWonder.Helpers.Model
{ 
    public class Classes
    {  
        public class PostType
        {
            public int Id { get; set; }
            public string TypeText { get; set; }
            public int Image { get; set; }
            public string ImageColor { get; set; }
        }
        
        public class Categories
        {
            public string CategoriesId { get; set; }
            public string CategoriesName { get; set; }
            public string CategoriesColor { get; set; }
        }

        public class Family
        {
            public string FamilyId { get; set; }
            public string FamilyName { get; set; }
        }
         
        public class Geocoding
        {
            public class AddressComponent
            {
                public string LongName { get; set; }
                public string ShortName { get; set; }
                public List<string> Types { get; set; }
            }

            public class Location
            {
                public double Lat { get; set; }
                public double Lng { get; set; }
            }

            public class Northeast
            {
                public double Lat { get; set; }
                public double Lng { get; set; }
            }

            public class Southwest
            {
                public double Lat { get; set; }
                public double Lng { get; set; }
            }

            public class Viewport
            {
                public Northeast Northeast { get; set; }
                public Southwest Southwest { get; set; }
            }

            public class Geometry
            {
                public Location Location { get; set; }
                public string LocationType { get; set; }
                public Viewport Viewport { get; set; }
            }

            public class Result
            {
                public List<AddressComponent> AddressComponents { get; set; }
                public string FormattedAddress { get; set; }
                public Geometry Geometry { get; set; }
                public string PlaceId { get; set; }
                public List<string> Types { get; set; }
            }

            public class GeoClass
            {
                public List<Result> Results { get; set; }
                public string Status { get; set; }
            }
        }
    }
} 