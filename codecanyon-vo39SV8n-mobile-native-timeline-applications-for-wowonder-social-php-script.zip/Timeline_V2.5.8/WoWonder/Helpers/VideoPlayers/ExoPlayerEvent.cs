﻿using System;
using Android.Views;
using Android.Widget;
using Com.Google.Android.Exoplayer2;
using Com.Google.Android.Exoplayer2.Source;
using Com.Google.Android.Exoplayer2.Trackselection;
using Com.Google.Android.Exoplayer2.UI;
using Object = Java.Lang.Object;

namespace WoWonder.Helpers.VideoPlayers
{
    public abstract class ExoPlayerEvent :Object, IPlayerEventListener, PlaybackControlView.IVisibilityListener
    {
        private View ActContext;
        private readonly ProgressBar LoadingProgressBar;
        private readonly ImageButton VideoPlayButton;
        private readonly ImageButton VideoResumeButton;

        public ExoPlayerEvent(View context, PlayerControlView controlView)
        {
            ActContext = context;

            if (controlView == null) return;

            VideoPlayButton = controlView.FindViewById<ImageButton>(Resource.Id.exo_play);
            VideoResumeButton = controlView.FindViewById<ImageButton>(Resource.Id.exo_pause);
            LoadingProgressBar = context.FindViewById<ProgressBar>(Resource.Id.progress_bar);
        }

        public void OnLoadingChanged(bool p0)
        {

        }

        public void OnPlaybackParametersChanged(PlaybackParameters p0)
        {

        }

        public void OnPlayerError(ExoPlaybackException p0)
        {

        }

        public void OnPlayerStateChanged(bool playWhenReady, int playbackState)
        {
            try
            {
                if (VideoResumeButton == null || VideoPlayButton == null || LoadingProgressBar == null)
                    return;

                if (playbackState == Player.StateEnded)
                {
                    if (playWhenReady == false)
                        VideoResumeButton.Visibility = ViewStates.Visible;
                    else
                    {
                        VideoResumeButton.Visibility = ViewStates.Gone;
                        VideoPlayButton.Visibility = ViewStates.Visible;
                    }

                    LoadingProgressBar.Visibility = ViewStates.Invisible;
                }
                else if (playbackState == Player.StateReady)
                {
                    if (playWhenReady == false)
                    {
                        VideoResumeButton.Visibility = ViewStates.Gone;
                        VideoPlayButton.Visibility = ViewStates.Visible;
                    }
                    else
                        VideoResumeButton.Visibility = ViewStates.Visible;
                

                    LoadingProgressBar.Visibility = ViewStates.Invisible;
                }
                else if (playbackState == Player.StateBuffering)
                {
                    LoadingProgressBar.Visibility = ViewStates.Visible;
                    VideoResumeButton.Visibility = ViewStates.Invisible;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void OnPositionDiscontinuity(int p0)
        {

        }

        public void OnRepeatModeChanged(int p0)
        {

        }

        public void OnSeekProcessed()
        {

        }

        public void OnShuffleModeEnabledChanged(bool p0)
        {

        }

        public void OnTimelineChanged(Timeline p0, Object p1, int p2)
        {

        }

        public void OnTracksChanged(TrackGroupArray p0, TrackSelectionArray p1)
        {

        }

        public void OnVisibilityChange(int p0)
        {

        }
    }
}