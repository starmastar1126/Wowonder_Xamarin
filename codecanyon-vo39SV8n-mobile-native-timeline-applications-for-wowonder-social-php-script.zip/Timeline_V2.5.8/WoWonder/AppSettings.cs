﻿//##############################################

//Cᴏᴘʏʀɪɢʜᴛ 2018 DᴏᴜɢʜᴏᴜᴢLɪɢʜᴛ Codecanyon Item 19703216
//Elin Doughouz >> https://www.facebook.com/Elindoughous
//====================================================

using WoWonder.Helpers.Model;

namespace WoWonder
{
    public static class AppSettings
    {
        public static string TripleDesAppServiceProvider = "SAWyNC/l4GDUn+TMe93hLr3fMP1KY0GMyRoJmLciRCO2RWHfny+y+Ir5zNxgBkjleUEBAy/eA+E+4dPOsuNXYQ3B78SeZn685HOGOaiOX+rNqyI1Q7ru0teoPR5oYF5xrlV1YY3+PQTckjDJ/R2Gey6E5ylYSVGbw3R0trDC5a/2wpCjdFusdfDT5G4f48tY8SaoO1AxTjqhWwnHs/kP0wYTMWitqbb2fRA5w5cKezm36VWmQTFuDm5KvW9XusPF8vJC6C5k9XyTiLFDUHN/YA==";

        //Main Settings >>>>>
        //*********************************************************

        public static string Version = "2.5";
        public static string ApplicationName = "wowonder Timeline";
        public static string YoutubeKey = "AIzaSyA-JSf9CU1cdMpgzROCCUpl4wOve9S94ZU";

        // Friend system = 0 , follow system = 1
        public static int ConnectivitySystem = 1;

        public static PostButtonSystem PostButton = PostButtonSystem.Reaction;

        public static bool ShowTextShareButton = true; //#New 

        //Main Colors >>
        //*********************************************************
        public static string MainColor = "#a84849";

        //Language Settings >> http://www.lingoes.net/en/translator/langcode.htm
        //*********************************************************
        public static bool FlowDirectionRightToLeft = false;
        public static string Lang = ""; //Default language ar_AE

        //Notification Settings >>
        //*********************************************************
        public static bool ShowNotification = true;
        public static string OneSignalAppId = "0eded64f-651e-472b-ac5a-69ecd785a94f";

        // WalkThrough Settings >>
        //*********************************************************
        public static bool ShowWalkTroutPage = true;
        public static bool WalkThroughSetFlowAnimation = true;
        public static bool WalkThroughSetZoomAnimation = false;
        public static bool WalkThroughSetSlideOverAnimation = false;
        public static bool WalkThroughSetDepthAnimation = false;
        public static bool WalkThroughSetFadeAnimation = false;

        //Main Messenger settings
        //*********************************************************
        public static bool MessengerIntegration = false;
        public static string MessengerPackageName = "com.wowonderandroid.messenger"; //APK name on Google Play

        //ADMOB >> Please add the code ad in the Here and analytic.xml 
        //*********************************************************
        public static bool ShowAdmobBanner = false;
        public static bool ShowAdmobInterstitial = false;
        public static bool ShowAdmobRewardVideo = false;
        public static bool ShowAdmobNative = false;//#New

        public static string AdInterstitialKey = "ca-app-pub-5135691635931982/3584502890";
        public static string AdRewardVideoKey = "ca-app-pub-5135691635931982/2518408206";
        public static string AdAdmobNativeKey = "ca-app-pub-5135691635931982/2280543246";//#New

        //Three times after entering the ad is displayed
        public static int ShowAdmobInterstitialCount = 3;
        public static int ShowAdmobRewardedVideoCount = 3;
        public static int ShowAdmobNativCount = 10;

        //*********************************************************

        //Set Theme Welcome Pages 
        //*********************************************************
        //Types >> Gradient or Video or Image
        public static string BackgroundScreenWelcomeType = "Image";

        //Set Theme Full Screen App
        //*********************************************************
        public static bool EnableFullScreenApp = false;

        //Code Time Zone (true => Get from Internet , false => Get From #CodeTimeZone )
        //*********************************************************
        public static bool AutoCodeTimeZone = true; //#New
        public static string CodeTimeZone = "UTC";//#New

        //Social Logins >>
        //If you want login with facebook or google you should change id key in the analytic.xml file or AndroidManifest.xml
        //Facebook >> ../values/analytic.xml .. 
        //Google >> ../Properties/AndroidManifest.xml .. line 43 
        //*********************************************************
        public static bool ShowFacebookLogin = false;
        public static bool ShowGoogleLogin = false;

        public static readonly string ClientId = "430795656343-4vbnu62jjv7olvmk4jrptv0q0it7ee6m.apps.googleusercontent.com";
        public static readonly string ClientSecret = "xuTYDJwOivWG3qNhsYFOZ2jB";
        //########################### 
         
        //Main Slider settings
        //*********************************************************
        public static bool ShowAlbum = true;
        public static bool ShowArticles = true;
        public static bool ShowPokes = true; //#New
        public static bool ShowCommunitiesGroups = true;
        public static bool ShowCommunitiesPages = true;
        public static bool ShowEvents = true;
        public static bool ShowMarket = true;
        public static bool ShowPopularPosts = true;//#New
        public static bool ShowMovies = true;
        public static bool ShowNearBy = true;
        public static bool ShowStory = true;
        public static bool ShowSavedPost = true;
        public static bool ShowUserContacts = true; // Follow or Friend System

        //Native Post settings
        //*********************************************************
        public static int AvatarPostSize = 60; //#New
        public static int ImagePostSize = 200; //#New 
        public static string PostApiLimitOnScroll = "15";

        public static bool EmbedPlayTubePostType = true; //#New
        public static bool EmbedDeepSoundPostType = true; //#New
        public static bool EmbedFacebookVideoPostType = true; //#New

        public static bool ShowFullScreenVideoPost = true; //#New

        //Error Report Mode
        //*********************************************************
        public static bool SetApisReportMode = false;//#New

        //UsersPages
        public static bool ShowProUsersMembers = true;
        public static bool ShowPromotedPages = true;
        public static bool ShowTrendingHashTags = true;
        public static bool ShowLastActivities = true;

        public static bool ShowUserPoint = true;//#New

        //Add Post
        public static bool ShowGalleryImage = true;
        public static bool ShowGalleryVideo = true;
        public static bool ShowMention = true;
        public static bool ShowLocation = true;
        public static bool ShowFeelingActivity = true;
        public static bool ShowFeeling = true;
        public static bool ShowListening = true;
        public static bool ShowPlaying = true;
        public static bool ShowWatching = true;
        public static bool ShowTraveling = true;
        public static bool ShowCamera = true;
        public static bool ShowGif = true;
        public static bool ShowFile = true;
        public static bool ShowMusic = true;
        public static bool ShowPolls = false;
        public static bool ShowColor = true; //#New

        //Settings Page >> General Account
        public static bool ShowSettingsGeneralAccount = true;

        public static bool ShowSettingsAccount = true;
        public static bool ShowSettingsSocialLinks = true;
        public static bool ShowSettingsPassword = true;
        public static bool ShowSettingsBlockedUsers = true;
        public static bool ShowSettingsDeleteAccount = true;

        //Settings Page >> Privacy
        public static bool ShowSettingsPrivacy = true;
        public static bool ShowSettingsNotification = true;

        //Settings Page >> Tell a Friends 
        public static bool ShowSettingsInviteFriends = true;


        public static bool ShowSettingsShare = true;
        public static bool ShowSettingsMyAffiliates = true;

        //Settings Page >> Help && Support
        public static bool ShowSettingsHelpSupport = true;

        public static bool ShowSettingsHelp = true;
        public static bool ShowSettingsReportProblem = true;
        public static bool ShowSettingsAbout = true;
        public static bool ShowSettingsPrivacyPolicy = true;
        public static bool ShowSettingsTermsOfUse = true;

        public static bool ShowSuggestedUsersOnRegister = true;

        public static bool ImageCropping = true; //#New

        //Set Theme Tab
        //*********************************************************
        public static bool SetTabColoredTheme = false;
        public static bool SetTabDarkTheme = false;

        public static readonly string TabColoredColor = MainColor;
        public static bool SetTabOnButton = true;
        public static bool SetTabIsTitledWithText = false;

        //Bypass Web Errors  
        //*********************************************************
        public static bool TurnTrustFailureOnWebException = false;
        public static bool TurnSecurityProtocolType3072On = false;

        //*********************************************************
        public static bool RenderPriorityFastPostLoad = false;
    }
}
