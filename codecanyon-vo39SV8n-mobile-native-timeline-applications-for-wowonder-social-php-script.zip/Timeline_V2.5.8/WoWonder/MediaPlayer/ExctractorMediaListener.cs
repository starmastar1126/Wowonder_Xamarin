﻿using Com.Google.Android.Exoplayer2.Source;
using Java.IO;

namespace WoWonder.MediaPlayer
{
    public class ExctractorMediaListener : Java.Lang.Object, ExtractorMediaSource.IEventListener
    {
        public void Dispose()
        {

        }

        public void OnLoadError(IOException p0)
        {

        }
    }
}