﻿using System;
using System.Collections.ObjectModel;
using Android.App;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;

namespace WoWonder.Adapters
{
    public class CategoriesAdapter : RecyclerView.Adapter
    {
        
        public Activity ActivityContext;

        public ObservableCollection<Classes.Categories>
            MCategoriesList = new ObservableCollection<Classes.Categories>();

        public CategoriesAdapter(Activity context)
        {
            try
            {
                ActivityContext = context;
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (MCategoriesList != null)
                    return MCategoriesList.Count;
                return 0;
            }
        }

        public event EventHandler<CategoriesAdapterClickEventArgs> ItemClick;
        public event EventHandler<CategoriesAdapterClickEventArgs> ItemLongClick;

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Categories_View
                var itemView = LayoutInflater.From(parent.Context)
                    .Inflate(Resource.Layout.Style_Categories_View, parent, false);
                var vh = new CategoriesAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder is CategoriesAdapterViewHolder holder)
                {
                    var item = MCategoriesList[position];
                    if (item != null)
                    {
                        holder.Button.Text = item.CategoriesName;

                        holder.Button.SetBackgroundResource(item.CategoriesColor == AppSettings.MainColor ? Resource.Drawable.follow_button_profile_friends : Resource.Drawable.Categories_button);
                        holder.Button.SetTextColor(Color.ParseColor(item.CategoriesColor)); 
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        public Classes.Categories GetItem(int position)
        {
            return MCategoriesList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(CategoriesAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(CategoriesAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
    }

    public class CategoriesAdapterViewHolder : RecyclerView.ViewHolder
    {
        public CategoriesAdapterViewHolder(View itemView, Action<CategoriesAdapterClickEventArgs> clickListener,
            Action<CategoriesAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                Button = MainView.FindViewById<Button>(Resource.Id.cont);

                //Create an Event
                itemView.Click += (sender, e) => clickListener(new CategoriesAdapterClickEventArgs{View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new CategoriesAdapterClickEventArgs{View = itemView, Position = AdapterPosition});

                //Don't Remove this code #####
                FontUtils.SetFont(Button, Fonts.SfRegular);
                //#####
                Button.SetTextColor(Color.ParseColor("#efefef"));
            } 
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        public View MainView { get; }

        

        public Button Button { get; set; }

        #endregion
    }

    public class CategoriesAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}