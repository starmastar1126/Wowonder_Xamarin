using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using SQLite;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.Library.OneSignal;
using WoWonderClient;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Movies;
using Exception = System.Exception;

namespace WoWonder.SQLite
{
    public class SqLiteDatabase : IDisposable
    {
        //############# DON'T MODIFY HERE #############
        public static string Folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
        public static string PathCombine = Path.Combine(Folder, "WowonderSocial.db");
        public SQLiteConnection Connection;

        //Open Connection in Database
        //*********************************************************

        #region Connection

        public void OpenConnection()
        {
            try
            {
                Connection = new SQLiteConnection(PathCombine);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void CheckTablesStatus()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    OpenConnection();

                    Connection?.CreateTable<DataTables.LoginTb>();
                    Connection?.CreateTable<DataTables.MyContactsTb>();
                    Connection?.CreateTable<DataTables.MyFollowersTb>();
                    Connection?.CreateTable<DataTables.MyProfileTb>();
                    Connection?.CreateTable<DataTables.SearchFilterTb>();
                    Connection?.CreateTable<DataTables.NearByFilterTb>();
                    Connection?.CreateTable<DataTables.WatchOfflineVideosTb>();
                    Connection?.CreateTable<DataTables.SettingsTb>();
                    Connection?.CreateTable<DataTables.GiftsTb>();

                    Connection?.Dispose();
                    Connection?.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Close Connection in Database
        public void Dispose()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection?.Dispose();
                    Connection?.Close();
                    GC.SuppressFinalize(this);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void DeleteDatabase()
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(Folder);

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public void ClearAll()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection.DeleteAll<DataTables.LoginTb>();
                    Connection.DeleteAll<DataTables.MyContactsTb>();
                    Connection.DeleteAll<DataTables.MyFollowersTb>();
                    Connection.DeleteAll<DataTables.MyProfileTb>();
                    Connection.DeleteAll<DataTables.SearchFilterTb>();
                    Connection.DeleteAll<DataTables.NearByFilterTb>();
                    Connection.DeleteAll<DataTables.WatchOfflineVideosTb>();
                    Connection.DeleteAll<DataTables.SettingsTb>();
                    Connection.DeleteAll<DataTables.GiftsTb>();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Delete table 
        public void DropAll()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection.DropTable<DataTables.LoginTb>();
                    Connection.DropTable<DataTables.MyContactsTb>();
                    Connection.DropTable<DataTables.MyFollowersTb>();
                    Connection.DropTable<DataTables.MyProfileTb>();
                    Connection.DropTable<DataTables.SearchFilterTb>();
                    Connection.DropTable<DataTables.NearByFilterTb>();
                    Connection.DropTable<DataTables.WatchOfflineVideosTb>();
                    Connection.DropTable<DataTables.SettingsTb>();
                    Connection.DropTable<DataTables.GiftsTb>();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        //########################## End SQLite_Entity ##########################

        //Start SQL_Commander >>  General 
        //*********************************************************

        #region General

        public void InsertRow(object row)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection.Insert(row);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void UpdateRow(object row)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection.Update(row);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void DeleteRow(object row)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection.Delete(row);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void InsertListOfRows(List<object> row)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    Connection.InsertAll(row);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        //Start SQL_Commander >>  Custom 
        //*********************************************************

        #region Login

        //Insert Or Update data Login
        public void InsertOrUpdateLogin_Credentials(DataTables.LoginTb db)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var dataUser = Connection.Table<DataTables.LoginTb>().FirstOrDefault();
                    if (dataUser != null)
                    {
                        dataUser.UserId = UserDetails.UserId;
                        dataUser.AccessToken = UserDetails.AccessToken;
                        dataUser.Cookie = UserDetails.Cookie;
                        dataUser.Username = UserDetails.Username;
                        dataUser.Password = UserDetails.Password;
                        dataUser.Status = UserDetails.Status;
                        dataUser.Lang = AppSettings.Lang;
                        dataUser.DeviceId = UserDetails.DeviceId;
                        dataUser.Email = UserDetails.Email;

                        Connection.Update(dataUser);
                    }
                    else
                    {
                        Connection.Insert(db);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Get data Login
        public DataTables.LoginTb Get_data_Login_Credentials()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var dataUser = Connection.Table<DataTables.LoginTb>().FirstOrDefault();
                    if (dataUser != null)
                    {
                        UserDetails.Username = dataUser.Username;
                        UserDetails.FullName = dataUser.Username;
                        UserDetails.Password = dataUser.Password;
                        UserDetails.AccessToken = dataUser.AccessToken;
                        UserDetails.UserId = dataUser.UserId;
                        UserDetails.Status = dataUser.Status;
                        UserDetails.Cookie = dataUser.Cookie;
                        UserDetails.Email = dataUser.Email;
                        UserDetails.PlayTubeUrl = dataUser.PlayTubeUrl;
                        AppSettings.Lang = dataUser.Lang;
                        UserDetails.DeviceId = dataUser.DeviceId;

                        Current.AccessToken = dataUser.AccessToken;
                        ListUtils.DataUserLoginList.Add(dataUser);

                        return dataUser;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        #endregion

        #region Settings

        public void InsertOrUpdateSettings(GetSiteSettingsObject.Config settingsData)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    if (settingsData != null)
                    {
                        var select = Connection.Table<DataTables.SettingsTb>().FirstOrDefault();
                        if (select == null)
                        {
                            var db = Mapper.Map<DataTables.SettingsTb>(settingsData);

                            db.CurrencyArray = JsonConvert.SerializeObject(settingsData.CurrencyArray);
                            db.CurrencySymbolArray = JsonConvert.SerializeObject(settingsData.CurrencySymbolArray);
                            db.PageCategories = JsonConvert.SerializeObject(settingsData.PageCategories);
                            db.GroupCategories = JsonConvert.SerializeObject(settingsData.GroupCategories);
                            db.BlogCategories = JsonConvert.SerializeObject(settingsData.BlogCategories);
                            db.ProductsCategories = JsonConvert.SerializeObject(settingsData.ProductsCategories);
                            db.Genders = JsonConvert.SerializeObject(settingsData.Genders);
                            db.Family = JsonConvert.SerializeObject(settingsData.Family);
                            if (settingsData.PostColors != null)
                                db.PostColors = JsonConvert.SerializeObject(settingsData.PostColors.Value.PostColorsList);
                            db.PostReactionsTypes = JsonConvert.SerializeObject(settingsData.PostReactionsTypes);

                            Connection.Insert(db);
                        }
                        else
                        {
                            var db = Mapper.Map<DataTables.SettingsTb>(settingsData);

                            db.CurrencyArray = JsonConvert.SerializeObject(settingsData.CurrencyArray);
                            db.CurrencySymbolArray = JsonConvert.SerializeObject(settingsData.CurrencySymbolArray);
                            db.PageCategories = JsonConvert.SerializeObject(settingsData.PageCategories);
                            db.GroupCategories = JsonConvert.SerializeObject(settingsData.GroupCategories);
                            db.BlogCategories = JsonConvert.SerializeObject(settingsData.BlogCategories);
                            db.ProductsCategories = JsonConvert.SerializeObject(settingsData.ProductsCategories);
                            db.Genders = JsonConvert.SerializeObject(settingsData.Genders);
                            db.Family = JsonConvert.SerializeObject(settingsData.Family);
                            if (settingsData.PostColors != null)
                                db.PostColors = JsonConvert.SerializeObject(settingsData.PostColors.Value.PostColorsList);
                            db.PostReactionsTypes = JsonConvert.SerializeObject(settingsData.PostReactionsTypes);

                            Connection.Update(db);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Get Settings
        public GetSiteSettingsObject.Config GetSettings()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var select = Connection.Table<DataTables.SettingsTb>().FirstOrDefault();
                    if (select != null)
                    {
                        var db = Mapper.Map<GetSiteSettingsObject.Config>(select);
                        if (db != null)
                        {
                            GetSiteSettingsObject.Config asd = db;
                            asd.CurrencyArray = new GetSiteSettingsObject.CurrencyArray();
                            asd.CurrencySymbolArray = new CurrencySymbolArray();
                            asd.PageCategories = new Dictionary<string, string>();
                            asd.GroupCategories = new Dictionary<string, string>();
                            asd.BlogCategories = new Dictionary<string, string>();
                            asd.ProductsCategories = new Dictionary<string, string>();
                            asd.Genders = new Dictionary<string, string>();
                            asd.Family = new Dictionary<string, string>();
                            asd.PostColors = new Dictionary<string, PostColorsObject>();
                            asd.PostReactionsTypes = new List<string>();

                            if (!string.IsNullOrEmpty(select.CurrencyArray))
                                asd.CurrencyArray = new GetSiteSettingsObject.CurrencyArray()
                                {
                                    CurrencyList = JsonConvert.DeserializeObject<List<string>>(select.CurrencyArray)
                                };

                            if (!string.IsNullOrEmpty(select.CurrencySymbolArray))
                                asd.CurrencySymbolArray = JsonConvert.DeserializeObject<CurrencySymbolArray>(select.CurrencySymbolArray);

                            if (!string.IsNullOrEmpty(select.PageCategories))
                                asd.PageCategories = JsonConvert.DeserializeObject<Dictionary<string, string>>(select.PageCategories);

                            if (!string.IsNullOrEmpty(select.GroupCategories))
                                asd.GroupCategories = JsonConvert.DeserializeObject<Dictionary<string, string>>(select.GroupCategories);

                            if (!string.IsNullOrEmpty(select.BlogCategories))
                                asd.BlogCategories = JsonConvert.DeserializeObject<Dictionary<string, string>>(select.BlogCategories);

                            if (!string.IsNullOrEmpty(select.ProductsCategories))
                                asd.ProductsCategories = JsonConvert.DeserializeObject<Dictionary<string, string>>(select.ProductsCategories);

                            if (!string.IsNullOrEmpty(select.Genders))
                                asd.Genders = JsonConvert.DeserializeObject<Dictionary<string, string>>(select.Genders);

                            if (!string.IsNullOrEmpty(select.Family))
                                asd.Family = JsonConvert.DeserializeObject<Dictionary<string, string>>(select.Family);

                            if (!string.IsNullOrEmpty(select.PostColors))
                                asd.PostColors = new GetSiteSettingsObject.PostColorUnion { PostColorsList = JsonConvert.DeserializeObject<Dictionary<string, PostColorsObject>>(select.PostColors) };

                            if (!string.IsNullOrEmpty(select.PostReactionsTypes))
                                asd.PostReactionsTypes = JsonConvert.DeserializeObject<List<string>>(select.PostReactionsTypes);

                            var list = db.PageCategories.Select(cat => new Classes.Categories
                            {
                                CategoriesId = cat.Key,
                                CategoriesName = cat.Value,
                                CategoriesColor = "#ffffff"
                            }).ToList();

                            CategoriesController.ListCategoriesPage.Clear();
                            CategoriesController.ListCategoriesPage = new ObservableCollection<Classes.Categories>(list);

                            //Group Categories
                            var listGroup = db.GroupCategories.Select(cat => new Classes.Categories
                            {
                                CategoriesId = cat.Key,
                                CategoriesName = cat.Value,
                                CategoriesColor = "#ffffff"
                            }).ToList();

                            CategoriesController.ListCategoriesGroup.Clear();
                            CategoriesController.ListCategoriesGroup = new ObservableCollection<Classes.Categories>(listGroup);

                            //Products Categories
                            var listProducts = db.ProductsCategories.Select(cat => new Classes.Categories
                            {
                                CategoriesId = cat.Key,
                                CategoriesName = cat.Value,
                                CategoriesColor = "#ffffff"
                            }).ToList();

                            CategoriesController.ListCategoriesProducts.Clear();
                            CategoriesController.ListCategoriesProducts = new ObservableCollection<Classes.Categories>(listProducts);

                            //Family
                            var listFamily = db.Family.Select(cat => new Classes.Family
                            {
                                FamilyId = cat.Key,
                                FamilyName = cat.Value,
                            }).ToList();

                            ListUtils.FamilyList.Clear();
                            ListUtils.FamilyList = new ObservableCollection<Classes.Family>(listFamily);

                            AppSettings.OneSignalAppId = asd.AndroidNPushId;
                            OneSignalNotification.RegisterNotificationDevice();

                            return asd;
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        #endregion

        #region My Contacts >> Following

        //Insert data To My Contact Table
        public void Insert_Or_Replace_MyContactTable(ObservableCollection<UserDataObject> usersContactList)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var result = Connection.Table<DataTables.MyContactsTb>().ToList();
                    List<DataTables.MyContactsTb> list = new List<DataTables.MyContactsTb>();
                    foreach (var info in usersContactList)
                    {
                        var db = Mapper.Map<DataTables.MyContactsTb>(info);
                        db.Details = JsonConvert.SerializeObject(info.Details);
                        db.MutualFriendsData = JsonConvert.SerializeObject(info.MutualFriendsData);
                        list.Add(db);
                    }

                    if (list.Count <= 0) return;

                    Connection.BeginTransaction();
                    //Bring new  
                    var newItemList = list.Where(c => !result.Select(fc => fc.UserId).Contains(c.UserId)).ToList();
                    if (newItemList.Count > 0)
                        Connection.InsertAll(newItemList);

                    Connection.UpdateAll(list);

                    result = Connection.Table<DataTables.MyContactsTb>().ToList();
                    var deleteItemList = result.Where(c => !list.Select(fc => fc.UserId).Contains(c.UserId)).ToList();
                    if (deleteItemList.Count > 0)
                        foreach (var delete in deleteItemList)
                            Connection.Delete(delete);

                    Connection.Commit();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Get data To My Contact Table
        public ObservableCollection<UserDataObject> Get_MyContact(int id = 0, int nSize = 20)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    // var query = Connection.Table<DataTables.MyContactsTb>().Where(w => w.AutoIdMyFollowing >= id).OrderBy(q => q.AutoIdMyFollowing).Take(nSize).ToList();

                    var select = Connection.Table<DataTables.MyContactsTb>().ToList();
                    if (select.Count > 0)
                    {
                        var list = new ObservableCollection<UserDataObject>();

                        foreach (var item in select)
                        {
                            UserDataObject infoObject = new UserDataObject()
                            {
                                UserId = item.UserId,
                                Username = item.Username,
                                Email = item.Email,
                                FirstName = item.FirstName,
                                LastName = item.LastName,
                                Avatar = item.Avatar,
                                Cover = item.Cover,
                                BackgroundImage = item.BackgroundImage,
                                RelationshipId = item.RelationshipId,
                                Address = item.Address,
                                Working = item.Working,
                                Gender = item.Gender,
                                Facebook = item.Facebook,
                                Google = item.Google,
                                Twitter = item.Twitter,
                                Linkedin = item.Linkedin,
                                Website = item.Website,
                                Instagram = item.Instagram,
                                WebDeviceId = item.WebDeviceId,
                                Language = item.Language,
                                IpAddress = item.IpAddress,
                                PhoneNumber = item.PhoneNumber,
                                Timezone = item.Timezone,
                                Lat = item.Lat,
                                Lng = item.Lng,
                                About = item.About,
                                Birthday = item.Birthday,
                                Registered = item.Registered,
                                Lastseen = item.Lastseen,
                                LastLocationUpdate = item.LastLocationUpdate,
                                Balance = item.Balance,
                                Verified = item.Verified,
                                Status = item.Status,
                                Active = item.Active,
                                Admin = item.Admin,
                                IsPro = item.IsPro,
                                ProType = item.ProType,
                                School = item.School,
                                Name = item.Name,
                                AndroidMDeviceId = item.AndroidMDeviceId,
                                ECommented = item.ECommented,
                                AndroidNDeviceId = item.AndroidMDeviceId,
                                AvatarFull = item.AvatarFull,
                                BirthPrivacy = item.BirthPrivacy,
                                CanFollow = item.CanFollow,
                                ConfirmFollowers = item.ConfirmFollowers,
                                CountryId = item.CountryId,
                                EAccepted = item.EAccepted,
                                EFollowed = item.EFollowed,
                                EJoinedGroup = item.EJoinedGroup,
                                ELastNotif = item.ELastNotif,
                                ELiked = item.ELiked,
                                ELikedPage = item.ELikedPage,
                                EMentioned = item.EMentioned,
                                EProfileWallPost = item.EProfileWallPost,
                                ESentmeMsg = item.ESentmeMsg,
                                EShared = item.EShared,
                                EVisited = item.EVisited,
                                EWondered = item.EWondered,
                                EmailNotification = item.EmailNotification,
                                FollowPrivacy = item.FollowPrivacy,
                                FriendPrivacy = item.FriendPrivacy,
                                GenderText = item.GenderText,
                                InfoFile = item.InfoFile,
                                IosMDeviceId = item.IosMDeviceId,
                                IosNDeviceId = item.IosNDeviceId,
                                IsBlocked = item.IsBlocked,
                                IsFollowing = item.IsFollowing,
                                IsFollowingMe = item.IsFollowingMe,
                                LastAvatarMod = item.LastAvatarMod,
                                LastCoverMod = item.LastCoverMod,
                                LastDataUpdate = item.LastDataUpdate,
                                LastFollowId = item.LastFollowId,
                                LastLoginData = item.LastLoginData,
                                LastseenStatus = item.LastseenStatus,
                                LastseenTimeText = item.LastseenTimeText,
                                LastseenUnixTime = item.LastseenUnixTime,
                                MessagePrivacy = item.MessagePrivacy,
                                NewEmail = item.NewEmail,
                                NewPhone = item.NewPhone,
                                NotificationSettings = item.NotificationSettings,
                                NotificationsSound = item.NotificationsSound,
                                OrderPostsBy = item.OrderPostsBy,
                                PaypalEmail = item.PaypalEmail,
                                PostPrivacy = item.PostPrivacy,
                                Referrer = item.Referrer,
                                ShareMyData = item.ShareMyData,
                                ShareMyLocation = item.ShareMyLocation,
                                ShowActivitiesPrivacy = item.ShowActivitiesPrivacy,
                                TwoFactor = item.TwoFactor,
                                TwoFactorVerified = item.TwoFactorVerified,
                                Url = item.Url,
                                VisitPrivacy = item.VisitPrivacy,
                                Vk = item.Vk,
                                Wallet = item.Wallet,
                                WorkingLink = item.WorkingLink,
                                Youtube = item.Youtube,
                                City = item.City,
                                State = item.State,
                                Zip = item.Zip,
                                Points = item.Points,
                                DailyPoints = item.DailyPoints,
                                PointDayExpire = item.PointDayExpire,
                                Details = new Details(),
                                MutualFriendsData = new List<string>(),
                                Selected = false,
                            };

                            if (!string.IsNullOrEmpty(item.Details))
                                infoObject.Details = JsonConvert.DeserializeObject<Details>(item.Details);

                            if (!string.IsNullOrEmpty(item.MutualFriendsData))
                                infoObject.MutualFriendsData = JsonConvert.DeserializeObject<List<string>>(item.MutualFriendsData);

                            list.Add(infoObject);
                        }

                        return list;
                    }
                    else
                    {
                        return new ObservableCollection<UserDataObject>();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return new ObservableCollection<UserDataObject>();
            }
        }

        public void Delete_UsersContact(string userId)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var user = Connection.Table<DataTables.MyContactsTb>().FirstOrDefault(c => c.UserId == userId);
                    if (user != null)
                    {
                        Connection.Delete(user);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region My Contacts >> Following

        //Insert data To my Followers Table
        public void Insert_Or_Replace_MyFollowersTable(ObservableCollection<UserDataObject> myFollowersList)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var result = Connection.Table<DataTables.MyFollowersTb>().ToList();
                    List<DataTables.MyFollowersTb> list = new List<DataTables.MyFollowersTb>();
                    foreach (var info in myFollowersList)
                    {
                        var db = Mapper.Map<DataTables.MyFollowersTb>(info);
                        db.Details = JsonConvert.SerializeObject(info.Details);
                        db.MutualFriendsData = JsonConvert.SerializeObject(info.MutualFriendsData);
                        list.Add(db);
                    }

                    if (list.Count <= 0) return;

                    Connection.BeginTransaction();
                    //Bring new  
                    var newItemList = list.Where(c => !result.Select(fc => fc.UserId).Contains(c.UserId)).ToList();
                    if (newItemList.Count > 0)
                        Connection.InsertAll(newItemList);

                    Connection.UpdateAll(list);

                    result = Connection.Table<DataTables.MyFollowersTb>().ToList();
                    var deleteItemList = result.Where(c => !list.Select(fc => fc.UserId).Contains(c.UserId)).ToList();
                    if (deleteItemList.Count > 0)
                        foreach (var delete in deleteItemList)
                            Connection.Delete(delete);

                    Connection.Commit();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Get data To my Followers Table
        public ObservableCollection<UserDataObject> Get_MyFollowers(int id = 0, int nSize = 20)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    // var query = Connection.Table<DataTables.MyFollowersTb>().Where(w => w.AutoIdMyFollowing >= id).OrderBy(q => q.AutoIdMyFollowing).Take(nSize).ToList();

                    var select = Connection.Table<DataTables.MyFollowersTb>().ToList();
                    if (select.Count > 0)
                    {
                        var list = new ObservableCollection<UserDataObject>();
                        foreach (var item in select)
                        {
                            UserDataObject infoObject = new UserDataObject()
                            {
                                UserId = item.UserId,
                                Username = item.Username,
                                Email = item.Email,
                                FirstName = item.FirstName,
                                LastName = item.LastName,
                                Avatar = item.Avatar,
                                Cover = item.Cover,
                                BackgroundImage = item.BackgroundImage,
                                RelationshipId = item.RelationshipId,
                                Address = item.Address,
                                Working = item.Working,
                                Gender = item.Gender,
                                Facebook = item.Facebook,
                                Google = item.Google,
                                Twitter = item.Twitter,
                                Linkedin = item.Linkedin,
                                Website = item.Website,
                                Instagram = item.Instagram,
                                WebDeviceId = item.WebDeviceId,
                                Language = item.Language,
                                IpAddress = item.IpAddress,
                                PhoneNumber = item.PhoneNumber,
                                Timezone = item.Timezone,
                                Lat = item.Lat,
                                Lng = item.Lng,
                                About = item.About,
                                Birthday = item.Birthday,
                                Registered = item.Registered,
                                Lastseen = item.Lastseen,
                                LastLocationUpdate = item.LastLocationUpdate,
                                Balance = item.Balance,
                                Verified = item.Verified,
                                Status = item.Status,
                                Active = item.Active,
                                Admin = item.Admin,
                                IsPro = item.IsPro,
                                ProType = item.ProType,
                                School = item.School,
                                Name = item.Name,
                                AndroidMDeviceId = item.AndroidMDeviceId,
                                ECommented = item.ECommented,
                                AndroidNDeviceId = item.AndroidMDeviceId,
                                AvatarFull = item.AvatarFull,
                                BirthPrivacy = item.BirthPrivacy,
                                CanFollow = item.CanFollow,
                                ConfirmFollowers = item.ConfirmFollowers,
                                CountryId = item.CountryId,
                                EAccepted = item.EAccepted,
                                EFollowed = item.EFollowed,
                                EJoinedGroup = item.EJoinedGroup,
                                ELastNotif = item.ELastNotif,
                                ELiked = item.ELiked,
                                ELikedPage = item.ELikedPage,
                                EMentioned = item.EMentioned,
                                EProfileWallPost = item.EProfileWallPost,
                                ESentmeMsg = item.ESentmeMsg,
                                EShared = item.EShared,
                                EVisited = item.EVisited,
                                EWondered = item.EWondered,
                                EmailNotification = item.EmailNotification,
                                FollowPrivacy = item.FollowPrivacy,
                                FriendPrivacy = item.FriendPrivacy,
                                GenderText = item.GenderText,
                                InfoFile = item.InfoFile,
                                IosMDeviceId = item.IosMDeviceId,
                                IosNDeviceId = item.IosNDeviceId,
                                IsBlocked = item.IsBlocked,
                                IsFollowing = item.IsFollowing,
                                IsFollowingMe = item.IsFollowingMe,
                                LastAvatarMod = item.LastAvatarMod,
                                LastCoverMod = item.LastCoverMod,
                                LastDataUpdate = item.LastDataUpdate,
                                LastFollowId = item.LastFollowId,
                                LastLoginData = item.LastLoginData,
                                LastseenStatus = item.LastseenStatus,
                                LastseenTimeText = item.LastseenTimeText,
                                LastseenUnixTime = item.LastseenUnixTime,
                                MessagePrivacy = item.MessagePrivacy,
                                NewEmail = item.NewEmail,
                                NewPhone = item.NewPhone,
                                NotificationSettings = item.NotificationSettings,
                                NotificationsSound = item.NotificationsSound,
                                OrderPostsBy = item.OrderPostsBy,
                                PaypalEmail = item.PaypalEmail,
                                PostPrivacy = item.PostPrivacy,
                                Referrer = item.Referrer,
                                ShareMyData = item.ShareMyData,
                                ShareMyLocation = item.ShareMyLocation,
                                ShowActivitiesPrivacy = item.ShowActivitiesPrivacy,
                                TwoFactor = item.TwoFactor,
                                TwoFactorVerified = item.TwoFactorVerified,
                                Url = item.Url,
                                VisitPrivacy = item.VisitPrivacy,
                                Vk = item.Vk,
                                Wallet = item.Wallet,
                                WorkingLink = item.WorkingLink,
                                Youtube = item.Youtube,
                                City = item.City,
                                DailyPoints = item.DailyPoints,
                                PointDayExpire = item.PointDayExpire,
                                State = item.State,
                                Zip = item.Zip,
                                Details = new Details(),
                                MutualFriendsData = new List<string>(),
                                Selected = false,
                            };

                            if (!string.IsNullOrEmpty(item.Details))
                                infoObject.Details = JsonConvert.DeserializeObject<Details>(item.Details);

                            if (!string.IsNullOrEmpty(item.MutualFriendsData))
                                infoObject.MutualFriendsData = JsonConvert.DeserializeObject<List<string>>(item.MutualFriendsData);

                            list.Add(infoObject);
                        }

                        return list;
                    }
                    else
                    {
                        return new ObservableCollection<UserDataObject>();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return new ObservableCollection<UserDataObject>();
            }
        }

        public void Delete_MyFollowers(string userId)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var user = Connection.Table<DataTables.MyFollowersTb>().FirstOrDefault(c => c.UserId == userId);
                    if (user != null)
                    {
                        Connection.Delete(user);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        // Get data One user To My Contact Table
        public UserDataObject Get_DataOneUser(string userName)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var item = Connection.Table<DataTables.MyContactsTb>().FirstOrDefault(a => a.Username == userName || a.Name == userName);
                    if (item != null)
                    {
                        UserDataObject infoObject = new UserDataObject()
                        {
                            UserId = item.UserId,
                            Username = item.Username,
                            Email = item.Email,
                            FirstName = item.FirstName,
                            LastName = item.LastName,
                            Avatar = item.Avatar,
                            Cover = item.Cover,
                            BackgroundImage = item.BackgroundImage,
                            RelationshipId = item.RelationshipId,
                            Address = item.Address,
                            Working = item.Working,
                            Gender = item.Gender,
                            Facebook = item.Facebook,
                            Google = item.Google,
                            Twitter = item.Twitter,
                            Linkedin = item.Linkedin,
                            Website = item.Website,
                            Instagram = item.Instagram,
                            WebDeviceId = item.WebDeviceId,
                            Language = item.Language,
                            IpAddress = item.IpAddress,
                            PhoneNumber = item.PhoneNumber,
                            Timezone = item.Timezone,
                            Lat = item.Lat,
                            Lng = item.Lng,
                            About = item.About,
                            Birthday = item.Birthday,
                            Registered = item.Registered,
                            Lastseen = item.Lastseen,
                            LastLocationUpdate = item.LastLocationUpdate,
                            Balance = item.Balance,
                            Verified = item.Verified,
                            Status = item.Status,
                            Active = item.Active,
                            Admin = item.Admin,
                            IsPro = item.IsPro,
                            ProType = item.ProType,
                            School = item.School,
                            Name = item.Name,
                            AndroidMDeviceId = item.AndroidMDeviceId,
                            ECommented = item.ECommented,
                            AndroidNDeviceId = item.AndroidMDeviceId,
                            AvatarFull = item.AvatarFull,
                            BirthPrivacy = item.BirthPrivacy,
                            CanFollow = item.CanFollow,
                            ConfirmFollowers = item.ConfirmFollowers,
                            CountryId = item.CountryId,
                            EAccepted = item.EAccepted,
                            EFollowed = item.EFollowed,
                            EJoinedGroup = item.EJoinedGroup,
                            ELastNotif = item.ELastNotif,
                            ELiked = item.ELiked,
                            ELikedPage = item.ELikedPage,
                            EMentioned = item.EMentioned,
                            EProfileWallPost = item.EProfileWallPost,
                            ESentmeMsg = item.ESentmeMsg,
                            EShared = item.EShared,
                            EVisited = item.EVisited,
                            EWondered = item.EWondered,
                            EmailNotification = item.EmailNotification,
                            FollowPrivacy = item.FollowPrivacy,
                            FriendPrivacy = item.FriendPrivacy,
                            GenderText = item.GenderText,
                            InfoFile = item.InfoFile,
                            IosMDeviceId = item.IosMDeviceId,
                            IosNDeviceId = item.IosNDeviceId,
                            IsBlocked = item.IsBlocked,
                            IsFollowing = item.IsFollowing,
                            IsFollowingMe = item.IsFollowingMe,
                            LastAvatarMod = item.LastAvatarMod,
                            LastCoverMod = item.LastCoverMod,
                            LastDataUpdate = item.LastDataUpdate,
                            LastFollowId = item.LastFollowId,
                            LastLoginData = item.LastLoginData,
                            LastseenStatus = item.LastseenStatus,
                            LastseenTimeText = item.LastseenTimeText,
                            LastseenUnixTime = item.LastseenUnixTime,
                            MessagePrivacy = item.MessagePrivacy,
                            NewEmail = item.NewEmail,
                            NewPhone = item.NewPhone,
                            NotificationSettings = item.NotificationSettings,
                            NotificationsSound = item.NotificationsSound,
                            OrderPostsBy = item.OrderPostsBy,
                            PaypalEmail = item.PaypalEmail,
                            PostPrivacy = item.PostPrivacy,
                            Referrer = item.Referrer,
                            ShareMyData = item.ShareMyData,
                            ShareMyLocation = item.ShareMyLocation,
                            ShowActivitiesPrivacy = item.ShowActivitiesPrivacy,
                            TwoFactor = item.TwoFactor,
                            TwoFactorVerified = item.TwoFactorVerified,
                            Url = item.Url,
                            VisitPrivacy = item.VisitPrivacy,
                            Vk = item.Vk,
                            Wallet = item.Wallet,
                            WorkingLink = item.WorkingLink,
                            Youtube = item.Youtube,
                            City = item.City,
                            DailyPoints = item.DailyPoints,
                            PointDayExpire = item.PointDayExpire,
                            State = item.State,
                            Zip = item.Zip,
                            Details = new Details(),
                            MutualFriendsData = new List<string>(),
                            Selected = false,
                        };

                        if (!string.IsNullOrEmpty(item.Details))
                            infoObject.Details = JsonConvert.DeserializeObject<Details>(item.Details);

                        if (!string.IsNullOrEmpty(item.MutualFriendsData))
                            infoObject.MutualFriendsData = JsonConvert.DeserializeObject<List<string>>(item.MutualFriendsData);

                        return infoObject;
                    }
                    else
                    {
                        var userFollowers = Connection.Table<DataTables.MyFollowersTb>().FirstOrDefault(a => a.Username == userName || a.Name == userName);
                        if (userFollowers != null)
                        {
                            UserDataObject infoObject = new UserDataObject()
                            {
                                UserId = userFollowers.UserId,
                                Username = userFollowers.Username,
                                Email = userFollowers.Email,
                                FirstName = userFollowers.FirstName,
                                LastName = userFollowers.LastName,
                                Avatar = userFollowers.Avatar,
                                Cover = userFollowers.Cover,
                                BackgroundImage = userFollowers.BackgroundImage,
                                RelationshipId = userFollowers.RelationshipId,
                                Address = userFollowers.Address,
                                Working = userFollowers.Working,
                                Gender = userFollowers.Gender,
                                Facebook = userFollowers.Facebook,
                                Google = userFollowers.Google,
                                Twitter = userFollowers.Twitter,
                                Linkedin = userFollowers.Linkedin,
                                Website = userFollowers.Website,
                                Instagram = userFollowers.Instagram,
                                WebDeviceId = userFollowers.WebDeviceId,
                                Language = userFollowers.Language,
                                IpAddress = userFollowers.IpAddress,
                                PhoneNumber = userFollowers.PhoneNumber,
                                Timezone = userFollowers.Timezone,
                                Lat = userFollowers.Lat,
                                Lng = userFollowers.Lng,
                                About = userFollowers.About,
                                Birthday = userFollowers.Birthday,
                                Registered = userFollowers.Registered,
                                Lastseen = userFollowers.Lastseen,
                                LastLocationUpdate = userFollowers.LastLocationUpdate,
                                Balance = userFollowers.Balance,
                                Verified = userFollowers.Verified,
                                Status = userFollowers.Status,
                                Active = userFollowers.Active,
                                Admin = userFollowers.Admin,
                                IsPro = userFollowers.IsPro,
                                ProType = userFollowers.ProType,
                                School = userFollowers.School,
                                Name = userFollowers.Name,
                                AndroidMDeviceId = userFollowers.AndroidMDeviceId,
                                ECommented = userFollowers.ECommented,
                                AndroidNDeviceId = userFollowers.AndroidMDeviceId,
                                AvatarFull = userFollowers.AvatarFull,
                                BirthPrivacy = userFollowers.BirthPrivacy,
                                CanFollow = userFollowers.CanFollow,
                                ConfirmFollowers = userFollowers.ConfirmFollowers,
                                CountryId = userFollowers.CountryId,
                                EAccepted = userFollowers.EAccepted,
                                EFollowed = userFollowers.EFollowed,
                                EJoinedGroup = userFollowers.EJoinedGroup,
                                ELastNotif = userFollowers.ELastNotif,
                                ELiked = userFollowers.ELiked,
                                ELikedPage = userFollowers.ELikedPage,
                                EMentioned = userFollowers.EMentioned,
                                EProfileWallPost = userFollowers.EProfileWallPost,
                                ESentmeMsg = userFollowers.ESentmeMsg,
                                EShared = userFollowers.EShared,
                                EVisited = userFollowers.EVisited,
                                EWondered = userFollowers.EWondered,
                                EmailNotification = userFollowers.EmailNotification,
                                FollowPrivacy = userFollowers.FollowPrivacy,
                                FriendPrivacy = userFollowers.FriendPrivacy,
                                GenderText = userFollowers.GenderText,
                                InfoFile = userFollowers.InfoFile,
                                IosMDeviceId = userFollowers.IosMDeviceId,
                                IosNDeviceId = userFollowers.IosNDeviceId,
                                IsBlocked = userFollowers.IsBlocked,
                                IsFollowing = userFollowers.IsFollowing,
                                IsFollowingMe = userFollowers.IsFollowingMe,
                                LastAvatarMod = userFollowers.LastAvatarMod,
                                LastCoverMod = userFollowers.LastCoverMod,
                                LastDataUpdate = userFollowers.LastDataUpdate,
                                LastFollowId = userFollowers.LastFollowId,
                                LastLoginData = userFollowers.LastLoginData,
                                LastseenStatus = userFollowers.LastseenStatus,
                                LastseenTimeText = userFollowers.LastseenTimeText,
                                LastseenUnixTime = userFollowers.LastseenUnixTime,
                                MessagePrivacy = userFollowers.MessagePrivacy,
                                NewEmail = userFollowers.NewEmail,
                                NewPhone = userFollowers.NewPhone,
                                NotificationSettings = userFollowers.NotificationSettings,
                                NotificationsSound = userFollowers.NotificationsSound,
                                OrderPostsBy = userFollowers.OrderPostsBy,
                                PaypalEmail = userFollowers.PaypalEmail,
                                PostPrivacy = userFollowers.PostPrivacy,
                                Referrer = userFollowers.Referrer,
                                ShareMyData = userFollowers.ShareMyData,
                                ShareMyLocation = userFollowers.ShareMyLocation,
                                ShowActivitiesPrivacy = userFollowers.ShowActivitiesPrivacy,
                                TwoFactor = userFollowers.TwoFactor,
                                TwoFactorVerified = userFollowers.TwoFactorVerified,
                                Url = userFollowers.Url,
                                VisitPrivacy = userFollowers.VisitPrivacy,
                                Vk = userFollowers.Vk,
                                Wallet = userFollowers.Wallet,
                                WorkingLink = userFollowers.WorkingLink,
                                Youtube = userFollowers.Youtube,
                                City = userFollowers.City,
                                DailyPoints = userFollowers.DailyPoints,
                                PointDayExpire = userFollowers.PointDayExpire,
                                State = userFollowers.State,
                                Zip = userFollowers.Zip,
                                Details = new Details(),
                                MutualFriendsData = new List<string>(),
                                Selected = false,
                            };

                            if (!string.IsNullOrEmpty(userFollowers.Details))
                                infoObject.Details = JsonConvert.DeserializeObject<Details>(userFollowers.Details);

                            if (!string.IsNullOrEmpty(userFollowers.MutualFriendsData))
                                infoObject.MutualFriendsData = JsonConvert.DeserializeObject<List<string>>(userFollowers.MutualFriendsData);

                            return infoObject;
                        }

                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }


        #region My Profile

        //Insert Or Update data My Profile Table
        public void Insert_Or_Update_To_MyProfileTable(UserDataObject info)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var resultInfoTb = Connection.Table<DataTables.MyProfileTb>().FirstOrDefault();
                    if (resultInfoTb != null)
                    {
                        DataTables.MyProfileTb db = new DataTables.MyProfileTb()
                        {
                            UserId = info.UserId,
                            Username = info.Username,
                            Email = info.Email,
                            FirstName = info.FirstName,
                            LastName = info.LastName,
                            Avatar = info.Avatar,
                            Cover = info.Cover,
                            BackgroundImage = info.BackgroundImage,
                            RelationshipId = info.RelationshipId,
                            Address = info.Address,
                            Working = info.Working,
                            Gender = info.Gender,
                            Facebook = info.Facebook,
                            Google = info.Google,
                            Twitter = info.Twitter,
                            Linkedin = info.Linkedin,
                            Website = info.Website,
                            Instagram = info.Instagram,
                            WebDeviceId = info.WebDeviceId,
                            Language = info.Language,
                            IpAddress = info.IpAddress,
                            PhoneNumber = info.PhoneNumber,
                            Timezone = info.Timezone,
                            Lat = info.Lat,
                            Lng = info.Lng,
                            About = info.About,
                            Birthday = info.Birthday,
                            Registered = info.Registered,
                            Lastseen = info.Lastseen,
                            LastLocationUpdate = info.LastLocationUpdate,
                            Balance = info.Balance,
                            Verified = info.Verified,
                            Status = info.Status,
                            Active = info.Active,
                            Admin = info.Admin,
                            IsPro = info.IsPro,
                            ProType = info.ProType,
                            School = info.School,
                            Name = info.Name,
                            AndroidMDeviceId = info.AndroidMDeviceId,
                            ECommented = info.ECommented,
                            AndroidNDeviceId = info.AndroidMDeviceId,
                            AvatarFull = info.AvatarFull,
                            BirthPrivacy = info.BirthPrivacy,
                            CanFollow = info.CanFollow,
                            ConfirmFollowers = info.ConfirmFollowers,
                            CountryId = info.CountryId,
                            EAccepted = info.EAccepted,
                            EFollowed = info.EFollowed,
                            EJoinedGroup = info.EJoinedGroup,
                            ELastNotif = info.ELastNotif,
                            ELiked = info.ELiked,
                            ELikedPage = info.ELikedPage,
                            EMentioned = info.EMentioned,
                            EProfileWallPost = info.EProfileWallPost,
                            ESentmeMsg = info.ESentmeMsg,
                            EShared = info.EShared,
                            EVisited = info.EVisited,
                            EWondered = info.EWondered,
                            EmailNotification = info.EmailNotification,
                            FollowPrivacy = info.FollowPrivacy,
                            FriendPrivacy = info.FriendPrivacy,
                            GenderText = info.GenderText,
                            InfoFile = info.InfoFile,
                            IosMDeviceId = info.IosMDeviceId,
                            IosNDeviceId = info.IosNDeviceId,
                            IsBlocked = info.IsBlocked,
                            IsFollowing = info.IsFollowing,
                            IsFollowingMe = info.IsFollowingMe,
                            LastAvatarMod = info.LastAvatarMod,
                            LastCoverMod = info.LastCoverMod,
                            LastDataUpdate = info.LastDataUpdate,
                            LastFollowId = info.LastFollowId,
                            LastLoginData = info.LastLoginData,
                            LastseenStatus = info.LastseenStatus,
                            LastseenTimeText = info.LastseenTimeText,
                            LastseenUnixTime = info.LastseenUnixTime,
                            MessagePrivacy = info.MessagePrivacy,
                            NewEmail = info.NewEmail,
                            NewPhone = info.NewPhone,
                            NotificationSettings = info.NotificationSettings,
                            NotificationsSound = info.NotificationsSound,
                            OrderPostsBy = info.OrderPostsBy,
                            PaypalEmail = info.PaypalEmail,
                            PostPrivacy = info.PostPrivacy,
                            Referrer = info.Referrer,
                            ShareMyData = info.ShareMyData,
                            ShareMyLocation = info.ShareMyLocation,
                            ShowActivitiesPrivacy = info.ShowActivitiesPrivacy,
                            TwoFactor = info.TwoFactor,
                            TwoFactorVerified = info.TwoFactorVerified,
                            Url = info.Url,
                            VisitPrivacy = info.VisitPrivacy,
                            Vk = info.Vk,
                            Wallet = info.Wallet,
                            WorkingLink = info.WorkingLink,
                            Youtube = info.Youtube,
                            City = info.City,
                            Points = info.Points,
                            DailyPoints = info.DailyPoints,
                            PointDayExpire = info.PointDayExpire,
                            State = info.State,
                            Zip = info.Zip,
                            Details = string.Empty,
                            MutualFriendsData = string.Empty,
                            Selected = false,
                        };

                        db.Details = JsonConvert.SerializeObject(info.Details);
                        db.MutualFriendsData = JsonConvert.SerializeObject(info.MutualFriendsData);
                        Connection.Update(db);
                    }
                    else
                    {
                        DataTables.MyProfileTb db = new DataTables.MyProfileTb()
                        {
                            UserId = info.UserId,
                            Username = info.Username,
                            Email = info.Email,
                            FirstName = info.FirstName,
                            LastName = info.LastName,
                            Avatar = info.Avatar,
                            Cover = info.Cover,
                            BackgroundImage = info.BackgroundImage,
                            RelationshipId = info.RelationshipId,
                            Address = info.Address,
                            Working = info.Working,
                            Gender = info.Gender,
                            Facebook = info.Facebook,
                            Google = info.Google,
                            Twitter = info.Twitter,
                            Linkedin = info.Linkedin,
                            Website = info.Website,
                            Instagram = info.Instagram,
                            WebDeviceId = info.WebDeviceId,
                            Language = info.Language,
                            IpAddress = info.IpAddress,
                            PhoneNumber = info.PhoneNumber,
                            Timezone = info.Timezone,
                            Lat = info.Lat,
                            Lng = info.Lng,
                            About = info.About,
                            Birthday = info.Birthday,
                            Registered = info.Registered,
                            Lastseen = info.Lastseen,
                            LastLocationUpdate = info.LastLocationUpdate,
                            Balance = info.Balance,
                            Verified = info.Verified,
                            Status = info.Status,
                            Active = info.Active,
                            Admin = info.Admin,
                            IsPro = info.IsPro,
                            ProType = info.ProType,
                            School = info.School,
                            Name = info.Name,
                            AndroidMDeviceId = info.AndroidMDeviceId,
                            ECommented = info.ECommented,
                            AndroidNDeviceId = info.AndroidMDeviceId,
                            AvatarFull = info.AvatarFull,
                            BirthPrivacy = info.BirthPrivacy,
                            CanFollow = info.CanFollow,
                            ConfirmFollowers = info.ConfirmFollowers,
                            CountryId = info.CountryId,
                            EAccepted = info.EAccepted,
                            EFollowed = info.EFollowed,
                            EJoinedGroup = info.EJoinedGroup,
                            ELastNotif = info.ELastNotif,
                            ELiked = info.ELiked,
                            ELikedPage = info.ELikedPage,
                            EMentioned = info.EMentioned,
                            EProfileWallPost = info.EProfileWallPost,
                            ESentmeMsg = info.ESentmeMsg,
                            EShared = info.EShared,
                            EVisited = info.EVisited,
                            EWondered = info.EWondered,
                            EmailNotification = info.EmailNotification,
                            FollowPrivacy = info.FollowPrivacy,
                            FriendPrivacy = info.FriendPrivacy,
                            GenderText = info.GenderText,
                            InfoFile = info.InfoFile,
                            IosMDeviceId = info.IosMDeviceId,
                            IosNDeviceId = info.IosNDeviceId,
                            IsBlocked = info.IsBlocked,
                            IsFollowing = info.IsFollowing,
                            IsFollowingMe = info.IsFollowingMe,
                            LastAvatarMod = info.LastAvatarMod,
                            LastCoverMod = info.LastCoverMod,
                            LastDataUpdate = info.LastDataUpdate,
                            LastFollowId = info.LastFollowId,
                            LastLoginData = info.LastLoginData,
                            LastseenStatus = info.LastseenStatus,
                            LastseenTimeText = info.LastseenTimeText,
                            LastseenUnixTime = info.LastseenUnixTime,
                            MessagePrivacy = info.MessagePrivacy,
                            NewEmail = info.NewEmail,
                            NewPhone = info.NewPhone,
                            NotificationSettings = info.NotificationSettings,
                            NotificationsSound = info.NotificationsSound,
                            OrderPostsBy = info.OrderPostsBy,
                            PaypalEmail = info.PaypalEmail,
                            PostPrivacy = info.PostPrivacy,
                            Referrer = info.Referrer,
                            ShareMyData = info.ShareMyData,
                            ShareMyLocation = info.ShareMyLocation,
                            ShowActivitiesPrivacy = info.ShowActivitiesPrivacy,
                            TwoFactor = info.TwoFactor,
                            TwoFactorVerified = info.TwoFactorVerified,
                            Url = info.Url,
                            VisitPrivacy = info.VisitPrivacy,
                            Vk = info.Vk,
                            Wallet = info.Wallet,
                            WorkingLink = info.WorkingLink,
                            Youtube = info.Youtube,
                            City = info.City,
                            Points = info.Points,
                            DailyPoints = info.DailyPoints,
                            PointDayExpire = info.PointDayExpire,
                            State = info.State,
                            Zip = info.Zip,
                            Details = string.Empty,
                            MutualFriendsData = string.Empty,
                            Selected = false,
                        };

                        db.Details = JsonConvert.SerializeObject(info.Details);
                        db.MutualFriendsData = JsonConvert.SerializeObject(info.MutualFriendsData);
                        Connection.Insert(db);
                    }

                    UserDetails.Avatar = info.Avatar;
                    UserDetails.Cover = info.Cover;
                    UserDetails.Username = info.Username;
                    UserDetails.FullName = info.Name;
                    UserDetails.Email = info.Email;

                    ListUtils.MyProfileList = new ObservableCollection<UserDataObject>();
                    ListUtils.MyProfileList.Clear();
                    ListUtils.MyProfileList.Add(info);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Get data To My Profile Table
        public UserDataObject Get_MyProfile()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var item = Connection.Table<DataTables.MyProfileTb>().FirstOrDefault();
                    if (item != null)
                    {
                        UserDataObject infoObject = new UserDataObject()
                        {
                            UserId = item.UserId,
                            Username = item.Username,
                            Email = item.Email,
                            FirstName = item.FirstName,
                            LastName = item.LastName,
                            Avatar = item.Avatar,
                            Cover = item.Cover,
                            BackgroundImage = item.BackgroundImage,
                            RelationshipId = item.RelationshipId,
                            Address = item.Address,
                            Working = item.Working,
                            Gender = item.Gender,
                            Facebook = item.Facebook,
                            Google = item.Google,
                            Twitter = item.Twitter,
                            Linkedin = item.Linkedin,
                            Website = item.Website,
                            Instagram = item.Instagram,
                            WebDeviceId = item.WebDeviceId,
                            Language = item.Language,
                            IpAddress = item.IpAddress,
                            PhoneNumber = item.PhoneNumber,
                            Timezone = item.Timezone,
                            Lat = item.Lat,
                            Lng = item.Lng,
                            About = item.About,
                            Birthday = item.Birthday,
                            Registered = item.Registered,
                            Lastseen = item.Lastseen,
                            LastLocationUpdate = item.LastLocationUpdate,
                            Balance = item.Balance,
                            Verified = item.Verified,
                            Status = item.Status,
                            Active = item.Active,
                            Admin = item.Admin,
                            IsPro = item.IsPro,
                            ProType = item.ProType,
                            School = item.School,
                            Name = item.Name,
                            AndroidMDeviceId = item.AndroidMDeviceId,
                            ECommented = item.ECommented,
                            AndroidNDeviceId = item.AndroidMDeviceId,
                            AvatarFull = item.AvatarFull,
                            BirthPrivacy = item.BirthPrivacy,
                            CanFollow = item.CanFollow,
                            ConfirmFollowers = item.ConfirmFollowers,
                            CountryId = item.CountryId,
                            EAccepted = item.EAccepted,
                            EFollowed = item.EFollowed,
                            EJoinedGroup = item.EJoinedGroup,
                            ELastNotif = item.ELastNotif,
                            ELiked = item.ELiked,
                            ELikedPage = item.ELikedPage,
                            EMentioned = item.EMentioned,
                            EProfileWallPost = item.EProfileWallPost,
                            ESentmeMsg = item.ESentmeMsg,
                            EShared = item.EShared,
                            EVisited = item.EVisited,
                            EWondered = item.EWondered,
                            EmailNotification = item.EmailNotification,
                            FollowPrivacy = item.FollowPrivacy,
                            FriendPrivacy = item.FriendPrivacy,
                            GenderText = item.GenderText,
                            InfoFile = item.InfoFile,
                            IosMDeviceId = item.IosMDeviceId,
                            IosNDeviceId = item.IosNDeviceId,
                            IsBlocked = item.IsBlocked,
                            IsFollowing = item.IsFollowing,
                            IsFollowingMe = item.IsFollowingMe,
                            LastAvatarMod = item.LastAvatarMod,
                            LastCoverMod = item.LastCoverMod,
                            LastDataUpdate = item.LastDataUpdate,
                            LastFollowId = item.LastFollowId,
                            LastLoginData = item.LastLoginData,
                            LastseenStatus = item.LastseenStatus,
                            LastseenTimeText = item.LastseenTimeText,
                            LastseenUnixTime = item.LastseenUnixTime,
                            MessagePrivacy = item.MessagePrivacy,
                            NewEmail = item.NewEmail,
                            NewPhone = item.NewPhone,
                            NotificationSettings = item.NotificationSettings,
                            NotificationsSound = item.NotificationsSound,
                            OrderPostsBy = item.OrderPostsBy,
                            PaypalEmail = item.PaypalEmail,
                            PostPrivacy = item.PostPrivacy,
                            Referrer = item.Referrer,
                            ShareMyData = item.ShareMyData,
                            ShareMyLocation = item.ShareMyLocation,
                            ShowActivitiesPrivacy = item.ShowActivitiesPrivacy,
                            TwoFactor = item.TwoFactor,
                            TwoFactorVerified = item.TwoFactorVerified,
                            Url = item.Url,
                            VisitPrivacy = item.VisitPrivacy,
                            Vk = item.Vk,
                            Wallet = item.Wallet,
                            WorkingLink = item.WorkingLink,
                            Youtube = item.Youtube,
                            City = item.City,
                            Points = item.Points,
                            DailyPoints = item.DailyPoints,
                            PointDayExpire = item.PointDayExpire,
                            State = item.State,
                            Zip = item.Zip,
                            Details = new Details(),
                            MutualFriendsData = new List<string>(),
                            Selected = false,
                        };

                        if (!string.IsNullOrEmpty(item.Details))
                            infoObject.Details = JsonConvert.DeserializeObject<Details>(item.Details);

                        if (!string.IsNullOrEmpty(item.MutualFriendsData))
                            infoObject.MutualFriendsData = JsonConvert.DeserializeObject<List<string>>(item.MutualFriendsData);

                        UserDetails.Avatar = item.Avatar;
                        UserDetails.Cover = item.Cover;
                        UserDetails.Username = item.Username;
                        UserDetails.FullName = item.Name;
                        UserDetails.Email = item.Email;

                        ListUtils.MyProfileList = new ObservableCollection<UserDataObject>();
                        ListUtils.MyProfileList.Clear();
                        ListUtils.MyProfileList.Add(infoObject);

                        return infoObject;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region Search Filter 

        public void InsertOrUpdate_SearchFilter(DataTables.SearchFilterTb dataFilter)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var data = Connection.Table<DataTables.SearchFilterTb>().FirstOrDefault();
                    if (data == null)
                    {
                        Connection.Insert(dataFilter);
                    }
                    else
                    {
                        data.Gender = dataFilter.Gender;
                        data.Country = dataFilter.Country;
                        data.Status = dataFilter.Status;
                        data.Verified = dataFilter.Verified;
                        data.FilterByAge = dataFilter.FilterByAge;
                        data.AgeFrom = dataFilter.AgeFrom;
                        data.AgeTo = dataFilter.AgeTo;

                        Connection.Update(data);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public DataTables.SearchFilterTb GetSearchFilterById()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var data = Connection.Table<DataTables.SearchFilterTb>().FirstOrDefault();
                    return data ?? null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region Near By Filter 

        public void InsertOrUpdate_NearByFilter(DataTables.NearByFilterTb dataFilter)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var data = Connection.Table<DataTables.NearByFilterTb>().FirstOrDefault();
                    if (data == null)
                    {
                        Connection.Insert(dataFilter);
                    }
                    else
                    {
                        data.DistanceValue = dataFilter.DistanceValue;
                        data.Gender = dataFilter.Gender;
                        data.Status = dataFilter.Status;

                        Connection.Update(data);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public DataTables.NearByFilterTb GetNearByFilterById()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var data = Connection.Table<DataTables.NearByFilterTb>().FirstOrDefault();
                    return data ?? null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region WatchOffline Videos

        //Insert WatchOffline Videos
        public void Insert_WatchOfflineVideos(GetMoviesObject.Movie video)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    if (video != null)
                    {
                        var select = Connection.Table<DataTables.WatchOfflineVideosTb>().FirstOrDefault(a => a.Id == video.Id);
                        if (select == null)
                        {
                            DataTables.WatchOfflineVideosTb watchOffline = new DataTables.WatchOfflineVideosTb()
                            {
                                Id = video.Id,
                                Name = video.Name,
                                Cover = video.Cover,
                                Description = video.Description,
                                Country = video.Country,
                                Duration = video.Duration,
                                Genre = video.Genre,
                                Iframe = video.Iframe,
                                Quality = video.Quality,
                                Producer = video.Producer,
                                Release = video.Release,
                                Source = video.Source,
                                Stars = video.Stars,
                                Url = video.Url,
                                Video = video.Video,
                                Views = video.Views,
                            };

                            Connection.Insert(watchOffline);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Remove WatchOffline Videos
        public void Remove_WatchOfflineVideos(string watchOfflineVideosId)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    if (!string.IsNullOrEmpty(watchOfflineVideosId))
                    {
                        var select = Connection.Table<DataTables.WatchOfflineVideosTb>().FirstOrDefault(a => a.Id == watchOfflineVideosId);
                        if (select != null)
                        {
                            Connection.Delete(select);
                        }
                    }
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Get WatchOffline Videos
        public ObservableCollection<DataTables.WatchOfflineVideosTb> Get_WatchOfflineVideos()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var select = Connection.Table<DataTables.WatchOfflineVideosTb>().ToList().OrderByDescending(a => a.AutoIdWatchOfflineVideos);
                    if (select.Count() > 0)
                    {
                        return new ObservableCollection<DataTables.WatchOfflineVideosTb>(select);
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        //Get WatchOffline Videos
        public GetMoviesObject.Movie Get_WatchOfflineVideos_ById(string id)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var video = Connection.Table<DataTables.WatchOfflineVideosTb>().FirstOrDefault(a => a.Id == id);
                    if (video != null)
                    {
                        GetMoviesObject.Movie watchOffline = new GetMoviesObject.Movie()
                        {
                            Id = video.Id,
                            Name = video.Name,
                            Cover = video.Cover,
                            Description = video.Description,
                            Country = video.Country,
                            Duration = video.Duration,
                            Genre = video.Genre,
                            Iframe = video.Iframe,
                            Quality = video.Quality,
                            Producer = video.Producer,
                            Release = video.Release,
                            Source = video.Source,
                            Stars = video.Stars,
                            Url = video.Url,
                            Video = video.Video,
                            Views = video.Views,
                        };

                        return watchOffline;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public DataTables.WatchOfflineVideosTb Update_WatchOfflineVideos(string videoId, string videoPath)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var select = Connection.Table<DataTables.WatchOfflineVideosTb>().FirstOrDefault(a => a.Id == videoId);
                    if (select != null)
                    {
                        select.VideoName = videoId + ".mp4";
                        select.VideoSavedPath = videoPath;

                        Connection.Update(select);

                        return select;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        #endregion

        #region Gifts

        //Insert data Gifts
        public void InsertAllGifts(ObservableCollection<GiftObject.DataGiftObject> listData)
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var result = Connection.Table<DataTables.GiftsTb>().ToList();

                    List<DataTables.GiftsTb> list = listData.Select(gift => new DataTables.GiftsTb
                    {
                        Id = gift.Id,
                        MediaFile = gift.MediaFile,
                        Name = gift.Name,
                        Time = gift.Time,
                        TimeText = gift.TimeText,
                    }).ToList();

                    if (list.Count <= 0) return;
                    Connection.BeginTransaction();
                    //Bring new  
                    var newItemList = list.Where(c => !result.Select(fc => fc.Id).Contains(c.Id)).ToList();
                    if (newItemList.Count > 0)
                    {
                        Connection.InsertAll(newItemList);
                    }

                    Connection.UpdateAll(list);
                    Connection.Commit();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Get List Gifts 
        public ObservableCollection<GiftObject.DataGiftObject> GetGiftsList()
        {
            try
            {
                using (Connection = new SQLiteConnection(PathCombine))
                {
                    var result = Connection.Table<DataTables.GiftsTb>().ToList();
                    if (result?.Count > 0)
                    {
                        List<GiftObject.DataGiftObject> list = result.Select(gift => new GiftObject.DataGiftObject
                        {
                            Id = gift.Id,
                            MediaFile = gift.MediaFile,
                            Name = gift.Name,
                            Time = gift.Time,
                            TimeText = gift.TimeText,
                        }).ToList();

                        return new ObservableCollection<GiftObject.DataGiftObject>(list);
                    }
                    else
                    {
                        return new ObservableCollection<GiftObject.DataGiftObject>();
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return new ObservableCollection<GiftObject.DataGiftObject>();
            }
        }

        #endregion

    }
}