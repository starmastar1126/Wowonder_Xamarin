﻿using SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Movies;


namespace WoWonder.SQLite
{
    public class DataTables
    {
        public class LoginTb
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdLogin { get; set; }

            public string UserId { get; set; }
            public string Username { get; set; }
            public string Password { get; set; }
            public string AccessToken { get; set; }
            public string Cookie { get; set; }
            public string Email { get; set; }
            public string Status { get; set; }
            public string Lang { get; set; }
            public string DeviceId { get; set; }
            public string PlayTubeUrl { get; set; }
        }

        public class SettingsTb : GetSiteSettingsObject.Config
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdSettings { get; set; } 

            public new string CurrencyArray { get; set; }
            public new string CurrencySymbolArray  { get; set; }
            public new string PageCategories  { get; set; }
            public new string GroupCategories  { get; set; }
            public new string BlogCategories  { get; set; }
            public new string ProductsCategories  { get; set; }
            public new string Genders { get; set; }
            public new string Family  { get; set; }
            public new string PostColors  { get; set; }
            public new string PostReactionsTypes  { get; set; } 
        }
        
        public class MyContactsTb : UserDataObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMyFollowing { get; set; }

            public new string Details { get; set; }
            public new string MutualFriendsData { get; set; }
        }

        public class MyFollowersTb : UserDataObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMyFollowers { get; set; }

            public new string Details { get; set; }
            public new string MutualFriendsData { get; set; }
        }
        
        public class MyProfileTb : UserDataObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdMyProfile { get; set; }

            public new string Details { get; set; }
            public new string MutualFriendsData { get; set; }
        }

        public class SearchFilterTb
        {
            [PrimaryKey, AutoIncrement]
            public int  AutoIdSearchFilter { get; set; }

            public string Gender { get; set; }
            public string Country { get; set; }
            public string Status { get; set; }
            public string Verified { get; set; }
            public string FilterByAge { get; set; }
            public string AgeFrom { get; set; }
            public string AgeTo { get; set; }
        }
        
        public class WatchOfflineVideosTb : GetMoviesObject.Movie
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdWatchOfflineVideos { get; set; }

            public string VideoName { get; set; }
            public string VideoSavedPath { get; set; }
        }

        public class NearByFilterTb
        {

            [PrimaryKey, AutoIncrement] public int AutoIdNearByFilter { get; set; }
            
            public int DistanceValue { get; set; }
            public int Gender { get; set; }
            public int Status { get; set; }
        }


        public class GiftsTb : GiftObject.DataGiftObject
        {
            [PrimaryKey, AutoIncrement]
            public int AutoIdGift { get; set; } 
        } 
    }
}