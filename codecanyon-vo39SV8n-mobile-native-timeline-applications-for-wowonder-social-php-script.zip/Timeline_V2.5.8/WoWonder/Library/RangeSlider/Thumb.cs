﻿namespace WoWonder.Library.RangeSlider
{
    public enum Thumb
    {
        Upper,
        Lower
    }
}
