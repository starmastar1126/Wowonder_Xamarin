﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Support.V7.Content.Res;
using Android.Util;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Requests;

namespace WoWonder.Library.Anjo
{
    public class ReactButton : Button  
    {
        //ReactButton custom view object to make easy to change attribute
        private ReactButton MReactButton;

        //Reaction Alert Dialog to show Reaction layout with 6 Reactions
        private Android.Support.V7.App.AlertDialog MReactAlertDialog;
       
        //react current state as boolean variable is false in default state and true in all other states
        private bool MCurrentReactState;

        //ImagesButton one for every Reaction
        private ImageView MImgButtonOne;
        private ImageView MImgButtonTwo;
        private ImageView MImgButtonThree;
        private ImageView MImgButtonFour;
        private ImageView MImgButtonFive;
        private ImageView MImgButtonSix;

        //Number of Valid Reactions
        private static readonly int ReactionsNumber = 6;

        //Array of ImagesButton to set any action for all
        private readonly ImageView[] MReactImgArray = new ImageView[ReactionsNumber];

        //Reaction Object to save default Reaction
        private Reaction MDefaultReaction = XReactions.GetDefaultReact();

        //Reaction Object to save the current Reaction
        private Reaction MCurrentReaction;

        //Array of six Reaction one for every ImageButton Icon
        private List<Reaction>  MReactionPack = XReactions.GetReactions();

        //Integer variable to change react dialog shape Default value is react_dialog_shape
        private int MReactDialogShape = Resource.Xml.react_dialog_shape;
          
        private GlobalClickEventArgs PostData;
        private string NamePage;
        private readonly Context Context;

        protected ReactButton(IntPtr javaReference, JniHandleOwnership transfer) : base(javaReference, transfer)
        {
        }

        public ReactButton(Context context) : base(context)
        {
            Context = context;
            Init();
            ReactButtonDefaultSetting();
        }

        public ReactButton(Context context, IAttributeSet attrs) : base(context, attrs)
        {
            Context = context;
            Init();
            ReactButtonDefaultSetting();
        }

        public ReactButton(Context context, IAttributeSet attrs, int defStyleAttr) : base(context, attrs, defStyleAttr)
        {
            Context = context;
            Init();
            ReactButtonDefaultSetting();
        }

        public ReactButton(Context context, IAttributeSet attrs, int defStyleAttr, int defStyleRes) : base(context, attrs, defStyleAttr, defStyleRes)
        {
            Context = context;
            Init();
            ReactButtonDefaultSetting();
        }
         
        private void Init()
        {
            try
            {
                MReactButton = this;
                MDefaultReaction = XReactions.GetDefaultReact();
                MCurrentReaction = MDefaultReaction;

                AppCompatDelegate.CompatVectorFromResourcesEnabled = true; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// Method with 2 state set first React or back to default state
        /// </summary>
        public void ClickLikeAndDisLike(GlobalClickEventArgs postData, string namePage = "")
        {
            try
            {
                PostData = postData;
                NamePage = namePage;
                
                //Code When User Click On Button
                //If State is true , dislike The Button And Return To Default State  

                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Application.Context, Application.Context.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    return;
                }
                 
                if (MCurrentReactState)
                {
                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                    {
                        switch (PostData.NewsFeedClass.Reaction.Type)
                        {
                            case "Like":
                                PostData.NewsFeedClass.Reaction.Like--;
                                break;
                            case "Love":
                                PostData.NewsFeedClass.Reaction.Love--;
                                break;
                            case "HaHa":
                                PostData.NewsFeedClass.Reaction.HaHa--;
                                break;
                            case "Wow":
                                PostData.NewsFeedClass.Reaction.Wow--;
                                break;
                            case "Sad":
                                PostData.NewsFeedClass.Reaction.Sad--;
                                break;
                            case "Angry":
                                PostData.NewsFeedClass.Reaction.Angry--;
                                break;  
                        }
                        PostData.NewsFeedClass.Reaction.Type = "Default";
                    }

                    UpdateReactButtonByReaction(MDefaultReaction);

                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                    {
                        if (PostData.NewsFeedClass.Reaction == null)
                            PostData.NewsFeedClass.Reaction = new WoWonderClient.Classes.Posts.Reaction();

                        if (PostData.NewsFeedClass.Reaction != null)
                        {
                            PostData.NewsFeedClass.Reaction.Count--;
                           
                            PostData.NewsFeedClass.Reaction.IsReacted = false; 
                        }
                    }
                    else
                    {
                        var x = Convert.ToInt32(PostData.NewsFeedClass.PostLikes);
                        if (x > 0)
                            x--;
                        else
                            x = 0;

                        PostData.NewsFeedClass.IsLiked = false; 
                        PostData.NewsFeedClass.PostLikes = Convert.ToString(x, CultureInfo.InvariantCulture);
                    }

                    if (NamePage == "ImagePostViewerActivity" || NamePage == "MultiImagesPostViewerActivity")
                    {
                        var likeCount = PostData.View?.FindViewById<TextView>(Resource.Id.LikeText1);
                        if (likeCount != null && !likeCount.Text.Contains("K") && !likeCount.Text.Contains("M"))
                        {
                            var x = Convert.ToInt32(likeCount.Text);
                            if (x > 0)
                                x--;
                            else
                                x = 0;

                            likeCount.Text = Convert.ToString(x, CultureInfo.InvariantCulture);
                        }
                    }
                    else
                    {
                        var likeCount = PostData.View?.FindViewById<TextView>(Resource.Id.Likecount);
                        if (likeCount != null) 
                        {
                            if (AppSettings.PostButton == PostButtonSystem.Reaction)
                            {
                                likeCount.Text = PostData.NewsFeedClass.Reaction.Count + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                            else
                            { 
                                likeCount.Text = PostData.NewsFeedClass.PostLikes + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                        }

                        // If Post Type Share 
                        var likeCount2 = PostData.View?.FindViewById<TextView>(Resource.Id.Likecount2);
                        if (likeCount2 != null)
                        {
                            if (AppSettings.PostButton == PostButtonSystem.Reaction)
                            {
                                likeCount2.Text = PostData.NewsFeedClass.Reaction.Count + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                            else
                            {
                                likeCount2.Text = PostData.NewsFeedClass.PostLikes + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                        }
                    }

                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                        RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "").ConfigureAwait(false);
                    else  
                        RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "like").ConfigureAwait(false);
                }
                else
                {
                    UpdateReactButtonByReaction(MReactionPack[0]);

                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                    {
                        if (PostData.NewsFeedClass.Reaction == null)
                            PostData.NewsFeedClass.Reaction = new WoWonderClient.Classes.Posts.Reaction();

                        PostData.NewsFeedClass.Reaction.Count++;
                        PostData.NewsFeedClass.Reaction.Like++;
                        PostData.NewsFeedClass.Reaction.Type = "Like";
                        PostData.NewsFeedClass.Reaction.IsReacted = true;
                    }
                    else
                    {
                        var x = Convert.ToInt32(PostData.NewsFeedClass.PostLikes);
                        x++;

                        PostData.NewsFeedClass.IsLiked = true; 
                        PostData.NewsFeedClass.PostLikes = Convert.ToString(x, CultureInfo.InvariantCulture);
                    }
                     
                    if (NamePage == "ImagePostViewerActivity" || NamePage == "MultiImagesPostViewerActivity")
                    {
                        var likeCount = PostData.View?.FindViewById<TextView>(Resource.Id.LikeText1);

                        if (likeCount != null && (!likeCount.Text.Contains("K") && !likeCount.Text.Contains("M")))
                        {
                            var x = Convert.ToInt32(likeCount.Text);
                            x++;

                            likeCount.Text = Convert.ToString(x, CultureInfo.InvariantCulture);
                        }
                    }
                    else
                    {
                        var likeCount = PostData.View?.FindViewById<TextView>(Resource.Id.Likecount);
                        if (likeCount != null)
                        {
                            if (AppSettings.PostButton == PostButtonSystem.Reaction)
                            {
                                likeCount.Text = PostData.NewsFeedClass.Reaction.Count + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                            else
                            {
                                likeCount.Text = PostData.NewsFeedClass.PostLikes + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                        }

                        // If Post Type Share
                        var likeCount2 = PostData.View?.FindViewById<TextView>(Resource.Id.Likecount2);
                        if (likeCount2 != null)
                        {
                            if (AppSettings.PostButton == PostButtonSystem.Reaction)
                            {
                                likeCount2.Text = PostData.NewsFeedClass.Reaction.Count + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            }
                            else
                            {
                                likeCount2.Text = PostData.NewsFeedClass.PostLikes + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                            } 
                        }
                    }
                     
                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                        RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "Like").ConfigureAwait(false);
                    else  
                        RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "like").ConfigureAwait(false);
                }

                var dataPost = WRecyclerView.GetInstance()?.NativeFeedAdapter?.PostFeedList?.FirstOrDefault(q => q.PostData?.PostId == PostData.NewsFeedClass?.PostId);
                if (dataPost != null)
                {
                    dataPost.PostData = PostData.NewsFeedClass;

                    var indexPost = WRecyclerView.GetInstance().NativeFeedAdapter.PostFeedList.IndexOf(dataPost);
                    if (indexPost > -1)
                    {
                        // WRecyclerView.GetInstance()?.NativeFeedAdapter.NotifyItemChanged(indexPost);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// Show Reaction dialog when user long click on react button
        /// </summary>
        public void LongClickDialog(GlobalClickEventArgs postData , string namePage = "")
        {
            try
            {
                PostData = postData;
                NamePage = namePage;

                //Show Dialog With 6 React
                Android.Support.V7.App.AlertDialog.Builder dialogBuilder = new Android.Support.V7.App.AlertDialog.Builder(Context);

                //Irrelevant code for customizing the buttons and title
                LayoutInflater inflater = (LayoutInflater)Context.GetSystemService(Context.LayoutInflaterService);
                View dialogView = inflater.Inflate(Resource.Layout.XReactDialogLayout, null);

                InitializingReactImages(dialogView);
                SetReactionsArray();
                ResetReactionsIcons();
                ClickImageButtons();

                dialogBuilder.SetView(dialogView);
                MReactAlertDialog = dialogBuilder.Create();
                MReactAlertDialog.Window.SetBackgroundDrawableResource(MReactDialogShape);

                Window window = MReactAlertDialog.Window;
                window.SetLayout(ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent);

                MReactAlertDialog.Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            } 
        }

        public void SetReactionPack(string type)
        {
            try
            {
                if (type == ReactConstants.Like)
                {
                    UpdateReactButtonByReaction(MReactionPack[0]);
                }
                else if (type == ReactConstants.Love)
                {
                    UpdateReactButtonByReaction(MReactionPack[1]);
                }
                else if (type == ReactConstants.HaHa)
                {
                    UpdateReactButtonByReaction(MReactionPack[2]);
                }
                else if (type == ReactConstants.Wow)
                {
                    UpdateReactButtonByReaction(MReactionPack[3]);
                }
                else if (type == ReactConstants.Sad)
                {
                    UpdateReactButtonByReaction(MReactionPack[4]);
                }
                else if (type == ReactConstants.Angry)
                {
                    UpdateReactButtonByReaction(MReactionPack[5]);
                }
                else  
                {
                    UpdateReactButtonByReaction(XReactions.GetDefaultReact());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="view">View Object to initialize all ImagesButton</param>
        private void InitializingReactImages(View view)
        {
            MImgButtonOne = view.FindViewById<ImageView>(Resource.Id.imgButtonOne);
            MImgButtonTwo = view.FindViewById<ImageView>(Resource.Id.imgButtonTwo);
            MImgButtonThree = view.FindViewById<ImageView>(Resource.Id.imgButtonThree);
            MImgButtonFour = view.FindViewById<ImageView>(Resource.Id.imgButtonFour);
            MImgButtonFive = view.FindViewById<ImageView>(Resource.Id.imgButtonFive);
            MImgButtonSix = view.FindViewById<ImageView>(Resource.Id.imgButtonSix);
             
            Glide.With(Context).Load(Resource.Drawable.like).Apply(new RequestOptions().FitCenter()).Into(MImgButtonOne);
            Glide.With(Context).Load(Resource.Drawable.love).Apply(new RequestOptions().FitCenter()).Into(MImgButtonTwo);
            Glide.With(Context).Load(Resource.Drawable.haha).Apply(new RequestOptions().FitCenter()).Into(MImgButtonThree);
            Glide.With(Context).Load(Resource.Drawable.wow).Apply(new RequestOptions().FitCenter()).Into(MImgButtonFour);
            Glide.With(Context).Load(Resource.Drawable.sad).Apply(new RequestOptions().FitCenter()).Into(MImgButtonFive);
            Glide.With(Context).Load(Resource.Drawable.angry).Apply(new RequestOptions().FitCenter()).Into(MImgButtonSix);
        }

        /// <summary>
        /// Put all ImagesButton on Array
        /// </summary>
        private void SetReactionsArray()
        {
            MReactImgArray[0] = MImgButtonOne;
            MReactImgArray[1] = MImgButtonTwo;
            MReactImgArray[2] = MImgButtonThree;
            MReactImgArray[3] = MImgButtonFour;
            MReactImgArray[4] = MImgButtonFive;
            MReactImgArray[5] = MImgButtonSix;
        }


        /// <summary>
        /// Set onClickListener For every Image Buttons on Reaction Dialog
        /// </summary>
        private void ClickImageButtons()
        { 
            ImgButtonSetListener(MImgButtonOne, 0);
            ImgButtonSetListener(MImgButtonTwo, 1);
            ImgButtonSetListener(MImgButtonThree, 2);
            ImgButtonSetListener(MImgButtonFour, 3);
            ImgButtonSetListener(MImgButtonFive, 4);
            ImgButtonSetListener(MImgButtonSix, 5); 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="imgButton">ImageButton view to set onClickListener</param>
        /// <param name="reactIndex">Index of Reaction to take it from ReactionPack</param>
        private void ImgButtonSetListener(ImageView imgButton, int reactIndex)
        {
            if (!imgButton.HasOnClickListeners)
                imgButton.Click += (sender, e) => ImgButtonOnClick(new ReactionsClickEventArgs { ImgButton = imgButton, Position = reactIndex });
        }

        private void ImgButtonOnClick(ReactionsClickEventArgs e)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Application.Context, Application.Context.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    return;
                }

                Reaction data = MReactionPack[e.Position];
                UpdateReactButtonByReaction(data);
                MReactAlertDialog.Dismiss();
                
                if (PostData.NewsFeedClass.Reaction == null)
                    PostData.NewsFeedClass.Reaction = new WoWonderClient.Classes.Posts.Reaction();

                PostData.NewsFeedClass.Reaction.Count++;

                if (!PostData.NewsFeedClass.Reaction.IsReacted)
                {
                    PostData.NewsFeedClass.Reaction.IsReacted = true;

                    if (NamePage == "ImagePostViewerActivity" || NamePage == "MultiImagesPostViewerActivity")
                    {
                        var likeCount = PostData.View?.FindViewById<TextView>(Resource.Id.LikeText1);

                        if (likeCount != null && (!likeCount.Text.Contains("K") && !likeCount.Text.Contains("M")))
                        {
                            var x = Convert.ToInt32(likeCount.Text);
                            x++;

                            likeCount.Text = Convert.ToString(x, CultureInfo.InvariantCulture);
                        }
                    }
                    else
                    {
                        var likeCount = PostData.View?.FindViewById<TextView>(Resource.Id.Likecount);
                        if (likeCount != null)
                        {
                            likeCount.Text = PostData.NewsFeedClass.Reaction.Count + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                        }

                        // If Post Type Share 
                        var likeCount2 = PostData.View?.FindViewById<TextView>(Resource.Id.Likecount2);
                        if (likeCount2 != null)
                        {
                            likeCount2.Text = PostData.NewsFeedClass.Reaction.Count + " " + Application.Context.Resources.GetString(Resource.String.Btn_Likes);
                        }
                    }
                }

                if (data.GetReactText() == ReactConstants.Like)
                {
                    PostData.NewsFeedClass.Reaction.Type = "Like";
                    PostData.NewsFeedClass.Reaction.Like++;
                    RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "Like").ConfigureAwait(false);
                }
                else if (data.GetReactText() == ReactConstants.Love)
                {
                    PostData.NewsFeedClass.Reaction.Type = "Love";
                    PostData.NewsFeedClass.Reaction.Love++;
                    RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "Love").ConfigureAwait(false);
                }
                else if (data.GetReactText() == ReactConstants.HaHa)
                {
                    PostData.NewsFeedClass.Reaction.Type = "HaHa";
                    PostData.NewsFeedClass.Reaction.HaHa++;
                    RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "HaHa").ConfigureAwait(false);
                }
                else if (data.GetReactText() == ReactConstants.Wow)
                {
                    PostData.NewsFeedClass.Reaction.Type = "Wow";
                    PostData.NewsFeedClass.Reaction.Wow++;
                    RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "Wow").ConfigureAwait(false);
                }
                else if (data.GetReactText() == ReactConstants.Sad)
                {
                    PostData.NewsFeedClass.Reaction.Type = "Sad";
                    PostData.NewsFeedClass.Reaction.Sad++;
                    RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "Sad").ConfigureAwait(false);
                }
                else if (data.GetReactText() == ReactConstants.Angry)
                {
                    PostData.NewsFeedClass.Reaction.Type = "Angry";
                    PostData.NewsFeedClass.Reaction.Angry++;
                    RequestsAsync.Global.Post_Actions(PostData.NewsFeedClass.PostId, "reaction", "Angry").ConfigureAwait(false);
                }

                var dataPost = WRecyclerView.GetInstance()?.NativeFeedAdapter?.PostFeedList?.FirstOrDefault(q => q.PostData?.PostId == PostData.NewsFeedClass?.PostId);
                if (dataPost != null)
                {
                    dataPost.PostData = PostData.NewsFeedClass;

                    var indexPost = WRecyclerView.GetInstance().NativeFeedAdapter.PostFeedList.IndexOf(dataPost);
                    if (indexPost > -1)
                    {
                        // WRecyclerView.GetInstance()?.NativeFeedAdapter.NotifyItemChanged(indexPost);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            } 
        }

        /// <summary>
        /// Update All Reaction ImageButton one by one from Reactions array
        /// </summary>
        private void ResetReactionsIcons()
        {
            for (int index = 0; index < ReactionsNumber; index++)
            {
                MReactImgArray[index].SetImageResource(MReactionPack[index].GetReactIconId());
            }
        }
        
        /// <summary>
        /// Simple Method to set default settings for ReactButton Constructors
        /// - Default Text Is Like
        /// - set onClick And onLongClick
        /// - set Default image is Dark Like
        /// </summary>
        private void ReactButtonDefaultSetting()
        {
            MReactButton.Text = MDefaultReaction.GetReactText();
            //MReactButton.SetOnClickListener(this);
            //MReactButton.SetOnLongClickListener(this);

            Drawable icon;
            if (MReactButton.Text == ReactConstants.Like)
            {
                icon = AppCompatResources.GetDrawable(Context, MDefaultReaction.GetReactType() == ReactConstants.Default ? Resource.Drawable.ic_action_like : Resource.Drawable.like);
            }
            else if (MReactButton.Text == ReactConstants.Love)
            {
                icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.love);
            }
            else if (MReactButton.Text == ReactConstants.HaHa)
            {
                icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.haha);
            }
            else if (MReactButton.Text == ReactConstants.Wow)
            {
                icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.wow);
            }
            else if (MReactButton.Text == ReactConstants.Sad)
            {
                icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.sad);
            }
            else if (MReactButton.Text == ReactConstants.Angry)
            {
                icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.angry);
            }
            else
            {
                icon = AppCompatResources.GetDrawable(Context, MDefaultReaction.GetReactIconId());
            }

            // Drawable icon = Build.VERSION.SdkInt < BuildVersionCodes.Lollipop ? VectorDrawableCompat.Create(Context.Resources, MDefaultReaction.GetReactIconId(), Context.Theme) : AppCompatResources.GetDrawable(Context, MDefaultReaction.GetReactIconId());

            //if (AppSettings.FlowDirectionRightToLeft)
            //    MReactButton.SetCompoundDrawablesWithIntrinsicBounds(0, 0, MDefaultReaction.GetReactIconId(), 0);
            //else
            //    MReactButton.SetCompoundDrawablesWithIntrinsicBounds(MDefaultReaction.GetReactIconId(), 0, 0, 0);

            MReactButton.CompoundDrawablePadding = 20;

            if (AppSettings.FlowDirectionRightToLeft)
                MReactButton.SetCompoundDrawablesWithIntrinsicBounds(null, null, icon, null);
            else
                MReactButton.SetCompoundDrawablesWithIntrinsicBounds(icon, null, null, null);
        }
         
        /// <summary>
        /// 
        /// </summary>
        /// <param name="shapeId">Get xml Shape for react dialog layout</param>
        public void SetReactionDialogShape(int shapeId)
        {
            //Set Shape for react dialog layout
            MReactDialogShape = shapeId;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="react">Reaction to update UI by take attribute from it</param>
        private void UpdateReactButtonByReaction(Reaction react)
        {
            try
            {
                MCurrentReaction = react;
                MReactButton.Text = react.GetReactText();
                MReactButton.SetTextColor(Color.ParseColor(react.GetReactTextColor()));

                //Drawable icon = Build.VERSION.SdkInt < BuildVersionCodes.Lollipop ? VectorDrawableCompat.Create(Context.Resources, react.GetReactIconId(), Context.Theme) : AppCompatResources.GetDrawable(Context,react.GetReactIconId());

                Drawable icon;
                if (MReactButton.Text == ReactConstants.Like)
                {
                    icon = AppCompatResources.GetDrawable(Context, react.GetReactType() == ReactConstants.Default ? Resource.Drawable.ic_action_like : Resource.Drawable.like);
                }
                else if (MReactButton.Text == ReactConstants.Love)
                {
                    icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.love);
                }
                else if (MReactButton.Text == ReactConstants.HaHa)
                {
                    icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.haha);
                }
                else if (MReactButton.Text == ReactConstants.Wow)
                {
                    icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.wow);
                }
                else if (MReactButton.Text == ReactConstants.Sad)
                {
                    icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.sad);
                }
                else if (MReactButton.Text == ReactConstants.Angry)
                {
                    icon = AppCompatResources.GetDrawable(Context, Resource.Drawable.angry);
                }
                else
                {
                    icon = AppCompatResources.GetDrawable(Context, react.GetReactIconId()); 
                }
                 
                if (AppSettings.FlowDirectionRightToLeft)
                    MReactButton.SetCompoundDrawablesWithIntrinsicBounds(null, null, icon, null);

                else
                    MReactButton.SetCompoundDrawablesWithIntrinsicBounds(icon, null, null, null);

                MReactButton.CompoundDrawablePadding = 20;

                MCurrentReactState = !react.GetReactType().Equals(MDefaultReaction.GetReactType());
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        /// <summary>
        /// 
        /// </summary>
        /// <param name="reactions">Array of six Reactions to update default six Reactions</param>
        public void SetReactions(List<Reaction> reactions)
        {
            //Assert that Reactions number is six
            if (reactions.Count != ReactionsNumber)
                return;

            //Update array of library default reactions
            MReactionPack = reactions;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reaction">set This Reaction as current Reaction</param>
        public void SetCurrentReaction(Reaction reaction)
        {
            UpdateReactButtonByReaction(reaction);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>The Current reaction Object</returns>
        public Reaction GetCurrentReaction()
        {
            return MCurrentReaction;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reaction">Update library default Reaction by other Reaction</param>
        public void SetDefaultReaction(Reaction reaction)
        {
            MDefaultReaction = reaction;
            UpdateReactButtonByReaction(MDefaultReaction);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>The current default Reaction object</returns>
        public Reaction GetDefaultReaction()
        {
            return MDefaultReaction;
        }
         
        /// <summary>
        /// 
        /// </summary>
        /// <returns>true if current reaction type is default</returns>
        public bool IsDefaultReaction()
        {
            return MCurrentReaction.Equals(MDefaultReaction);
        }
          
    }
}