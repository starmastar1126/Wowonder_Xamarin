﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.Content;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using Com.Github.Library.Bubbleview;
using Com.Luseen.Autolinklibrary;
using Com.Tuyenmonkey.Textdecorator;
using Java.Util;
using Refractored.Controls;
using WoWonder.Activities.NativePost.Holders;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient;
using WoWonderClient.Classes.Comments;
using WoWonderClient.Requests;
using IList = System.Collections.IList;
using Object = Java.Lang.Object;

namespace WoWonder.Activities.NativePost.Comment
{ 
    public class ReplyCommentAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    { 
        public string EmptyState = "Wo_Empty_State"; 
        private readonly ReplyCommentActivity ActivityContext; 
        public ObservableCollection<GetCommentObject> ReplyCommentList = new ObservableCollection<GetCommentObject>();
        private readonly RecyclerView MainRecyclerView;
        private readonly LinearLayoutManager MainLinearLayoutManager; 
        private readonly RecyclerScrollListener MainScrollEvent;
        private string ApiIdParameter { get;  set; }

        public ReplyCommentAdapter(ReplyCommentActivity context, RecyclerView mainRecyclerView,string commentId)
        {
            try
            {
                HasStableIds = true;
                ActivityContext = context;
                MainRecyclerView = mainRecyclerView;
              
                ApiIdParameter = commentId;

                MainLinearLayoutManager = new LinearLayoutManager(context);
                MainRecyclerView.SetLayoutManager(MainLinearLayoutManager);
                
                var sizeProvider = new FixedPreloadSizeProvider(10, 10);
                var preLoader = new RecyclerViewPreloader<GetCommentObject>(context, this, sizeProvider, 8);
                MainRecyclerView.AddOnScrollListener(preLoader);

                MainRecyclerView.SetAdapter(this);
                MainRecyclerView.HasFixedSize = true;
                MainRecyclerView.SetItemViewCacheSize(10);
                MainRecyclerView.ClearAnimation();
                MainRecyclerView.GetLayoutManager().ItemPrefetchEnabled = true;
                MainRecyclerView.SetItemViewCacheSize(10);

                MainScrollEvent = new RecyclerScrollListener(context, this);
                MainRecyclerView.AddOnScrollListener(MainScrollEvent);
                MainScrollEvent.LoadMoreEvent += MainScrollEvent_LoadMoreEvent;
                MainScrollEvent.IsLoading = false;

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount => ReplyCommentList?.Count ?? 0;

         



        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                switch (viewType)
                {
                    case 0: return new ReplyCommentAdapterViewHolder(LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Comment, parent, false));
                    case 1: return new ReplyCommentAdapterViewHolder(LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Comment_Image, parent, false));
                    case 666: return new MainHolders.EmptyStateAdapterViewHolder(LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_EmptyState, parent, false));
                    default:
                        return new ReplyCommentAdapterViewHolder(LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Comment, parent, false));
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }


        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder.ItemViewType == 666)
                {
                    if (!(viewHolder is MainHolders.EmptyStateAdapterViewHolder emptyHolder))
                        return;

                    emptyHolder.EmptyText.Text = "No Replies to be displayed";
                    return;
                }

                if (!(viewHolder is ReplyCommentAdapterViewHolder holder))
                    return;

                var item = ReplyCommentList[position];
                if (item == null)
                    return;

                if (AppSettings.FlowDirectionRightToLeft)
                    holder.BubbleLayout.LayoutDirection = LayoutDirection.Rtl;  

                var changer = new TextSanitizer(holder.CommentText, ActivityContext);
                changer.Load(Methods.FunString.DecodeString(item.Text)); 

                if (holder.TimeTextView.Tag?.ToString() == "true")
                    return;

                holder.TimeTextView.Text = Methods.Time.TimeAgo(int.Parse(item.Time));
                holder.UserName.Text = item.Publisher.Name;
                GlideImageLoader.LoadImage(ActivityContext, item.Publisher.Avatar, holder.Image, ImageStyle.CircleCrop, ImagePlaceholders.Color);
                 
                var textHighLighter = item.Publisher.Name;
                var textIsPro = string.Empty;

                if (item.Publisher.Verified == "1")
                    textHighLighter += " " + IonIconsFonts.CheckmarkCircled;

                if (item.Publisher.IsPro == "1")
                {
                    textIsPro = " " + IonIconsFonts.Flash;
                    textHighLighter += textIsPro;
                }

                var decorator = TextDecorator.Decorate(holder.UserName, textHighLighter)
                    .SetTextStyle((int)TypefaceStyle.Bold, 0, item.Publisher.Name.Length);

                if (item.Publisher.Verified == "1")
                    decorator.SetTextColor(Resource.Color.Post_IsVerified, IonIconsFonts.CheckmarkCircled);

                if (item.Publisher.IsPro == "1")
                    decorator.SetTextColor(Resource.Color.text_color_in_between, textIsPro);

                decorator.Build();

                if (holder.ItemViewType == 1)
                    if (!string.IsNullOrEmpty(item.CFile) && (item.CFile.Contains("file://") || item.CFile.Contains("content://") || item.CFile.Contains("storage")))
                    {
                        GlideImageLoader.LoadImage(ActivityContext, item.CFile, holder.CommentImage, ImageStyle.CenterCrop, ImagePlaceholders.Color);
                    }
                    else
                    {
                        GlideImageLoader.LoadImage(ActivityContext, Client.WebsiteUrl + "/" + item.CFile, holder.CommentImage, ImageStyle.CenterCrop, ImagePlaceholders.Color);
                    }

                if (item.IsCommentLiked)
                {
                    holder.LikeTextView.Text = ActivityContext.GetText(Resource.String.Btn_Liked); 
                    holder.LikeTextView.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                    holder.LikeTextView.Tag = "Liked";
                }
                else
                {
                    holder.LikeTextView.Text = ActivityContext.GetText(Resource.String.Btn_Like);
                    holder.LikeTextView.SetTextColor(Color.ParseColor("#444444"));
                    holder.LikeTextView.Tag = "Like";
                }
                  
                holder.TimeTextView.Tag = "true";

                if (holder.Image.HasOnClickListeners)
                    return;
                 
                var postEventListener = new CommentClickListener(ActivityContext, "Reply");

                //Create an Event 
                holder.MainView.LongClick += (sender, e) => postEventListener.MoreCommentReplyPostClick(new CommentReplyClickEventArgs { CommentObject = item, Position = position, View = holder.MainView });

                holder.Image.Click += (sender, args) => postEventListener.ProfilePostClick(new ProfileClickEventArgs { Holder = holder, CommentClass = item, Position = position, View = holder.MainView });

                holder.ReplyTextView.Click += (sender, args) =>
                {
                    try
                    {
                        ActivityContext.TxtComment.Text = "";
                        ActivityContext.TxtComment.Text = "@" + item.Publisher.Username + " ";
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                };
                 
                holder.LikeTextView.Click += delegate
                {
                    try
                    {
                        if (holder.LikeTextView.Tag.ToString() == "Liked")
                        {
                            item.IsCommentLiked = false;

                            holder.LikeTextView.Text = ActivityContext.GetText(Resource.String.Btn_Like);
                            holder.LikeTextView.SetTextColor(Color.ParseColor("#444444"));
                            holder.LikeTextView.Tag = "Like";

                            //sent api Dislike comment 
                            RequestsAsync.Comment.LikeUnLikeCommentAsync(item.Id, false).ConfigureAwait(false);
                        }
                        else
                        {
                            item.IsCommentLiked = true;

                            holder.LikeTextView.Text = ActivityContext.GetText(Resource.String.Btn_Liked);
                            holder.LikeTextView.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                            holder.LikeTextView.Tag = "Liked";

                            //sent api like comment 
                            RequestsAsync.Comment.LikeUnLikeCommentAsync(item.Id, true).ConfigureAwait(false);
                        } 
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                };

                holder.CommentImage.Click += (sender, args) => postEventListener.OpenImageLightBox(item);

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

      
        public GetCommentObject GetItem(int position)
        {
            return ReplyCommentList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(ReplyCommentList[position].Id);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            { 
                if (string.IsNullOrEmpty(ReplyCommentList[position].CFile) && ReplyCommentList[position].Text != EmptyState)
                    return 0;
                else if (ReplyCommentList[position].Text == EmptyState)
                    return 666;
                else
                    return 1;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }


        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = ReplyCommentList[p0];
                if (item == null)
                    return d;
                else
                {
                    if (item.Text != EmptyState)
                    {
                        if (!string.IsNullOrEmpty(item.CFile))
                            d.Add(item.CFile);

                        if (!string.IsNullOrEmpty(item.Publisher.Avatar))
                            d.Add(item.Publisher.Avatar);

                        return d;
                    }

                    return Collections.SingletonList(p0);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
               return Collections.SingletonList(p0);
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.CenterCrop);
        }

        public class RecyclerScrollListener : RecyclerView.OnScrollListener
        {
            public delegate void LoadMoreEventHandler(object sender, EventArgs e);

            public event LoadMoreEventHandler LoadMoreEvent;

            public bool IsLoading { get; set; }

            private ReplyCommentAdapter PostAdapter;
            private Context Context;
            private LinearLayoutManager LayoutManager;

            public RecyclerScrollListener(Context ctx, ReplyCommentAdapter adapter)
            {
                PostAdapter = adapter;
                Context = ctx;
                IsLoading = false;
            }

            public override void OnScrolled(RecyclerView recyclerView, int dx, int dy)
            {
                base.OnScrolled(recyclerView, dx, dy);


                if (LayoutManager == null)
                    LayoutManager = (LinearLayoutManager)recyclerView.GetLayoutManager();

                var visibleItemCount = recyclerView.ChildCount;
                var totalItemCount = recyclerView.GetAdapter().ItemCount;

                var pastItems = LayoutManager.FindFirstVisibleItemPosition();

                if (visibleItemCount + pastItems + 4 < totalItemCount)
                    return;

                if (IsLoading)
                    return;

                LoadMoreEvent?.Invoke(this, null);
            }
        }

        private void MainScrollEvent_LoadMoreEvent(object sender, EventArgs e)
        {
            MainScrollEvent.IsLoading = true;

           
            var item = ReplyCommentList?.LastOrDefault()?.Id;

            if (ReplyCommentList?.Count <= 3)
                item ="";

            if (item == null)
                return;

            if (!Methods.CheckConnectivity())
                Toast.MakeText(ActivityContext, ActivityContext.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => FetchPostApiComments(item, ApiIdParameter) });
        }

        public async Task FetchPostApiComments(string offset,string postId)
        {
            try
            {
               var (apiStatus, respond) = await RequestsAsync.Comment.GetPostComments(postId,"32", offset, "fetch_comments_reply");

                if (apiStatus == 200)
                {
                    if (respond is Comments result)
                    {
                        if (result.CommentList.Count > 0)
                        {
                            var postsCount = ReplyCommentList.Count;

                            if (postsCount == 0)
                            {
                                ReplyCommentList = new ObservableCollection<GetCommentObject>(result.CommentList);
                                NotifyDataSetChanged();
                                MainScrollEvent.IsLoading = false;
                            }
                            else
                            {
                                foreach (var comment in result.CommentList)
                                    if (ReplyCommentList.FirstOrDefault(a=>a.Id== comment.Id)==null)
                                        ReplyCommentList.Add(comment);

                                NotifyItemRangeInserted(postsCount + 1, ReplyCommentList.Count);
                                MainScrollEvent.IsLoading = false;

                            }
                        }
                        else
                        {
                            MainScrollEvent.IsLoading = true;
                        }

                    }
                }
                else Methods.DisplayReportResult(ActivityContext, respond);



                if (ReplyCommentList.Count > 0)
                {
                    var emptyStateChecker = ReplyCommentList.FirstOrDefault(a => a.Text == EmptyState);
                    if (emptyStateChecker != null && ReplyCommentList.Count>1)
                    {
                        ReplyCommentList.Remove(emptyStateChecker);
                        NotifyDataSetChanged();
                    }
                }
                else
                {
                    var d = new GetCommentObject { Text = EmptyState};
                    ReplyCommentList.Add(d);
                    NotifyDataSetChanged();
                }
                
            }
            catch (Exception e)
            {
                MainScrollEvent.IsLoading = false;
                Console.WriteLine(e);
            }
        }
    }

    public class ReplyCommentAdapterViewHolder : RecyclerView.ViewHolder
    {
        #region Variables Basic

        public View MainView { get; private set; }
        public BubbleLinearLayout BubbleLayout { get; private set; }

        public CircleImageView Image { get; private set; }
        public AutoLinkTextView CommentText { get; private set; }
        public TextView TimeTextView { get; private set; }
        public TextView UserName { get; private set; }
        public TextView ReplyTextView { get; private set; }
        public TextView LikeTextView { get; private set; }

        public ImageView CommentImage { get; private set; }
        #endregion

        public ReplyCommentAdapterViewHolder(View itemView) : base(itemView)
        {
            try
            {
                MainView = itemView;
                BubbleLayout = MainView.FindViewById<BubbleLinearLayout>(Resource.Id.bubble_layout);
                Image = MainView.FindViewById<CircleImageView>(Resource.Id.card_pro_pic);
                CommentText = MainView.FindViewById<AutoLinkTextView>(Resource.Id.active);
                UserName = MainView.FindViewById<TextView>(Resource.Id.username);
                TimeTextView = MainView.FindViewById<TextView>(Resource.Id.time);
                ReplyTextView = MainView.FindViewById<TextView>(Resource.Id.reply);
                LikeTextView = MainView.FindViewById<TextView>(Resource.Id.Like);
                CommentImage = MainView.FindViewById<ImageView>(Resource.Id.image);
               
                var font = Typeface.CreateFromAsset(MainView.Context.Resources.Assets, "ionicons.ttf");
                UserName.SetTypeface(font, TypefaceStyle.Normal);
                ReplyTextView.Visibility = ViewStates.Visible; 

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }


}