﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Com.Theartofdev.Edmodo.Cropper;
using Java.IO;
using Newtonsoft.Json;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Comments;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using Console = System.Console;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.NativePost.Comment
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class CommentActivity : AppCompatActivity
    {
        #region Variables Basic

        private static CommentActivity Instance;
        public CommentAdapter CommentsAdapter;
        private RecyclerView MainRecyclerView;
        private EditText TxtComment;
        private TextView LikeCountBox;
        private ImageView ImgSent, ImgGallery;
        private PostDataObject PostObject; 
        private string PostId,PathImage;
         
        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                Window.SetSoftInputMode(SoftInput.AdjustResize);

                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Native_Comment_Layout);

                Instance = this;

                PostId = Intent.GetStringExtra("PostId") ?? string.Empty; 
                PostObject = JsonConvert.DeserializeObject<PostDataObject>(Intent.GetStringExtra("PostObject"));
                 
                //Get Value And Set Toolbar
                InitComponent();
                
                GetDataPost();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
        
        #region Functions

        private void InitComponent()
        {
            try
            {
                LikeCountBox = FindViewById<TextView>(Resource.Id.like_box);
                MainRecyclerView = FindViewById<RecyclerView>(Resource.Id.recycler_view);
                TxtComment = FindViewById<EditText>(Resource.Id.commenttext);
                ImgSent = FindViewById<ImageView>(Resource.Id.send);
                ImgGallery = FindViewById<ImageView>(Resource.Id.image);

                TxtComment.Text = "";
                PathImage = "";

                CommentsAdapter = new CommentAdapter(this, MainRecyclerView, "Light", PostId)
                {
                    CommentList = PostObject?.GetPostComments?.Count > 0
                        ? new ObservableCollection<GetCommentObject>(PostObject.GetPostComments)
                        : new ObservableCollection<GetCommentObject>()
                };

                
                if (CommentsAdapter.CommentList.Count > 0)
                    CommentsAdapter?.NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    ImgSent.Click += ImgSentOnClick;
                    ImgGallery.Click += ImgGalleryOnClick;
                }
                else
                {
                    ImgSent.Click -= ImgSentOnClick;
                    ImgGallery.Click -= ImgGalleryOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static CommentActivity GetInstance()
        {
            try
            {
                return Instance;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region Events

        //Open Gallery
        private void ImgGalleryOnClick(object sender, EventArgs e)
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    if (AppSettings.ImageCropping)
                        OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                    else
                        new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                }
                else
                {
                    if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                   && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                    {
                        if (AppSettings.ImageCropping)
                            OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                        else
                            new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Api sent Comment
        private async void ImgSentOnClick(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(TxtComment.Text) && string.IsNullOrEmpty(PathImage))
                    return;

                if (Methods.CheckConnectivity())
                {
                    var dataUser = ListUtils.MyProfileList.FirstOrDefault();
                    //Comment Code 
                    
                    int unixTimestamp = (int)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
 
                    GetCommentObject comment = new GetCommentObject
                    {
                        Id = unixTimestamp.ToString(),
                        PostId = PostObject.Id,
                        UserId = UserDetails.UserId,
                        Text = TxtComment.Text, 
                        Time = unixTimestamp.ToString(),  
                        CFile = PathImage,
                        Record = "",
                        Publisher = dataUser, 
                        Url = dataUser?.Url, 
                        Fullurl = PostObject?.PostUrl,
                        Orginaltext = TxtComment.Text,
                        Owner = true,
                        CommentLikes = "0",
                        CommentWonders = "0",
                        IsCommentLiked = false,
                        Replies = "0"
                    };

                    CommentsAdapter.CommentList.Add(comment);

                    var index = CommentsAdapter.CommentList.IndexOf(comment);
                    if (index > -1)
                    {
                        CommentsAdapter.NotifyItemInserted(index);
                    }
                     
                    MainRecyclerView.Visibility = ViewStates.Visible;

                    var dd = CommentsAdapter.CommentList.FirstOrDefault();
                    if (dd?.Text == CommentsAdapter.EmptyState)
                    {
                        CommentsAdapter.CommentList.Remove(dd);
                        CommentsAdapter.NotifyItemRemoved(CommentsAdapter.CommentList.IndexOf(dd));
                    }
                     
                    ImgGallery.SetImageDrawable(GetDrawable(Resource.Drawable.ic_action_AddPost));
                    var text = TxtComment.Text;

                    //Hide keyboard
                    TxtComment.Text = "";

                    (int apiStatus, var respond) =await RequestsAsync.Comment.CreatePostComments(PostObject.PostId, text, PathImage);
                    if (apiStatus == 200)
                    {
                        if (respond is CreateComments result)
                        {
                            var date = CommentsAdapter.CommentList.FirstOrDefault(a => a.Id == comment.Id.ToString()) ?? CommentsAdapter.CommentList.FirstOrDefault(x => x.Id == result.Data.Id.ToString());
                            if (date != null)
                            {
                                date = result.Data;
                                date.Id = result.Data.Id;

                                index = CommentsAdapter.CommentList.IndexOf(CommentsAdapter.CommentList.FirstOrDefault(a => a.Id == unixTimestamp.ToString()));
                                if (index > -1)
                                {
                                    CommentsAdapter.CommentList[index] = result.Data;

                                    //CommentsAdapter.NotifyItemChanged(index);
                                    MainRecyclerView.ScrollToPosition(index);
                                }

                                var dataPost = WRecyclerView.GetInstance()?.NativeFeedAdapter?.PostFeedList?.FirstOrDefault(q => q.PostData?.PostId == PostObject?.PostId);
                                if (dataPost != null && dataPost.PostData != null)
                                {
                                    if (dataPost.PostData.GetPostComments?.Count > 0)
                                    {
                                        var dataComment = dataPost.PostData.GetPostComments.FirstOrDefault(a => a.Id == date.Id);
                                        if (dataComment == null)
                                        {
                                            dataPost.PostData.GetPostComments.Add(date);
                                        }
                                    }
                                    else
                                    {
                                        dataPost.PostData.GetPostComments = new List<GetCommentObject>() { date };
                                    }

                                    dataPost.PostData.PostComments = dataPost.PostData.GetPostComments.Count.ToString();
                                    
                                    var indexPost = WRecyclerView.GetInstance().NativeFeedAdapter.PostFeedList.IndexOf(dataPost);
                                    if (indexPost > -1)
                                    {
                                        WRecyclerView.GetInstance()?.NativeFeedAdapter.NotifyItemChanged(indexPost);
                                    }
                                } 
                            } 
                        }
                    }
                    else Methods.DisplayReportResult(this, respond);

                    //Hide keyboard
                    TxtComment.Text = "";
                    PathImage = "";
                }
                else
                {
                    Toast.MakeText(this, GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        #region Permissions && Result

        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

                //If its from Camera or Gallery  
                if (requestCode == 500)
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Image")
                        {
                            if (!string.IsNullOrEmpty(filepath))
                            {
                                PathImage = filepath;
                                GlideImageLoader.LoadImage(this, PathImage, ImgGallery, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                    } 
                }
                else  if (requestCode == CropImage.CropImageActivityRequestCode)  
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                PathImage = resultUri.Path;
                                GlideImageLoader.LoadImage(this, PathImage, ImgGallery, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long)
                                .Show();
                        }
                    } 
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        if (AppSettings.ImageCropping)
                            OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                        else
                            new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion

        private void GetDataPost()
        {
            try
            { 
                if (PostObject != null)
                {
                    if (PostObject.Reaction == null)
                        PostObject.Reaction = new Reaction();

                    if (PostObject.Reaction != null)
                        LikeCountBox.Text = PostObject.Reaction.Count + " " + GetString(Resource.String.Btn_Likes);
                    else
                        LikeCountBox.Text = "0" + " " + GetString(Resource.String.Btn_Likes);

                    if (PostObject.GetPostComments.Count == 0)
                        StartApiService("0"); 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            } 
        }
         
        private void StartApiService(string offset)
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => CommentsAdapter.FetchPostApiComments(offset, PostId) });
        }

        private void OpenDialogGallery()
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}