﻿using System;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.Tabbes;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.NativePost.Share
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class SharePostActivity : AppCompatActivity
    { 
        #region Variables Basic

        private Toolbar TopToolBar;
        private ImageView PostSectionImage;
        private TextView TxtSharePost, TxtUserName;
        private EditText TxtContentPost; 
        private WRecyclerView MainRecyclerView;
        private NativePostAdapter PostFeedAdapter;
        private GroupClass GroupData;
        private PageClass PageData;
        private PostDataObject PostData;
        private string TypePost = "";

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.SharePostLayout);

                var postdate = Intent.GetStringExtra("ShareToType") ?? "Data not available";
                if (postdate != "Data not available" && !string.IsNullOrEmpty(postdate)) TypePost = postdate; //Group , Page , MyTimeline
                 
                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                GetDataPost();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                TxtSharePost = FindViewById<TextView>(Resource.Id.toolbar_title);
                TxtContentPost = FindViewById<EditText>(Resource.Id.editTxtEmail); 
                PostSectionImage = FindViewById<ImageView>(Resource.Id.postsectionimage); 
                TxtUserName = FindViewById<TextView>(Resource.Id.card_name); 

                TxtContentPost.ClearFocus(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                TopToolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (TopToolBar != null)
                {
                    TopToolBar.Title = GetText(Resource.String.Lbl_SharePost);
                    TopToolBar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(TopToolBar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                MainRecyclerView = FindViewById<WRecyclerView>(Resource.Id.Recyler);
                PostFeedAdapter = new NativePostAdapter(this, MainRecyclerView, NativeFeedType.Global);
                MainRecyclerView.SetXAdapter(PostFeedAdapter, null);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    TxtSharePost.Click += TxtSharePostOnClick;
                }
                else
                {
                    TxtSharePost.Click -= TxtSharePostOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Event

        //Share Post 
        private async void TxtSharePostOnClick(object sender, EventArgs e)
        {
            try
            {
                if (TypePost == "Group")
                {
                    (int apiStatus, dynamic respond) = await RequestsAsync.Posts.SharePostToAsync(PostData.PostId, GroupData.GroupId, "share_post_on_group", TxtContentPost.Text);
                    ResultApi(apiStatus, respond);
                }
                else if (TypePost == "Page")
                { 
                    (int apiStatus, dynamic respond) = await RequestsAsync.Posts.SharePostToAsync(PostData.PostId, PageData.PageId, "share_post_on_page",TxtContentPost.Text);
                    ResultApi(apiStatus, respond);
                }
                else if (TypePost == "MyTimeline")
                {
                    (int apiStatus, dynamic respond) = await RequestsAsync.Posts.SharePostToAsync(PostData.PostId, UserDetails.UserId, "share_post_on_timeline");
                    ResultApi(apiStatus, respond);
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ResultApi(int apiStatus, dynamic respond)
        {
            try
            {
                if (apiStatus == 200)
                {
                    if (respond is SharePostToObject result)
                    {
                        var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(result.Data);

                        TabbedMainActivity.GetInstance()?.NewsFeedTab?.MainRecyclerView?.InsertByRowIndex(new AdapterModelsClass()
                        {
                            TypeView = postType,
                            Id = int.Parse(result.Data.Id),
                            PostData = result.Data,
                            IsDefaultFeedPost = true,
                        });
                         
                        Toast.MakeText(this, GetText(Resource.String.Lbl_PostSuccessfullyShared), ToastLength.Short).Show();
                        Finish();
                    }
                }
                else Methods.DisplayReportResult(this, respond);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion
         
        private void GetDataPost()
        {
            try
            {
                if (TypePost == "Group")
                {
                    GroupData = JsonConvert.DeserializeObject<GroupClass>(Intent.GetStringExtra("ShareToGroup"));
                    if (GroupData != null)
                    {
                        GlideImageLoader.LoadImage(this, GroupData.Avatar, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable, false);
                        TxtUserName.Text = GroupData.GroupName;
                    }
                }
                else if(TypePost == "Page")
                {
                    PageData = JsonConvert.DeserializeObject<PageClass>(Intent.GetStringExtra("ShareToPage"));
                    if (PageData != null)
                    {
                        GlideImageLoader.LoadImage(this, PageData.Avatar, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable, false);
                        TxtUserName.Text = PageData.PageName;
                    } 
                }
                else if(TypePost == "MyTimeline")
                {
                    GlideImageLoader.LoadImage(this, UserDetails.Avatar, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable, false);
                    TxtUserName.Text = UserDetails.FullName;
                }

                PostData = JsonConvert.DeserializeObject<PostDataObject>(Intent.GetStringExtra("PostObject"));
                if (PostData != null)
                {
                    var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(PostData);

                    var d2 = new AdapterModelsClass
                    {
                        TypeView = postType,
                        Id = int.Parse(PostData.Id),
                        PostData = PostData,
                        IsDefaultFeedPost = true
                    };

                    PostFeedAdapter.PostFeedList.Add(d2);
                    PostFeedAdapter.NotifyDataSetChanged(); 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }
}