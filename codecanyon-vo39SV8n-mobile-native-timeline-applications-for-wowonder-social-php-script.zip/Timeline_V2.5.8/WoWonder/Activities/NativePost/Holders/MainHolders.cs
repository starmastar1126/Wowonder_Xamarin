﻿using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;

namespace WoWonder.Activities.NativePost.Holders
{
    public class MainHolders
    {
        public class EmptyStateAdapterViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; set; }
            public TextView EmptyText { get; set; }
            public ImageView EmptyImage { get; set; }

            public EmptyStateAdapterViewHolder(View itemView) : base(itemView)
            {
                MainView = itemView;
                EmptyText = MainView.FindViewById<TextView>(Resource.Id.textEmpty);
                EmptyImage = MainView.FindViewById<ImageView>(Resource.Id.imageEmpty);
            }
        }
    }
}