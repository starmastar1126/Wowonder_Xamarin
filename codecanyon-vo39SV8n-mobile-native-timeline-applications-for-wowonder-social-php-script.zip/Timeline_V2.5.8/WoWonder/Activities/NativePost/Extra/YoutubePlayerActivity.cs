﻿using System;
using System.Collections.ObjectModel;
using Android.App;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Com.Google.Android.Youtube.Player;
using Newtonsoft.Json;
using WoWonder.Activities.NativePost.Comment;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonder.Library.Anjo.SuperTextLibrary;
using WoWonderClient.Classes.Comments;
using WoWonderClient.Classes.Posts;

namespace WoWonder.Activities.NativePost.Extra
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/TransparentBlack", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.Orientation)]
    public class YoutubePlayerActivity : AppCompatActivity, IYouTubePlayerOnInitializedListener
    {
        private CommentAdapter CommentsAdapter;
        private RecyclerView MainRecyclerView;

        private ImageView UserAvatar { get; set; } 
        private TextView Username { get; set; }
        private TextView IsVip { get; set; }
        private TextView IsVerified { get; set; }
        private TextView MoreIcon { get; set; }
        private TextView PostMinText { get; set; }
        private ViewStub StubLoader { get; set; }
        private SuperTextView Description { get; set; }
        private TextView TimeText { get; set; }
        private TextView CommentCount { get; set; }
        private TextView LikeCount { get; set; }
        private LinearLayout CommentButton { get; set; }
        private LinearLayout ShareButton { get; set; }
        private View MainView { get; set; } 
        private IYouTubePlayer YoutubePlayer;
        private YouTubePlayerSupportFragment YouTubeFragment;
        private string PostId;
        private PostDataObject PostObject;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                SetContentView(Resource.Layout.YoutubePlayerActivityLayout);

                PostId = Intent.GetStringExtra("PostId") ?? string.Empty;
                PostObject = JsonConvert.DeserializeObject<PostDataObject>(Intent.GetStringExtra("PostObject"));

                CommentButton = FindViewById<LinearLayout>(Resource.Id.linercomment);
                ShareButton = FindViewById<LinearLayout>(Resource.Id.linershare);
                TimeText = FindViewById<TextView>(Resource.Id.time_text);
                MoreIcon = FindViewById<TextView>(Resource.Id.moreicon);
                StubLoader = FindViewById<ViewStub>(Resource.Id.viewStubloader);
                CommentCount = FindViewById<TextView>(Resource.Id.Commentcount);
                LikeCount = FindViewById<TextView>(Resource.Id.Likecount);
                Username = FindViewById<TextView>(Resource.Id.username);
                UserAvatar = FindViewById<ImageView>(Resource.Id.userAvatar);
                Description = FindViewById<SuperTextView>(Resource.Id.description);
                MainRecyclerView = FindViewById<RecyclerView>(Resource.Id.recycler_view);
                MainView = FindViewById<View>(Resource.Id.main_content);

                if (MoreIcon.Text != IonIconsFonts.More)
                {
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, MoreIcon, IonIconsFonts.More);

                    Description?.SetTextInfo(Description);
                }

                CommentsAdapter = new CommentAdapter(this, MainRecyclerView, "Dark", PostId);

                var viewsLayouts = new AdapterHolders.PostViewsLayouts(MainView);  
                var binder = new AdapterBinders(this,null, ""); 
                binder.LoadPostData(viewsLayouts, PostObject, 0);
                 
                YouTubeFragment = new YouTubePlayerSupportFragment();
                SupportFragmentManager.BeginTransaction().Add(Resource.Id.root, YouTubeFragment, YouTubeFragment.Id.ToString() + DateTime.Now).Commit();
                YouTubeFragment.Initialize(AppSettings.YoutubeKey, this);
                 
                CommentsAdapter.CommentList = new ObservableCollection<GetCommentObject>(PostObject.GetPostComments);
                CommentsAdapter.NotifyDataSetChanged(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            } 
        }

        public void OnInitializationFailure(IYouTubePlayerProvider p0, YouTubeInitializationResult errorReason)
        {
            if (errorReason.IsUserRecoverableError)
                errorReason.GetErrorDialog(this, 1).Show();
            else
                Toast.MakeText(this, errorReason.ToString(), ToastLength.Short).Show();
        }

        public void OnInitializationSuccess(IYouTubePlayerProvider p0, IYouTubePlayer player, bool p2)
        {
            try
            {
                YoutubePlayer = player;
                YoutubePlayer.SetPlayerStyle(YouTubePlayerPlayerStyle.Default);
                YoutubePlayer.LoadVideo(PostObject.PostYoutube);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}