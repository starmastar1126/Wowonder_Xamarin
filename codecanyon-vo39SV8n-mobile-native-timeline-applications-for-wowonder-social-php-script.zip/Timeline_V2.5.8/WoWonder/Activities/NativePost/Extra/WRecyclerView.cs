﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Util;
using Android.Views;
using Android.Widget;
using Com.Google.Android.Exoplayer2;
using Com.Google.Android.Exoplayer2.Extractor;
using Com.Google.Android.Exoplayer2.Source;
using Com.Google.Android.Exoplayer2.Trackselection;
using Com.Google.Android.Exoplayer2.UI;
using Com.Google.Android.Exoplayer2.Upstream;
using Com.Google.Android.Exoplayer2.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WoWonder.Activities.NativePost.Pages;
//using Webianks.Library;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.Tabbes;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using WoWonder.MediaPlayer;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using LayoutDirection = Android.Views.LayoutDirection;
using Object = Java.Lang.Object;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.NativePost.Extra
{
    public class WRecyclerView : RecyclerView
    {
        private static WRecyclerView Instance;
        private enum VolumeState { On, Off };

        private FrameLayout MediaContainerLayout;
        private ImageView Thumbnail, PlayControl;
        private PlayerView VideoSurfaceView;
        private SimpleExoPlayer VideoPlayer;
        private View ViewHolderParent;
        private int VideoSurfaceDefaultHeight;
        private int ScreenDefaultHeight;
        private Context MainContext;
        private int PlayPosition = -1;
        private bool IsVideoViewAdded;
        private RecyclerScrollListener MainScrollEvent;
        public NativePostAdapter NativeFeedAdapter;
        private SwipeRefreshLayout SwipeRefreshLayoutView;
        //private dynamic /*PopupBubble*/ PopupBubbleView; //wael
        private int OffsetCountTop = 0;
        private VolumeState VolumeStateProvider;
        private static bool ShowFindMoreAlert = false;
        private ExoPlayerRecyclerEvent lis;

        protected WRecyclerView(IntPtr javaReference, JniHandleOwnership transfer) : base(javaReference, transfer)
        {
        }

        public WRecyclerView(Activity context) : base(context)
        {
            Init(context);
        }

        public WRecyclerView(Context context, IAttributeSet attrs) : base(context, attrs)
        {
            Init(context);
        }

        public WRecyclerView(Context context, IAttributeSet attrs, int defStyle) : base(context, attrs, defStyle)
        {
            Init(context);
        }

        private void Init(Context context)
        {
            try
            {
                MainContext = context.ApplicationContext;

                Instance = this;

                if (AppSettings.FlowDirectionRightToLeft)
                    LayoutDirection = LayoutDirection.Rtl;

                HasFixedSize = true;
                SetItemViewCacheSize(10);
                ClearAnimation();
                SetItemViewCacheSize(10);

                var display = Context.GetSystemService(Context.WindowService).JavaCast<IWindowManager>().DefaultDisplay;

                var point = new Point();
                display.GetSize(point);
                VideoSurfaceDefaultHeight = point.X;
                ScreenDefaultHeight = point.Y;

                VideoSurfaceView = new PlayerView(MainContext)
                {
                    ResizeMode = AspectRatioFrameLayout.ResizeModeFixedWidth
                };

                var bandWidthMeter = new DefaultBandwidthMeter();
                var videoTrackSelectionFactory = new AdaptiveTrackSelection.Factory(bandWidthMeter);

                TrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);

                //DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                //    .SetAllocator(new DefaultAllocator(true, 16))
                //    .SetBufferDurationsMs(VideoPlayerConfig.MIN_BUFFER_DURATION,
                //        VideoPlayerConfig.MAX_BUFFER_DURATION,
                //        VideoPlayerConfig.MIN_PLAYBACK_START_BUFFER,
                //        VideoPlayerConfig.MIN_PLAYBACK_RESUME_BUFFER)
                //    .SetTargetBufferBytes(-1)
                //    .SetPrioritizeTimeOverSizeThresholds(true).CreateDefaultLoadControl();

                // 2. Create the player
                VideoPlayer = ExoPlayerFactory.NewSimpleInstance(MainContext, trackSelector);

                VideoSurfaceView.UseController = true;
                VideoSurfaceView.Player = VideoPlayer;

                MainScrollEvent = new RecyclerScrollListener(MainContext, this, (NativePostAdapter)GetAdapter());

                AddOnScrollListener(MainScrollEvent);
                AddOnChildAttachStateChangeListener(new ChildAttachStateChangeListener(this));

                MainScrollEvent.LoadMoreEvent += MainScrollEvent_LoadMoreEvent;
                MainScrollEvent.IsLoading = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static WRecyclerView GetInstance()
        {
            try
            {
                return Instance;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public void SetXAdapter(NativePostAdapter adapter, SwipeRefreshLayout swipeRefreshLayout)
        {
            try
            {
                NativeFeedAdapter = adapter;
                SwipeRefreshLayoutView = swipeRefreshLayout;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        //PopupBubble //wael
        public void SetXPopupBubble(dynamic popupBubble)
        {
            try
            {
                //PopupBubbleView = popupBubble;
                //PopupBubbleView.SetRecyclerView(this);
                //PopupBubbleView.SetPopupBubbleListener(new PopupBubbleClickEvent(this));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void PlayVideo(bool isEndOfList, AdapterHolders.VideoPlayerViewHolder holderVideoPlayer = null, PostDataObject item = null)
        {
            try
            {
                var targetPosition = 0;
                if (!isEndOfList)
                {
                    var startPosition = ((LinearLayoutManager)GetLayoutManager()).FindFirstVisibleItemPosition();
                    var endPosition = ((LinearLayoutManager)GetLayoutManager()).FindLastVisibleItemPosition();

                    if (endPosition - startPosition > 1)
                        endPosition = startPosition + 1;

                    if (startPosition < 0 || endPosition < 0)
                        return;

                    if (startPosition != endPosition)
                    {
                        var startPositionVideoHeight = GetVisibleVideoSurfaceHeight(startPosition);
                        var endPositionVideoHeight = GetVisibleVideoSurfaceHeight(endPosition);
                        targetPosition = startPositionVideoHeight > endPositionVideoHeight ? startPosition : endPosition;
                    }
                    else
                        targetPosition = startPosition;
                }
                else
                    targetPosition = GetAdapter().ItemCount - 1;


                if (targetPosition == PlayPosition)
                    return;

                // set the position of the list-item that is to be played
                PlayPosition = targetPosition;
                if (VideoSurfaceView == null)
                    return;

                VideoSurfaceView.Visibility = ViewStates.Invisible;
                RemoveVideoView(VideoSurfaceView);

                var currentPosition = targetPosition - ((LinearLayoutManager)GetLayoutManager()).FindFirstVisibleItemPosition();

                var child = GetChildAt(currentPosition);
                if (child == null)
                    return;

                dynamic holder;
                if (holderVideoPlayer != null)
                {
                    holder = holderVideoPlayer;
                    targetPosition = holderVideoPlayer.LayoutPosition;
                }
                else
                {
                    AdapterHolders.VideoPlayerViewHolder holderChild = (AdapterHolders.VideoPlayerViewHolder)child.Tag;
                    if (holderChild == null)
                    {
                        PlayPosition = -1;
                        return;
                    }
                    else
                    {
                        targetPosition = holderChild.LayoutPosition;
                        holder = holderChild;
                    }
                }

                MediaContainerLayout = holder.ViewsLayouts.MediaContainerLayout;
                Thumbnail = holder.ViewsLayouts.VideoImage;

                ViewHolderParent = holder.ItemView;
                PlayControl = holder.ViewsLayouts.PlayControl;

                //if (!IsVideoViewAdded)
                //    AddVideoView();

                VideoSurfaceView.Player = VideoPlayer;

                var controlView = VideoSurfaceView.FindViewById<PlayerControlView>(Resource.Id.exo_controller);

                Uri videoUrl = Uri.Parse(item != null ? item.PostFileFull : NativeFeedAdapter.PostFeedList[targetPosition].PostData?.PostFileFull);

                holder.VideoUrl = videoUrl.ToString();
                var defaultDataMediaFactory = new DefaultDataSourceFactory(MainContext, Util.GetUserAgent(MainContext, AppSettings.ApplicationName), new DefaultBandwidthMeter());
                var defaultSource = new ExtractorMediaSource(videoUrl, defaultDataMediaFactory, new DefaultExtractorsFactory(), new Handler(), new ExctractorMediaListener());

                ExoPlayerRecyclerEvent lis = new ExoPlayerRecyclerEvent(controlView, this, holder);

                //var holderChild = (AdapterHolders.VideoPlayerViewHolder)child.Tag;
                //holder.BindClickEvents(targetPosition, holder.ViewsLayouts.ClickEvent, videoUrl.Path, lis.mFullScreenButton);


                lis.mFullScreenButton.SetOnClickListener(new NewClicker(lis.mFullScreenButton, holder.VideoUrl,this));


                VideoPlayer.Prepare(defaultSource);
                VideoPlayer.AddListener(lis);
                VideoPlayer.PlayWhenReady = true;


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public class NewClicker : Java.Lang.Object, View.IOnClickListener
        {
            public string VideoUrl { get; set; }
            public FrameLayout FullScreenButton { get; set; }
            public WRecyclerView WRecyclerViewController { get; set; }
            public NewClicker(FrameLayout fullScreenButton, string videoUrl, WRecyclerView wRecyclerViewController)
            {
                WRecyclerViewController = wRecyclerViewController;
                FullScreenButton = fullScreenButton;
                VideoUrl = videoUrl;
            }
            public void OnClick(View v)
            {
                if(v.Id == FullScreenButton.Id)
                {
                    try
                    {
                       
                        WRecyclerViewController.VideoPlayer.PlayWhenReady = false;

                        Intent intent = new Intent(WRecyclerViewController.MainContext, typeof(VideoFullScreenActivity));
                        intent.PutExtra("videoUrl", VideoUrl);
                        //  intent.PutExtra("videoDuration", videoPlayer.Duration.ToString());
                        MainApplication.GetInstance().Activity.StartActivity(intent);
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    }
                }
            }
        }

        private int GetVisibleVideoSurfaceHeight(int playPosition)
        {
            try
            {
                var d = (LinearLayoutManager)GetLayoutManager();
                var at = playPosition - d.FindFirstVisibleItemPosition();

                var child = GetChildAt(at);
                if (child == null)
                    return 0;

                int[] location = new int[2];
                child.GetLocationInWindow(location);

                if (location[1] < 0)
                    return location[1] + VideoSurfaceDefaultHeight;

                return ScreenDefaultHeight - location[1];
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return 0;
            }
        }

        private void AddVideoView()
        {
            try
            {
                MediaContainerLayout.AddView(VideoSurfaceView);
                IsVideoViewAdded = true;
                VideoSurfaceView.RequestFocus();
                VideoSurfaceView.Visibility = ViewStates.Visible;
                Thumbnail.Visibility = ViewStates.Gone;
                PlayControl.Visibility = ViewStates.Gone;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void RemoveVideoView(PlayerView videoView)
        {
            try
            {
                var parent = (ViewGroup)videoView.Parent;
                if (parent == null)
                    return;

                var index = parent.IndexOfChild(videoView);
                if (index < 0)
                    return;

                parent.RemoveViewAt(index);
                IsVideoViewAdded = false;
                PlayControl.SetOnClickListener(null);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        public void ReleasePlayer()
        {
            try
            {
                if (VideoPlayer != null)
                {
                    VideoPlayer.Release();
                    VideoPlayer = null;
                }

                ViewHolderParent = null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void MainScrollEvent_LoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                MainScrollEvent.IsLoading = true;

                if (NativeFeedAdapter.PostFeedList.Count <= 5)
                    return;

                var item = NativeFeedAdapter.PostFeedList.LastOrDefault();

                var lastItem = NativeFeedAdapter.PostFeedList.IndexOf(item);

                item = NativeFeedAdapter.PostFeedList[lastItem];

                if (item.PostData == null)
                {
                    item = NativeFeedAdapter.PostFeedList[lastItem - 1];
                }

                string offset;

                if (item.PostData != null)
                {
                    if (item.PostData.PostType == "ad")
                    {
                        item = NativeFeedAdapter.PostFeedList[lastItem - 1];
                    }

                    offset = item.PostData.Id;
                }
                else
                {
                    return;
                }

                if (!Methods.CheckConnectivity())
                    Toast.MakeText(MainContext, MainContext.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                else
                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => FetchNewsFeedApiPosts(offset) });
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void InsertByRowIndex(AdapterModelsClass item, string index = "")
        {
            try
            {
                int countIndex = 0;

                var model1 = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.Story);
                var model2 = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AlertBox);
                var model3 = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AddPostBox);

                if (model1 != null)
                    countIndex += NativeFeedAdapter.PostFeedList.IndexOf(model1);
                if (model2 != null)
                    countIndex += NativeFeedAdapter.PostFeedList.IndexOf(model2);
                if (model3 != null)
                    countIndex += NativeFeedAdapter.PostFeedList.IndexOf(model3);

                if (!string.IsNullOrEmpty(index))
                    countIndex = int.Parse(index);

                NativeFeedAdapter.PostFeedList.Insert(countIndex, item);
                NativeFeedAdapter.NotifyItemInserted(countIndex);

                var emptyStateChecker = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.EmptyState);
                if (emptyStateChecker != null && NativeFeedAdapter.PostFeedList.Count > 1)
                {
                    NativeFeedAdapter.PostFeedList.Remove(emptyStateChecker);
                    NativeFeedAdapter.NotifyDataSetChanged();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        public void RemoveByRowIndex(AdapterModelsClass item)
        {
            try
            {
                var index = NativeFeedAdapter.PostFeedList.IndexOf(item);
                if (index <= 0)
                    return;

                NativeFeedAdapter.PostFeedList.RemoveAt(index);
                NativeFeedAdapter.NotifyItemRemoved(index);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public async Task FetchNewsFeedApiPosts(string offset, string hash = "")
        {
            try
            {
                int apiStatus;
                dynamic respond;

                switch (NativeFeedAdapter.NativePostType)
                {
                    case NativeFeedType.Global:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "get_news_feed", NativeFeedAdapter.ApiIdParameter);
                        break;
                    case NativeFeedType.User:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "get_user_posts", NativeFeedAdapter.ApiIdParameter);
                        break;
                    case NativeFeedType.Group:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "get_group_posts", NativeFeedAdapter.ApiIdParameter);
                        break;
                    case NativeFeedType.Page:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "get_page_posts", NativeFeedAdapter.ApiIdParameter);
                        break;
                    case NativeFeedType.Event:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "get_event_posts", NativeFeedAdapter.ApiIdParameter);
                        break;
                    case NativeFeedType.Saved:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "saved");
                        break;
                    case NativeFeedType.HashTag:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "hashtag", "", hash);
                        break;
                    case NativeFeedType.Popular:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetPopularPost(AppSettings.PostApiLimitOnScroll, offset);
                        break;
                    default:
                        (apiStatus, respond) = await RequestsAsync.Posts.GetGlobalPost(AppSettings.PostApiLimitOnScroll, offset, "get_news_feed", NativeFeedAdapter.ApiIdParameter);
                        break;
                }

                if (apiStatus != 200 || !(respond is WoWonderClient.Classes.Posts.PostObject result) || result.Data == null)
                {
                    Methods.DisplayReportResult((Activity)Context, respond);
                }
                else
                {
                    if (apiStatus == 200)
                    {
                        OffsetCountTop = 0;

                        if (SwipeRefreshLayoutView != null && SwipeRefreshLayoutView.Refreshing)
                            SwipeRefreshLayoutView.Refreshing = false;

                        if (result.Data.Count > 0)
                        {
                            result.Data.RemoveAll(a => a.Publisher == null && a.UserData == null);
                             
                            var postsCount = NativeFeedAdapter.PostFeedList.Count;

                            if (NativeFeedAdapter.NativePostType == NativeFeedType.Global)
                            {
                                if (result.Data.Count < 6)
                                {
                                    if (!ShowFindMoreAlert)
                                    {
                                        ShowFindMoreAlert = true;

                                        TabbedMainActivity.GetInstance().NewsFeedTab.SetFindMoreAlert("Pages");
                                        TabbedMainActivity.GetInstance().NewsFeedTab.SetFindMoreAlert("Groups");
                                    }
                                }
                            }
                             
                            if (offset == "")
                            {
                                int countIndex = 0;
                                var model1 = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.Story);
                                var model2 = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AlertBox);
                                var model3 = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AddPostBox);

                                if (model1 != null)
                                    countIndex += NativeFeedAdapter.PostFeedList.IndexOf(model1);
                                if (model2 != null)
                                    countIndex += NativeFeedAdapter.PostFeedList.IndexOf(model2);
                                if (model3 != null)
                                    countIndex += NativeFeedAdapter.PostFeedList.IndexOf(model3);

                                result.Data.Reverse();
                                 
                                foreach (var post in result.Data)
                                {
                                    if (NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.Id == int.Parse(post.Id)) != null )
                                        continue;
                                     
                                    if (NativeFeedAdapter.PostFeedList.Count % AppSettings.ShowAdmobNativCount == 0)
                                    {
                                        if (AppSettings.ShowAdmobNative)
                                        {
                                            var adMobBox = new AdapterModelsClass
                                            {
                                                TypeView = PostModelType.AdMob,
                                                Id = 2222019
                                            };
                                            NativeFeedAdapter.PostFeedList.Add(adMobBox);
                                        } 
                                    }

                                    var postType = NativeFeedAdapter.BaseAdapterBinder.GetAdapterType(post);
                                    if (postType != PostModelType.PollPost)
                                    {
                                        if (post.PostType == "ad")
                                        {
                                            postType = PostModelType.AdsPost;
                                        }
                                        var item = new AdapterModelsClass
                                        {
                                            TypeView = postType,
                                            Id = int.Parse(post.Id),
                                            PostData = post,
                                            IsDefaultFeedPost = true
                                        };

                                        NativeFeedAdapter.PostFeedList.Insert(countIndex, item);
                                        OffsetCountTop += 1;
                                    }
                                }

                                if (OffsetCountTop > 0)
                                {
                                    NativeFeedAdapter.NotifyItemRangeInserted(countIndex, OffsetCountTop);
                                    //PopupBubbleView.Activate();
                                }
                            }
                            else if (postsCount <= 5)
                            {
                                foreach (var post in result.Data)
                                { 
                                    if (NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.Id == int.Parse(post.Id)) != null )
                                        continue;

                                    if (NativeFeedAdapter.PostFeedList.Count % AppSettings.ShowAdmobNativCount == 0)
                                    {
                                        if (AppSettings.ShowAdmobNative)
                                        {
                                            var adMobBox = new AdapterModelsClass
                                            {
                                                TypeView = PostModelType.AdMob,
                                                Id = 2222019
                                            };
                                            NativeFeedAdapter.PostFeedList.Add(adMobBox);
                                        }
                                    }
                                      
                                    var postType = NativeFeedAdapter.BaseAdapterBinder.GetAdapterType(post);
                                    if (postType != PostModelType.PollPost)
                                    {
                                        if (post.PostType == "ad")
                                        {
                                            postType = PostModelType.AdsPost;
                                        }
                                        var d2 = new AdapterModelsClass
                                        {
                                            TypeView = postType,
                                            Id = int.Parse(post.Id),
                                            PostData = post,
                                            IsDefaultFeedPost = true
                                        };
                                         
                                        NativeFeedAdapter.PostFeedList.Add(d2);
                                    }
                                }
                                NativeFeedAdapter.NotifyItemRangeInserted(postsCount, NativeFeedAdapter.PostFeedList.Count);
                                MainScrollEvent.IsLoading = false;
                            }
                            else
                            {
                                foreach (var post in result.Data)
                                {
                                    if (NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.Id == int.Parse(post.Id)) != null )
                                        continue;

                                    if (NativeFeedAdapter.PostFeedList.Count % AppSettings.ShowAdmobNativCount == 0)
                                    {
                                        if (AppSettings.ShowAdmobNative)
                                        {
                                            var adMobBox = new AdapterModelsClass
                                            {
                                                TypeView = PostModelType.AdMob,
                                                Id = 2222019
                                            };
                                            NativeFeedAdapter.PostFeedList.Add(adMobBox);
                                        }
                                    }

                                    var postType = NativeFeedAdapter.BaseAdapterBinder.GetAdapterType(post);
                                    if (postType != PostModelType.PollPost)
                                    {
                                        if (post.PostType == "ad")
                                        {
                                            postType = PostModelType.AdsPost;
                                        }

                                        var item = new AdapterModelsClass
                                        {
                                            TypeView = postType,
                                            Id = int.Parse(post.Id),
                                            PostData = post,
                                            IsDefaultFeedPost = true
                                        };

                                        NativeFeedAdapter.PostFeedList.Add(item);
                                    }
                                }

                                NativeFeedAdapter.NotifyItemRangeInserted(postsCount, NativeFeedAdapter.PostFeedList.Count);
                                MainScrollEvent.IsLoading = false; 
                            }
                        }
                        else
                        {
                            MainScrollEvent.IsLoading = true;
                        }

                        if (NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.IsDefaultFeedPost) != null)
                        {
                            var emptyStateChecker = NativeFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.EmptyState);
                            if (emptyStateChecker != null && NativeFeedAdapter.PostFeedList.Count > 1)
                            {
                                NativeFeedAdapter.PostFeedList.Remove(emptyStateChecker);
                                NativeFeedAdapter.NotifyDataSetChanged();
                            }
                        }
                        else
                        {
                            NativeFeedAdapter.PostFeedList.Add(new AdapterModelsClass { TypeView = PostModelType.EmptyState, Id = 9999999 });
                            NativeFeedAdapter.NotifyDataSetChanged();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MainScrollEvent.IsLoading = false;
                Console.WriteLine(e);
            }
        }



        public class RecyclerScrollListener : OnScrollListener
        {
            public delegate void LoadMoreEventHandler(object sender, EventArgs e);

            public event LoadMoreEventHandler LoadMoreEvent;

            public bool IsLoading { get; set; }

            private NativePostAdapter PostAdapter;
            private Context Context;
            private LinearLayoutManager LayoutManager;
            private readonly WRecyclerView XRecyclerView;

            public RecyclerScrollListener(Context ctx, WRecyclerView recyclerView, NativePostAdapter adapter)
            {
                PostAdapter = adapter;
                Context = ctx;
                XRecyclerView = recyclerView;
                IsLoading = false;
            }

            public override void OnScrollStateChanged(RecyclerView recyclerView, int newState)
            {
                base.OnScrollStateChanged(recyclerView, newState);

                try
                {
                    if (newState == (int)Android.Widget.ScrollState.Idle)
                    {
                        //if (XRecyclerView.Thumbnail != null)
                        //    XRecyclerView.Thumbnail.Visibility = ViewStates.Visible;

                        //if (XRecyclerView.PlayControl != null)
                        //    XRecyclerView.PlayControl.Visibility = ViewStates.Visible;

                        XRecyclerView.PlayVideo(!recyclerView.CanScrollVertically(1));
                    }
                    else
                    {
                        var startPosition = ((LinearLayoutManager)LayoutManager).FindFirstVisibleItemPosition();
                        var endPosition = ((LinearLayoutManager)LayoutManager).FindLastVisibleItemPosition();

                        var startPositionVideoHeight = XRecyclerView.GetVisibleVideoSurfaceHeight(startPosition);
                        var endPositionVideoHeight = XRecyclerView.GetVisibleVideoSurfaceHeight(endPosition);
                        var targetPosition = startPositionVideoHeight > endPositionVideoHeight;

                        if (endPositionVideoHeight - 230 > startPositionVideoHeight)
                            if (XRecyclerView.VideoPlayer.PlayWhenReady)
                                XRecyclerView.VideoPlayer.PlayWhenReady = false;
                        if (startPositionVideoHeight <= 60)
                        {
                            if (XRecyclerView.Thumbnail != null)
                                XRecyclerView.Thumbnail.Visibility = ViewStates.Visible;

                            if (XRecyclerView.PlayControl != null)
                                XRecyclerView.PlayControl.Visibility = ViewStates.Visible;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public override void OnScrolled(RecyclerView recyclerView, int dx, int dy)
            {
                try
                {
                    //if (dy > 0)
                    //    TabbedMainActivity.navigationTabBar.Hide();
                    //else
                    //    TabbedMainActivity.navigationTabBar.Show();


                    if (LayoutManager == null)
                        LayoutManager = (LinearLayoutManager)recyclerView.GetLayoutManager();

                    var visibleItemCount = recyclerView.ChildCount;
                    var totalItemCount = recyclerView.GetAdapter().ItemCount;

                    var pastItems = LayoutManager.FindFirstVisibleItemPosition();

                    if (visibleItemCount + pastItems + 10 < totalItemCount)
                        return;

                    if (IsLoading)
                        return;

                    LoadMoreEvent?.Invoke(this, null);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        #region Listeners
        //PopupBubble //wael
        public class PopupBubbleClickEvent : Object/*, PopupBubble.IPopupBubbleClickListener*/
        {
            public WRecyclerView MainRecyclerView;

            public PopupBubbleClickEvent(WRecyclerView mainRecyclerView)
            {
                MainRecyclerView = mainRecyclerView;
            }

            public void BubbleClicked(Context context)
            {
                //MainRecyclerView.PopupBubbleView.Hide();
                MainRecyclerView.ScrollToPosition(0);
            }
        }

        private class ChildAttachStateChangeListener : Object, IOnChildAttachStateChangeListener
        {
            private readonly WRecyclerView XRecyclerView;

            public ChildAttachStateChangeListener(WRecyclerView recyclerView)
            {
                XRecyclerView = recyclerView;
            }

            public void OnChildViewAttachedToWindow(View view)
            {
                try
                {
                    var mainHolder = XRecyclerView.GetChildViewHolder(view);

                    if (XRecyclerView.ViewHolderParent != null && XRecyclerView.ViewHolderParent.Equals(view))
                    {
                        if (!(mainHolder is AdapterHolders.VideoPlayerViewHolder holder))
                            return;

                        if (!XRecyclerView.IsVideoViewAdded)
                            return;

                        XRecyclerView.RemoveVideoView(XRecyclerView.VideoSurfaceView);
                        XRecyclerView.PlayPosition = -1;
                        XRecyclerView.VideoSurfaceView.Visibility = ViewStates.Invisible;
                        holder.ViewsLayouts.VideoImage.Visibility = ViewStates.Visible;
                        holder.ViewsLayouts.PlayControl.Visibility = ViewStates.Visible;
                        holder.ViewsLayouts.VideoProgressBar.Visibility = ViewStates.Gone;

                        XRecyclerView.VideoPlayer?.Stop();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnChildViewDetachedFromWindow(View view)
            {
            }
        }

        private class ExoPlayerRecyclerEvent : Object, IPlayerEventListener, PlaybackControlView.IVisibilityListener
        {
            private readonly ProgressBar LoadingProgressBar;
            private readonly ImageButton VideoPlayButton, VideoResumeButton;
            public ImageView VolumeControl, mFullScreenIcon;
            public FrameLayout mFullScreenButton;
            private readonly WRecyclerView XRecyclerView;
            public ExoPlayerRecyclerEvent(PlayerControlView controlView, WRecyclerView recyclerView, AdapterHolders.VideoPlayerViewHolder holder)
            {
                try
                {
                    XRecyclerView = recyclerView;
                    if (controlView == null)
                        return;

                    mFullScreenIcon = controlView.FindViewById<ImageView>(Resource.Id.exo_fullscreen_icon);
                    mFullScreenButton = controlView.FindViewById<FrameLayout>(Resource.Id.exo_fullscreen_button);

                    VideoPlayButton = controlView.FindViewById<ImageButton>(Resource.Id.exo_play);
                    VideoResumeButton = controlView.FindViewById<ImageButton>(Resource.Id.exo_pause);
                    VolumeControl = controlView.FindViewById<ImageView>(Resource.Id.exo_volume_icon);

                    if (!AppSettings.ShowFullScreenVideoPost)
                    {
                        mFullScreenIcon.Visibility = ViewStates.Gone;
                        mFullScreenButton.Visibility = ViewStates.Gone;
                    }

                    if (holder != null) LoadingProgressBar = holder.ViewsLayouts.VideoProgressBar;

                    SetVolumeControl(XRecyclerView.VolumeStateProvider == VolumeState.On ? VolumeState.On : VolumeState.Off);

                    if (!VolumeControl.HasOnClickListeners)
                    {
                        VolumeControl.Click += (sender, args) =>
                        {
                            ToggleVolume();
                        };
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            private void ToggleVolume()
            {
                try
                {
                    if (XRecyclerView.VideoPlayer == null)
                        return;

                    switch (XRecyclerView.VolumeStateProvider)
                    {
                        case VolumeState.Off:
                            SetVolumeControl(VolumeState.On);
                            break;
                        case VolumeState.On:
                            SetVolumeControl(VolumeState.Off);
                            break;
                        default:
                            SetVolumeControl(VolumeState.Off);
                            break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            private void SetVolumeControl(VolumeState state)
            {
                try
                {
                    XRecyclerView.VolumeStateProvider = state;
                    switch (state)
                    {
                        case VolumeState.Off:
                            XRecyclerView.VolumeStateProvider = VolumeState.Off;
                            XRecyclerView.VideoPlayer.Volume = 0f;
                            AnimateVolumeControl();
                            break;
                        case VolumeState.On:
                            XRecyclerView.VolumeStateProvider = VolumeState.On;
                            XRecyclerView.VideoPlayer.Volume = 1f;
                            AnimateVolumeControl();
                            break;
                        default:
                            XRecyclerView.VideoPlayer.Volume = 1f;
                            AnimateVolumeControl();
                            break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            private void AnimateVolumeControl()
            {
                try
                {
                    if (VolumeControl == null)
                        return;

                    VolumeControl.BringToFront();
                    switch (XRecyclerView.VolumeStateProvider)
                    {
                        case VolumeState.Off:
                            VolumeControl.SetImageResource(Resource.Drawable.ic_volume_off_grey_24dp);

                            break;
                        case VolumeState.On:
                            VolumeControl.SetImageResource(Resource.Drawable.ic_volume_up_grey_24dp);
                            break;
                        default:
                            VolumeControl.SetImageResource(Resource.Drawable.ic_volume_off_grey_24dp);
                            break;
                    }
                    //VolumeControl.Animate().Cancel();

                    //VolumeControl.Alpha = (1f);

                    //VolumeControl.Animate().Alpha(0f).SetDuration(600).SetStartDelay(1000);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnLoadingChanged(bool p0)
            {
            }

            public void OnPlaybackParametersChanged(PlaybackParameters p0)
            {
            }

            public void OnPlayerError(ExoPlaybackException p0)
            {
            }

            public void OnPlayerStateChanged(bool playWhenReady, int playbackState)
            {
                try
                {
                    //if (VideoResumeButton == null || VideoPlayButton == null || LoadingProgressBar == null)
                    //    return;

                    if (playbackState == Player.StateEnded)
                    {
                        if (playWhenReady == false)
                            VideoResumeButton.Visibility = ViewStates.Visible;
                        else
                        {
                            VideoResumeButton.Visibility = ViewStates.Gone;
                            VideoPlayButton.Visibility = ViewStates.Visible;
                        }

                        LoadingProgressBar.Visibility = ViewStates.Invisible;
                        XRecyclerView.VideoPlayer.SeekTo(0);
                    }
                    else if (playbackState == Player.StateReady)
                    {

                        if (playWhenReady == false)
                        {
                            VideoResumeButton.Visibility = ViewStates.Gone;
                            VideoPlayButton.Visibility = ViewStates.Visible;
                        }
                        else
                        {
                            VideoResumeButton.Visibility = ViewStates.Visible;
                        }

                        LoadingProgressBar.Visibility = ViewStates.Invisible;

                        if (!XRecyclerView.IsVideoViewAdded)
                            XRecyclerView.AddVideoView();
                    }
                    else if (playbackState == Player.StateBuffering)
                    {
                        VideoPlayButton.Visibility = ViewStates.Invisible;
                        LoadingProgressBar.Visibility = ViewStates.Visible;
                        VideoResumeButton.Visibility = ViewStates.Invisible;
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }

            public void OnPositionDiscontinuity(int p0)
            {
            }

            public void OnRepeatModeChanged(int p0)
            {
            }

            public void OnSeekProcessed()
            {
            }

            public void OnShuffleModeEnabledChanged(bool p0)
            {
            }

            public void OnTimelineChanged(Timeline p0, Object p1, int p2)
            {
            }

            public void OnTracksChanged(TrackGroupArray p0, TrackSelectionArray p1)
            {
            }

            public void OnVisibilityChange(int p0)
            {
            }
        }

        #endregion
    }
}