﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.Story;

namespace WoWonder.Activities.NativePost.Post
{

    public enum PostModelType
    {
        NormalPost = 1, AboutBox = 2, PagesBox = 3, GroupsBox = 4, FollowersBox = 5, ImagesBox = 6, Story = 0, AddPostBox = 7, EmptyState = 8, AlertBox = 9, VideoPost = 10, ImagePost = 11, VoicePost = 12,
        StickerPost = 13, YoutubePost = 14, DeepSoundPost = 15, PlayTubePost = 16, LinkPost = 17, ProductPost = 18, BlogPost = 19, FilePost = 20, AlertJoinBox = 21, SharedPost = 22, EventPost = 23, ColorPost = 24, FacebookPost = 25, MultiImage2 = 26,
        MultiImage3 = 27, MultiImage4 = 28, MultiImages = 29, PollPost = 30, AdsPost = 31, AdMob = 32
    }

    public class AdapterModelsClass
    {
        public int Id { get; set; }
        public PostModelType TypeView { get; set; }

        public bool IsDefaultFeedPost { get; set; }
        public PostDataObject PostData { get; set; }

        public AboutModelClass AboutModel { get; set; }
        public FollowersModelClass FollowersModel { get; set; }
        public GroupsModelClass GroupsModel { get; set; }
        public PagesModelClass PagesModel { get; set; }
        public ImagesModelClass ImagesModel { get; set; }
        public AlertModelClass AlertModel { get; set; } 
        public ObservableCollection<GetUserStoriesObject.StoryObject> StoryList { get; set; } 
    }

    public class AboutModelClass
    {
        public string TitleHead { get; set; }
        public string Description { get; set; }
    }

    public class FollowersModelClass
    {
        public List<UserDataObject> FollowersList { get; set; }
        public string TitleHead { get; set; }
        public string More { get; set; }
    }

    public class GroupsModelClass
    {
        public List<GroupClass> GroupsList { get; set; }
        public string TitleHead { get; set; }
        public string More { get; set; }
        public string UserProfileId { get; set; }
    }

    public class PagesModelClass
    {
        public List<PageClass> PagesList { get; set; }
        public string TitleHead { get; set; }
        public string More { get; set; }
    }
    public class ImagesModelClass
    {
        public List<PostDataObject> ImagesList { get; set; }
        public string TitleHead { get; set; }
        public string More { get; set; }
    }

    public class AlertModelClass
    {
        public int ImageDrawable { get; set; }
        public string TitleHead { get; set; }
        public string SubText { get; set; }
        public string LinerColor { get; set; }


        public string TypeAlert { get; set; }
        public int IconImage { get; set; }
    } 
}