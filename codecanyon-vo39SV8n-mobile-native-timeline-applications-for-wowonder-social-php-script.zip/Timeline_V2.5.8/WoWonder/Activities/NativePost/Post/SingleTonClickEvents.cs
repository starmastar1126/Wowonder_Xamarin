﻿using Android.Support.V7.Widget;
using Android.Views;
using Com.Tuyenmonkey.Textdecorator.Callback;
using System;
using WoWonder.Helpers.Model;
using WoWonderClient.Classes.Comments;
using WoWonderClient.Classes.Posts;

namespace WoWonder.Activities.NativePost.Post
{
    public enum ClickType
    {
        Global = 0, Product = 1, Youtube = 2, Link = 3, Sound = 4, Images = 5, File = 6, Event = 7,Image=8, Ads=9, VideoFullScreen=10
    }

    public class SingleTonClickEvents : Java.Lang.Object, View.IOnClickListener, View.IOnLongClickListener
    {
        private IOnPostItemClickListener ClickListener;
        private PostDataObject Item;
        private AdapterHolders.PostViewsLayouts PostViewsLayouts;
        private int Position;
        private ClickType ClickType;

        private AdapterHolders.PostImagesViewHolder ImagesViewsLayouts;
        private AdapterHolders.YoutubePostViewHolder YoutubeViewsLayouts;
        private AdapterHolders.LinkPostViewHolder LinkViewsLayouts;
        private AdapterHolders.AdsPostViewHolder AdsViewsLayouts;
        private AdapterHolders.ProductPostViewHolder ProductViewsLayouts;
        private AdapterHolders.FilePostViewHolder FileViewsLayouts;
        private AdapterHolders.SoundPostViewHolder SoundViewsLayouts;
        private AdapterHolders.EventPostViewHolder EventViewsLayouts;
        private AdapterHolders.VideoPlayerViewHolder VideoPlayerViewsLayouts;
        public void SetGlobalClickEvents(IOnPostItemClickListener listener, PostDataObject item, AdapterHolders.PostViewsLayouts postViewsLayouts, int position, ClickType clickType)
        {
            ClickListener = listener;
            Item = item;
            Position = position;
            if (clickType == ClickType.Global)
            {
                PostViewsLayouts = postViewsLayouts;
            }
        }

        public void SetGlobalClickEvents(IOnPostItemClickListener listener, PostDataObject item, RecyclerView.ViewHolder viewHolder, int position, ClickType clickType)
        {
            try
            {
                ClickListener = listener;
                Item = item;
                Position = position;
                ClickType = clickType;

                if (clickType == ClickType.Global)
                {
                    if (!(viewHolder is AdapterHolders.GlobalViewHolder holder)) return;
                    PostViewsLayouts = holder.ViewsLayouts;
                }
                else if (clickType == ClickType.Youtube)
                {
                    if (!(viewHolder is AdapterHolders.YoutubePostViewHolder holder)) return;
                    YoutubeViewsLayouts = holder;
                }
                else if (clickType == ClickType.Link)
                {
                    if (!(viewHolder is AdapterHolders.LinkPostViewHolder holder)) return;
                    LinkViewsLayouts = holder;
                }
                else if (clickType == ClickType.Images)
                {
                    if (!(viewHolder is AdapterHolders.PostImagesViewHolder holder)) return;
                    ImagesViewsLayouts = holder;
                }
                else if (clickType == ClickType.Product)
                {
                    if (!(viewHolder is AdapterHolders.ProductPostViewHolder holder)) return;
                    ProductViewsLayouts = holder;
                }
                else if (clickType == ClickType.File)
                {
                    if (!(viewHolder is AdapterHolders.FilePostViewHolder holder)) return;
                    FileViewsLayouts = holder;
                }
                else if (clickType == ClickType.Sound)
                {
                    if (!(viewHolder is AdapterHolders.SoundPostViewHolder holder)) return;
                    SoundViewsLayouts = holder;
                }
                else if (clickType == ClickType.Event)
                {
                    if (!(viewHolder is AdapterHolders.EventPostViewHolder holder)) return;
                    EventViewsLayouts = holder;
                }
                else if (clickType == ClickType.Image)
                {
                    if (!(viewHolder is AdapterHolders.GlobalViewHolder holder)) return;
                    PostViewsLayouts = holder.ViewsLayouts;
                }
                else if (clickType == ClickType.Ads)
                {
                    if (!(viewHolder is AdapterHolders.AdsPostViewHolder holder)) return;
                    AdsViewsLayouts = holder;
                }
                else if (clickType == ClickType.VideoFullScreen)
                {
                    if (!(viewHolder is AdapterHolders.VideoPlayerViewHolder holder)) return;
                    VideoPlayerViewsLayouts = holder;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(View v)
        {
            try
            {
                //Bind Global Post Clicks
                if (PostViewsLayouts?.Username.Id == v.Id)
                    ClickListener.ProfilePostClick(new ProfileClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView }, "NewsFeedClass", "Username");
                if (PostViewsLayouts?.UserAvatar.Id == v.Id)
                    ClickListener.ProfilePostClick(new ProfileClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView }, "NewsFeedClass", "UserAvatar");
                else if (PostViewsLayouts?.CommentButton.Id == v.Id)
                    ClickListener.CommentPostClick(new CommentClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
                else if (PostViewsLayouts?.CommentCount.Id == v.Id)
                    ClickListener.CommentPostClick(new CommentClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
                else if (PostViewsLayouts?.ShareButton?.Id == v.Id)
                { ClickListener.SharePostClick(new GlobalClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView }, ClickType); }
                else if (PostViewsLayouts?.LikeButton.Id == v.Id)
                    PostViewsLayouts?.LikeButton.ClickLikeAndDisLike(new GlobalClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
                else if (PostViewsLayouts?.MoreIcon.Id == v.Id)
                    ClickListener.MorePostIconClick(new MoreClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
                else if (PostViewsLayouts?.LikeCount.Id == v.Id)
                    ClickListener.DataItemPostClick(new GlobalClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
                else if (PostViewsLayouts?.SecondReactionButton.Id == v.Id)
                    ClickListener.SecondReactionButtonClick(new GlobalClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
                 
                //Bind Images Clicks
                else if (ImagesViewsLayouts?.Image?.Id == v.Id)
                    ClickListener.ImagePostClick(new ImageClickEventArgs { NewsFeedClass = Item, Position = 0, View = ImagesViewsLayouts?.MainView });
                else if (ImagesViewsLayouts?.Image2?.Id == v.Id)
                    ClickListener.ImagePostClick(new ImageClickEventArgs { NewsFeedClass = Item, Position = 1, View = ImagesViewsLayouts?.MainView });
                else if (ImagesViewsLayouts?.Image3?.Id == v.Id)
                    ClickListener.ImagePostClick(new ImageClickEventArgs { NewsFeedClass = Item, Position = 2, View = ImagesViewsLayouts?.MainView });
                else if (ImagesViewsLayouts?.Image4?.Id == v.Id)
                    ClickListener.ImagePostClick(new ImageClickEventArgs { NewsFeedClass = Item, Position = 3, View = ImagesViewsLayouts?.MainView });
                else if (ImagesViewsLayouts?.CountImageLabel?.Id == v.Id)
                    ClickListener.ImagePostClick(new ImageClickEventArgs { NewsFeedClass = Item, Position = 4, View = ImagesViewsLayouts?.MainView });

                else if (PostViewsLayouts?.VideoImage?.Id == v.Id)
                    ClickListener.SingleImagePostClick(new GlobalClickEventArgs { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });

                //Bind Youtube Post Clicks
                else if (YoutubeViewsLayouts?.VideoIcon?.Id == v.Id)
                    ClickListener.YoutubePostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView });

                //Bind Link Post Clicks
                else if (LinkViewsLayouts?.PostLinkLinearLayout?.Id == v.Id)
                    ClickListener.LinkPostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView }, "LinkPost");
               
                //Bind Ads Post Clicks
                else if (AdsViewsLayouts?.PostLinkLinearLayout?.Id == v.Id)
                    ClickListener.LinkPostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView }, "AdsPost");

                //Bind Product Post Clicks
                else if (ProductViewsLayouts?.PostLinkLinearLayout?.Id == v.Id)
                    ClickListener.ProductPostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView });

                //Bind File Post Clicks
                else if (FileViewsLayouts?.DownlandButton?.Id == v.Id)
                    ClickListener.FileDownloadPostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView });

                //Bind Voice Post Clicks
                else if (SoundViewsLayouts?.PlayButton?.Id == v.Id)
                    ClickListener.VoicePostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView, HolderSound = SoundViewsLayouts });

                //Bind VideoFull Screen Post Clicks
                else if (VideoPlayerViewsLayouts?.FullScreenButton?.Id == v.Id)
                    ClickListener.InitFullscreenDialog(Android.Net.Uri.Parse(VideoPlayerViewsLayouts?.VideoUrl), null);

                //Bind Event Post Clicks
                else if (EventViewsLayouts?.GoingButton?.Id == v.Id)
                    ClickListener.EventGoingPostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView });
                else if (EventViewsLayouts?.PostLinkLinearLayout?.Id == v.Id)
                    ClickListener.EventItemPostClick(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = ImagesViewsLayouts?.MainView });
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            } 
        }

        public bool OnLongClick(View v)
        {
            //add event if System = ReactButton 
            if (AppSettings.PostButton == PostButtonSystem.Reaction)
            {
                if (PostViewsLayouts.LikeButton.Id == v.Id)
                    PostViewsLayouts.LikeButton.LongClickDialog(new GlobalClickEventArgs() { NewsFeedClass = Item, Position = Position, View = PostViewsLayouts?.MainView });
            }
             
            return true;
        }
    }

    public class GlobalClickEventArgs : EventArgs
    {
        public int Position { get; set; }
        public AdapterHolders.SoundPostViewHolder HolderSound { get; set; }  
        public RecyclerView.ViewHolder Holder { get; set; }  
        public View View { get; set; }
        public PostDataObject NewsFeedClass { get; set; }
    }

    public class CommentClickEventArgs : EventArgs
    {
        public int Position { get; set; }
        public RecyclerView.ViewHolder Holder { get; set; }
        public View View { get; set; }
        public PostDataObject NewsFeedClass { get; set; }
    }

    public class CommentReplyClickEventArgs : EventArgs
    {
        public int Position { get; set; }
        public View View { get; set; }
        public GetCommentObject CommentObject { get; set; }
    }

    public class ProfileClickEventArgs : EventArgs
    {
        public int Position { get; set; }
        public RecyclerView.ViewHolder Holder { get; set; }
        public View View { get; set; }
        public string PassedId { get; set; }
        public GetCommentObject CommentClass { get; set; }
        public PostDataObject NewsFeedClass { get; set; }
    }

    public class MoreClickEventArgs : EventArgs
    {
        public int Position { get; set; }
        public RecyclerView.ViewHolder Holder { get; set; }
        public View View { get; set; }
        public string PassedId { get; set; }
        public GetCommentObject CommentClass { get; set; }
        public PostDataObject NewsFeedClass { get; set; }
    }

    public class PostTextClickListener : Java.Lang.Object, IOnTextClickListener
    {
        public PostDataObject Item;

        public PostTextClickListener(PostDataObject item)
        {
            Item = item;
        }

        public void OnClick(View p0, string p1)
        { 
           // Toast.MakeText(p0.Context, "This is a test for id" + Item.ParentId, ToastLength.Short).Show();
        }
    }

    public class ImageClickEventArgs : EventArgs
    {
        public int Position { get; set; }
        public RecyclerView.ViewHolder Holder { get; set; }
        public View View { get; set; }
        public PostDataObject NewsFeedClass { get; set; }
    }
}