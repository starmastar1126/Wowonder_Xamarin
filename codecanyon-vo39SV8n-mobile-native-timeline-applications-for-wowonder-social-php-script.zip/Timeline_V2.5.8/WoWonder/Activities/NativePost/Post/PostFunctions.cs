﻿using Android.App;

namespace WoWonder.Activities.NativePost.Post
{
    public class PostFunctions
    {
        public static string GetFeelingTypeIcon(string feeling)
        {
            if (feeling == "sad")
                return "☹️";
            if (feeling == "happy")
                return "😄";
            if (feeling == "angry")
                return "😠";
            if (feeling == "funny")
                return "😂";
            if (feeling == "loved")
                return "😍";
            if (feeling == "cool")
                return "🕶️";
            if (feeling == "tired")
                return "😩";
            if (feeling == "sleepy")
                return "😴";
            if (feeling == "expressionless")
                return "😑";
            if (feeling == "confused")
                return "😕";
            if (feeling == "shocked")
                return "😱";
            if (feeling == "so_sad")
                return "😭";
            if (feeling == "blessed")
                return "😇";
            if (feeling == "bored")
                return "😒";
            if (feeling == "broken")
                return "💔";
            if (feeling == "lovely")
                return "❤️";
            if (feeling == "hot")
                return "😏";

            else
                return string.Empty;
        }

        public static string GetFeelingTypeTextString(string feeling, Activity activityContext)
        {
            if (feeling == "sad")
                return activityContext.GetText(Resource.String.Lbl_Sad);
            if (feeling == "happy")
                return activityContext.GetText(Resource.String.Lbl_Happy);
            if (feeling == "angry")
                return activityContext.GetText(Resource.String.Lbl_Angry);
            if (feeling == "funny")
                return activityContext.GetText(Resource.String.Lbl_Funny);
            if (feeling == "loved")
                return activityContext.GetText(Resource.String.Lbl_Loved);
            if (feeling == "cool")
                return activityContext.GetText(Resource.String.Lbl_Cool);
            if (feeling == "tired")
                return activityContext.GetText(Resource.String.Lbl_Tired);
            if (feeling == "sleepy")
                return activityContext.GetText(Resource.String.Lbl_Sleepy);
            if (feeling == "expressionless")
                return activityContext.GetText(Resource.String.Lbl_Expressionless);
            if (feeling == "confused")
                return activityContext.GetText(Resource.String.Lbl_Confused);
            if (feeling == "shocked")
                return activityContext.GetText(Resource.String.Lbl_Shocked);
            if (feeling == "so_sad")
                return activityContext.GetText(Resource.String.Lbl_VerySad);
            if (feeling == "blessed")
                return activityContext.GetText(Resource.String.Lbl_Blessed);
            if (feeling == "bored")
                return activityContext.GetText(Resource.String.Lbl_Bored);
            if (feeling == "broken")
                return activityContext.GetText(Resource.String.Lbl_Broken);
            if (feeling == "lovely")
                return activityContext.GetText(Resource.String.Lbl_Lovely);
            if (feeling == "hot")
                return activityContext.GetText(Resource.String.Lbl_Hot);

            else
                return string.Empty;
        }

        public static bool GetVideosExtenstions(string extenstion)
        {
            if (extenstion.Contains(".MP4") || extenstion.Contains(".mp4"))
                return true;
            if (extenstion.Contains(".WMV") || extenstion.Contains(".wmv"))
                return true;
            if (extenstion.Contains(".3GP") || extenstion.Contains(".3gp"))
                return true;
            if (extenstion.Contains(".WEBM") || extenstion.Contains(".webm"))
                return true;
            if (extenstion.Contains(".FLV") || extenstion.Contains(".flv"))
                return true;
            if (extenstion.Contains(".AVI") || extenstion.Contains(".avi"))
                return true;
            if (extenstion.Contains(".HDV") || extenstion.Contains(".hdv"))
                return true;
            if (extenstion.Contains(".MPEG") || extenstion.Contains(".mpeg"))
                return true;
            if (extenstion.Contains(".MXF") || extenstion.Contains(".mxf"))
                return true;
            if (extenstion.Contains(".mov") || extenstion.Contains(".MOV"))
                return true;

            else
                return false;
        }

        public static bool GetImagesExtenstions(string extenstion)
        {
            if (extenstion == null)
                return false;

            if ((extenstion.Contains(".PNG") || extenstion.Contains(".png")))
                return true;
            if (extenstion.Contains(".JPG") || extenstion.Contains(".jpg"))
                return true;
            if (extenstion.Contains(".GIF") || extenstion.Contains(".gif"))
                return true;
            if (extenstion.Contains(".JEPG") || extenstion.Contains(".jpeg"))
                return true;
            else
                return false;
        }
    }
}