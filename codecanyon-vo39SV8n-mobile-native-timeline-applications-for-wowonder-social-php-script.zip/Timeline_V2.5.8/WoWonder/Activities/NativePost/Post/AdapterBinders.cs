﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Webkit;
using Android.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using Com.Tuyenmonkey.Textdecorator;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Android.Media;
using Android.OS;
using Java.IO;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.AddPost;
using WoWonder.Activities.MyProfile;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Pages;
using WoWonder.Activities.Search;
using WoWonder.Activities.Tabbes;
using WoWonder.Activities.UserProfile;
using WoWonder.Activities.UsersPages;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.Library.Anjo;
using WoWonder.SQLite;
using WoWonderClient;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.Story;
using Exception = System.Exception;
using Console = System.Console;
using Option = Android.Media.Option;
using Uri = Android.Net.Uri;
using WoWonder.Helpers.Controller;
using WoWonder.Library.Anjo.SuperTextLibrary;

namespace WoWonder.Activities.NativePost.Post
{
    public class AdapterBinders : Java.Lang.Object, StTools.IXAutoLinkOnClickListener
    {
        private StReadMoreOption ReadMoreOption { get; }
        private Activity MainContext { get; set; }
        private PostClickListener PostEventListener { get; set; }
        private readonly string PassedId;

        private RequestOptions CircleCropRequestOptions { get; }
        private RequestOptions NormalRequestOptions;
        private NativePostAdapter PostAdapter { get; set; }

        public AdapterBinders(Activity context, NativePostAdapter adapter, string passedId)
        {
            try
            {
                MainContext = context;
                PostEventListener = new PostClickListener(MainContext);
                PassedId = passedId;
                PostAdapter = adapter;
                ReadMoreOption = new StReadMoreOption.Builder()
                    .TextLength(200, StReadMoreOption.TypeCharacter)
                    .MoreLabel(context.GetText(Resource.String.Lbl_ReadMore))
                    .LessLabel(context.GetText(Resource.String.Lbl_ReadLess))
                    .MoreLabelColor(Color.ParseColor(AppSettings.MainColor))
                    .LessLabelColor(Color.ParseColor(AppSettings.MainColor))
                    .LabelUnderLine(true)
                    .Build();

                CircleCropRequestOptions = GlideImageLoader.GetRequestOptions(ImageStyle.CircleCrop, ImagePlaceholders.Color);
                NormalRequestOptions = GlideImageLoader.GetRequestOptions(ImageStyle.CenterCrop, ImagePlaceholders.Color);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public PostModelType GetAdapterType(PostDataObject item)
        {
            try
            {
                if (item == null)
                    return PostModelType.NormalPost;
                else if (!string.IsNullOrEmpty(item.PostType) && item.PostType == "ad")
                    return PostModelType.AdsPost;
                else if (item.SharedInfo.SharedInfoClass != null)
                    return PostModelType.SharedPost;
                else if (item.PostFile != null && (PostFunctions.GetImagesExtenstions(item.PostFile) || item.PhotoMulti?.Count > 0 || !string.IsNullOrEmpty(item.AlbumName)))
                {
                    if (item.PhotoMulti?.Count > 0)
                    {
                        if (item.PhotoMulti?.Count == 2)
                            return PostModelType.MultiImage2;
                        else if (item.PhotoMulti?.Count == 3)
                            return PostModelType.MultiImage3;
                        else if (item.PhotoMulti?.Count == 4)
                            return PostModelType.MultiImage4;
                        else if (item.PhotoMulti?.Count >= 5)
                            return PostModelType.MultiImages;
                    }

                    if (item.PhotoAlbum?.Count > 0)
                    {
                        if (item.PhotoAlbum?.Count is 1)
                        {
                            return PostModelType.ImagePost;
                        }
                        else if (item.PhotoAlbum?.Count is 2)
                        {
                            return PostModelType.MultiImage2;
                        }
                        else if (item.PhotoAlbum?.Count is 3)
                        {
                            return PostModelType.MultiImage3;
                        }
                        else if (item.PhotoAlbum?.Count is 4)
                        {
                            return PostModelType.MultiImage4;
                        }
                        else
                        {
                            if (item.PhotoAlbum?.Count >= 5)
                                return PostModelType.MultiImages;
                        }
                    }

                    return PostModelType.ImagePost;
                }
                else if (item.PostFileFull != null && (item.PostFileFull.Contains(".MP3") || item.PostFileFull.Contains(".mp3") || item.PostFileFull.Contains(".wav") || !string.IsNullOrEmpty(item.PostRecord)))
                    return PostModelType.VoicePost;
                else if (item.PostFile != null && PostFunctions.GetVideosExtenstions(item.PostFileFull))
                    return PostModelType.VideoPost;
                else if (!string.IsNullOrEmpty(item.PostSticker))
                    return PostModelType.StickerPost;
                else if (!string.IsNullOrEmpty(item.PostYoutube))
                    return PostModelType.YoutubePost;
                else if (!string.IsNullOrEmpty(item.PostDeepSound))
                    return PostModelType.DeepSoundPost;
                else if (!string.IsNullOrEmpty(item.PostPlaytube))
                    return PostModelType.PlayTubePost;
                else if (!string.IsNullOrEmpty(item.PostLink))
                    return PostModelType.LinkPost;
                else if (item.Product != null)
                    return PostModelType.ProductPost;
                else if (item.Blog != null)
                    return PostModelType.BlogPost;
                else if (item.Event != null)
                    return PostModelType.EventPost;
                else if (item.PostFileFull != null && (item.PostFileFull.Contains(".rar") || item.PostFileFull.Contains(".zip") || item.PostFileFull.Contains(".pdf")))
                    return PostModelType.FilePost;
                else if (item.ColorId != "0")
                    return PostModelType.ColorPost;
                else if (item.PollId != "0")
                    return PostModelType.PollPost;
                else if (!string.IsNullOrEmpty(item.PostFacebook))
                    return PostModelType.FacebookPost;

                return PostModelType.NormalPost;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return PostModelType.NormalPost;
            }
        }

        public void LoadPostData(AdapterHolders.PostViewsLayouts holder, PostDataObject item, int position)
        {
            try
            {
                if (item.PostType == "ad")
                {
                    //Bind click events to views
                    holder.BindClickEvents(item, position, PostEventListener);
                    return;
                }

                if (holder.SecondReactionButton != null)
                {
                    if (AppSettings.PostButton == PostButtonSystem.Reaction || AppSettings.PostButton == PostButtonSystem.Like)
                    {
                        holder.MainSectionButton.WeightSum = 3;
                        holder.SecondReactionButton.Visibility = ViewStates.Gone;
                    }
                    else if (AppSettings.PostButton == PostButtonSystem.Wonder)
                    {
                        holder.MainSectionButton.WeightSum = 4;
                        holder.SecondReactionButton.Visibility = ViewStates.Visible;

                        holder.SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_wowonder);
                        holder.SecondReactionText.Text = Application.Context.GetText(Resource.String.Btn_Wonder);
                    }
                    else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                    {
                        holder.MainSectionButton.WeightSum = 4;
                        holder.SecondReactionButton.Visibility = ViewStates.Visible;

                        holder.SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_dislike);
                        holder.SecondReactionText.Text = Application.Context.GetText(Resource.String.Btn_Dislike);
                    }
                }

                if (!AppSettings.ShowTextShareButton && holder.ShareText != null)
                    holder.ShareText.Visibility = ViewStates.Gone;

                UserDataObject publisher = null;
                if (item.Publisher != null)
                {
                    publisher = item.Publisher;
                }
                else if (item.UserData != null)
                {
                    publisher = item.UserData;
                }

                if (publisher != null)
                {
                    GlideImageLoader.LoadImage(MainContext, publisher.Avatar, holder.UserAvatar, ImageStyle.CircleCrop, ImagePlaceholders.Color, false, CircleCropRequestOptions);

                    if (holder.PostExtrasLayout != null)
                        holder.PostExtrasLayout.Visibility = item.IsPostBoosted == "0" ? ViewStates.Gone : ViewStates.Visible;

                    if (string.IsNullOrEmpty(item.Orginaltext))
                    {
                        if (holder.Description.Visibility != ViewStates.Gone)
                            holder.Description.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        if (holder.Description.Visibility != ViewStates.Visible)
                            holder.Description.Visibility = ViewStates.Visible;

                        Dictionary<string, string> dataUser = new Dictionary<string, string>();
                        if (item.PostText.Contains("data-id="))
                        {
                            try
                            {
                                string pattern = @"(data-id=[""'](.*?)[""']|href=[""'](.*?)[""'])";
                                var aa = Regex.Matches(item.PostText, pattern);

                                for (int i = 0; i < aa.Count; i++)
                                {
                                    var userid = aa[i].Value.Replace("data-id=", "").Replace('"', ' ').Replace(" ", "");
                                    var username = aa[i + 1].Value.Replace("href=", "").Replace('"', ' ').Replace(" ", "").Replace(Client.WebsiteUrl, "");

                                    var data = dataUser.FirstOrDefault(a => a.Key?.ToString() == userid && a.Value?.ToString() == username);
                                    if (data.Key != null) continue;
                                    i++;
                                    dataUser.Add(userid, username);
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        }

                        if (!holder.Description.Text.Contains(MainContext.GetText(Resource.String.Lbl_ReadMore)) && !holder.Description.Text.Contains(MainContext.GetText(Resource.String.Lbl_ReadLess)))
                        {
                            holder.Description.SetAutoLinkOnClickListener(this, dataUser);
                            holder.Description.Text = Methods.FunString.DecodeString(item.Orginaltext);
                            ReadMoreOption.AddReadMoreTo(holder.Description, new String(holder.Description.Text));
                        }
                        else if (holder.Description.Text.Contains(MainContext.GetText(Resource.String.Lbl_ReadLess)))
                        {
                            ReadMoreOption.AddReadLess(holder.Description, new String(holder.Description.Text));
                        } 
                    }

                    holder.TimeText.Text = Methods.Time.TimeAgo(int.Parse(item.Time));

                    var font = Typeface.CreateFromAsset(Application.Context.Resources.Assets, "ionicons.ttf");
                    holder.CommentCount.SetTypeface(font, TypefaceStyle.Normal);

                    TextDecorator.Decorate(holder.CommentCount, IonIconsFonts.IosChatbubbleOutline + " " + item.PostComments)
                        .SetTextColor(Resource.Color.text_color_in_between, IonIconsFonts.IosChatbubbleOutline + " " + item.PostComments)
                        .SetRelativeSize(1.3f, IonIconsFonts.IosChatbubbleOutline)
                        .SetRelativeSize(1.1f, item.PostComments)
                        .AlignText(Android.Text.Layout.Alignment.AlignOpposite, item.PostComments).Build();

                    var textHighLighter = Methods.FunString.DecodeString(publisher.Name);
                    var textIsPro = string.Empty;
                    var textFeelings = string.Empty;
                    var textTraveling = string.Empty;
                    var textWatching = string.Empty;
                    var textPlaying = string.Empty;
                    var textListening = string.Empty;
                    var textProduct = string.Empty;
                    var textArticle = string.Empty;
                    var textLocation = string.Empty;
                    var textAlbumName = string.Empty;
                    var textImageChange = string.Empty;
                    var textShare = string.Empty;
                    var textGroupRecipient = string.Empty;
                    var textUserRecipient = string.Empty;

                    if (publisher.Verified == "1")
                        textHighLighter += " " + IonIconsFonts.CheckmarkCircled;

                    if (publisher.IsPro == "1")
                    {
                        textIsPro = " " + IonIconsFonts.Flash;
                        textHighLighter += textIsPro;
                    }

                    if (!string.IsNullOrEmpty(item.PostFeeling) && item.SharedInfo.SharedInfoClass == null)
                    {
                        textFeelings = " " + MainContext.GetString(Resource.String.Lbl_IsFeeling) + " " +
                                       PostFunctions.GetFeelingTypeIcon(item.PostFeeling) + " " +
                                       PostFunctions.GetFeelingTypeTextString(item.PostFeeling, MainContext);
                        textHighLighter += textFeelings;
                    }

                    if (!string.IsNullOrEmpty(item.PostTraveling))
                    {
                        textTraveling = "  " + IonIconsFonts.Plane + " " +
                                        MainContext.GetText(Resource.String.Lbl_IsTravelingTo) + " " +
                                        item.PostTraveling;
                        textHighLighter += textTraveling;
                    }

                    if (!string.IsNullOrEmpty(item.PostWatching))
                    {
                        textWatching = "  " + IonIconsFonts.Eye + " " +
                                       MainContext.GetText(Resource.String.Lbl_IsWatching) + " " + item.PostWatching;
                        textHighLighter += textWatching;
                    }

                    if (!string.IsNullOrEmpty(item.PostPlaying))
                    {
                        textPlaying = "  " + IonIconsFonts.IosGameControllerB + " " +
                                      MainContext.GetText(Resource.String.Lbl_IsPlaying) + " " + item.PostPlaying;
                        textHighLighter += textPlaying;
                    }

                    if (!string.IsNullOrEmpty(item.PostListening))
                    {
                        textListening = "  " + IonIconsFonts.Headphone + " " +
                                        MainContext.GetText(Resource.String.Lbl_IsListeningTo) + " " +
                                        item.PostListening;
                        textHighLighter += textListening;
                    }

                    if (!string.IsNullOrEmpty(item.PostMap))
                    {
                        textLocation = "  " + IonIconsFonts.Location + " " + item.PostMap;
                        textHighLighter += textLocation;
                    }

                    if (item.PostType == "profile_cover_picture" && item.SharedInfo.SharedInfoClass == null)
                    {
                        textImageChange += " " + MainContext.GetText(Resource.String.Lbl_ChangedProfileCover) + " ";
                        textHighLighter += textImageChange;
                    }

                    if (item.PostType == "profile_picture" && item.SharedInfo.SharedInfoClass == null)
                    {
                        textImageChange += " " + MainContext.GetText(Resource.String.Lbl_ChangedProfilePicture) + " ";
                        textHighLighter += textImageChange;
                    }

                    if (item.Product != null && item.SharedInfo.SharedInfoClass == null)
                    {
                        textProduct = " " + MainContext.GetText(Resource.String.Lbl_AddedNewProductForSell) + " ";
                        textHighLighter += textProduct;
                    }

                    if (item.Blog != null && item.SharedInfo.SharedInfoClass == null)
                    {
                        textArticle = " " + MainContext.GetText(Resource.String.Lbl_CreatedNewArticle) + " ";
                        textHighLighter += textArticle;
                    }

                    if (!string.IsNullOrEmpty(item.AlbumName) && item.AlbumName != null &&
                        item.SharedInfo.SharedInfoClass == null)
                    {
                        textAlbumName = " " + MainContext.GetText(Resource.String.Lbl_addedNewPhotosTo) + " " +
                                        item.AlbumName;
                        textHighLighter += textAlbumName;
                    }

                    if (item.ParentId != "0")
                    {
                        textShare += " " + MainContext.GetText(Resource.String.Lbl_SharedPost) + " ";
                        textHighLighter += textShare;
                    }

                    if (item.GroupRecipientExists)
                    {
                        if (PostAdapter.NativePostType != NativeFeedType.Group)
                        {
                            textGroupRecipient += " " + IonIconsFonts.ArrowRightC + " " + item.GroupRecipient.Name;
                            textHighLighter += textGroupRecipient;
                        }
                    }

                    if (item.RecipientExists)
                    {
                        textUserRecipient += " " + IonIconsFonts.ArrowRightC + " " + item.Recipient.Name;
                        textHighLighter += textUserRecipient;
                    }

                    holder.Username.SetTypeface(font, TypefaceStyle.Normal);

                    var decorator = TextDecorator.Decorate(holder.Username, textHighLighter)
                        .SetTextStyle((int)TypefaceStyle.Bold, 0, publisher.Name.Length);

                    if (publisher.Verified == "1")
                        decorator.SetTextColor(Resource.Color.Post_IsVerified, IonIconsFonts.CheckmarkCircled);

                    if (publisher.IsPro == "1")
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textIsPro);

                    if (!string.IsNullOrEmpty(item.PostFeeling))
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textFeelings);

                    if (!string.IsNullOrEmpty(item.PostTraveling))
                    {
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textTraveling);
                        decorator.SetTextColor(Resource.Color.Post_Traveling, IonIconsFonts.Plane);
                        decorator.SetRelativeSize(1.3f, IonIconsFonts.Plane);
                    }

                    if (!string.IsNullOrEmpty(item.PostWatching))
                    {
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textWatching);
                        decorator.SetTextColor(Resource.Color.Post_Watching, IonIconsFonts.Eye);
                        decorator.SetRelativeSize(1.3f, IonIconsFonts.Eye);
                    }

                    if (!string.IsNullOrEmpty(item.PostPlaying))
                    {
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textPlaying);
                        decorator.SetTextColor(Resource.Color.Post_Playing, IonIconsFonts.IosGameControllerB);
                        decorator.SetRelativeSize(1.3f, IonIconsFonts.IosGameControllerB);
                    }

                    if (!string.IsNullOrEmpty(item.PostListening))
                    {
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textListening);
                        decorator.SetTextColor(Resource.Color.Post_Listening, IonIconsFonts.Headphone);
                        decorator.SetRelativeSize(1.3f, IonIconsFonts.Headphone);
                    }

                    if (!string.IsNullOrEmpty(item.PostMap))
                    {
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textLocation);
                        decorator.SetTextColor(Resource.Color.Post_Watching, IonIconsFonts.Location);
                        decorator.SetRelativeSize(1.3f, IonIconsFonts.Location);
                    }

                    if (item.PostType == "profile_cover_picture" || item.PostType == "profile_picture")
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textImageChange);

                    if (item.Product != null)
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textProduct);

                    if (item.Blog != null)
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textArticle);

                    if (item.ParentId != "0")
                    {
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textShare);
                        decorator.MakeTextClickable(new PostTextClickListener(item), false, "post");
                    }

                    if (item.GroupRecipientExists)
                    {
                        decorator.SetTextStyle((int)TypefaceStyle.Bold, textGroupRecipient);
                        decorator.SetRelativeSize(1.0f, IonIconsFonts.ArrowRightC);
                        //decorator.SetTextColor(Resource.Color.text_color_in_between, textGroupRecipient);
                    }

                    if (item.RecipientExists)
                    {
                        decorator.SetTextStyle((int)TypefaceStyle.Bold, textUserRecipient);
                        decorator.SetRelativeSize(1.0f, IonIconsFonts.ArrowRightC);
                    }

                    if (!string.IsNullOrEmpty(item.AlbumName) && item.AlbumName != null)
                        decorator.SetTextColor(Resource.Color.text_color_in_between, textAlbumName);

                    decorator.Build();
                }

                if (AppSettings.PostButton == PostButtonSystem.Reaction)
                {
                    if (item.Reaction == null)
                        item.Reaction = new WoWonderClient.Classes.Posts.Reaction();

                    holder.LikeCount.Text = item?.Reaction?.Count == null ? "0" + " " + MainContext.GetString(Resource.String.Btn_Likes) : item?.Reaction?.Count + " " + MainContext.GetString(Resource.String.Btn_Likes);

                    if ((bool)(item.Reaction != null & item.Reaction?.IsReacted))
                    {
                        if (!string.IsNullOrEmpty(item.Reaction.Type))
                        {
                            switch (item.Reaction.Type)
                            {
                                case "Like":
                                    holder.LikeButton.SetReactionPack(ReactConstants.Like);
                                    break;
                                case "Love":
                                    holder.LikeButton.SetReactionPack(ReactConstants.Love);
                                    break;
                                case "HaHa":
                                    holder.LikeButton.SetReactionPack(ReactConstants.HaHa);
                                    break;
                                case "Wow":
                                    holder.LikeButton.SetReactionPack(ReactConstants.Wow);
                                    break;
                                case "Sad":
                                    holder.LikeButton.SetReactionPack(ReactConstants.Sad);
                                    break;
                                case "Angry":
                                    holder.LikeButton.SetReactionPack(ReactConstants.Angry);
                                    break;
                                default:
                                    holder.LikeButton.SetReactionPack(ReactConstants.Default);
                                    break;

                            }
                        }
                    }
                }
                else
                {
                    if (item.IsLiked)
                        holder.LikeButton.SetReactionPack(ReactConstants.Like);

                    holder.LikeCount.Text = Methods.FunString.FormatPriceValue(int.Parse(item.PostLikes)) + " " + MainContext.GetString(Resource.String.Btn_Likes);

                    if (holder.SecondReactionImage != null)
                    {
                        if (AppSettings.PostButton == PostButtonSystem.Wonder)
                        {

                            if (item.IsWondered)
                            {
                                holder.SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_wowonder);
                                holder.SecondReactionImage.SetColorFilter(Color.ParseColor(AppSettings.MainColor));

                                holder.SecondReactionText.Text = MainContext.GetString(Resource.String.Lbl_wondered);
                                holder.SecondReactionText.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                            }
                            else
                            {
                                holder.SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_wowonder);
                                holder.SecondReactionImage.SetColorFilter(Color.ParseColor("#666666"));

                                holder.SecondReactionText.Text = MainContext.GetString(Resource.String.Btn_Wonder);
                                holder.SecondReactionText.SetTextColor(Color.ParseColor("#444444"));
                            }
                        }
                        else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                        {
                            if (item.IsWondered)
                            {
                                holder.SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_dislike);
                                holder.SecondReactionImage.SetColorFilter(Color.ParseColor(AppSettings.MainColor));

                                holder.SecondReactionText.Text = MainContext.GetString(Resource.String.Lbl_disliked);
                                holder.SecondReactionText.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                            }
                            else
                            {
                                holder.SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_dislike);
                                holder.SecondReactionImage.SetColorFilter(Color.ParseColor("#666666"));

                                holder.SecondReactionText.Text = MainContext.GetString(Resource.String.Btn_Dislike);
                                holder.SecondReactionText.SetTextColor(Color.ParseColor("#444444"));
                            }
                        }
                    }
                }

                //Bind click events to views
                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindSharedPost(AdapterHolders.SharedGlobalViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                if (item.SharedInfo.SharedInfoClass == null)
                    return;

                holder.ViewsLayouts.MainSectionButton.WeightSum = 2;

                var getSharedFrom = GetAdapterType(item.SharedInfo.SharedInfoClass);

                if (getSharedFrom == PostModelType.ColorPost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_ColorBox;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.ColorBoxViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass, 0, this);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindColorPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.VideoPost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_Video;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.VideoPlayerViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass, 0, this);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindVideoPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.MultiImage2 || getSharedFrom == PostModelType.MultiImage3 || getSharedFrom == PostModelType.MultiImage4 || getSharedFrom == PostModelType.MultiImages)
                {
                    if (getSharedFrom == PostModelType.MultiImage2)
                        holder.StubLoader.LayoutResource = Resource.Layout.PostType_2Photo;
                    else if (getSharedFrom == PostModelType.MultiImage3)
                        holder.StubLoader.LayoutResource = Resource.Layout.PostType_3Photo;
                    else if (getSharedFrom == PostModelType.MultiImage4)
                        holder.StubLoader.LayoutResource = Resource.Layout.PostType_4Photo;
                    else if (getSharedFrom == PostModelType.MultiImages)
                        holder.StubLoader.LayoutResource = Resource.Layout.PostType_MultiPhoto;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.PostImagesViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindMultiImagesPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.LinkPost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_Link;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.LinkPostViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindLinkPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.ProductPost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_Product;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.ProductPostViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindProductPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.FilePost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_File;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.FilePostViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindFilePost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.YoutubePost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_Youtube;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.YoutubePostViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindThirdPartyVideosPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.VoicePost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_Voice;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.SoundPostViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindVoicePost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }
                else if (getSharedFrom == PostModelType.EventPost)
                {
                    holder.StubLoader.LayoutResource = Resource.Layout.PostType_Event;

                    if (holder.Inflated == null)
                        holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var insideMainHolder1 = new AdapterHolders.EventPostViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass);
                    insideMainHolder1.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;
                    BindEventPost(insideMainHolder1, item.SharedInfo.SharedInfoClass, position);
                    holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                    holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                    holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                    holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);
                    LoadPostData(holder.ViewsLayouts, item, position);
                    return;
                }

                holder.StubLoader.LayoutResource = Resource.Layout.PostType_Global;

                if (holder.Inflated == null)
                    holder.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                var insideMainHolder = new AdapterHolders.GlobalViewHolder(holder.Inflated, item.SharedInfo.SharedInfoClass, 0, this);
                insideMainHolder.ViewsLayouts.PostActionsView.Visibility = ViewStates.Gone;

                holder.ViewsLayouts.LikeButton = holder.ViewsLayouts.MainView.FindViewById<ReactButton>(Resource.Id.beactButton2);
                holder.ViewsLayouts.CommentButton = holder.ViewsLayouts.MainView.FindViewById<LinearLayout>(Resource.Id.linercomment2);
                holder.ViewsLayouts.LikeCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Likecount2);
                holder.ViewsLayouts.CommentCount = holder.ViewsLayouts.MainView.FindViewById<TextView>(Resource.Id.Commentcount2);

                LoadPostData(holder.ViewsLayouts, item, position);

                if (getSharedFrom == PostModelType.DeepSoundPost)
                    BindDeepSoundPost(insideMainHolder, item.SharedInfo.SharedInfoClass, position);
                else if (getSharedFrom == PostModelType.ImagePost)
                    BindPhotoPost(insideMainHolder, item.SharedInfo.SharedInfoClass, position);
                else if (getSharedFrom == PostModelType.PlayTubePost)
                    BindPlayTubePost(insideMainHolder, item.SharedInfo.SharedInfoClass, position);
                else if (getSharedFrom == PostModelType.StickerPost)
                    BindPhotoPost(insideMainHolder, item.SharedInfo.SharedInfoClass, position);
                else
                    LoadPostData(insideMainHolder.ViewsLayouts, item.SharedInfo.SharedInfoClass, position);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindPhotoPost(AdapterHolders.GlobalViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                holder.ViewsLayouts.StubLoader.LayoutResource = Resource.Layout.ViewSub_Post_Image;

                if (holder.ViewsLayouts.Inflated == null)
                    holder.ViewsLayouts.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                var image = holder.ViewsLayouts.Inflated.FindViewById<ImageView>(Resource.Id.image);
                var imageUrl = !string.IsNullOrEmpty(item.PostSticker) ? item.PostSticker : item.PostFileFull;
                GlideImageLoader.LoadImage(MainContext, imageUrl, image, ImageStyle.FitCenter, ImagePlaceholders.Color, false);


                holder.BindClickEvents(item, position, PostEventListener, image);

                //if (!image.HasOnClickListeners)
                //{
                //    image.Click += delegate
                //    { 
                //        var Int = new Intent(MainContext, typeof(ImagePostViewerActivity));
                //        Int.PutExtra("itemIndex", "00"); //PhotoAlbumObject
                //        Int.PutExtra("AlbumObject", JsonConvert.SerializeObject(item)); // PostDataObject
                //        MainContext.StartActivity(Int); 
                //    };
                //} 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindMultiImagesPost(AdapterHolders.PostImagesViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                if (item.PhotoMulti?.Count == 2 || item.PhotoAlbum?.Count == 2)
                {
                    var imagesList = item.PhotoMulti ?? item.PhotoAlbum;

                    GlideImageLoader.LoadImage(MainContext, imagesList[0].Image, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[1].Image, holder.Image2, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                }
                else if (item.PhotoMulti?.Count == 3 || item.PhotoAlbum?.Count == 3)
                {
                    var imagesList = item.PhotoMulti ?? item.PhotoAlbum;

                    GlideImageLoader.LoadImage(MainContext, imagesList[0].Image, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[1].Image, holder.Image2, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[2].Image, holder.Image3, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                }
                else if (item.PhotoMulti?.Count == 4 || item.PhotoAlbum?.Count == 4)
                {
                    var imagesList = item.PhotoMulti ?? item.PhotoAlbum;

                    GlideImageLoader.LoadImage(MainContext, imagesList[0].Image, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[1].Image, holder.Image2, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[2].Image, holder.Image3, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[3].Image, holder.Image4, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                }
                else if (item.PhotoMulti?.Count >= 5 || item.PhotoAlbum?.Count >= 5)
                {
                    var imagesList = item.PhotoMulti ?? item.PhotoAlbum;

                    GlideImageLoader.LoadImage(MainContext, imagesList[0].Image, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[1].Image, holder.Image2, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[2].Image, holder.Image3, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    GlideImageLoader.LoadImage(MainContext, imagesList[3].Image, holder.Image3, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                    holder.CountImageLabel.Text = "+" + (imagesList?.Count - 2);
                }

                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindVoicePost(AdapterHolders.SoundPostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.MoreIcon, IonIconsFonts.More);
                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindThirdPartyVideosPost(AdapterHolders.YoutubePostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                Glide.With(MainContext).Load("https://img.youtube.com/vi/" + item.PostYoutube + "/0.jpg").Apply(new RequestOptions().Placeholder(Resource.Drawable.ImagePlacholder)).Into(holder.Image);

                //GlideImageLoader.LoadImage(MainContext, "https://img.youtube.com/vi/" + item.PostYoutube + "/0.jpg", holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color);

                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindLinkPost(AdapterHolders.LinkPostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                holder.LinkUrl.Text = item.PostLink?.Replace("https://", "").Replace("http://", "").Split('/').FirstOrDefault();
                holder.PostLinkTitle.Text = Methods.FunString.DecodeString(item.PostLinkTitle);
                holder.PostLinkContent.Text = Methods.FunString.DecodeString(item.PostLinkContent);

                if (string.IsNullOrEmpty(item.PostLinkImage))
                    holder.Image.Visibility = ViewStates.Gone;
                else
                    Glide.With(MainContext).Load(item.PostLinkImage).Apply(new RequestOptions()).Into(holder.Image);
                // GlideImageLoader.LoadImage(MainContext, item.PostLinkImage, holder.Image, ImageStyle.None, ImagePlaceholders.Color);

                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindAdsPost(AdapterHolders.AdsPostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                GlideImageLoader.LoadImage(MainContext, item.UserData.Avatar, holder.ViewsLayouts.UserAvatar, ImageStyle.CircleCrop, ImagePlaceholders.Color, false, CircleCropRequestOptions);

                holder.ViewsLayouts.Username.Text = Methods.FunString.DecodeString(item.Name);
                holder.ViewsLayouts.TimeText.Text = Methods.Time.TimeAgo(int.Parse(item.Posted));
                holder.TextLocation.Text = Methods.FunString.DecodeString(item.Location);

                if (string.IsNullOrEmpty(item.Orginaltext))
                {
                    if (holder.ViewsLayouts.Description.Visibility != ViewStates.Gone)
                        holder.ViewsLayouts.Description.Visibility = ViewStates.Gone;
                }
                else
                {
                    if (holder.ViewsLayouts.Description.Visibility != ViewStates.Visible)
                        holder.ViewsLayouts.Description.Visibility = ViewStates.Visible;

                    Dictionary<string, string> dataUser = new Dictionary<string, string>();
                    if (item.PostText.Contains("data-id="))
                    {
                        string pattern = @"(data-id=[""'](.*?)[""']|href=[""'](.*?)[""'])";
                        var aa = Regex.Matches(item.PostText, pattern);

                        for (int i = 0; i < aa.Count; i++)
                        {
                            var userid = aa[i].Value.Replace("data-id=", "").Replace('"', ' ').Replace(" ", "");
                            var username = aa[i + 1].Value.Replace("href=", "").Replace('"', ' ').Replace(" ", "").Replace(Client.WebsiteUrl, "");

                            var data = dataUser.FirstOrDefault(a => a.Key?.ToString() == userid && a.Value?.ToString() == username);
                            if (data.Key == null)
                            {
                                i++;
                                dataUser.Add(userid, username);
                            }
                        }
                    }

                    if (!holder.ViewsLayouts.Description.Text.Contains(MainContext.GetText(Resource.String.Lbl_ReadMore)) && !holder.ViewsLayouts.Description.Text.Contains(MainContext.GetText(Resource.String.Lbl_ReadLess)))
                    {
                        holder.ViewsLayouts.Description.SetAutoLinkOnClickListener(this, dataUser);
                        holder.ViewsLayouts.Description.Text = Methods.FunString.DecodeString(item.Description);
                        ReadMoreOption.AddReadMoreTo(holder.ViewsLayouts.Description, new String(holder.ViewsLayouts.Description.Text));
                    }
                    else if (holder.ViewsLayouts.Description.Text.Contains(MainContext.GetText(Resource.String.Lbl_ReadLess)))
                    {
                        ReadMoreOption.AddReadLess(holder.ViewsLayouts.Description, new String(holder.ViewsLayouts.Description.Text));
                    }
                     
                    //ReadMoreOption.AddReadMoreTo(holder.Description, Methods.FunString.DecodeString(item.Orginaltext));
                }

                TextSanitizer headlineSanitizer = new TextSanitizer(holder.Headline, MainContext);
                headlineSanitizer.Load(Methods.FunString.DecodeString(item.Headline));

                holder.LinkUrl.Text = item.Url?.Replace("https://", "").Replace("http://", "").Split('/').FirstOrDefault();
                holder.PostLinkTitle.Visibility = ViewStates.Gone;
                holder.PostLinkContent.Visibility = ViewStates.Gone;

                if (string.IsNullOrEmpty(item.AdMedia))
                    holder.Image.Visibility = ViewStates.Gone;
                else
                    Glide.With(MainContext).Load(item.AdMedia).Apply(new RequestOptions()).Into(holder.Image);

                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindPlayTubePost(AdapterHolders.GlobalViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                var playTubeUrl = ListUtils.SettingsSiteList.PlaytubeUrl;

                var fullEmbedUrl = playTubeUrl + "/embed/" + item.PostPlaytube;

                if (AppSettings.EmbedPlayTubePostType)
                {
                    holder.ViewsLayouts.StubLoader.LayoutResource = Resource.Layout.ViewSub_Post_WebView;
                    if (holder.ViewsLayouts.Inflated == null)
                        holder.ViewsLayouts.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var webView = holder.ViewsLayouts?.Inflated?.FindViewById<WebView>(Resource.Id.webview);
                    if (webView != null)
                    {
                        webView.Settings.JavaScriptEnabled = true;
                        webView.Settings.DomStorageEnabled = true;
                        webView.Settings.AllowFileAccess = true;
                        webView.Settings.JavaScriptCanOpenWindowsAutomatically = true;
                        webView.Settings.SetLayoutAlgorithm(WebSettings.LayoutAlgorithm.NarrowColumns);

                        webView.LoadUrl(fullEmbedUrl);
                    }
                }
                else
                {
                    item.PostLink = fullEmbedUrl;
                    //  BindLinkPost(holder, item, position);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindDeepSoundPost(AdapterHolders.GlobalViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                var deepSoundUrl = ListUtils.SettingsSiteList.DeepsoundUrl;

                var fullEmbedUrl = deepSoundUrl + "/embed/" + item.PostDeepSound;

                if (AppSettings.EmbedDeepSoundPostType)
                {
                    holder.ViewsLayouts.StubLoader.LayoutResource = Resource.Layout.ViewSub_Post_WebView;
                    if (holder.ViewsLayouts.Inflated == null)
                        holder.ViewsLayouts.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                    var webView = holder.ViewsLayouts.Inflated.FindViewById<WebView>(Resource.Id.webview);
                    webView.Settings.JavaScriptEnabled = true;
                    webView.Settings.DomStorageEnabled = true;
                    webView.Settings.AllowFileAccess = true;
                    webView.Settings.JavaScriptCanOpenWindowsAutomatically = true;
                    webView.Settings.SetLayoutAlgorithm(WebSettings.LayoutAlgorithm.NarrowColumns);

                    webView.LoadUrl(fullEmbedUrl);
                }
                else
                {
                    item.PostLink = fullEmbedUrl;
                    //BindLinkPost(holder, item, position);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindFacebookPost(AdapterHolders.GlobalViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                var iframeEmbedUrl = "<html> " +
                                   "<body>" +
                                   "<iframe src='" + "https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2F" + item.PostFacebook + "&width=500&show_text=false&height=280' width='500' height='280' style='border: none; overflow: hidden' scrolling='no' frameborder='0' allowTransparency='true' allow='encrypted - media' allowFullScreen='true'>" +
                                   "</iframe>" +
                                   "</body>" +
                                   "</html>";
                var fullEmbedUrl = "https://www.facebook.com/video/embed?video_id=" + item.PostFacebook.Split("/videos/").Last();

                if (AppSettings.EmbedFacebookVideoPostType)
                {
                    holder.ViewsLayouts.StubLoader.LayoutResource = Resource.Layout.ViewSub_Post_WebView;
                    if (holder.ViewsLayouts.Inflated != null)
                        return;

                    holder.ViewsLayouts.Inflated = holder.ViewsLayouts.StubLoader.Inflate();
                    var webView = holder.ViewsLayouts.Inflated.FindViewById<WebView>(Resource.Id.webview);

                    webView.Settings.SetLayoutAlgorithm(WebSettings.LayoutAlgorithm.NarrowColumns);
                    webView.Settings.JavaScriptEnabled = true;
                    webView.Settings.DomStorageEnabled = true;
                    webView.Settings.AllowFileAccess = true;
                    webView.Settings.JavaScriptCanOpenWindowsAutomatically = true;
                    webView.Settings.DefaultTextEncodingName = "utf-8";

                    //Load url to be rendered on WebView 
                    webView.LoadUrl(fullEmbedUrl);
                    webView.Visibility = ViewStates.Visible;
                }
                else
                {
                    item.PostLink = fullEmbedUrl;
                    //BindLinkPost(holder, item, position);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindVideoPost(AdapterHolders.VideoPlayerViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);
                holder.ViewsLayouts.MainView.Tag = holder;

                holder.ViewsLayouts.Viewcount.Text = item.VideoViews + " " + MainContext.GetString(Resource.String.Lbl_Views);
                if (!string.IsNullOrEmpty(item.PostFileThumb))
                {
                    Glide.With(MainContext).Load(item.PostFileThumb).Apply(new RequestOptions().Error(Resource.Drawable.ImagePlacholder)
                        .Placeholder(Resource.Drawable.ImagePlacholder).Override(AppSettings.ImagePostSize)).Into(holder.ViewsLayouts.VideoImage);
                }
                else
                {
                    //GetImage(holder, item).ConfigureAwait(false);

                    Glide.With(MainContext).Load(Resource.Drawable.blackdefault).Apply(new RequestOptions().Error(Resource.Drawable.ImagePlacholder)
                        .Placeholder(Resource.Drawable.ImagePlacholder).Override(AppSettings.ImagePostSize)).Into(holder.ViewsLayouts.VideoImage);
                }

                if (!holder.ViewsLayouts.PlayControl.HasOnClickListeners)
                    holder.ViewsLayouts.PlayControl.Click += (sender, args) =>
                    {
                        try
                        {
                            WRecyclerView.GetInstance()?.PlayVideo(!WRecyclerView.GetInstance().CanScrollVertically(1), holder, item);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async Task GetImage(AdapterHolders.VideoPlayerViewHolder holder, PostDataObject item)
        {
            try
            {
                MediaMetadataRetriever retriever;
                if (item.PostFileFull.Contains("http"))
                {
                    retriever = new MediaMetadataRetriever();
                    if ((int)Build.VERSION.SdkInt >= 14)
                        retriever.SetDataSource(item.PostFileFull, new Dictionary<string, string>());
                    else
                        retriever.SetDataSource(item.PostFileFull);
                }
                else
                {
                    var file = Uri.FromFile(new File(item.PostFileFull));

                    retriever = new MediaMetadataRetriever();
                    retriever.SetDataSource(file.Path);
                }

                Bitmap bitmap = retriever.GetFrameAtTime(1, Option.Closest);
                if (bitmap != null)
                {
                    Glide.With(MainContext).Load(bitmap).Apply(new RequestOptions()
                        .Error(Resource.Drawable.ImagePlacholder)
                        .Placeholder(Resource.Drawable.ImagePlacholder)
                        .Override(AppSettings.ImagePostSize)).Into(holder.ViewsLayouts.VideoImage);
                }
                retriever.Release();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);

            }
        }


        public void BindProductPost(AdapterHolders.ProductPostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                if (item.Product != null && item.Product.Value.ProductClass?.Images.Count > 0)
                {
                    if (item.Product.Value.ProductClass?.Images.Count == 1)
                        holder.ImageViewSub.LayoutResource = Resource.Layout.ViewSub_Post_Image;

                    if (item.Product.Value.ProductClass?.Images.Count == 2)
                        holder.ImageViewSub.LayoutResource = Resource.Layout.ViewSub_Post_2Image;

                    if (item.Product.Value.ProductClass?.Images.Count == 3)
                        holder.ImageViewSub.LayoutResource = Resource.Layout.ViewSub_Post_3Image;

                    if (item.Product.Value.ProductClass?.Images.Count == 4)
                        holder.ImageViewSub.LayoutResource = Resource.Layout.ViewSub_Post_4Image;

                    if (item.Product.Value.ProductClass?.Images.Count >= 5)
                        holder.ImageViewSub.LayoutResource = Resource.Layout.ViewSub_Post_MultiImages;

                    var imageView = holder.ImageViewSub.Inflate();
                    var image = imageView.FindViewById<ImageView>(Resource.Id.image);
                    var image2 = imageView.FindViewById<ImageView>(Resource.Id.image2);
                    var image3 = imageView.FindViewById<ImageView>(Resource.Id.image3);
                    var image4 = imageView.FindViewById<ImageView>(Resource.Id.image4);

                    GlideImageLoader.LoadImage(MainContext, item.Product.Value.ProductClass?.Images[0].Image, image, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);

                    if (item.Product.Value.ProductClass?.Images.Count >= 2)
                        GlideImageLoader.LoadImage(MainContext, item.Product.Value.ProductClass?.Images[1].Image, image2, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);

                    if (item.Product.Value.ProductClass?.Images.Count >= 3)
                        GlideImageLoader.LoadImage(MainContext, item.Product.Value.ProductClass?.Images[2].Image, image3, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);

                    if (item.Product.Value.ProductClass?.Images.Count >= 4)
                        GlideImageLoader.LoadImage(MainContext, item.Product.Value.ProductClass?.Images[3].Image, image4, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);

                    if (item.Product.Value.ProductClass?.Images.Count >= 5)
                    {
                        var countLeft = holder.ViewsLayouts.Inflated.FindViewById<TextView>(Resource.Id.counttext);
                        countLeft.Text = "+" + (item.PhotoMulti?.Count - 2);
                    }
                    //open Product view
                    if (image != null && !image.HasOnClickListeners)
                        image.Click += (sender, args) => { PostEventListener.ProductPostClick(new GlobalClickEventArgs { NewsFeedClass = item, Holder = holder, Position = position }); };

                    if (image2 != null && !image2.HasOnClickListeners)
                        image2.Click += (sender, args) => { PostEventListener.ProductPostClick(new GlobalClickEventArgs { NewsFeedClass = item, Holder = holder, Position = position }); };

                    if (image3 != null && !image3.HasOnClickListeners)
                        image3.Click += (sender, args) => { PostEventListener.ProductPostClick(new GlobalClickEventArgs { NewsFeedClass = item, Holder = holder, Position = position }); };

                    if (image4 != null && !image4.HasOnClickListeners)
                        image4.Click += (sender, args) => { PostEventListener.ProductPostClick(new GlobalClickEventArgs { NewsFeedClass = item, Holder = holder, Position = position }); };
                }

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.LocationIcon, IonIconsFonts.IosLocationOutline);

                if (item.Product != null && item.Product.Value.ProductClass == null)
                    return;

                if (item.Product != null && item.Product.Value.ProductClass?.Seller == null)
                    if (item.Product.Value.ProductClass != null)
                        item.Product.Value.ProductClass.Seller = item.Publisher;

                if (item.Product != null)
                {
                    holder.PostProductLocationText.Text = Methods.FunString.DecodeString(item.Product.Value.ProductClass?.Location);
                    holder.PostLinkTitle.Text = Methods.FunString.DecodeString(item.Product.Value.ProductClass?.Name);
                    holder.PostProductContent.Text = Methods.FunString.DecodeString(item.Product.Value.ProductClass?.Description);

                    holder.PriceText.Text = item.Product.Value.ProductClass?.Price;

                    if (item.Product.Value.ProductClass?.Type == "0") // New
                        holder.TypeText.Text = MainContext.GetString(Resource.String.Radio_New);
                    else // Used
                        holder.TypeText.Text = MainContext.GetString(Resource.String.Radio_Used);

                    if (item.Product.Value.ProductClass?.Status == "0") // Status InStock
                        holder.StatusText.Text = MainContext.GetString(Resource.String.Lbl_In_Stock);
                    else
                        holder.StatusText.Text = " ";
                }

                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindBlogPost(AdapterHolders.GlobalViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                //if (!(viewHolder is AdapterHolders.GlobalViewHolder holder)) return;

                LoadPostData(holder.ViewsLayouts, item, position);

                holder.ViewsLayouts.StubLoader.LayoutResource = Resource.Layout.ViewSub_Post_Blog;

                if (holder.ViewsLayouts.Inflated == null)
                    holder.ViewsLayouts.Inflated = holder.ViewsLayouts.StubLoader.Inflate();

                var imageBlog = holder.ViewsLayouts.Inflated.FindViewById<ImageView>(Resource.Id.imageblog);
                var blogIcon = holder.ViewsLayouts.Inflated.FindViewById<TextView>(Resource.Id.blogIcon);
                var postBlogText = holder.ViewsLayouts.Inflated.FindViewById<TextView>(Resource.Id.postblogText);
                var postBlogContent = holder.ViewsLayouts.Inflated.FindViewById<TextView>(Resource.Id.postBlogContent);
                var catText = holder.ViewsLayouts.Inflated.FindViewById<TextView>(Resource.Id.catText);

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, blogIcon, IonIconsFonts.IosBook);

                if (!string.IsNullOrEmpty(item.Blog?.Thumbnail))
                    GlideImageLoader.LoadImage(MainContext, item.Blog?.Thumbnail, imageBlog, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);

                if (!string.IsNullOrEmpty(item.Blog?.Title))
                    postBlogText.Text = Methods.FunString.SubStringCutOf(Methods.FunString.DecodeString(item.Blog?.Title), 60);

                if (!string.IsNullOrEmpty(item.Blog?.Description))
                    postBlogContent.Text = Methods.FunString.DecodeString(item.Blog?.Description);

                if (!string.IsNullOrEmpty(item.Blog?.Title))
                    catText.Text = Methods.FunString.DecodeString(item.Blog?.CategoryName);

                if (imageBlog != null && !imageBlog.HasOnClickListeners)
                    imageBlog.Click += (sender, args) => { PostEventListener.ArticleItemPostClick(item.Blog); };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindFilePost(AdapterHolders.FilePostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.FileIcon, IonIconsFonts.Document);
                holder.PostFileText.Text = item.PostFileName;
                holder.BindClickEvents(item, position, PostEventListener);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindEventPost(AdapterHolders.EventPostViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                if (item.Event != null && item.Event.Value.EventClass != null)
                {
                    GlideImageLoader.LoadImage(MainContext, item.Event.Value.EventClass.Cover, holder.Image, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);

                    holder.TxtEventTitle.Text = Methods.FunString.DecodeString(item.Event.Value.EventClass.Name);
                    holder.TxtEventDescription.Text = Methods.FunString.DecodeString(item.Event.Value.EventClass.Description);
                    holder.TxtEventTime.Text = item.Event.Value.EventClass.StartDate;
                    holder.TxtEventLocation.Text = item.Event.Value.EventClass.Location;
                    holder.GoingButton.SetImageResource(item.Event.Value.EventClass.IsGoing
                        ? Resource.Drawable.ic_star_filled
                        : Resource.Drawable.ic_star);
                }

                holder.BindClickEvents(item, position, PostEventListener);

                //open event view 
                if (holder.Image != null && !holder.Image.HasOnClickListeners)
                    holder.Image.Click += (sender, args) => { PostEventListener.EventItemPostClick(new GlobalClickEventArgs { NewsFeedClass = item, Holder = holder, Position = position }); };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindColorPost(AdapterHolders.ColorBoxViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                LoadPostData(holder.ViewsLayouts, item, position);

                if (ListUtils.SettingsSiteList.PostColors != null && ListUtils.SettingsSiteList.PostColors.Value.PostColorsList != null)
                {
                    var getColorObject = ListUtils.SettingsSiteList.PostColors.Value.PostColorsList.FirstOrDefault(a => a.Key == item.ColorId);

                    if (getColorObject.Value != null)
                    {
                        if (!string.IsNullOrEmpty(getColorObject.Value.Image))
                        {
                            Glide.With(MainContext).Load(getColorObject.Value.Image).Apply(new RequestOptions()).Into(holder.ColorBoxImage);
                        }
                        else
                        {
                            var colorsList = new List<int>();

                            if (!string.IsNullOrEmpty(getColorObject.Value.Color1))
                                colorsList.Add(Color.ParseColor(getColorObject.Value.Color1));

                            if (!string.IsNullOrEmpty(getColorObject.Value.Color2))
                                colorsList.Add(Color.ParseColor(getColorObject.Value.Color2));

                            GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TopBottom, colorsList.ToArray());
                            gd.SetCornerRadius(0f);
                            holder.ColorBoxImage.Background = (gd);
                        }
                        holder.ViewsLayouts.Description.SetTextColor(Color.ParseColor(getColorObject.Value.TextColor));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindStoryModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.StoryViewHolder holder)) return;

                if (item.StoryList.Count > 0)
                {
                    holder.StoryAdapter.StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>(item.StoryList);

                    var dataOwner = holder.StoryAdapter.StoryList.FirstOrDefault(a => a.Type == "Your");
                    if (dataOwner == null)
                    {
                        holder.StoryAdapter.StoryList.Insert(0, new GetUserStoriesObject.StoryObject()
                        {
                            Avatar = UserDetails.Avatar,
                            Type = "Your",
                            Username = MainContext.GetText(Resource.String.Lbl_YourStory),
                            Stories = new List<GetUserStoriesObject.StoryObject.Story>()
                            {
                                new GetUserStoriesObject.StoryObject.Story()
                                {
                                    Thumbnail = UserDetails.Avatar,
                                }
                            }
                        });
                    }

                    holder.StoryAdapter.NotifyDataSetChanged();
                }

                if (holder.StoryAdapter?.StoryList?.Count > 4)
                {
                    holder.AboutMore.Visibility = ViewStates.Visible;
                    holder.AboutMoreIcon.Visibility = ViewStates.Visible;
                }
                else
                {
                    holder.AboutMore.Visibility = ViewStates.Invisible;
                    holder.AboutMoreIcon.Visibility = ViewStates.Invisible;
                }

                if (!holder.AboutMore.HasOnClickListeners)
                {
                    holder.AboutMore.Click += delegate { OpenAllViewer("StoryModel", item); };
                    holder.AboutMoreIcon.Click += delegate { OpenAllViewer("StoryModel", item); };
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindAboutModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.AboutBoxViewHolder holder)) return;

                if (!string.IsNullOrEmpty(item.AboutModel.TitleHead))
                    holder.AboutHead.Text = item.AboutModel.TitleHead;

                holder.AboutDescription.SetAutoLinkOnClickListener(this, new Dictionary<string, string>());
                holder.AboutDescription.Text = Methods.FunString.DecodeString(item.AboutModel.Description);
                ReadMoreOption.AddReadMoreTo(holder.AboutDescription, new String(holder.AboutDescription.Text));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindFollowersModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.FollowersViewHolder holder)) return;

                if (holder.FollowersAdapter?.MUserFriendsList?.Count == 0)
                {
                    holder.FollowersAdapter.MUserFriendsList = new ObservableCollection<UserDataObject>(item.FollowersModel.FollowersList);
                    holder.FollowersAdapter.NotifyDataSetChanged();
                }

                if (!string.IsNullOrEmpty(item.FollowersModel.TitleHead))
                    holder.AboutHead.Text = item.FollowersModel.TitleHead;

                holder.AboutMore.Text = item.FollowersModel.More;

                if (holder.FollowersAdapter?.MUserFriendsList?.Count > 4)
                {
                    holder.AboutMore.Visibility = ViewStates.Visible;
                    holder.AboutMoreIcon.Visibility = ViewStates.Visible;

                }
                else
                {
                    holder.AboutMore.Visibility = ViewStates.Invisible;
                    holder.AboutMoreIcon.Visibility = ViewStates.Invisible;
                }

                if (holder.FollowersAdapter != null)
                {
                    holder.FollowersAdapter.ItemClick += (sender, e) =>
                    {
                        var position = e.Position;
                        if (position < 0) return;

                        var user = holder.FollowersAdapter.GetItem(position);
                        if (user == null)
                            return;

                        WoWonderTools.OpenProfile(MainContext, user.UserId, user);
                    };

                    if (!holder.AboutMore.HasOnClickListeners)
                    {
                        holder.AboutMore.Click += delegate { OpenAllViewer("FollowersModel", item); };
                        holder.AboutMoreIcon.Click += delegate { OpenAllViewer("FollowersModel", item); };
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindImagesModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.ImagesViewHolder holder)) return;

                if (!string.IsNullOrEmpty(item.ImagesModel.TitleHead))
                    holder.AboutHead.Text = item.ImagesModel.TitleHead;

                holder.AboutMore.Text = item.ImagesModel.More;

                if (item.ImagesModel?.ImagesList == null)
                {
                    holder.MainView.Visibility = ViewStates.Gone;
                    return;
                }

                if (holder.MainView.Visibility != ViewStates.Visible)
                    holder.MainView.Visibility = ViewStates.Visible;

                if (holder.ImagesAdapter?.MUserAlbumsList?.Count == 0)
                {
                    holder.ImagesAdapter.MUserAlbumsList = new ObservableCollection<PostDataObject>(item.ImagesModel.ImagesList);
                    holder.ImagesAdapter.NotifyDataSetChanged();
                }

                if (holder.ImagesAdapter?.MUserAlbumsList?.Count > 3)
                {
                    holder.AboutMore.Visibility = ViewStates.Visible;
                    holder.AboutMoreIcon.Visibility = ViewStates.Visible;

                }
                else
                {
                    holder.AboutMore.Visibility = ViewStates.Invisible;
                    holder.AboutMoreIcon.Visibility = ViewStates.Invisible;
                }

                if (holder.ImagesAdapter != null)
                {
                    holder.ImagesAdapter.ItemClick += (sender, e) =>
                    {
                        var position = e.Position;
                        if (position < 0) return;

                        var photo = holder.ImagesAdapter.GetItem(position);
                        if (photo == null)
                            return;

                        PostEventListener.OpenImageLightBox(photo);
                    };
                }

                if (!holder.AboutMore.HasOnClickListeners)
                {
                    holder.AboutMore.Click += delegate { OpenAllViewer("ImagesModel", item); };
                    holder.AboutMoreIcon.Click += delegate { OpenAllViewer("ImagesModel", item); };
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindGroupsModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.GroupsViewHolder holder)) return;

                if (holder.GroupsAdapter?.UserGroupsList?.Count == 0)
                {
                    holder.GroupsAdapter.UserGroupsList = new ObservableCollection<GroupClass>(item.GroupsModel.GroupsList);
                    holder.GroupsAdapter.NotifyDataSetChanged();
                }

                if (!string.IsNullOrEmpty(item.GroupsModel?.TitleHead))
                    holder.AboutHead.Text = item.GroupsModel?.TitleHead;

                holder.AboutMore.Text = item.GroupsModel?.More;

                if (holder.GroupsAdapter != null)
                {
                    if (holder.GroupsAdapter?.UserGroupsList?.Count > 4)
                    {
                        holder.AboutMore.Visibility = ViewStates.Visible;
                        holder.AboutMoreIcon.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        holder.AboutMore.Visibility = ViewStates.Invisible;
                        holder.AboutMoreIcon.Visibility = ViewStates.Invisible;
                    }

                    if (!holder.AboutMore.HasOnClickListeners)
                    {
                        holder.AboutMore.Click += delegate { OpenAllViewer("GroupsModel", item); };
                        holder.AboutMoreIcon.Click += delegate { OpenAllViewer("GroupsModel", item); };
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindPagesModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.PagesViewHolder holder)) return;

                if (!string.IsNullOrEmpty(item.PagesModel?.TitleHead))
                    holder.AboutHead.Text = item.PagesModel?.TitleHead;

                if (!string.IsNullOrEmpty(item.PagesModel?.More))
                    holder.AboutMore.Text = item.PagesModel?.More;

                var count = item.PagesModel?.PagesList.Count;
                try
                {
                    for (var i = 0; i < 4; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                GlideImageLoader.LoadImage(MainContext, item.PagesModel?.PagesList[i].Avatar, holder.PageImage1, ImageStyle.CircleCrop, ImagePlaceholders.Color);
                                break;

                            case 1:
                                GlideImageLoader.LoadImage(MainContext, item.PagesModel?.PagesList[i].Avatar, holder.PageImage2, ImageStyle.CircleCrop, ImagePlaceholders.Color);
                                break;

                            case 2:
                                GlideImageLoader.LoadImage(MainContext, item.PagesModel?.PagesList[i].Avatar, holder.PageImage3, ImageStyle.CircleCrop, ImagePlaceholders.Color);
                                break;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                if (holder.MainView.HasOnClickListeners)
                    return;

                if (item.PagesModel?.PagesList?.Count > 0)
                {
                    holder.MainView.Click += (o, eventArgs) => { OpenAllViewer("PagesModel", item); };
                    holder.AboutMore.Click += (o, eventArgs) => { OpenAllViewer("PagesModel", item); };
                    holder.AboutMoreIcon.Click += (o, eventArgs) => { OpenAllViewer("PagesModel", item); };
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindAlertModel(RecyclerView.ViewHolder viewHolder, AdapterModelsClass item)
        {
            try
            {
                if (!(viewHolder is AdapterHolders.AlertAdapterViewHolder holder)) return;

                if (!string.IsNullOrEmpty(item.AlertModel?.TitleHead))
                    holder.HeadText.Text = item.AlertModel?.TitleHead;

                if (!string.IsNullOrEmpty(item.AlertModel?.SubText))
                    holder.SubText.Text = item.AlertModel?.SubText;

                if (item.AlertModel?.ImageDrawable != null)
                    holder.Image.SetImageResource(item.AlertModel.ImageDrawable);

                if (!string.IsNullOrEmpty(item.AlertModel?.LinerColor))
                    holder.LineView.SetBackgroundColor(Color.ParseColor(item.AlertModel?.LinerColor));

                if (!holder.MianAlert.HasOnClickListeners)
                    holder.MianAlert.Click += delegate
                    {
                        try
                        {
                            var data = holder.Adapter.PostFeedList.FirstOrDefault(a => a.AlertModel == item.AlertModel);
                            if (data != null)
                            {
                                TabbedMainActivity.GetInstance()?.NewsFeedTab.MainRecyclerView.RemoveByRowIndex(data);

                                //holder.Adapter.PostFeedList.Remove(data); 
                                //var index = holder.Adapter.PostFeedList.IndexOf(data);
                                //if (index > -1)
                                //{
                                //    holder.Adapter.NotifyItemRemoved(index);
                                //} 
                                //holder.Adapter.NotifyItemChanged(holder.Adapter.PostFeedList.IndexOf(data));
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindFindMoreModel(AdapterHolders.AlertJoinAdapterViewHolder holder, AdapterModelsClass item)
        {
            try
            {
                if (!string.IsNullOrEmpty(item.AlertModel?.TitleHead))
                    holder.HeadText.Text = item.AlertModel?.TitleHead;

                if (!string.IsNullOrEmpty(item.AlertModel?.SubText))
                    holder.SubText.Text = item.AlertModel?.SubText;

                if (item.AlertModel?.ImageDrawable != null)
                    holder.NormalImageView.SetImageResource(item.AlertModel.ImageDrawable);
                else
                {
                    holder.NormalImageView.Visibility = ViewStates.Gone;
                }

                if (item.AlertModel?.IconImage != null)
                    holder.IconImageView.SetImageResource(item.AlertModel.IconImage);

                if (item.AlertModel?.TypeAlert == "Groups")
                {
                    holder.MainRelativeLayout.SetBackgroundResource(Resource.Drawable.Shape_Gradient_Linear);
                    holder.ButtonView.Text = MainContext.GetString(Resource.String.Lbl_FindYourGroups);

                    if (!holder.ButtonView.HasOnClickListeners)
                        holder.ButtonView.Click += delegate
                        {
                            try
                            {
                                var intent = new Intent(MainContext, typeof(SearchTabbedActivity));
                                intent.PutExtra("Key", "Random_Groups");
                                MainContext.StartActivity(intent);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        };
                }
                else if (item.AlertModel?.TypeAlert == "Pages")
                {
                    holder.MainRelativeLayout.SetBackgroundResource(Resource.Drawable.Shape_Gradient_Linear1);
                    holder.ButtonView.Text = MainContext.GetString(Resource.String.Lbl_FindPopularPages);

                    if (!holder.ButtonView.HasOnClickListeners)
                        holder.ButtonView.Click += delegate
                        {
                            try
                            {
                                var intent = new Intent(MainContext, typeof(SearchTabbedActivity));
                                intent.PutExtra("Key", "Random_Pages");
                                MainContext.StartActivity(intent);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        };
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindAddPost(AdapterHolders.AddPostViewHolder holder, int position)
        {
            try
            {
                GlideImageLoader.LoadImage(MainContext, UserDetails.Avatar, holder.ProfileImageView, ImageStyle.CircleCrop, ImagePlaceholders.Color);

                if (!holder.IconMore.HasOnClickListeners)
                    holder.IconMore.Click += delegate
                    {
                        try
                        {
                            var Int = new Intent(MainContext, typeof(AddPostActivity));
                            Int.PutExtra("Type", "Normal_More");
                            Int.PutExtra("PostId", UserDetails.UserId);
                            //Int.PutExtra("itemObject", JsonConvert.SerializeObject(EventData));
                            MainContext.StartActivityForResult(Int, 2500);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };

                if (!holder.ImageGallery.HasOnClickListeners)
                    holder.ImageGallery.Click += delegate
                    {
                        try
                        {
                            var Int = new Intent(MainContext, typeof(AddPostActivity));
                            Int.PutExtra("Type", "Normal_Gallery");
                            Int.PutExtra("PostId", UserDetails.UserId);
                            //Int.PutExtra("itemObject", JsonConvert.SerializeObject(EventData));
                            MainContext.StartActivityForResult(Int, 2500);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };

                if (!holder.PostText.HasOnClickListeners)
                    holder.PostText.Click += delegate
                    {
                        try
                        {
                            var Int = new Intent(MainContext, typeof(AddPostActivity));
                            Int.PutExtra("Type", "Normal");
                            Int.PutExtra("PostId", UserDetails.UserId);
                            //Int.PutExtra("itemObject", JsonConvert.SerializeObject(EventData));
                            MainContext.StartActivityForResult(Int, 2500);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void OpenAllViewer(string type, AdapterModelsClass item)
        {
            try
            {
                var Int = new Intent(MainContext, typeof(AllViewerActivity));
                Int.PutExtra("Type", type); //StoryModel , FollowersModel , GroupsModel , PagesModel , ImagesModel
                Int.PutExtra("itemObject", JsonConvert.SerializeObject(item));
                MainContext.StartActivity(Int);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void AutoLinkTextClick(StTools.XAutoLinkMode p0, string p1, Dictionary<string, string> userdata)
        {
            try
            {
                var typetext = Methods.FunString.Check_Regex(p1.Replace(" ", ""));
                if (typetext == "Email")
                {
                    Methods.App.SendEmail(MainContext, p1.Replace(" ", ""));
                }
                else if (typetext == "Website")
                {
                    string url = p1.Replace(" ", "");
                    if (!p1.Contains("http"))
                    {
                        url = "http://" + p1.Replace(" ", "");
                    }

                    //var intent = new Intent(MainContext, typeof(LocalWebViewActivity));
                    //intent.PutExtra("URL", url.Replace(" ", ""));
                    //intent.PutExtra("Type", url.Replace(" ", ""));
                    //MainContext.StartActivity(intent);
                    new IntentController(MainContext).OpenBrowserFromApp(url);
                }
                else if (typetext == "Hashtag")
                {
                    var Int = new Intent(MainContext, typeof(HashTagPostsActivity));
                    Int.PutExtra("Id", p1.Replace(" ", ""));
                    Int.PutExtra("Tag", p1.Replace(" ", ""));
                    MainContext.StartActivity(Int);
                }
                else if (typetext == "Mention")
                {
                    var dataUSer = ListUtils.MyProfileList.FirstOrDefault();
                    string name = p1.Replace("@", "").Replace(" ", "");

                    var sqlEntity = new SqLiteDatabase();
                    var user = sqlEntity.Get_DataOneUser(name);
                    sqlEntity.Dispose();

                    if (user != null)
                    {
                        WoWonderTools.OpenProfile(MainContext, user.UserId, user);
                    }
                    else if (userdata?.Count > 0)
                    {
                        var data = userdata.FirstOrDefault(a => a.Value == name);
                        if (data.Key != null && data.Key == UserDetails.UserId)
                        {
                            if (PostClickListener.OpenMyProfile) return;
                            var intent = new Intent(MainContext, typeof(MyProfileActivity));
                            MainContext.StartActivity(intent);
                        }
                        else if (data.Key != null)
                        {
                            var Int = new Intent(MainContext, typeof(UserProfileActivity));
                            //Int.PutExtra("UserObject", JsonConvert.SerializeObject(item));
                            Int.PutExtra("UserId", data.Key);
                            MainContext.StartActivity(Int);
                        }
                    }
                    else
                    {
                        if (name == dataUSer?.Name || name == dataUSer?.Username)
                        {
                            if (PostClickListener.OpenMyProfile) return;
                            var intent = new Intent(MainContext, typeof(MyProfileActivity));
                            MainContext.StartActivity(intent);
                        }
                        else
                        {
                            var Int = new Intent(MainContext, typeof(UserProfileActivity));
                            //Int.PutExtra("UserObject", JsonConvert.SerializeObject(item));
                            Int.PutExtra("name", name);
                            MainContext.StartActivity(Int);
                        }
                    }
                }
                else if (typetext == "Number")
                {
                    Methods.App.SaveContacts(MainContext, p1.Replace(" ", ""), "", "2");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}