﻿using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using System;
using Android.App;
using AT.Markushi.UI;
using Com.Luseen.Autolinklibrary;
using Refractored.Controls;
using WoWonder.Activities.Communities.Groups;
using WoWonder.Activities.Story.Adapters;
using WoWonder.Helpers.Fonts;
using WoWonder.Activities.Communities.Pages;
using WoWonder.Activities.Tabbes;
using WoWonder.Activities.userProfile.Adapters;
using WoWonder.Activities.UserProfile.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Model;
using WoWonder.Library.Anjo;
using WoWonder.Library.Anjo.SuperTextLibrary;
using WoWonderClient.Classes.Posts;
using Exception = System.Exception;

namespace WoWonder.Activities.NativePost.Post
{
    public class AdapterHolders
    {
        public class PostViewsLayouts
        {
            public View MainView { get; private set; }
          
            public CircleImageView UserAvatar { get; private  set; }
            public TextView Username {get; private set; }
            public TextView IsVip {get;  set; }
            public TextView IsVerified {get;  set; }
            public TextView MoreIcon { get; private set; }
            public TextView PostMinText {get; set; }
            public ViewStub StubLoader {get; private set; }
            public View Inflated {get;  set; }
            public SuperTextView Description { get; private set; }
            public TextView TimeText { get; private set; }
            public LinearLayout MainSectionButton { get; private set; }
            public LinearLayout SecondReactionButton { get; private set; }
            public ImageView SecondReactionImage { get; set; }
            public TextView SecondReactionText { get; set; }
            public TextView CommentCount {get;  set; }
            public TextView LikeCount {get;  set; }
            public TextView Viewcount { get;  set; }
            public RelativeLayout DataPostLayout { get;  set; }
            public LinearLayout LikeLinear { get;  set; }
            public ReactButton LikeButton {get;  set; }
            public LinearLayout CommentButton {get;  set; }
            public LinearLayout ShareButton {get; private set; }
            public ImageView PinnedIcon { get;  set; }
            public ImageView PromoteIcon { get;  set; }
            public TextView PromotText { get;  set; }
            public TextView ShareText { get;  set; }
            public View PostActionsView { get; private set; }
             
            public RelativeLayout PostExtrasLayout { get; private set; }
            public Android.Media.MediaPlayer VoicePlayer {get;  set; }
            //VideoHolder
         
            public ImageView VideoImage { get;  set; }
            public FrameLayout MediaContainerLayout { get; private set; }
            public ProgressBar VideoProgressBar { get; private set; }
            public ImageView PlayControl { get; private set; }

            public SingleTonClickEvents ClickEvent = new SingleTonClickEvents();
             
            public PostViewsLayouts(View itemView)
            {
                try
                {
                    MainView = itemView;

                    MainSectionButton = MainView.FindViewById<LinearLayout>(Resource.Id.mainsection);
                    SecondReactionButton = MainView.FindViewById<LinearLayout>(Resource.Id.linerSecondReaction);
                    SecondReactionImage = MainView.FindViewById<ImageView>(Resource.Id.image_SecondReaction);
                    SecondReactionText = MainView.FindViewById<TextView>(Resource.Id.SecondReactionText);
                    LikeButton = MainView.FindViewById<ReactButton>(Resource.Id.beactButton);
                    LikeLinear = MainView.FindViewById<LinearLayout>(Resource.Id.linerlike);
                    CommentButton = MainView.FindViewById<LinearLayout>(Resource.Id.linercomment);
                    ShareButton = MainView.FindViewById<LinearLayout>(Resource.Id.linershare);
                    ShareText = MainView.FindViewById<TextView>(Resource.Id.ShareText);
                    TimeText = MainView.FindViewById<TextView>(Resource.Id.time_text);
                    MoreIcon = MainView.FindViewById<TextView>(Resource.Id.moreicon);
                    StubLoader = MainView.FindViewById<ViewStub>(Resource.Id.viewStubloader);
                    CommentCount = MainView.FindViewById<TextView>(Resource.Id.Commentcount);
                    LikeCount = MainView.FindViewById<TextView>(Resource.Id.Likecount);
                    
                    Username = MainView.FindViewById<TextView>(Resource.Id.username);
                    UserAvatar = MainView.FindViewById<CircleImageView>(Resource.Id.userAvatar);
                    Description = MainView.FindViewById<SuperTextView>(Resource.Id.description);
                    PinnedIcon = MainView.FindViewById<ImageView>(Resource.Id.pinnedIcon);
                    PromoteIcon = MainView.FindViewById<ImageView>(Resource.Id.promoteIcon);
                    PromotText = MainView.FindViewById<TextView>(Resource.Id.promotText);
                    PostExtrasLayout = MainView.FindViewById<RelativeLayout>(Resource.Id.postExtras);
                    PostActionsView = MainView.FindViewById<View>(Resource.Id.postEvent);
                    DataPostLayout = MainView.FindViewById<RelativeLayout>(Resource.Id.dataPostLayout);

                    if (MoreIcon.Text != IonIconsFonts.More)
                    {
                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, MoreIcon, IonIconsFonts.More);

                        Description?.SetTextInfo(Description);
                    }

                    Viewcount = MainView.FindViewById<TextView>(Resource.Id.viewcount);
                    MediaContainerLayout = MainView.FindViewById<FrameLayout>(Resource.Id.media_container);
                    VideoImage = MainView.FindViewById<ImageView>(Resource.Id.image);
                    VideoProgressBar = MainView.FindViewById<ProgressBar>(Resource.Id.progressBar); 
                    PlayControl = MainView.FindViewById<ImageView>(Resource.Id.Play_control);

                    if (SecondReactionButton != null)
                    {
                        if (AppSettings.PostButton == PostButtonSystem.Reaction || AppSettings.PostButton == PostButtonSystem.Like)
                        {
                            MainSectionButton.WeightSum = 3;
                            SecondReactionButton.Visibility = ViewStates.Gone;
                        }
                        else if (AppSettings.PostButton == PostButtonSystem.Wonder)
                        {
                            MainSectionButton.WeightSum = 4;
                            SecondReactionButton.Visibility = ViewStates.Visible;

                            SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_wowonder);
                            SecondReactionText.Text = Application.Context.GetText(Resource.String.Btn_Wonder);
                        }
                        else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                        {
                            MainSectionButton.WeightSum = 4;
                            SecondReactionButton.Visibility = ViewStates.Visible;

                            SecondReactionImage.SetImageResource(Resource.Drawable.ic_action_dislike);
                            SecondReactionText.Text = Application.Context.GetText(Resource.String.Btn_Dislike);
                        }
                    } 
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Global);

                    UserAvatar?.SetOnClickListener(ClickEvent);
                    Username?.SetOnClickListener(ClickEvent);
                    CommentButton?.SetOnClickListener(ClickEvent);
                    CommentCount?.SetOnClickListener(ClickEvent);
                    ShareButton?.SetOnClickListener(ClickEvent);
                    LikeButton.SetOnClickListener(ClickEvent);
                    LikeButton?.SetOnLongClickListener(ClickEvent);
                    MoreIcon?.SetOnClickListener(ClickEvent);
                    LikeCount?.SetOnClickListener(ClickEvent);
                    SecondReactionButton?.SetOnClickListener(ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class VideoPlayerViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts { get; private set; }
            public string VideoUrl { get; set; }

            public FrameLayout FullScreenButton { get; set; }
            public VideoPlayerViewHolder(View itemView, PostDataObject item, int position, AdapterBinders baseAdapterBinder) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(int position, PostClickListener listener ,string videoUrl,FrameLayout mFullScreenButton)
            {
                try
                {
                    VideoUrl = videoUrl;
                    FullScreenButton = mFullScreenButton;
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, null, this, position, ClickType.VideoFullScreen);
                    FullScreenButton.SetOnClickListener(ViewsLayouts.ClickEvent);


                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class GlobalViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts { get; private set; }

            public ImageView VideoIconImage {get;  set; }

            public GlobalViewHolder(View itemView, PostDataObject item, int position, AdapterBinders baseAdapterBinder) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener, ImageView image)
            {
                try
                {
                    ViewsLayouts.VideoImage = image;
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Image);
                    ViewsLayouts.VideoImage?.SetOnClickListener(ViewsLayouts.ClickEvent); 
                }
                catch (Exception e)
                { 
                    Console.WriteLine(e);
                }
            } 
        }

        public class SharedGlobalViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts {get; private set; }
            public ViewStub StubLoader {get; private set; }
            public View Inflated {get;  set; }
            public SharedGlobalViewHolder(View itemView, PostDataObject item, int position, AdapterBinders baseAdapterBinder) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    StubLoader = itemView.FindViewById<ViewStub>(Resource.Id.viewStubloader);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class ColorBoxViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts {get; private set; }
            public ImageView ColorBoxImage {get; private set; }
            public ColorBoxViewHolder(View itemView, PostDataObject item, int position, AdapterBinders baseAdapterBinder) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    ColorBoxImage = itemView.FindViewById<ImageView>(Resource.Id.Image);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class PostImagesViewHolder : RecyclerView.ViewHolder
        {
            public View MainView {get; private set; }

            public ImageView Image {get; private set; }
            public ImageView Image2 {get; private set; }
            public ImageView Image3 {get; private set; }
            public ImageView Image4 {get; private set; }

            public TextView CountImageLabel {get; private set; }

            public PostViewsLayouts ViewsLayouts {get; private set; }

            public PostImagesViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    MainView = itemView;

                    Image = itemView.FindViewById<ImageView>(Resource.Id.image);
                    Image2 = itemView.FindViewById<ImageView>(Resource.Id.image2);
                    Image3 = itemView.FindViewById<ImageView>(Resource.Id.image3);
                    Image4 = itemView.FindViewById<ImageView>(Resource.Id.image4);
                    CountImageLabel = MainView.FindViewById<TextView>(Resource.Id.counttext);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Images);

                    Image?.SetOnClickListener(ViewsLayouts.ClickEvent);
                    Image2?.SetOnClickListener(ViewsLayouts.ClickEvent);
                    Image3?.SetOnClickListener(ViewsLayouts.ClickEvent);
                    Image4?.SetOnClickListener(ViewsLayouts.ClickEvent);
                    CountImageLabel?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class LinkPostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts {get; private set; }
            public ImageView Image {get; private set; }
            public TextView LinkUrl {get; private set; }
            public TextView PostLinkTitle {get; private set; }
            public TextView PostLinkContent {get; private set; }
            public LinearLayout PostLinkLinearLayout {get; private set; }

            public LinkPostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    Image = itemView.FindViewById<ImageView>(Resource.Id.image);
                    LinkUrl = itemView.FindViewById<TextView>(Resource.Id.linkUrl);
                    PostLinkTitle = itemView.FindViewById<TextView>(Resource.Id.postLinkTitle);
                    PostLinkContent = itemView.FindViewById<TextView>(Resource.Id.postLinkContent);
                    PostLinkLinearLayout = itemView.FindViewById<LinearLayout>(Resource.Id.linklinearLayout);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Link);
                    PostLinkLinearLayout?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class AdsPostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts { get; private set; }
            public ImageView Image {get; private set; }
            public TextView IconLocation { get; private set; }
            public TextView TextLocation { get; private set; }
            public TextView IconLink { get; private set; }
            public AutoLinkTextView Headline { get; private set; }
            public TextView LinkUrl {get; private set; }
            public TextView PostLinkTitle {get; private set; }
            public TextView PostLinkContent {get; private set; }
            public LinearLayout PostLinkLinearLayout {get; private set; }

            public AdsPostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);

                    IconLocation = itemView.FindViewById<TextView>(Resource.Id.iconloca);
                    TextLocation = itemView.FindViewById<TextView>(Resource.Id.textloc);
                    IconLink = itemView.FindViewById<TextView>(Resource.Id.IconLink);
                    Headline = itemView.FindViewById<AutoLinkTextView>(Resource.Id.headline);
                    Image = itemView.FindViewById<ImageView>(Resource.Id.image);
                    LinkUrl = itemView.FindViewById<TextView>(Resource.Id.linkUrl);
                    PostLinkTitle = itemView.FindViewById<TextView>(Resource.Id.postLinkTitle);
                    PostLinkContent = itemView.FindViewById<TextView>(Resource.Id.postLinkContent);
                    PostLinkLinearLayout = itemView.FindViewById<LinearLayout>(Resource.Id.linklinearLayout);

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconLocation, IonIconsFonts.AndroidPin);
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconLink, IonIconsFonts.Link);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Ads);
                    PostLinkLinearLayout?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class ProductPostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts {get; private set; }
            public ViewStub ImageViewSub {get; private set; }
            public TextView LocationIcon {get; private set; }
            public TextView PostProductLocationText {get; private set; }
            public TextView PostLinkTitle {get; private set; }
            public TextView PostProductContent {get; private set; }
            public TextView TypeText {get; private set; }
            public TextView PriceText {get; private set; }
            public TextView StatusText {get; private set; }
            public LinearLayout PostLinkLinearLayout {get; private set; }

            public ProductPostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    ImageViewSub = itemView.FindViewById<ViewStub>(Resource.Id.viewStubImageloader);
                    LocationIcon = itemView.FindViewById<TextView>(Resource.Id.locationIcon);
                    PostProductLocationText = itemView.FindViewById<TextView>(Resource.Id.postProductLocationText);
                    PostLinkTitle = itemView.FindViewById<TextView>(Resource.Id.postProductTitle);
                    PostProductContent = itemView.FindViewById<TextView>(Resource.Id.postProductContent);
                    TypeText = itemView.FindViewById<TextView>(Resource.Id.typeText);
                    PriceText = itemView.FindViewById<TextView>(Resource.Id.priceText);
                    StatusText = itemView.FindViewById<TextView>(Resource.Id.statusText);
                    PostLinkLinearLayout = itemView.FindViewById<LinearLayout>(Resource.Id.linklinearLayout);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Product);
                    PostLinkLinearLayout?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class FilePostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts {get; private set; }
            public CircleButton DownlandButton {get; private set; }
            public TextView PostFileText {get; private set; }
            public TextView FileIcon {get; private set; }

            public FilePostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    DownlandButton = itemView.FindViewById<CircleButton>(Resource.Id.downlaodButton);
                    PostFileText = itemView.FindViewById<TextView>(Resource.Id.postfileText);
                    FileIcon = itemView.FindViewById<TextView>(Resource.Id.fileIcon);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.File);
                    DownlandButton?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class YoutubePostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts { get; private set; }
            public ImageView Image { get; private set; }
            public ImageView VideoIcon { get; private set; }


            public YoutubePostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView); 
                    Image = itemView.FindViewById<ImageView>(Resource.Id.image);
                    VideoIcon = itemView.FindViewById<ImageView>(Resource.Id.videoicon);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Youtube);
                    VideoIcon?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class SoundPostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts {get; private set; }
            public SeekBar SeekBar {get; private set; }
            public TextView MoreIcon {get; private set; }
            public TextView Time {get; private set; }
            public TextView Duration { get; private set; }
            public ProgressBar LoadingProgressView {get; private set; }
            public CircleButton PlayButton {get; private set; }

            public SoundPostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);
                    SeekBar = itemView.FindViewById<SeekBar>(Resource.Id.seekBar);
                    MoreIcon = itemView.FindViewById<TextView>(Resource.Id.moreicon);
                    Time = itemView.FindViewById<TextView>(Resource.Id.time);
                    Duration = itemView.FindViewById<TextView>(Resource.Id.Duration);
                    LoadingProgressView = itemView.FindViewById<ProgressBar>(Resource.Id.loadingProgressview);
                    PlayButton = itemView.FindViewById<CircleButton>(Resource.Id.playButton);
                    PlayButton.Tag = "Play";
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Sound);
                    PlayButton?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class EventPostViewHolder : RecyclerView.ViewHolder
        {
            public PostViewsLayouts ViewsLayouts { get; private set; }
            public ImageView Image { get; private set; }
            public TextView TxtEventTitle { get; private set; }
            public TextView TxtEventDescription { get; private set; }
            public TextView TxtEventTime { get; private set; }
            public ImageView GoingButton { get; private set; }
            public TextView TxtEventLocation { get; private set; }
            public LinearLayout PostLinkLinearLayout { get; private set; }
            public EventPostViewHolder(View itemView, PostDataObject item) : base(itemView)
            {
                try
                {
                    ViewsLayouts = new PostViewsLayouts(itemView);

                    Image = itemView.FindViewById<ImageView>(Resource.Id.Image);
                    TxtEventTitle = itemView.FindViewById<TextView>(Resource.Id.event_titile);
                    TxtEventDescription = itemView.FindViewById<TextView>(Resource.Id.event_description);
                    TxtEventTime = itemView.FindViewById<TextView>(Resource.Id.event_time);
                    TxtEventLocation = itemView.FindViewById<TextView>(Resource.Id.event_location);
                    GoingButton = itemView.FindViewById<ImageView>(Resource.Id.ImageStar);
                    PostLinkLinearLayout = itemView.FindViewById<LinearLayout>(Resource.Id.linklinearLayout);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void BindClickEvents(PostDataObject item, int position, PostClickListener listener)
            {
                try
                {
                    ViewsLayouts.ClickEvent.SetGlobalClickEvents(listener, item, this, position, ClickType.Sound);
                    GoingButton?.SetOnClickListener(ViewsLayouts.ClickEvent);
                    PostLinkLinearLayout?.SetOnClickListener(ViewsLayouts.ClickEvent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

         
        public class StoryViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public RecyclerView StoryRecyclerView {get; private set; }
            public StoryAdapter StoryAdapter { get; private set; }
            public TextView AboutHead { get; private set; }
            public TextView AboutMore { get; private set; }
            public TextView AboutMoreIcon { get; private set; }

            public StoryViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    StoryRecyclerView = MainView.FindViewById<RecyclerView>(Resource.Id.Recyler);
                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);

                    if (StoryAdapter != null)
                        return;

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, AboutMoreIcon, IonIconsFonts.ChevronRight);

                    StoryRecyclerView.SetLayoutManager(new LinearLayoutManager(itemView.Context, LinearLayoutManager.Horizontal, false));
                    StoryAdapter = new StoryAdapter(activity);
                    StoryRecyclerView.SetAdapter(StoryAdapter);
                    StoryAdapter.ItemClick += TabbedMainActivity.GetInstance().StoryAdapterOnItemClick;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
             
            public void RefreshData()
            {
                StoryAdapter.NotifyDataSetChanged();
            }
        }

        public class AddPostViewHolder : RecyclerView.ViewHolder
        {
            public View MainView {get; private set; }
            public CircleImageView ProfileImageView { get; private set; }
            public TextView PostText { get; private set; }
            public LinearLayout ImageGallery { get; private set; }
            public LinearLayout IconMore { get; private set; }

            public AddPostViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    ProfileImageView = MainView.FindViewById<CircleImageView>(Resource.Id.image);
                    PostText = MainView.FindViewById<TextView>(Resource.Id.postText);
                    ImageGallery = MainView.FindViewById<LinearLayout>(Resource.Id.photoLinear);
                    IconMore = MainView.FindViewById<LinearLayout>(Resource.Id.moreLinear);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class AboutBoxViewHolder : RecyclerView.ViewHolder
        {
            public View MainView {get; private set; }
            public TextView AboutHead {get; private set; }
            public SuperTextView AboutDescription {get; private set; }

            public AboutBoxViewHolder(View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.tv_about);
                    AboutDescription = MainView.FindViewById<SuperTextView>(Resource.Id.tv_aboutdescUser);

                    AboutDescription?.SetTextInfo(AboutDescription);

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class FollowersViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public RecyclerView FollowersRecyclerView {get; private set; }
            public UserFriendsAdapter FollowersAdapter {get; private set; }
            public TextView AboutHead {get; private set; }
            public TextView AboutMore {get; private set; }
            public TextView AboutMoreIcon {get; private set; }

            public FollowersViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    FollowersRecyclerView = MainView.FindViewById<RecyclerView>(Resource.Id.Recyler);
                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);

                    if (FollowersAdapter != null)
                        return;

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, AboutMoreIcon, IonIconsFonts.ChevronRight);

                    FollowersRecyclerView.SetLayoutManager(new LinearLayoutManager(itemView.Context, LinearLayoutManager.Horizontal, false));
                    FollowersAdapter = new UserFriendsAdapter(activity);
                    FollowersRecyclerView.SetAdapter(FollowersAdapter);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class ImagesViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public RecyclerView ImagesRecyclerView {get; private set; }
            public UserPhotosAdapter ImagesAdapter {get; private set; }
            public TextView AboutHead {get; private set; }
            public TextView AboutMore {get; private set; }
            public TextView AboutMoreIcon {get; private set; }

            public ImagesViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    ImagesRecyclerView = MainView.FindViewById<RecyclerView>(Resource.Id.Recyler);
                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);

                    if (ImagesAdapter != null)
                        return;

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, AboutMoreIcon, IonIconsFonts.ChevronRight);

                    ImagesRecyclerView.SetLayoutManager(new LinearLayoutManager(itemView.Context, LinearLayoutManager.Horizontal, false));
                    ImagesAdapter = new UserPhotosAdapter(activity);
                    ImagesRecyclerView.SetAdapter(ImagesAdapter);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class PagesSocialViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public RecyclerView PagesRecyclerView { get; private set; }
            public UserPagesAdapter PagesAdapter { get; private set; }
            public TextView AboutHead { get; private set; }
            public TextView AboutMore { get; private set; }
            public TextView AboutMoreIcon { get; private set; }

            public PagesSocialViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    PagesRecyclerView = MainView.FindViewById<RecyclerView>(Resource.Id.Recyler);
                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);

                    if (PagesAdapter != null)
                        return;

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, AboutMoreIcon, IonIconsFonts.ChevronRight);

                    PagesRecyclerView.SetLayoutManager(new LinearLayoutManager(itemView.Context, LinearLayoutManager.Horizontal, false));
                    PagesAdapter = new UserPagesAdapter(activity);
                    PagesRecyclerView.SetAdapter(PagesAdapter);
                    PagesAdapter.ItemClick += (sender, e) =>
                    {
                        try
                        {
                            var position = e.Position;
                            if (position < 0)
                                return;

                            var item = PagesAdapter.GetItem(position);
                            if (item == null)
                                return;

                            MainApplication.GetInstance()?.NavigateTo(activity, typeof(PageProfileActivity), item);
                        }
                        catch (Exception x)
                        {
                            Console.WriteLine(x);
                        }
                    };
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class GroupsViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public RecyclerView GroupsRecyclerView { get; private set; }
            public UserGroupsAdapter GroupsAdapter { get; private set; }

            public TextView AboutHead { get; private set; }
            public TextView AboutMore { get; private set; }
            public TextView AboutMoreIcon { get; private set; }

            public GroupsViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    GroupsRecyclerView = MainView.FindViewById<RecyclerView>(Resource.Id.Recyler);
                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);
  
                    if (GroupsAdapter != null)
                        return;

                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, AboutMoreIcon, IonIconsFonts.ChevronRight);

                    GroupsRecyclerView.SetLayoutManager(new LinearLayoutManager(itemView.Context, LinearLayoutManager.Horizontal, false));
                    GroupsAdapter = new UserGroupsAdapter(activity);
                    GroupsRecyclerView.SetAdapter(GroupsAdapter);
                    GroupsAdapter.ItemClick += (sender, e) =>
                    {
                        try
                        {
                            var position = e.Position;
                            if (position < 0)
                                return;

                            var item = GroupsAdapter.GetItem(position);
                            if (item == null)
                                return;
                             
                            if (UserDetails.UserId == item.UserId)
                                item.IsOwner = true;

                            //if (!string.IsNullOrEmpty(item.GroupsModel.UserProfileId) && UserDetails.UserId == item.GroupsModel.UserProfileId)
                            //    group.IsJoined = "true";

                            MainApplication.GetInstance()?.NavigateTo(activity, typeof(GroupProfileActivity), item);
                        }
                        catch (Exception x)
                        {
                            Console.WriteLine(x);
                        }
                    }; 
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class PagesViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public ImageView PageImage1 { get; private set; }
            public ImageView PageImage2 { get; private set; }
            public ImageView PageImage3 { get; private set; }
            public TextView AboutHead { get; private set; }
            public TextView AboutMore { get; private set; }
            public TextView AboutMoreIcon { get; private set; }

            public PagesViewHolder(View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;

                    PageImage1 = MainView.FindViewById<ImageView>(Resource.Id.image_page_1);
                    PageImage2 = MainView.FindViewById<ImageView>(Resource.Id.image_page_2);
                    PageImage3 = MainView.FindViewById<ImageView>(Resource.Id.image_page_3);

                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class EmptyStateAdapterViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public TextView EmptyText { get; private set; }
            public ImageView EmptyImage { get; private set; }

            public EmptyStateAdapterViewHolder(View itemView) : base(itemView)
            {
                MainView = itemView;
                EmptyText = MainView.FindViewById<TextView>(Resource.Id.textEmpty);
                EmptyImage = MainView.FindViewById<ImageView>(Resource.Id.imageEmpty);
            }
        }

        public class AlertAdapterViewHolder : RecyclerView.ViewHolder
        {
            public View MainView {get; private set; }
            public RelativeLayout MianAlert { get; private set; }
            public TextView HeadText { get; private set; }
            public TextView SubText { get; private set; }
            public View LineView { get; private set; }
            public ImageView Image { get; private set; }
            public NativePostAdapter Adapter { get; private set; }
            public AlertAdapterViewHolder(View itemView, NativePostAdapter adapter) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    Adapter = adapter;

                    MianAlert = MainView.FindViewById<RelativeLayout>(Resource.Id.main);

                    LineView = MainView.FindViewById<View>(Resource.Id.lineview);
                    HeadText = MainView.FindViewById<TextView>(Resource.Id.HeadText);
                    SubText = MainView.FindViewById<TextView>(Resource.Id.subText);
                    Image = MainView.FindViewById<ImageView>(Resource.Id.Image);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class AdMobAdapterViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public TemplateView MianAlert { get; private set; }
             
            public NativePostAdapter Adapter { get; private set; }
            public AdMobAdapterViewHolder(View itemView, NativePostAdapter adapter) : base(itemView)
            {
                try
                {
                    MainView = itemView;
                    Adapter = adapter;

                    MianAlert = MainView.FindViewById<TemplateView>(Resource.Id.my_template); 
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class AlertJoinAdapterViewHolder : RecyclerView.ViewHolder
        {
            public View MainView {get; private set; }
            public RelativeLayout MainRelativeLayout {get; private set; }
            public TextView HeadText {get; private set; }
            public TextView SubText {get; private set; }
            public Button ButtonView {get; private set; }
            public ImageView IconImageView {get; private set; }
            public ImageView NormalImageView {get; private set; }

            public AlertJoinAdapterViewHolder(View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;

                    MainRelativeLayout = MainView.FindViewById<RelativeLayout>(Resource.Id.mainview);
                    ButtonView = MainView.FindViewById<Button>(Resource.Id.buttonview);
                    HeadText = MainView.FindViewById<TextView>(Resource.Id.HeadText);
                    SubText = MainView.FindViewById<TextView>(Resource.Id.subText);
                    IconImageView = MainView.FindViewById<ImageView>(Resource.Id.IconImageview);
                    NormalImageView = MainView.FindViewById<ImageView>(Resource.Id.Imageview);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class SectionViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; private set; }
            public TextView AboutHead { get; private set; }
            public TextView AboutMore { get; private set; }
            public TextView AboutMoreIcon { get; private set; }

            public SectionViewHolder(View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;

                    AboutHead = MainView.FindViewById<TextView>(Resource.Id.headText);
                    AboutMore = MainView.FindViewById<TextView>(Resource.Id.moreText);
                    AboutMoreIcon = MainView.FindViewById<TextView>(Resource.Id.icon);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class SocialPagesViewHolder : RecyclerView.ViewHolder
        {
            public View MainView { get; }
            public RecyclerView PagesRecyclerView { get;  set; }
            public UserPagesAdapter PagesAdapter { get;  set; }

            public ImageView Image { get; private set; }
            public TextView Name { get; private set; }
            public TextView IconPage { get; private set; }


            public SocialPagesViewHolder(Activity activity, View itemView) : base(itemView)
            {
                try
                {
                    MainView = itemView;

                    Image = MainView.FindViewById<ImageView>(Resource.Id.Image);
                    Name = MainView.FindViewById<TextView>(Resource.Id.Name);
                    IconPage = MainView.FindViewById<TextView>(Resource.Id.Icon);

                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }
        }
    }
}