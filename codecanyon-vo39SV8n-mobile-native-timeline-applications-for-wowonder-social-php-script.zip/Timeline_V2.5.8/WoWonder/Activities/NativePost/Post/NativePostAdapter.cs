﻿using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Support.V7.Widget;
using Android.Util;
using Android.Views;
using Bumptech.Glide;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using Java.Lang;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Android.Gms.Ads;
using Android.Gms.Ads.Formats;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Posts;
using Exception = System.Exception;
using Object = Java.Lang.Object;

namespace WoWonder.Activities.NativePost.Post
{
    public enum NativeFeedType
    {
        Global, Event, Group, Page, Popular, User, Saved, HashTag
    }

    public class NativePostAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider, UnifiedNativeAd.IOnUnifiedNativeAdLoadedListener
    {
        private readonly Activity ActivityContext;

        public AdapterBinders BaseAdapterBinder { get; }
        public ObservableCollection<AdapterModelsClass> PostFeedList { get; private set; }
        private RecyclerView MainRecyclerView { get; }
        private LinearLayoutManager MainLinearLayoutManager;
        public NativeFeedType NativePostType { get; private set; }
        public string ApiIdParameter { get; set; }
        public AdapterHolders.StoryViewHolder HolderStory { get; private set; }

        public NativePostAdapter(Activity context, RecyclerView recyclerView, NativeFeedType nativePostType)
        {
            try
            {
                //HasStableIds = true;
                ActivityContext = context;
                NativePostType = nativePostType;
                MainRecyclerView = recyclerView;
                BaseAdapterBinder = new AdapterBinders(context, this, ApiIdParameter);

                var mLayoutManager = new PreCachingLayoutManager(ActivityContext)
                {
                    Orientation = LinearLayoutManager.Vertical
                };

                mLayoutManager.SetPreloadItemCount(5);

                MainLinearLayoutManager = new LinearLayoutManager(context);
                MainRecyclerView.SetLayoutManager(mLayoutManager);
                MainRecyclerView.GetLayoutManager().ItemPrefetchEnabled = true;

                var sizeProvider = new FixedPreloadSizeProvider(10, 10);
                var preLoader = new RecyclerViewPreloader<PostDataObject>(context, this, sizeProvider, 8);
                MainRecyclerView.AddOnScrollListener(preLoader);

                MainRecyclerView.SetAdapter(this);

                PostFeedList = new ObservableCollection<AdapterModelsClass>();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                View itemView;

                if (viewType == (int)PostModelType.AdsPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Ads, parent, false);
                    var vh = new AdapterHolders.AdsPostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.AlertBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_Alert, parent, false);
                    var vh = new AdapterHolders.AlertAdapterViewHolder(itemView, this);
                    return vh;
                }
                else if (viewType == (int)PostModelType.PagesBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_Pages, parent, false);
                    var vh = new AdapterHolders.PagesViewHolder(itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.ImagesBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_HRecyclerView, parent, false);
                    var vh = new AdapterHolders.ImagesViewHolder(ActivityContext, itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.FollowersBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_HRecyclerView, parent, false);
                    var vh = new AdapterHolders.FollowersViewHolder(ActivityContext, itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.GroupsBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_HRecyclerView, parent, false);
                    var vh = new AdapterHolders.GroupsViewHolder(ActivityContext, itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.AddPostBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_AddPost, parent, false);
                    var vh = new AdapterHolders.AddPostViewHolder(ActivityContext, itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.EmptyState)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_EmptyState, parent, false);
                    var vh = new AdapterHolders.EmptyStateAdapterViewHolder(itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.Story)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_HRecyclerView, parent, false);
                    var vh = new AdapterHolders.StoryViewHolder(ActivityContext, itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.AboutBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_About, parent, false);
                    var vh = new AdapterHolders.AboutBoxViewHolder(itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.AlertJoinBox)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ViewModel_AlertJoin, parent, false);
                    var vh = new AdapterHolders.AlertJoinAdapterViewHolder(itemView);
                    return vh;
                }
                else if (viewType == (int)PostModelType.VideoPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Video, parent, false);
                    var vh = new AdapterHolders.VideoPlayerViewHolder(itemView, null, viewType, BaseAdapterBinder);
                    return vh;
                }
                else if (viewType == (int)PostModelType.SharedPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Promoted, parent, false);
                    var vh = new AdapterHolders.SharedGlobalViewHolder(itemView, null, viewType, BaseAdapterBinder);
                    return vh;
                }
                else if (viewType == (int)PostModelType.ColorPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_ColorBox, parent, false);
                    var vh = new AdapterHolders.ColorBoxViewHolder(itemView, null, viewType, BaseAdapterBinder);
                    return vh;
                }
                else if (viewType == (int)PostModelType.MultiImage2)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_2Photo, parent, false);
                    var vh = new AdapterHolders.PostImagesViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.MultiImage3)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_3Photo, parent, false);
                    var vh = new AdapterHolders.PostImagesViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.MultiImage4)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_4Photo, parent, false);
                    var vh = new AdapterHolders.PostImagesViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.MultiImages)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_MultiPhoto, parent, false);
                    var vh = new AdapterHolders.PostImagesViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.LinkPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Link, parent, false);
                    var vh = new AdapterHolders.LinkPostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.ProductPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Product, parent, false);
                    var vh = new AdapterHolders.ProductPostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.FilePost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_File, parent, false);
                    var vh = new AdapterHolders.FilePostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.YoutubePost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Youtube, parent, false);
                    var vh = new AdapterHolders.YoutubePostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.VoicePost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Voice, parent, false);
                    var vh = new AdapterHolders.SoundPostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.EventPost)
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Event, parent, false);
                    var vh = new AdapterHolders.EventPostViewHolder(itemView, null);
                    return vh;
                }
                else if (viewType == (int)PostModelType.AdMob)
                { 
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_AdMob, parent, false);
                    var vh = new AdapterHolders.AdMobAdapterViewHolder(itemView, null);
                    return vh;
                }
                else
                {
                    itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.PostType_Global, parent, false);
                    var vh = new AdapterHolders.GlobalViewHolder(itemView, null, viewType, BaseAdapterBinder);
                    return vh;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("EX:ALLEN PostAdabter >> " + exception);
                return null;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position, IList<Object> payloads)
        {
            if (payloads.Count > 0)
            {
                if (payloads[0].ToString() == "StoryRefresh")
                {
                    if (viewHolder is AdapterHolders.StoryViewHolder holder)
                        holder.RefreshData();
                }
                else
                {
                    base.OnBindViewHolder(viewHolder, position, payloads);
                }
            }
            else
            {
                base.OnBindViewHolder(viewHolder, position, payloads);
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                Console.WriteLine("Allen Post OnBindViewHolder >>" + position);
                var item = PostFeedList[position];
                if (item == null)
                    return;

                int itemViewType = viewHolder.ItemViewType;

                if (itemViewType == (int)PostModelType.AlertBox)
                {
                    var holder = viewHolder as AdapterHolders.AlertAdapterViewHolder;
                    BaseAdapterBinder.BindAlertModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.AlertJoinBox)
                {
                    var holder = viewHolder as AdapterHolders.AlertJoinAdapterViewHolder;
                    BaseAdapterBinder.BindFindMoreModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.VideoPost)
                {
                    var holder = viewHolder as AdapterHolders.VideoPlayerViewHolder;
                    BaseAdapterBinder.BindVideoPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.BlogPost)
                {
                    var holder = viewHolder as AdapterHolders.GlobalViewHolder;
                    BaseAdapterBinder.BindBlogPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.AddPostBox)
                {
                    var holder = viewHolder as AdapterHolders.AddPostViewHolder;
                    BaseAdapterBinder.BindAddPost(holder, position);
                }
                else if (itemViewType == (int)PostModelType.Story)
                {
                    HolderStory = viewHolder as AdapterHolders.StoryViewHolder;
                    BaseAdapterBinder.BindStoryModel(HolderStory, item);
                }
                else if (itemViewType == (int)PostModelType.AboutBox)
                {
                    var holder = viewHolder as AdapterHolders.AboutBoxViewHolder;
                    BaseAdapterBinder.BindAboutModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.FollowersBox)
                {
                    var holder = viewHolder as AdapterHolders.FollowersViewHolder;
                    BaseAdapterBinder.BindFollowersModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.GroupsBox)
                {
                    var holder = viewHolder as AdapterHolders.GroupsViewHolder;
                    BaseAdapterBinder.BindGroupsModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.ImagesBox)
                {
                    var holder = viewHolder as AdapterHolders.ImagesViewHolder;
                    BaseAdapterBinder.BindImagesModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.PagesBox)
                {
                    var holder = viewHolder as AdapterHolders.PagesViewHolder;
                    BaseAdapterBinder.BindPagesModel(holder, item);
                }
                else if (itemViewType == (int)PostModelType.DeepSoundPost)
                {
                    var holder = viewHolder as AdapterHolders.GlobalViewHolder;
                    BaseAdapterBinder.BindDeepSoundPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.FacebookPost)
                {
                    var holder = viewHolder as AdapterHolders.GlobalViewHolder;
                    BaseAdapterBinder.BindFacebookPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.FilePost)
                {
                    var holder = viewHolder as AdapterHolders.FilePostViewHolder;
                    BaseAdapterBinder.BindFilePost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.MultiImage2 || itemViewType == (int)PostModelType.MultiImage3 || itemViewType == (int)PostModelType.MultiImage4 || itemViewType == (int)PostModelType.MultiImages)
                {
                    var holder = viewHolder as AdapterHolders.PostImagesViewHolder;
                    BaseAdapterBinder.BindMultiImagesPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.ImagePost || itemViewType == (int)PostModelType.StickerPost)
                {
                    var holder = viewHolder as AdapterHolders.GlobalViewHolder;
                    BaseAdapterBinder.BindPhotoPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.LinkPost)
                {
                    var holder = viewHolder as AdapterHolders.LinkPostViewHolder;
                    BaseAdapterBinder.BindLinkPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.PlayTubePost)
                {
                    var holder = viewHolder as AdapterHolders.GlobalViewHolder;
                    BaseAdapterBinder.BindPlayTubePost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.ProductPost)
                {
                    var holder = viewHolder as AdapterHolders.ProductPostViewHolder;
                    BaseAdapterBinder.BindProductPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.VoicePost)
                {
                    var holder = viewHolder as AdapterHolders.SoundPostViewHolder;
                    BaseAdapterBinder.BindVoicePost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.YoutubePost)
                {
                    var holder = viewHolder as AdapterHolders.YoutubePostViewHolder;
                    BaseAdapterBinder.BindThirdPartyVideosPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.EventPost)
                {
                    var holder = viewHolder as AdapterHolders.EventPostViewHolder;
                    BaseAdapterBinder.BindEventPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.AdsPost)
                {
                    var holder = viewHolder as AdapterHolders.AdsPostViewHolder;
                    BaseAdapterBinder.BindAdsPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.ColorPost)
                {
                    var holder = viewHolder as AdapterHolders.ColorBoxViewHolder;
                    BaseAdapterBinder.BindColorPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.SharedPost)
                {
                    var holder = viewHolder as AdapterHolders.SharedGlobalViewHolder;
                    BaseAdapterBinder.BindSharedPost(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.EmptyState)
                {
                    var holder = viewHolder as AdapterHolders.EmptyStateAdapterViewHolder;
                    BindEmptyState(holder, item.PostData, position);
                }
                else if (itemViewType == (int)PostModelType.AdMob)
                {
                    var holder = viewHolder as AdapterHolders.AdMobAdapterViewHolder;
                    BindAdMob(holder);
                }
                else
                {
                    if (viewHolder is AdapterHolders.GlobalViewHolder holder)
                    {
                        BaseAdapterBinder.LoadPostData(holder.ViewsLayouts, item.PostData, position);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private TemplateView Template;
        private void BindAdMob(AdapterHolders.AdMobAdapterViewHolder holder)
        {
            try
            {
               Template = holder.MianAlert;
                 
                AdLoader.Builder builder = new AdLoader.Builder(holder.MainView.Context, AppSettings.AdAdmobNativeKey);
                builder.ForUnifiedNativeAd(this);
                VideoOptions videoOptions = new VideoOptions.Builder()
                    .SetStartMuted(true)
                    .Build();
                NativeAdOptions adOptions = new NativeAdOptions.Builder()
                    .SetVideoOptions(videoOptions)
                    .Build();

                builder.WithNativeAdOptions(adOptions);

                AdLoader adLoader = builder.WithAdListener(new AdListener()).Build();
                adLoader.LoadAd(new AdRequest.Builder().Build());
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnUnifiedNativeAdLoaded(UnifiedNativeAd ad)
        {
            try
            {
                NativeTemplateStyle styles = new NativeTemplateStyle.Builder().Build();
                 
                if (Template.GetTemplateTypeName() == TemplateView.BigTemplate)
                {
                    Template.PopulateUnifiedNativeAdView(ad);
                }
                else
                {
                    Template.SetStyles(styles);
                    Template.SetNativeAd(ad);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        private void BindEmptyState(AdapterHolders.EmptyStateAdapterViewHolder holder, PostDataObject item, int position)
        {
            try
            {
                switch (NativePostType)
                {
                    case NativeFeedType.HashTag:
                        holder.EmptyText.Text = ActivityContext.GetText(Resource.String.Lbl_NoPost_TitleText_hashtag);
                        break;
                    case NativeFeedType.Saved:
                        holder.EmptyText.Text = ActivityContext.GetText(Resource.String.Lbl_NoPost_TitleText_saved);
                        break;
                    default:
                        holder.EmptyText.Text = ActivityContext.GetText(Resource.String.Lbl_NoPost_TitleText);
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public AdapterModelsClass GetItem(int position)
        {
            return PostFeedList[position];
        }

        public override int ItemCount => PostFeedList?.Count ?? 0;

        public override int GetItemViewType(int position)
        {
            try
            {
                var item = PostFeedList[position];

                switch (item.TypeView)
                {
                    case PostModelType.AdsPost:
                        return (int)PostModelType.AdsPost;

                    case PostModelType.AlertBox:
                        return (int)PostModelType.AlertBox;

                    case PostModelType.AddPostBox:
                        return (int)PostModelType.AddPostBox;

                    case PostModelType.VideoPost:
                        return (int)PostModelType.VideoPost;

                    case PostModelType.AboutBox:
                        return (int)PostModelType.AboutBox;

                    case PostModelType.BlogPost:
                        return (int)PostModelType.BlogPost;

                    case PostModelType.DeepSoundPost:
                        return (int)PostModelType.DeepSoundPost;

                    case PostModelType.EmptyState:
                        return (int)PostModelType.EmptyState;

                    case PostModelType.FilePost:
                        return (int)PostModelType.FilePost;

                    case PostModelType.FollowersBox:
                        return (int)PostModelType.FollowersBox;

                    case PostModelType.GroupsBox:
                        return (int)PostModelType.GroupsBox;

                    case PostModelType.ImagePost:
                        return (int)PostModelType.ImagePost;

                    case PostModelType.ImagesBox:
                        return (int)PostModelType.ImagesBox;

                    case PostModelType.LinkPost:
                        return (int)PostModelType.LinkPost;

                    case PostModelType.PagesBox:
                        return (int)PostModelType.PagesBox;

                    case PostModelType.PlayTubePost:
                        return (int)PostModelType.PlayTubePost;

                    case PostModelType.ProductPost:
                        return (int)PostModelType.ProductPost;

                    case PostModelType.StickerPost:
                        return (int)PostModelType.StickerPost;

                    case PostModelType.Story:
                        return (int)PostModelType.Story;

                    case PostModelType.VoicePost:
                        return (int)PostModelType.VoicePost;

                    case PostModelType.YoutubePost:
                        return (int)PostModelType.YoutubePost;

                    case PostModelType.AlertJoinBox:
                        return (int)PostModelType.AlertJoinBox;

                    case PostModelType.SharedPost:
                        return (int)PostModelType.SharedPost;

                    case PostModelType.EventPost:
                        return (int)PostModelType.EventPost;

                    case PostModelType.ColorPost:
                        return (int)PostModelType.ColorPost;

                    case PostModelType.FacebookPost:
                        return (int)PostModelType.FacebookPost;

                    case PostModelType.MultiImage2:
                        return (int)PostModelType.MultiImage2;

                    case PostModelType.MultiImage3:
                        return (int)PostModelType.MultiImage3;

                    case PostModelType.MultiImage4:
                        return (int)PostModelType.MultiImage4;

                    case PostModelType.MultiImages:
                        return (int)PostModelType.MultiImages;

                    case PostModelType.NormalPost:
                        return (int)PostModelType.NormalPost;

                    case PostModelType.PollPost:
                        return (int)PostModelType.PollPost;

                    case PostModelType.AdMob:
                        return (int)PostModelType.AdMob;
                           
                    default:
                        return (int)PostModelType.NormalPost;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return (int)PostModelType.NormalPost;
            }
        }

        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = PostFeedList[p0];
                if (item.PostData == null)
                    return d;
                else
                {
                    if (item.PostData.PhotoMulti?.Count > 0)
                        foreach (var photo in item.PostData.PhotoMulti)
                            if (!string.IsNullOrEmpty(photo.Image))
                                d.Add(photo.Image);

                    if (item.PostData.PhotoAlbum?.Count > 0)
                    {
                        foreach (var photo in item.PostData.PhotoAlbum)
                        {
                            if (!string.IsNullOrEmpty(photo.Image))
                                d.Add(photo.Image);

                            if (item.PostData.PhotoAlbum.IndexOf(photo) == 4)
                                continue;
                        }
                    }

                    if (item.PostData.ColorId != "0")
                    {
                        if (ListUtils.SettingsSiteList.PostColors != null && ListUtils.SettingsSiteList.PostColors.Value.PostColorsList != null)
                        {
                            var getColorObject = ListUtils.SettingsSiteList.PostColors.Value.PostColorsList.FirstOrDefault(a => a.Key == item.PostData.ColorId);
                            if (getColorObject.Value != null)
                            {
                                if (!string.IsNullOrEmpty(getColorObject.Value.Image))
                                    d.Add(getColorObject.Value.Image);
                            }
                        }
                    }

                    if (item.PostData.PostSticker != null && !string.IsNullOrEmpty(item.PostData.PostSticker))
                        d.Add(item.PostData.PostSticker);

                    if (PostFunctions.GetImagesExtenstions(item.PostData.PostFileFull))
                        d.Add(item.PostData.PostFileFull);

                    if (!string.IsNullOrEmpty(item.PostData.Publisher.Avatar))
                        d.Add(item.PostData.Publisher.Avatar);

                    return d;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                var d = new List<string>();
                return d;
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Object p0)
        {
            return Glide.With(ActivityContext).Load(p0.ToString()).Apply(new RequestOptions().CenterCrop().SetDiskCacheStrategy(DiskCacheStrategy.All));
        }
    }

    public sealed class PreCachingLayoutManager : LinearLayoutManager
    {
        public Context Context;
        public int ExtraLayoutSpace = -1;
        public int DefaultExtraLayoutSpace = 600;
        public OrientationHelper MOrientationHelper;

        public int MAdditionalAdjacentPrefetchItemCount;

        private PreCachingLayoutManager(IntPtr javaReference, JniHandleOwnership transfer) : base(javaReference, transfer)
        {
        }

        public PreCachingLayoutManager(Activity context) : base(context)
        {
            Context = context;
            Init();
        }

        public PreCachingLayoutManager(Context context, IAttributeSet attrs, int defStyleAttr, int defStyleRes) : base(context, attrs, defStyleAttr, defStyleRes)
        {
            Context = context;
            Init();
        }

        public PreCachingLayoutManager(Context context, int orientation, bool reverseLayout) : base(context, orientation, reverseLayout)
        {
            Context = context;
            Init();
        }

        public void Init()
        {
            MOrientationHelper = OrientationHelper.CreateOrientationHelper(this, Orientation);
            ItemPrefetchEnabled = true;
            InitialPrefetchItemCount = 20;
        }

        public void SetPreloadItemCount(int preloadItemCount)
        {
            if (preloadItemCount < 1)
            {
                throw new IllegalArgumentException("adjacentPrefetchItemCount must not smaller than 1!");
            }
            MAdditionalAdjacentPrefetchItemCount = preloadItemCount - 1;
        }

        public override void CollectAdjacentPrefetchPositions(int dx, int dy, RecyclerView.State state, ILayoutPrefetchRegistry layoutPrefetchRegistry)
        {
            try
            {
                base.CollectAdjacentPrefetchPositions(dx, dy, state, layoutPrefetchRegistry);

                int delta = Orientation == Horizontal ? dx : dy;
                if (ChildCount == 0 || delta == 0)
                    return;

                int layoutDirection = delta > 0 ? 1 : -1;
                View child = GetChildClosest(layoutDirection);
                int currentPosition = GetPosition(child) + layoutDirection;
                int scrollingOffset;

                if (layoutDirection == 1)
                {
                    scrollingOffset = MOrientationHelper.GetDecoratedEnd(child) - MOrientationHelper.EndAfterPadding;
                    for (int i = currentPosition + 1; i < currentPosition + MAdditionalAdjacentPrefetchItemCount + 1; i++)
                    {
                        if (i >= 0 && i < state.ItemCount)
                        {
                            layoutPrefetchRegistry.AddPosition(i, Java.Lang.Math.Max(0, scrollingOffset));
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private View GetChildClosest(int layoutDirection)
        {
            return GetChildAt(layoutDirection == -1 ? 0 : ChildCount - 1);
        }
    }
}