﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Com.Devs.ReadMoreOptionLib;
using Java.Lang;
using Newtonsoft.Json;
using Plugin.Share;
using Plugin.Share.Abstractions;
using WoWonder.Activities.AddPost;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Event;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using Exception = System.Exception;

namespace WoWonder.Activities.Events
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class EventViewActivity : AppCompatActivity , IOnMapReadyCallback, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private CollapsingToolbarLayout ToolbarLayout;
        private GoogleMap Map;
        private double CurrentLongitude, CurrentLatitude;
        private TextView TxtName,IconGoing, TxtGoing, IconInterested, TxtInterested, TxtStartDate, TxtEndDate, IconLocation, TxtLocation, TxtDescription;
        private FloatingActionButton FloatingActionButtonView;
        private ImageView ImageEventCover, IconBack;
        private Button BtnGo, BtnInterested;
        private WRecyclerView MainRecyclerView;
        private NativePostAdapter PostFeedAdapter;
        private ImageButton BtnMore; 
        private EventDataObject EventData;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.EventView_Layout);
                 
                var eventObject = Intent.GetStringExtra("EventView");
                if (!string.IsNullOrEmpty(eventObject))
                    EventData = JsonConvert.DeserializeObject<EventDataObject>(eventObject);

                //Get Value And Set Toolbar
                InitComponent();
                SetRecyclerViewAdapters();

                Get_Data_Event();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                MainRecyclerView.ReleasePlayer();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                ToolbarLayout = FindViewById<CollapsingToolbarLayout>(Resource.Id.collapsing_toolbar_ptwo);
                ToolbarLayout.Title = "";

                TxtName = FindViewById<TextView>(Resource.Id.tvName_ptwo);
                IconGoing = FindViewById<TextView>(Resource.Id.IconGoing);
                TxtGoing = FindViewById<TextView>(Resource.Id.GoingTextview);
                IconInterested = FindViewById<TextView>(Resource.Id.IconInterested);
                TxtInterested = FindViewById<TextView>(Resource.Id.InterestedTextview);
                TxtStartDate = FindViewById<TextView>(Resource.Id.txtStartDate);
                TxtEndDate = FindViewById<TextView>(Resource.Id.txtEndDate);

                IconLocation = FindViewById<TextView>(Resource.Id.IconLocation);
                TxtLocation = FindViewById<TextView>(Resource.Id.LocationTextview);
                TxtDescription = FindViewById<TextView>(Resource.Id.tv_aboutdescUser);

                ImageEventCover = FindViewById<ImageView>(Resource.Id.EventCover);
                IconBack = FindViewById<ImageView>(Resource.Id.back);

                BtnGo = FindViewById<Button>(Resource.Id.ButtonGoing);
                BtnInterested = FindViewById<Button>(Resource.Id.ButtonIntersted);

                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);

                MainRecyclerView = FindViewById<WRecyclerView>(Resource.Id.newsfeedRecyler);
                BtnMore = (ImageButton)FindViewById(Resource.Id.morebutton);

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconGoing, IonIconsFonts.IosPeople);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconInterested, IonIconsFonts.AndroidStar);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconLocation, IonIconsFonts.Location);

                var mapFragment = (MapFragment)FragmentManager.FindFragmentById(Resource.Id.map);
                mapFragment.GetMapAsync(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        
        private void SetRecyclerViewAdapters()
        {
            try
            {
                PostFeedAdapter = new NativePostAdapter(this, MainRecyclerView, NativeFeedType.Event)
                {
                    ApiIdParameter = EventData.Id
                };
                
                MainRecyclerView.SetXAdapter(PostFeedAdapter, null);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    IconBack.Click += IconBackOnClick;
                    FloatingActionButtonView.Click += AddPostOnClick;
                    BtnGo.Click += BtnGoOnClick;
                    BtnInterested.Click += BtnInterestedOnClick;
                    BtnMore.Click += BtnMoreOnClick;
                }
                else
                {
                    IconBack.Click -= IconBackOnClick;
                    FloatingActionButtonView.Click -= AddPostOnClick;
                    BtnGo.Click -= BtnGoOnClick;
                    BtnInterested.Click -= BtnInterestedOnClick;
                    BtnMore.Click -= BtnMoreOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        //Event Show More : Copy Link , Share , Edit (If user isOwner_Event)
        private void BtnMoreOnClick(object sender, EventArgs e)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetString(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(GetString(Resource.String.Lbl_Share));
                if (EventData.IsOwner)
                    arrayAdapter.Add(GetString(Resource.String.Lbl_Edit));

                dialogList.Title(GetString(Resource.String.Lbl_More));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnInterestedOnClick(object sender, EventArgs e)
        {
            try
            {
                if (BtnInterested.Tag.ToString() == "false")
                {
                    BtnInterested.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                    BtnInterested.SetTextColor(Color.ParseColor("#ffffff"));
                    BtnInterested.Text = GetText(Resource.String.Lbl_Interested);
                    BtnInterested.Tag = "true";
                }
                else
                {
                    BtnInterested.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    BtnInterested.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                    BtnInterested.Text = GetText(Resource.String.Lbl_Interested);
                    BtnInterested.Tag = "false";
                }
                 
                var dataEvent = EventMainActivity.EventTab.MAdapter.EventList?.FirstOrDefault(a => a.Id == EventData.Id);
                if (dataEvent != null)
                {
                    dataEvent.IsInterested = Convert.ToBoolean(BtnInterested.Tag);
                }

                RequestsAsync.Event.Interest_Event(EventData.Id).ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnGoOnClick(object sender, EventArgs e)
        {
            try
            {
                if (BtnGo.Tag.ToString() == "false")
                {
                    BtnGo.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                    BtnGo.SetTextColor(Color.ParseColor("#ffffff"));
                    BtnGo.Text = GetText(Resource.String.Lbl_Going);
                    BtnGo.Tag = "true";
                }
                else
                {
                    BtnGo.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    BtnGo.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                    BtnGo.Text = GetText(Resource.String.Lbl_Go);
                    BtnGo.Tag = "false";
                }

                var list = EventMainActivity.EventTab.MAdapter?.EventList;
                var dataEvent = list?.FirstOrDefault(a => a.Id == EventData.Id);
                if (dataEvent != null)
                {
                    dataEvent.IsGoing = Convert.ToBoolean(BtnGo.Tag);
                    EventMainActivity.EventTab.MAdapter.NotifyItemChanged(list.IndexOf(dataEvent));
                }

                RequestsAsync.Event.Go_To_Event(EventData.Id).ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void AddPostOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(this, typeof(AddPostActivity));
                Int.PutExtra("Type", "SocialEvent");
                Int.PutExtra("PostId", EventData.Id);
                Int.PutExtra("itemObject", JsonConvert.SerializeObject(EventData));
                StartActivityForResult(Int, 2500);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void IconBackOnClick(object sender, EventArgs e)
        {
            Finish();
        }

        #endregion
         
        #region Location
         
        public async void OnMapReady(GoogleMap googleMap)
        {
            try
            {
                var location = await ApiRequest.GetNameLocation(EventData.Location);
                if (location.Count > 0)
                {
                    CurrentLatitude = location[0].Geometry.Location.Lat;
                    CurrentLongitude = location[0].Geometry.Location.Lng;
                }

                Map = googleMap;

                //Optional
                googleMap.UiSettings.MapToolbarEnabled = true;
                googleMap.UiSettings.ZoomControlsEnabled = false;
                googleMap.UiSettings.CompassEnabled = false;
                googleMap.MoveCamera(CameraUpdateFactory.ZoomIn());

                var makerOptions = new MarkerOptions();
                makerOptions.SetPosition(new LatLng(CurrentLatitude, CurrentLongitude));
                makerOptions.SetTitle(GetText(Resource.String.Lbl_EventPlace));

                Map.AddMarker(makerOptions);
                Map.MapType = GoogleMap.MapTypeNormal;

                var builder = CameraPosition.InvokeBuilder();
                builder.Target(new LatLng(CurrentLatitude, CurrentLongitude));
                var cameraPosition = builder.Zoom(16).Target(new LatLng(CurrentLatitude, CurrentLongitude)).Build();
                cameraPosition.Zoom = 16;

                var cameraUpdate = CameraUpdateFactory.NewCameraPosition(cameraPosition);

                Map.MoveCamera(cameraUpdate);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Result

        //Result
        protected override async void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

                if (requestCode == 2500 && resultCode == Result.Ok) //add post
                {
                    var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                    if (postData != null)
                    {
                        var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                        MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                        {
                            TypeView = postType,
                            Id = int.Parse(postData.Id),
                            PostData = postData,
                            IsDefaultFeedPost = true,
                        });
                    }
                    else
                    {
                        await MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                    }
                }
                else if (requestCode == 3950 && resultCode == Result.Ok) //Edit post
                {
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemChanged(index);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == GetString(Resource.String.Lbl_CopeLink))
                {
                    CopyLinkEvent();
                }
                else if (text == GetString(Resource.String.Lbl_Share))
                {
                    ShareEvent();
                }
                else if (text == GetString(Resource.String.Lbl_Edit))
                {
                    EditInfoGroup_OnClick();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                    {

                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }    
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Copy Link
        private void CopyLinkEvent()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", EventData.Url);
                clipboardManager.PrimaryClip = clipData;

                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Share
        private async void ShareEvent()
        {
            try
            {
                //Share Plugin  
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = EventData.Name,
                    Text = EventData.Description,
                    Url = EventData.Url
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Edit Info Event if user == is_owner
        private void EditInfoGroup_OnClick()
        {
            try
            {
                if (EventData.IsOwner)
                {
                    var Int = new Intent(this, typeof(EditEventActivity));
                    Int.PutExtra("EventData", JsonConvert.SerializeObject(EventData));
                    Int.PutExtra("EventId", EventData.Id);
                    StartActivity(Int);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void Get_Data_Event()
        {
            try
            { 
                if (EventData != null)
                {
                    GlideImageLoader.LoadImage(this, EventData.Cover, ImageEventCover, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);

                    TxtName.Text = EventData.Name;
                    ToolbarLayout.Title = EventData.Name;

                    TxtGoing.Text = EventData.GoingCount + " " + GetText(Resource.String.Lbl_GoingPeople);
                    TxtInterested.Text = EventData.InterestedCount + " " + GetText(Resource.String.Lbl_InterestedPeople);
                    TxtLocation.Text = EventData.Location;

                    TxtStartDate.Text = EventData.StartDate;
                    TxtEndDate.Text = EventData.EndDate;

                    var description =Methods.FunString.DecodeString(EventData.Description);

                    var readMoreOption = new ReadMoreOption.Builder(this)
                        .TextLength(250, ReadMoreOption.TypeCharacter)
                        .MoreLabel(GetText(Resource.String.Lbl_ReadMore))
                        .LessLabel(GetText(Resource.String.Lbl_ReadLess))
                        .MoreLabelColor(Color.ParseColor(AppSettings.MainColor))
                        .LessLabelColor(Color.ParseColor(AppSettings.MainColor))
                        .LabelUnderLine(true)
                        .Build();
                    readMoreOption.AddReadMoreTo(TxtDescription, description);

                    if (EventData.IsGoing)
                    {
                        BtnGo.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                        BtnGo.SetTextColor(Color.ParseColor("#ffffff"));
                        BtnGo.Text = GetText(Resource.String.Lbl_Going);
                        BtnGo.Tag = "true";
                    }
                    else
                    {
                        BtnGo.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                        BtnGo.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                        BtnGo.Text = GetText(Resource.String.Lbl_Go);
                        BtnGo.Tag = "false";
                    }

                    if (EventData.IsInterested)
                    {
                        BtnInterested.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                        BtnInterested.SetTextColor(Color.ParseColor("#ffffff"));
                        BtnInterested.Text = GetText(Resource.String.Lbl_Interested);
                        BtnInterested.Tag = "true";
                    }
                    else
                    {
                        BtnInterested.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                        BtnInterested.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                        BtnInterested.Text = GetText(Resource.String.Lbl_Interested);
                        BtnInterested.Tag = "false";
                    }

                    StartApiService();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> {() => MainRecyclerView.FetchNewsFeedApiPosts("0") });
        } 

    }
}