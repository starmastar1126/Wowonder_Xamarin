﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using WoWonder.Activities.Events.Fragment;
using WoWonder.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Event;
using WoWonderClient.Requests;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.Events
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class EventMainActivity : AppCompatActivity
    {
        #region Variables Basic

        private ViewPager ViewPager;
        public static EventFragment EventTab;
        public static MyEventFragment MyEventTab;
        private TabLayout TabLayout;
        private FloatingActionButton FloatingActionButtonView;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.EventMain_Layout);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();

                LoadDataApi();
                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                if (EventTab.MAdapter.EventList.Count > 0)
                    ListUtils.ListCachedDataEvent = EventTab.MAdapter.EventList;

                if (MyEventTab.MAdapter.MyEventList.Count > 0)
                    ListUtils.ListCachedDataMyEvents = MyEventTab.MAdapter.MyEventList;

                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                ViewPager = FindViewById<ViewPager>(Resource.Id.viewpager);
                TabLayout = FindViewById<TabLayout>(Resource.Id.tabs);

                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);

                ViewPager.OffscreenPageLimit = 2;
                SetUpViewPager(ViewPager);
                TabLayout.SetupWithViewPager(ViewPager);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = GetText(Resource.String.Lbl_Events);
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    FloatingActionButtonView.Click += BtnCreateEventsOnClick;
                }
                else
                {
                    FloatingActionButtonView.Click -= BtnCreateEventsOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        public void BtnCreateEventsOnClick(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(this, typeof(CreateEventActivity)));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        #endregion

        #region Set Tap

        private void SetUpViewPager(ViewPager viewPager)
        {
            try
            {
                EventTab = new EventFragment();
                MyEventTab = new MyEventFragment();

                var adapter = new MainTabAdapter(SupportFragmentManager);
                adapter.AddFragment(EventTab, GetText(Resource.String.Lbl_All_Events));
                adapter.AddFragment(MyEventTab, GetText(Resource.String.Lbl_My_Events));

                viewPager.CurrentItem = 2;
                viewPager.Adapter = adapter;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Get Event Api 

        private void LoadDataApi()
        {
            try
            {
                string offsetEvent = "0", offsetMyEvent = "0";

                if (EventTab.MAdapter != null && ListUtils.ListCachedDataEvent.Count > 0)
                {
                    EventTab.MAdapter.EventList = ListUtils.ListCachedDataEvent;
                    MyEventTab.MAdapter.NotifyDataSetChanged();

                    var item = EventTab.MAdapter.EventList.LastOrDefault();
                    if (item != null && !string.IsNullOrEmpty(item.Id))
                        offsetEvent = item.Id;
                }

                if (MyEventTab.MAdapter != null && ListUtils.ListCachedDataEvent.Count > 0)
                {
                    MyEventTab.MAdapter.MyEventList = ListUtils.ListCachedDataMyEvents;
                    MyEventTab.MAdapter.NotifyDataSetChanged();

                    var item = MyEventTab.MAdapter.MyEventList.LastOrDefault();
                    if (item != null && !string.IsNullOrEmpty(item.Id))
                        offsetMyEvent = (item.Id);
                }

                StartApiService(offsetEvent, offsetMyEvent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void StartApiService(string offsetEvent = "0", string offsetMyEvent = "0")
        {
            if (Methods.CheckConnectivity())
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => GetEvent(offsetEvent), () => GetMyEvent(offsetMyEvent) });
            else
                Toast.MakeText(this, GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
        }

        public async Task GetEvent(string offset = "0")
        {
            if (Methods.CheckConnectivity())
            {
                int countList = EventTab.MAdapter.EventList.Count;
                (int apiStatus, var respond) = await RequestsAsync.Event.Get_Events("20", offset);
                if (apiStatus.Equals(200))
                {
                    if (respond is GetEventsObject result)
                    {
                        var respondList = result.Events.Count;
                        if (respondList > 0)
                        {
                            if (countList > 0)
                            {
                                foreach (var item in result.Events)
                                {
                                    var check = EventTab.MAdapter.EventList.FirstOrDefault(a => a.Id == item.Id);
                                    if (check == null)
                                    {
                                        EventTab.MAdapter.EventList.Add(item);
                                    }
                                }

                                RunOnUiThread(() => { EventTab.MAdapter.NotifyItemRangeInserted(countList - 1, EventTab.MAdapter.EventList.Count - countList); });
                            }
                            else
                            {
                                EventTab.MAdapter.EventList = new ObservableCollection<EventDataObject>(result.Events);
                                RunOnUiThread(() => { EventTab.MAdapter.NotifyDataSetChanged(); });
                            }
                        }
                        else
                        {
                            if (EventTab.MAdapter.EventList.Count > 10 && !EventTab.MRecycler.CanScrollVertically(1))
                                Toast.MakeText(this, GetText(Resource.String.Lbl_NoMoreEvent), ToastLength.Short).Show();
                        }
                    }
                }
                else Methods.DisplayReportResult(this, respond);

                EventTab.MainScrollEvent.IsLoading = false;
                RunOnUiThread(() => { ShowEmptyPage("GetEvent"); });
            }
            else
            {
                EventTab.Inflated = EventTab.EmptyStateLayout.Inflate();
                EmptyStateInflater x = new EmptyStateInflater();
                x.InflateLayout(EventTab.Inflated, EmptyStateInflater.Type.NoConnection);
                if (!x.EmptyStateButton.HasOnClickListeners)
                {
                    x.EmptyStateButton.Click += null;
                    x.EmptyStateButton.Click += EmptyStateButtonOnClick;
                }

                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            }
        }

        public async Task GetMyEvent(string offset = "0")
        {
            int countList = MyEventTab.MAdapter.MyEventList.Count;
            (int apiStatus, var respond) = await RequestsAsync.Event.Get_MyEvents("20", offset);
            if (apiStatus.Equals(200))
            {
                if (respond is GetMyEventObject result)
                {
                    var respondList = result.MyEvents.Count;
                    if (respondList > 0)
                    {
                        if (countList > 0)
                        {
                            foreach (var item in result.MyEvents)
                            {
                                var check = MyEventTab.MAdapter.MyEventList.FirstOrDefault(a => a.Id == item.Id);
                                if (check == null)
                                {
                                    EventTab.MAdapter.EventList.Add(item);
                                }
                            }

                            RunOnUiThread(() => { MyEventTab.MAdapter.NotifyItemRangeInserted(countList - 1, MyEventTab.MAdapter.MyEventList.Count - countList); });
                             
                        }
                        else
                        {
                            MyEventTab.MAdapter.MyEventList = new ObservableCollection<EventDataObject>(result.MyEvents);
                            RunOnUiThread(() => { MyEventTab.MAdapter.NotifyDataSetChanged(); }); 
                        }
                    }
                    else
                    {
                        if (MyEventTab.MAdapter.MyEventList.Count > 10 && !MyEventTab.MRecycler.CanScrollVertically(1))
                            Toast.MakeText(this, GetText(Resource.String.Lbl_NoMoreEvent), ToastLength.Short).Show();
                    }
                }
            }
            else Methods.DisplayReportResult(this, respond);

            MyEventTab.MainScrollEvent.IsLoading = false;
            RunOnUiThread(() => { ShowEmptyPage("GetMyEvent"); });
        }

        private void ShowEmptyPage(string type)
        {
            try
            {
                EventTab.SwipeRefreshLayout.Refreshing = false;
                MyEventTab.SwipeRefreshLayout.Refreshing = false;

                if (type == "GetEvent")
                {
                    if (EventTab.MAdapter.EventList.Count > 0)
                    {
                        EventTab.MRecycler.Visibility = ViewStates.Visible;
                        EventTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        EventTab.MRecycler.Visibility = ViewStates.Gone;

                        if (EventTab.Inflated == null)
                            EventTab.Inflated = EventTab.EmptyStateLayout.Inflate();

                        EmptyStateInflater x = new EmptyStateInflater();
                        x.InflateLayout(EventTab.Inflated, EmptyStateInflater.Type.NoEvent);
                        if (!x.EmptyStateButton.HasOnClickListeners)
                        {
                            x.EmptyStateButton.Click += null;
                            x.EmptyStateButton.Click += BtnCreateEventsOnClick;
                        }
                        EventTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    }
                }
                else if (type == "GetMyEvent")
                { 
                    if (MyEventTab.MAdapter.MyEventList.Count > 0)
                    {
                        MyEventTab.MRecycler.Visibility = ViewStates.Visible;
                        MyEventTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        MyEventTab.MRecycler.Visibility = ViewStates.Gone;

                        if (MyEventTab.Inflated == null)
                            MyEventTab.Inflated = MyEventTab.EmptyStateLayout.Inflate();

                        EmptyStateInflater x = new EmptyStateInflater();
                        x.InflateLayout(MyEventTab.Inflated, EmptyStateInflater.Type.NoEvent);
                        if (!x.EmptyStateButton.HasOnClickListeners)
                        {
                            x.EmptyStateButton.Click += null;
                            x.EmptyStateButton.Click += BtnCreateEventsOnClick;
                        }
                        MyEventTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    } 
                } 
            }
            catch (Exception e)
            {
                EventTab.SwipeRefreshLayout.Refreshing = false;
                MyEventTab.SwipeRefreshLayout.Refreshing = false;
                Console.WriteLine(e);
            }
        }

        //No Internet Connection 
        private void EmptyStateButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                StartApiService();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion
    }
}