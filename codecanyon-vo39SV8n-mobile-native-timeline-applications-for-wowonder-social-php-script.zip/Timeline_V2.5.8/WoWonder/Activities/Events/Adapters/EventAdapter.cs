﻿using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.App;
using Bumptech.Glide;
using Java.Util;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Event;
using WoWonderClient.Requests;
using IList = System.Collections.IList;
using Object = Java.Lang.Object;

namespace WoWonder.Activities.Events.Adapters
{
    public class EventAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<EventAdapterClickEventArgs> ItemClick;
        public event EventHandler<EventAdapterClickEventArgs> ItemLongClick;

        private readonly Activity ActivityContext; 
        public ObservableCollection<EventDataObject> EventList = new ObservableCollection<EventDataObject>();

        public EventAdapter(Activity context)
        {
            try
            {
                HasStableIds = true;
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount => EventList?.Count ?? 0;


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Event_Cell
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Event_Cell, parent, false);
                var vh = new EventAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            { 
                if (viewHolder is EventAdapterViewHolder holder)
                {
                    var item = EventList[position];
                    if (item != null) Initialize(holder, item);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Initialize(EventAdapterViewHolder holder, EventDataObject item)
        {
            try
            {
                GlideImageLoader.LoadImage(ActivityContext, item.Cover, holder.Image, ImageStyle.RoundedCrop, ImagePlaceholders.Color);

                holder.TxtEventTitle.Text = Methods.FunString.DecodeString(item.Name); 
                holder.TxtEventDescription.Text = Methods.FunString.DecodeString(item.Description); 
                holder.TxtEventTime.Text = item.StartDate; 
                holder.TxtEventLocation.Text = item.Location;

                holder.GoingButton.SetImageResource(item.IsGoing ? Resource.Drawable.ic_star_filled : Resource.Drawable.ic_star);
                 
                if (!holder.GoingButton.HasOnClickListeners)
                {
                    holder.GoingButton.Click += (sender, args) =>
                    {
                        if (item.IsGoing)
                        {
                            item.IsGoing = false;
                            holder.GoingButton.SetImageResource(Resource.Drawable.ic_star); 
                        } 
                        else
                        {
                            item.IsGoing = true;
                            holder.GoingButton.SetImageResource(Resource.Drawable.ic_star_filled); 
                        }

                        RequestsAsync.Event.Go_To_Event(item.Id).ConfigureAwait(false);
                    };
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public EventDataObject GetItem(int position)
        {
            return EventList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(EventList[position].Id);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(EventAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(EventAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }

        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = EventList[p0];
                if (item == null)
                    return Collections.SingletonList(p0);

                if (!string.IsNullOrEmpty(item.Cover))
                    d.Add(item.Cover);
                return d;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Collections.SingletonList(p0);
            }
        }


        public RequestBuilder GetPreloadRequestBuilder(Object p0)
        {
           return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext,p0.ToString(),ImageStyle.RoundedCrop);
        }
    }

    public class EventAdapterViewHolder : RecyclerView.ViewHolder
    {
        public EventAdapterViewHolder(View itemView, Action<EventAdapterClickEventArgs> clickListener,Action<EventAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;
                Image = MainView.FindViewById<ImageView>(Resource.Id.Image);
                TxtEventTitle = MainView.FindViewById<TextView>(Resource.Id.event_titile);
                TxtEventDescription = MainView.FindViewById<TextView>(Resource.Id.event_description);
                TxtEventTime = MainView.FindViewById<TextView>(Resource.Id.event_time);
                TxtEventLocation = MainView.FindViewById<TextView>(Resource.Id.event_location);
                GoingButton = MainView.FindViewById<ImageView>(Resource.Id.ImageStar);
                
                //Event
                itemView.Click += (sender, e) => clickListener(new EventAdapterClickEventArgs{ View = itemView, Position = AdapterPosition });
                itemView.LongClick += (sender, e) => longClickListener(new EventAdapterClickEventArgs{ View = itemView, Position = AdapterPosition });
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic

        public View MainView { get; }
        public ImageView Image { get; private set; }
        public ImageView GoingButton { get; private set; }
        public TextView TxtEventTitle { get; private set; }
        public TextView TxtEventTime { get; private set; }
        public TextView TxtEventDescription { get; private set; }
        public TextView TxtEventLocation { get; private set; }
        
        #endregion Variables Basic
        
    }

    public class EventAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}