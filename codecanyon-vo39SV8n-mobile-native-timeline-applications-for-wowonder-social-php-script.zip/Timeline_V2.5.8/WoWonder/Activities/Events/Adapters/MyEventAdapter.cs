﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Java.Util;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Event;
using IList = System.Collections.IList;

namespace WoWonder.Activities.Events.Adapters
{
    public class MyEventAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<MyEventAdapterClickEventArgs> ItemClick;
        public event EventHandler<MyEventAdapterClickEventArgs> ItemLongClick;

        private readonly Activity ActivityContext; 
        public ObservableCollection<EventDataObject> MyEventList = new ObservableCollection<EventDataObject>();
         
        public MyEventAdapter(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (MyEventList != null)
                    return MyEventList.Count;
                return 0;
            }
        }


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Event_Cell
                var itemView = LayoutInflater.From(parent.Context)
                    .Inflate(Resource.Layout.Style_Event_Cell, parent, false);
                var vh = new MyEventAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {


                if (viewHolder is MyEventAdapterViewHolder holder)
                {
                    var item = MyEventList[position];
                    if (item != null) Initialize(holder, item);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        public void Initialize(MyEventAdapterViewHolder holder, EventDataObject item)
        {
            try
            {
                GlideImageLoader.LoadImage(ActivityContext, item.Cover, holder.Image, ImageStyle.RoundedCrop, ImagePlaceholders.Color);

                holder.TxtEventTitle.Text = Methods.FunString.DecodeString(item.Name);
                holder.TxtEventDescription.Text = Methods.FunString.DecodeString(item.Description);
                holder.TxtEventTime.Text = item.StartDate;
                holder.TxtEventLocation.Text = item.Location;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public EventDataObject GetItem(int position)
        {
            return MyEventList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(MyEventList[position].Id);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(MyEventAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(MyEventAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }

        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = MyEventList[p0];
                if (item == null)
                   return Collections.SingletonList(p0);

                if (!string.IsNullOrEmpty(item.Cover))
                    d.Add(item.Cover);
                return d;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Collections.SingletonList(p0);
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Java.Lang.Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.RoundedCrop);
        } 
    }

    public class MyEventAdapterViewHolder : RecyclerView.ViewHolder
    {
        public MyEventAdapterViewHolder(View itemView, Action<MyEventAdapterClickEventArgs> clickListener,Action<MyEventAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;
                Image = MainView.FindViewById<ImageView>(Resource.Id.Image);
                TxtEventTitle = MainView.FindViewById<TextView>(Resource.Id.event_titile);
                TxtEventDescription = MainView.FindViewById<TextView>(Resource.Id.event_description);
                TxtEventTime = MainView.FindViewById<TextView>(Resource.Id.event_time);
                TxtEventLocation = MainView.FindViewById<TextView>(Resource.Id.event_location);
                GoingButton = MainView.FindViewById<ImageView>(Resource.Id.ImageStar);

                //Event
                itemView.Click += (sender, e) => clickListener(new MyEventAdapterClickEventArgs{ View = itemView, Position = AdapterPosition });
                itemView.LongClick += (sender, e) => longClickListener(new MyEventAdapterClickEventArgs{ View = itemView, Position = AdapterPosition });

                GoingButton.Visibility = ViewStates.Invisible;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic
         
        public View MainView { get; }
        public ImageView Image { get; private set; }
        public ImageView GoingButton { get; private set; }
        public TextView TxtEventTitle { get; private set; }
        public TextView TxtEventTime { get; private set; }
        public TextView TxtEventDescription { get; private set; }
        public TextView TxtEventLocation { get; private set; }

        #endregion
    }

    public class MyEventAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}