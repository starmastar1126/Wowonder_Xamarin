﻿using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.App;
using Bumptech.Glide;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using Java.Util;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Product;
using IList = System.Collections.IList;
using Object = Java.Lang.Object;

namespace WoWonder.Activities.Market.Adapters
{
    public class MarketAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<MarketAdapterClickEventArgs> ItemClick;
        public event EventHandler<MarketAdapterClickEventArgs> ItemLongClick;

        private readonly Activity ActivityContext;
        public ObservableCollection<ProductDataObject> MarketList =new ObservableCollection<ProductDataObject>();

        public MarketAdapter(Activity context)
        {
            try
            {
                HasStableIds = true;
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (MarketList != null)
                    return MarketList.Count;
                return 0;
            }
        }
         
        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Event_Cell
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Market_view, parent, false);
                var vh = new MarketAdapterViewHolder(itemView, Click, LongClick);
               
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }
         
        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder is MarketAdapterViewHolder holder)
                {
                    var item = MarketList[position];
                    if (item != null) Initialize(holder, item);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Initialize(MarketAdapterViewHolder holder, ProductDataObject item)
        {
            try
            {
                if (item.Images?.Count > 0)
                    GlideImageLoader.LoadImage(ActivityContext, item.Images?[0]?.Image, holder.Thumbnail,ImageStyle.CenterCrop, ImagePlaceholders.Color);

                GlideImageLoader.LoadImage(ActivityContext, item.Seller?.Avatar, holder.Userprofilepic,ImageStyle.CircleCrop, ImagePlaceholders.Color);
                 
                if (holder.MappinIcon.Text != IonIconsFonts.IosLocation)
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.MappinIcon,IonIconsFonts.IosLocation);
                 
                holder.Title.Text = Methods.FunString.DecodeString(item.Name);

                holder.UserName.Text = WoWonderTools.GetNameFinal(item.Seller);
                holder.Time.Text = item.TimeText;

                var (currency, currencyIcon) = WoWonderTools.GetCurrency(item.Currency);

                holder.TxtPrice.Text = currencyIcon + " " + item.Price;
                holder.LocationText.Text = !string.IsNullOrEmpty(item.Location) ? item.Location : ActivityContext.GetText(Resource.String.Lbl_Unknown);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public ProductDataObject GetItem(int position)
        {
            return MarketList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(MarketList[position].Id);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }
         
        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(MarketAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(MarketAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }

        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = MarketList[p0];
                if (item == null)
                    return Collections.SingletonList(p0);

                if (item.Images?.Count > 0)
                { 
                    d.Add(item.Images[0].Image);
                    d.Add(item.Seller.Avatar);
                    return d;
                }
                 
                d.Add(item.Seller.Avatar);
                
                return d;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
               return Collections.SingletonList(p0);
            }
        }


        public RequestBuilder GetPreloadRequestBuilder(Object p0)
        {
            
            return Glide.With(ActivityContext).Load(p0.ToString())
                .Apply(new RequestOptions().CenterCrop().SetDiskCacheStrategy(DiskCacheStrategy.All));
        }
    }

    public class MarketAdapterViewHolder : RecyclerView.ViewHolder
    {
        public MarketAdapterViewHolder(View itemView, Action<MarketAdapterClickEventArgs> clickListener,Action<MarketAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                Thumbnail = MainView.FindViewById<ImageView>(Resource.Id.thumbnail);
                Title = MainView.FindViewById<TextView>(Resource.Id.titleTextView);
                MappinIcon = MainView.FindViewById<TextView>(Resource.Id.mappin);
                LocationText = MainView.FindViewById<TextView>(Resource.Id.LocationText);
                Userprofilepic = MainView.FindViewById<ImageView>(Resource.Id.userprofile_pic);
                UserName = MainView.FindViewById<TextView>(Resource.Id.User_name);
                Time = MainView.FindViewById<TextView>(Resource.Id.card_dist);
                TxtPrice = MainView.FindViewById<TextView>(Resource.Id.pricetext);

                //Event
                itemView.Click += (sender, e) => clickListener(new MarketAdapterClickEventArgs{View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new MarketAdapterClickEventArgs{View = itemView, Position = AdapterPosition});

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic

        public View MainView { get; }

        public ImageView Thumbnail { get; private set; }
        public TextView Title { get; private set; }
        public TextView MappinIcon { get; private set; }
        public ImageView Userprofilepic { get; private set; }
        public TextView UserName { get; private set; }
        public TextView Time { get; private set; }
        public TextView LocationText { get; private set; }
        public TextView TxtPrice { get; private set; }

        #endregion
    }

    public class MarketAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    } 
}