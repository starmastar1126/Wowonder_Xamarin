﻿using System;
using System.Collections.Generic;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Com.Devs.ReadMoreOptionLib;
using Java.Lang;
using Me.Relex;
using Newtonsoft.Json;
using Plugin.Share;
using Plugin.Share.Abstractions;
using WoWonder.Activities.Market.Adapters;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Product;
using Exception = System.Exception;

namespace WoWonder.Activities.Market
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class ProductViewActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private TextView TxtProductPrice, TxtProductBoleanNew, TxtProductBoleanInStock, TxtProductDescription, TxtProductLocation, TxtProductCardName, TxtProductTime;
        private ImageView ImageMore, UserImageAvatar, IconBack;
        private Button BtnContact;
        private ProductDataObject ProductData;
        private ViewPager ViewPagerView;
        private CircleIndicator CircleIndicatorView;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.ProductView_Layout);

                //Get Value And Set Toolbar
                InitComponent();

                Get_Data_Product();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                ViewPagerView = FindViewById<ViewPager>(Resource.Id.pager);
                CircleIndicatorView = FindViewById<CircleIndicator>(Resource.Id.indicator);
                 
                TxtProductPrice = (TextView)FindViewById(Resource.Id.tv_price);
                TxtProductBoleanNew = (TextView)FindViewById(Resource.Id.BoleanNew);
                TxtProductBoleanInStock = (TextView)FindViewById(Resource.Id.BoleanInStock);
                TxtProductDescription = (TextView)FindViewById(Resource.Id.tv_description);
                TxtProductLocation = (TextView)FindViewById(Resource.Id.tv_Location);
                TxtProductCardName = (TextView)FindViewById(Resource.Id.card_name);
                TxtProductTime = (TextView)FindViewById(Resource.Id.card_dist);

                BtnContact = (Button)FindViewById(Resource.Id.cont);

                UserImageAvatar = (ImageView)FindViewById(Resource.Id.card_pro_pic);
                ImageMore = (ImageView)FindViewById(Resource.Id.Image_more);
                IconBack = (ImageView)FindViewById(Resource.Id.iv_back);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
 
 
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    BtnContact.Click += BtnContactOnClick;
                    ImageMore.Click += ImageMoreOnClick;
                    IconBack.Click += IconBackOnClick;
                }
                else
                {
                    BtnContact.Click -= BtnContactOnClick;
                    ImageMore.Click -= ImageMoreOnClick;
                    IconBack.Click -= IconBackOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Events

        // Event Open User Profile
        private void BtnContactOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                WoWonderTools.OpenProfile(this, ProductData.Seller.UserId, ProductData.Seller); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        //Event Back
        private void IconBackOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                Finish();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event More >> Show Menu (CopeLink , Share)
        private void ImageMoreOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetString(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(GetString(Resource.String.Lbl_Share));
                 
                dialogList.Title(GetString(Resource.String.Lbl_More));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Copy Link
        private void OnCopyLink_Button_Click()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", ProductData.Url);
                clipboardManager.PrimaryClip = clipData;

                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Share
        private async void OnShare_Button_Click()
        {
            try
            {
                //Share Plugin same as video
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = Methods.FunString.DecodeString(ProductData.Name),
                    Text = Methods.FunString.DecodeString(ProductData.Description),
                    Url = ProductData.Url
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == GetString(Resource.String.Lbl_CopeLink))
                {
                    OnCopyLink_Button_Click();
                }
                else if (text == GetString(Resource.String.Lbl_Share))
                {
                    OnShare_Button_Click();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void Get_Data_Product()
        {
            try
            {
                ProductData = JsonConvert.DeserializeObject<ProductDataObject>(Intent.GetStringExtra("ProductView"));
                if (ProductData != null)
                { 
                    List<string> listImageUser = new List<string>();
                    if (ProductData.Images?.Count > 0)
                        foreach (var t in ProductData.Images)
                            listImageUser.Add(t.Image);
                    else
                        listImageUser.Add(ProductData.Images?[0]?.Image);

                    ViewPagerView.Adapter = new MultiImagePagerAdapter(this, listImageUser);
                    ViewPagerView.CurrentItem = 0;
                    CircleIndicatorView.SetViewPager(ViewPagerView);
                    ViewPagerView.Adapter.NotifyDataSetChanged();

                    GlideImageLoader.LoadImage(this, ProductData.Seller?.Avatar, UserImageAvatar, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                     
                    var (currency, currencyIcon) = WoWonderTools.GetCurrency(ProductData.Currency); 
                    TxtProductPrice.Text = ProductData.Price + " " + currencyIcon;

                    var readMoreOption = new ReadMoreOption.Builder(this)
                        .TextLength(200, ReadMoreOption.TypeCharacter)
                        .MoreLabel(GetText(Resource.String.Lbl_ReadMore))
                        .LessLabel(GetText(Resource.String.Lbl_ReadLess))
                        .MoreLabelColor(Color.ParseColor(AppSettings.MainColor))
                        .LessLabelColor(Color.ParseColor(AppSettings.MainColor))
                        .LabelUnderLine(true)
                        .Build();

                    if (Methods.FunString.StringNullRemover(ProductData.Description) != "Empty")
                    {
                        var description =Methods.FunString.DecodeString(ProductData.Description);
                        readMoreOption.AddReadMoreTo(TxtProductDescription, description);
                    }
                    else
                    {
                        TxtProductDescription.Text = GetText(Resource.String.Lbl_Empty);
                    }

                    TxtProductLocation.Text = ProductData.Location;
                    TxtProductCardName.Text = Methods.FunString.SubStringCutOf(WoWonderTools.GetNameFinal(ProductData.Seller), 14);
                    TxtProductTime.Text = ProductData.TimeText;

                    if (ProductData.Type == "0") // New
                        TxtProductBoleanNew.Visibility = ViewStates.Visible;
                    else // Used
                        TxtProductBoleanNew.Visibility = ViewStates.Gone;

                    if (ProductData.Status == "0") // Status InStock
                        TxtProductBoleanInStock.Visibility = ViewStates.Visible;
                    else
                        TxtProductBoleanInStock.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }
}