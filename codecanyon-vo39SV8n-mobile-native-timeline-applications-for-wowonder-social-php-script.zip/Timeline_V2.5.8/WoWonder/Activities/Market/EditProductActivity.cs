﻿using System;
using System.Collections.Generic;
using System.Linq;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Ads;
using Android.Gms.Location.Places.UI;
using Android.Graphics;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AndroidHUD;
using AT.Markushi.UI;
using Com.Theartofdev.Edmodo.Cropper;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Product;
using Exception = System.Exception;
using File = Java.IO.File;
using Toolbar = Android.Support.V7.Widget.Toolbar;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Market
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class EditProductActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private TextView TxtAdd;
        private ImageView ImageItem;
        private CircleButton ImageDelete;
        private Button BtnAddPhoto;
        private EditText TxtName, TxtPrice, TxtLocation, TxtAbout, TxtCategory;
        private RadioButton RbNew, RbUsed;
        private string CategoryId = "", ProductType = "", ProductPathImage = "", PlaceText = "";
        private AdView MAdView;
        private ProductDataObject ProductData;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.CreateProduct_Layout);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                InitAdView();

                Get_Data_Product();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
                MAdView?.Resume();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
                MAdView?.Pause();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                TxtAdd = FindViewById<TextView>(Resource.Id.toolbar_title);
                TxtAdd.Text = GetText(Resource.String.Lbl_Save);

                ImageItem = FindViewById<ImageView>(Resource.Id.Image);
                ImageDelete = FindViewById<CircleButton>(Resource.Id.ImageCircle);
                BtnAddPhoto = FindViewById<Button>(Resource.Id.btn_AddPhoto);
                TxtName = FindViewById<EditText>(Resource.Id.nameet);
                TxtPrice = FindViewById<EditText>(Resource.Id.priceet);
                TxtLocation = FindViewById<EditText>(Resource.Id.Locationet);
                TxtAbout = FindViewById<EditText>(Resource.Id.aboutet);

                TxtCategory = FindViewById<EditText>(Resource.Id.categorieset);

                RbNew = FindViewById<RadioButton>(Resource.Id.rad_New);
                RbUsed = FindViewById<RadioButton>(Resource.Id.rad_Used);

                TxtCategory.SetFocusable(ViewFocusability.NotFocusable);
                TxtCategory.Focusable = true;
                TxtCategory.FocusableInTouchMode = true;
                TxtCategory.ClearFocus();

                GlideImageLoader.LoadImage(this, "Grey_Offline", ImageItem, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = GetText(Resource.String.Lbl_CreateNewProduct);
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitAdView()
        {
            try
            {
                MAdView = FindViewById<AdView>(Resource.Id.adView);
                if (AppSettings.ShowAdmobBanner)
                {
                    MAdView.Visibility = ViewStates.Visible;
                    var adRequest = new AdRequest.Builder();
                    adRequest.AddTestDevice(UserDetails.AndroidId);
                    MAdView.LoadAd(adRequest.Build());
                }
                else
                {
                    MAdView.Pause();
                    MAdView.Visibility = ViewStates.Invisible;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    ImageDelete.Click += ImageDeleteOnClick;
                    BtnAddPhoto.Click += BtnAddPhotoOnClick;
                    RbNew.CheckedChange += RbNewOnCheckedChange;
                    RbUsed.CheckedChange += RbUsedOnCheckedChange;
                    TxtAdd.Click += TxtAddOnClick;
                    TxtLocation.FocusChange += TxtLocationOnFocusChange;
                    TxtCategory.Touch += TxtCategoryOnClick;
                }
                else
                {
                    ImageDelete.Click -= ImageDeleteOnClick;
                    BtnAddPhoto.Click -= BtnAddPhotoOnClick;
                    RbNew.CheckedChange -= RbNewOnCheckedChange;
                    RbUsed.CheckedChange -= RbUsedOnCheckedChange;
                    TxtAdd.Click -= TxtAddOnClick;
                    TxtLocation.FocusChange -= TxtLocationOnFocusChange;
                    TxtCategory.Touch -= TxtCategoryOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        private void TxtCategoryOnClick(object sender, View.TouchEventArgs e)
        {
            try
            {
                if (e.Event.Action == MotionEventActions.Down)
                {
                    if (CategoriesController.ListCategoriesProducts.Count > 0)
                    {
                        var arrayAdapter = new List<string>();
                        var dialogList = new MaterialDialog.Builder(this);

                        foreach (var item in CategoriesController.ListCategoriesProducts)
                            arrayAdapter.Add(item.CategoriesName);

                        dialogList.Title(GetText(Resource.String.Lbl_SelectCategories));
                        dialogList.Items(arrayAdapter);
                        dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                        dialogList.AlwaysCallSingleChoiceCallback();
                        dialogList.ItemsCallback(this).Build().Show();
                    }
                    else
                    {
                        Methods.DisplayReportResult(this, "Not have List Categories Products");
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void TxtLocationOnFocusChange(object sender, View.FocusChangeEventArgs e)
        {
            try
            {
                if (e.HasFocus)
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        //Open intent Location when the request code of result is 502
                        new IntentController(this).OpenIntentLocation();
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.AccessFineLocation) == Permission.Granted && CheckSelfPermission(Manifest.Permission.AccessCoarseLocation) == Permission.Granted)
                        {
                            //Open intent Location when the request code of result is 502
                            new IntentController(this).OpenIntentLocation();
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(105);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private async void TxtAddOnClick(object sender, EventArgs e)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    if (string.IsNullOrEmpty(TxtName.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_enter_name), ToastLength.Short).Show();
                        return;
                    }

                    if (string.IsNullOrEmpty(TxtPrice.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_enter_price), ToastLength.Short).Show();
                        return;
                    }

                    if (string.IsNullOrEmpty(TxtLocation.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_select_Location), ToastLength.Short).Show();
                        return;
                    }

                    if (string.IsNullOrEmpty(TxtAbout.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_enter_about), ToastLength.Short).Show();
                        return;
                    }

                    if (string.IsNullOrEmpty(ProductPathImage))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_select_Image), ToastLength.Short).Show();
                    }
                    else
                    {
                        //Show a progress
                        AndHUD.Shared.Show(this, GetText(Resource.String.Lbl_Loading) + "...");

                        var (currency, currencyIcon) = WoWonderTools.GetCurrency(ProductData.Currency);

                        var price = TxtPrice.Text.Replace(currencyIcon, "").Replace(" ", "");
                        var (apiStatus, respond) = await WoWonderClient.Requests.RequestsAsync.Market.Edit_Product(ProductData.Id,TxtName.Text, TxtAbout.Text, TxtLocation.Text, price, CategoryId, ProductType, ProductPathImage);
                        if (apiStatus == 200)
                        {
                            if (respond is MessageObject result)
                            {
                                // Add new item to my Product list                                
                                var image = new Images
                                {
                                    Id = "",
                                    ProductId = ProductData.Id,
                                    Image = ProductPathImage,
                                    ImageOrg = ProductPathImage
                                };
                                var list = new List<Images> { image };

                                //Add new item to my Event list
                                var user = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                                 
                                if (TabbedMarketActivity.MyProductsTab.MAdapter.MarketList != null)
                                {
                                    var data = TabbedMarketActivity.MyProductsTab.MAdapter.MarketList?.FirstOrDefault(a => a.Id == ProductData.Id);
                                    if (data != null)
                                    {
                                        data.Id = ProductData.Id;
                                        data.Name = TxtName.Text;
                                        data.UserId = UserDetails.UserId;
                                        data.Location = TxtLocation.Text;
                                        data.Description = TxtAbout.Text;
                                        data.Category = CategoryId;
                                        if (data.Images != null)
                                            data.Images.Add(image);
                                        else
                                            data.Images = new List<Images>(list);
                                        data.Price = TxtPrice.Text;
                                        data.Type = ProductType;
                                        data.Seller = user;
                                         
                                        TabbedMarketActivity.MyProductsTab.MAdapter?.NotifyItemChanged(TabbedMarketActivity.MyProductsTab.MAdapter.MarketList.IndexOf(data));
                                    }
                                }

                                AndHUD.Shared.ShowSuccess(this);
                                Toast.MakeText(this, GetString(Resource.String.Lbl_ProductSuccessfullyEdited), ToastLength.Short).Show();

                                Finish(); 
                            }
                        }
                        else Methods.DisplayReportResult(this, respond);

                        AndHUD.Shared.Dismiss(this);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                AndHUD.Shared.Dismiss(this);
            }
        }

        private void RbUsedOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                var isChecked = RbUsed.Checked;
                if (isChecked)
                {
                    RbNew.Checked = false;
                    ProductType = "1";
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void RbNewOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                var isChecked = RbNew.Checked;
                if (isChecked)
                {
                    RbUsed.Checked = false;
                    ProductType = "0";
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnAddPhotoOnClick(object sender, EventArgs e)
        {
            try
            {
                OpenDialogGallery();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ImageDeleteOnClick(object sender, EventArgs e)
        {
            try
            {
                GlideImageLoader.LoadImage(this, "Grey_Offline", ImageItem, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

                if (requestCode == 502 && resultCode == Result.Ok)
                {
                    GetPlaceFromPicker(data);
                }
                else if (requestCode == CropImage.CropImageActivityRequestCode)
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                ProductPathImage = resultUri.Path;
                                GlideImageLoader.LoadImage(this, resultUri.Path, ImageItem, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                        }
                    } 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        OpenDialogGallery();
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 105)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        //Open intent Location when the request code of result is 502
                        new IntentController(this).OpenIntentLocation();
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                CategoryId = CategoriesController.ListCategoriesProducts.FirstOrDefault(categories => categories.CategoriesName == itemString.ToString())?.CategoriesId;
                TxtCategory.Text = itemString.ToString();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void GetPlaceFromPicker(Intent data)
        {
            try
            {
                var placePicked = PlacePicker.GetPlace(this, data);

                if (!string.IsNullOrEmpty(PlaceText))
                    PlaceText = string.Empty;

                PlaceText = placePicked?.AddressFormatted?.ToString();
                TxtLocation.Text = PlaceText;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void OpenDialogGallery()
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            } 
        }

        private void Get_Data_Product()
        {
            try
            {
                ProductData = JsonConvert.DeserializeObject<ProductDataObject>(Intent.GetStringExtra("ProductView"));
                if (ProductData != null)
                { 
                    ProductPathImage = ProductData.Images?[0]?.Image ?? ""; 
                    GlideImageLoader.LoadImage(this, ProductPathImage, ImageItem, ImageStyle.RoundedCrop, ImagePlaceholders.Drawable);

                    TxtName.Text = ProductData.Name;

                    var (currency, currencyIcon) = WoWonderTools.GetCurrency(ProductData.Currency); 
                    TxtPrice.Text = ProductData.Price + " " + currencyIcon;

                    TxtLocation.Text = ProductData.Location;
                    TxtAbout.Text = ProductData.Description;

                    CategoryId = ProductData.Category; 
                    TxtCategory.Text = CategoriesController.ListCategoriesProducts.FirstOrDefault(a => a.CategoriesId == ProductData.Category)?.CategoriesName; 
                     
                    if (ProductData.Type == "0") // New
                    {
                        RbNew.Checked = true;
                        RbUsed.Checked = false;
                        ProductType = "0";
                    }
                    else // Used
                    {
                        RbNew.Checked = false;
                        RbUsed.Checked = true;
                        ProductType = "1";
                    } 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

    }
}