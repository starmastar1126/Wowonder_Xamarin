﻿using System;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;

namespace WoWonder.Activities.Market
{
    public class FilterMarketDialogFragment : BottomSheetDialogFragment, SeekBar.IOnSeekBarChangeListener
    {
        #region Variables Basic

        private TabbedMarketActivity ContextMarket;
        private TextView IconBack, IconDistance, TxtDistanceCount;
        private SeekBar DistanceBar;
        private Button BtnApply;
        private int DistanceCount;

        #endregion
         
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.BottomSheetMarketFilter, container, false);

                ContextMarket = (TabbedMarketActivity)Activity;

                InitComponent(view);
                  
                return view;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }
         
        private void InitComponent(View view)
        {
            try
            {
                IconBack = view.FindViewById<TextView>(Resource.Id.IconBack);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconBack, IonIconsFonts.ChevronLeft);
                IconBack.Click += IconBackOnClick;

                IconDistance = view.FindViewById<TextView>(Resource.Id.IconDistance);
                TxtDistanceCount = view.FindViewById<TextView>(Resource.Id.Distancenumber);

                FontUtils.SetFont(IconDistance, Fonts.SfRegular);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, IconDistance,FontAwesomeIcon.StreetView);
                    
                DistanceBar = view.FindViewById<SeekBar>(Resource.Id.distanceSeeker);
                DistanceBar.Max = 300; 
                DistanceBar.SetOnSeekBarChangeListener(this);

                BtnApply = view.FindViewById<Button>(Resource.Id.ApplyButton);
                BtnApply.Click += BtnApplyOnClick; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Event

        private void IconBackOnClick(object sender, EventArgs e)
        {
            try
            {
                Dismiss();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnApplyOnClick(object sender, EventArgs e)
        {
            try
            {
                UserDetails.MarketDistanceCount = DistanceCount.ToString();

                ContextMarket.MarketTab.MAdapter.MarketList.Clear();
                ContextMarket.MarketTab.MAdapter.NotifyDataSetChanged();

                ContextMarket.GetMarket().ConfigureAwait(false);
                Dismiss();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        #endregion

        #region SeekBar

        public void OnProgressChanged(SeekBar seekBar, int progress, bool fromUser)
        {
            try
            {
                TxtDistanceCount.Text = progress + " " + GetText(Resource.String.Lbl_km);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnStartTrackingTouch(SeekBar seekBar)
        {

        }

        public void OnStopTrackingTouch(SeekBar seekBar)
        {
            try
            {
                DistanceCount = seekBar.Progress;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

    }
}