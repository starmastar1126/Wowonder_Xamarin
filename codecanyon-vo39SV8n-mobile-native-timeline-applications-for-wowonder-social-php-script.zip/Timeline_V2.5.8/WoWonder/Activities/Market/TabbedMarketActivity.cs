﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using WoWonder.Activities.Market.Fragment;
using WoWonder.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Product;
using WoWonderClient.Requests;
using SearchView = Android.Support.V7.Widget.SearchView;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.Market
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class TabbedMarketActivity : AppCompatActivity
    { 
        #region Variables Basic

        private ViewPager ViewPager;
        public MarketFragment MarketTab;
        public static MyProductsFragment MyProductsTab;
        private TabLayout TabLayout;
        private FloatingActionButton FloatingActionButtonView;
        private RecyclerView CatRecyclerView;
        private CategoriesAdapter CategoriesAdapter;
        private SearchView SearchBox;
        private TextView FilterButton;
        private string KeySearch = "";
        
        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.MarketMain_Layout);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                LoadDataApi();
                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                if (MarketTab.MAdapter.MarketList.Count > 0)
                    ListUtils.ListCachedDataProduct = MarketTab.MAdapter.MarketList;

                if (MyProductsTab.MAdapter.MarketList.Count > 0)
                    ListUtils.ListCachedDataMyProduct = MyProductsTab.MAdapter.MarketList;

                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }
         
        private async void SearchViewOnQueryTextSubmit(object sender, SearchView.QueryTextSubmitEventArgs e)
        {
            try
            {
                KeySearch = e.NewText;

                MarketTab.MAdapter.MarketList.Clear();
                MarketTab.MAdapter.NotifyDataSetChanged();

                MarketTab.SwipeRefreshLayout.Refreshing = true;
                MarketTab.SwipeRefreshLayout.Enabled = true;

                await GetMarketByKey(KeySearch);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void SearchViewOnQueryTextChange(object sender, SearchView.QueryTextChangeEventArgs e)
        {
            try
            {
                KeySearch = e.NewText;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                ViewPager = FindViewById<ViewPager>(Resource.Id.viewpager);
                TabLayout = FindViewById<TabLayout>(Resource.Id.tabs);
                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);

                ViewPager.OffscreenPageLimit = 2;
                SetUpViewPager(ViewPager);
                TabLayout.SetupWithViewPager(ViewPager);

                CatRecyclerView = FindViewById<RecyclerView>(Resource.Id.catRecyler);

                FilterButton = (TextView)FindViewById(Resource.Id.filter_icon);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, FilterButton, IonIconsFonts.AndroidOptions);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = " ";
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }

                SearchBox = FindViewById<SearchView>(Resource.Id.searchBox);
                SearchBox.SetQuery("", false);
                SearchBox.SetIconifiedByDefault(false);
                SearchBox.OnActionViewExpanded();
                SearchBox.Iconified = false;
                SearchBox.QueryTextChange += SearchViewOnQueryTextChange;
                SearchBox.QueryTextSubmit += SearchViewOnQueryTextSubmit;
                SearchBox.ClearFocus();

                //Change text colors
                var editText = (EditText)SearchBox.FindViewById(Resource.Id.search_src_text);
                editText.SetHintTextColor(Color.White);
                editText.SetTextColor(Color.White);

                //Remove Icon Search
                ImageView searchViewIcon = (ImageView)SearchBox.FindViewById(Resource.Id.search_mag_icon);
                ViewGroup linearLayoutSearchView = (ViewGroup)searchViewIcon.Parent;
                linearLayoutSearchView.RemoveView(searchViewIcon);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                if (CategoriesController.ListCategoriesProducts.Count > 0)
                {
                    var check = CategoriesController.ListCategoriesProducts.Where(a => a.CategoriesColor == AppSettings.MainColor).ToList();
                    if (check.Count > 0)
                        foreach (var all in check)
                            all.CategoriesColor = "#ffffff";
                     
                    CatRecyclerView.HasFixedSize = true;
                    CatRecyclerView.SetLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.Horizontal, false));
                    CategoriesAdapter = new CategoriesAdapter(this)
                    {
                        MCategoriesList = CategoriesController.ListCategoriesProducts,
                    };
                    CatRecyclerView.SetAdapter(CategoriesAdapter);
                    CatRecyclerView.NestedScrollingEnabled = false;
                    CategoriesAdapter.NotifyDataSetChanged();
                    CatRecyclerView.Visibility = ViewStates.Visible;
                    CategoriesAdapter.ItemClick += CategoriesAdapterOnItemClick;
                }
                else
                {
                    CatRecyclerView.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    FloatingActionButtonView.Click += CreateProductOnClick;
                    FilterButton.Click += FilterButtonOnClick;
                }
                else
                {
                    FloatingActionButtonView.Click -= CreateProductOnClick;
                    FilterButton.Click -= FilterButtonOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        private void FilterButtonOnClick(object sender, EventArgs e)
        {
            try
            { 
                FilterMarketDialogFragment mFragment = new FilterMarketDialogFragment(); 
                mFragment.Show(SupportFragmentManager, mFragment.Tag);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void CreateProductOnClick(object sender, EventArgs e)
        {
            try
            {
                StartActivityForResult(new Intent(this, typeof(CreateProductActivity)), 200);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private async void CategoriesAdapterOnItemClick(object sender, CategoriesAdapterClickEventArgs e)
        {
            try
            {
                KeySearch = "";

                MarketTab.MAdapter.MarketList.Clear();
                MarketTab.MAdapter.NotifyDataSetChanged();
                 
                var item = CategoriesAdapter.GetItem(e.Position);
                if (item != null)
                {
                    var check = CategoriesAdapter.MCategoriesList.Where(a => a.CategoriesColor == AppSettings.MainColor).ToList();
                    if (check.Count > 0)
                        foreach (var all in check)
                            all.CategoriesColor = "#ffffff";

                    var click = CategoriesAdapter.MCategoriesList.FirstOrDefault(a => a.CategoriesId == item.CategoriesId);
                    if (click != null) click.CategoriesColor = AppSettings.MainColor;

                    CategoriesAdapter.NotifyDataSetChanged();

                    MarketTab.SwipeRefreshLayout.Refreshing = true;
                    MarketTab.SwipeRefreshLayout.Enabled = true;

                    await GetMarketByKey(KeySearch, item.CategoriesId);
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                if (requestCode == 200)
                {
                    if (resultCode == Result.Ok)
                    {
                        if (MarketTab != null)
                        {
                            var result = data.GetStringExtra("product");

                            var item = JsonConvert.DeserializeObject<ProductDataObject>(result);

                            MarketTab.MAdapter.MarketList.Insert(0, item);
                            MarketTab.MAdapter.NotifyItemInserted(0);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion
         
        #region Set Tab

        private void SetUpViewPager(ViewPager viewPager)
        {
            try
            {
                MyProductsTab = new MyProductsFragment();
                MarketTab = new MarketFragment();

                var adapter = new MainTabAdapter(SupportFragmentManager);
                adapter.AddFragment(MarketTab, GetText(Resource.String.Lbl_Market));
                adapter.AddFragment(MyProductsTab, GetText(Resource.String.Lbl_MyProducts));

                viewPager.CurrentItem = 2; 
                viewPager.Adapter = adapter;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion Set Tab

        #region Get Market Api 

        private void LoadDataApi()
        {
            try
            {
                string offsetMarket = "0", offsetMyProducts = "0";

                if (MarketTab.MAdapter != null && ListUtils.ListCachedDataProduct.Count > 0)
                {
                    MarketTab.MAdapter.MarketList = ListUtils.ListCachedDataProduct;
                    MarketTab.MAdapter.NotifyDataSetChanged();

                    var item = MarketTab.MAdapter.MarketList.LastOrDefault();
                    if (item != null && !string.IsNullOrEmpty(item.Id))
                        offsetMarket = item.Id;
                }

                if (MyProductsTab.MAdapter != null && ListUtils.ListCachedDataMyProduct.Count > 0)
                {
                    MyProductsTab.MAdapter.MarketList = ListUtils.ListCachedDataMyProduct;
                    MyProductsTab.MAdapter.NotifyDataSetChanged();

                    var item = MyProductsTab.MAdapter.MarketList.LastOrDefault();
                    if (item != null && !string.IsNullOrEmpty(item.Id))
                        offsetMyProducts = item.Id;
                }
                  
                StartApiService(offsetMarket, offsetMyProducts);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void StartApiService(string offsetMarket = "0" , string offsetMyProducts = "0")
        {
            if (Methods.CheckConnectivity())
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => GetMarket(offsetMarket), () => GetMyProducts(offsetMyProducts) });
            else
                Toast.MakeText(this, GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
        }

        public async Task GetMarket(string offset = "0")
        {
            if (Methods.CheckConnectivity())
            {
                int countList = MarketTab.MAdapter.MarketList.Count;
                (int apiStatus, var respond) = await RequestsAsync.Market.Get_Products("","20", offset,"","", UserDetails.MarketDistanceCount);
                if (apiStatus.Equals(200))
                {
                    if (respond is GetProductsObject result)
                    {
                        var respondList = result.Products.Count;
                        if (respondList > 0)
                        {
                            if (countList > 0)
                            {
                                foreach (var item in result.Products)
                                {
                                    var check = MarketTab.MAdapter.MarketList.FirstOrDefault(a => a.Id == item.Id);
                                    if (check == null)
                                    {
                                        MarketTab.MAdapter.MarketList.Add(item);
                                    }
                                }
                                RunOnUiThread(() => { MarketTab.MAdapter.NotifyItemRangeInserted(countList - 1, MarketTab.MAdapter.MarketList.Count - countList); });
                            }
                            else
                            {
                                MarketTab.MAdapter.MarketList = new ObservableCollection<ProductDataObject>(result.Products);
                                RunOnUiThread(() => { MarketTab.MAdapter.NotifyDataSetChanged(); }); 
                            }
                        }
                        else
                        {
                            if (MarketTab.MAdapter.MarketList.Count > 10 && !MarketTab.MRecycler.CanScrollVertically(1))
                                Toast.MakeText(this, GetText(Resource.String.Lbl_NoMoreProducts), ToastLength.Short).Show();
                        }
                    }
                }
                else Methods.DisplayReportResult(this, respond);

                MarketTab.MainScrollEvent.IsLoading = false;
                RunOnUiThread(() => { ShowEmptyPage("GetMarket");}); 
            }
            else
            {
                MarketTab.Inflated = MarketTab.EmptyStateLayout.Inflate();
                EmptyStateInflater x = new EmptyStateInflater();
                x.InflateLayout(MarketTab.Inflated, EmptyStateInflater.Type.NoConnection);
                if (!x.EmptyStateButton.HasOnClickListeners)
                {
                    x.EmptyStateButton.Click += null;
                    x.EmptyStateButton.Click += EmptyStateButtonOnClick;
                }

                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            }
        }

        public async Task GetMyProducts(string offset = "0")
        {
            int countList = MyProductsTab.MAdapter.MarketList.Count;
            (int apiStatus, var respond) = await RequestsAsync.Market.Get_Products(UserDetails.UserId,"20", offset);
            if (apiStatus.Equals(200))
            {
                if (respond is GetProductsObject result)
                {
                    var respondList = result.Products.Count;
                    if (respondList > 0)
                    {
                        if (countList > 0)
                        {
                            foreach (var item in result.Products)
                            {
                                var check = MyProductsTab.MAdapter.MarketList.FirstOrDefault(a => a.Id == item.Id);
                                if (check == null)
                                {
                                    MyProductsTab.MAdapter.MarketList.Add(item);
                                }
                            }

                            RunOnUiThread(() => { MyProductsTab.MAdapter.NotifyItemRangeInserted(countList - 1, MyProductsTab.MAdapter.MarketList.Count - countList); });
                        }
                        else
                        {
                            MyProductsTab.MAdapter.MarketList = new ObservableCollection<ProductDataObject>(result.Products);
                            RunOnUiThread(() => { MyProductsTab.MAdapter.NotifyDataSetChanged(); });
                        }
                    }
                    else
                    {
                        if (MyProductsTab.MAdapter.MarketList.Count > 10 && !MyProductsTab.MRecycler.CanScrollVertically(1))
                            Toast.MakeText(this, GetText(Resource.String.Lbl_NoMoreProducts), ToastLength.Short).Show();
                    }
                }
            }
            else Methods.DisplayReportResult(this, respond);

            MyProductsTab.MainScrollEvent.IsLoading = false;
            RunOnUiThread(() => { ShowEmptyPage("GetMyProducts"); }); 
        }

        private void ShowEmptyPage(string type)
        {
            try
            {
                MarketTab.SwipeRefreshLayout.Refreshing = false;
                MyProductsTab.SwipeRefreshLayout.Refreshing = false;

                if (type == "GetMarket")
                {
                    if (MarketTab.MAdapter.MarketList.Count > 0)
                    {
                        MarketTab.MRecycler.Visibility = ViewStates.Visible;
                        MarketTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        MarketTab.MRecycler.Visibility = ViewStates.Gone;

                        if (MarketTab.Inflated == null)
                            MarketTab.Inflated = MarketTab.EmptyStateLayout.Inflate();

                        EmptyStateInflater x = new EmptyStateInflater();
                        x.InflateLayout(MarketTab.Inflated, EmptyStateInflater.Type.NoProduct);
                        if (!x.EmptyStateButton.HasOnClickListeners)
                        {
                            x.EmptyStateButton.Click += null;
                            x.EmptyStateButton.Click += BtnCreateProductsOnClick;
                        }
                        MarketTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    }
                }
                else if (type == "GetMyProducts")
                {
                    if (MyProductsTab.MAdapter.MarketList.Count > 0)
                    {
                        MyProductsTab.MRecycler.Visibility = ViewStates.Visible;
                        MyProductsTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                    }
                    else
                    {
                        MyProductsTab.MRecycler.Visibility = ViewStates.Gone;

                        if (MyProductsTab.Inflated == null)
                            MyProductsTab.Inflated = MyProductsTab.EmptyStateLayout.Inflate();

                        EmptyStateInflater x = new EmptyStateInflater();
                        x.InflateLayout(MyProductsTab.Inflated, EmptyStateInflater.Type.NoProduct);
                        if (!x.EmptyStateButton.HasOnClickListeners)
                        {
                            x.EmptyStateButton.Click += null;
                            x.EmptyStateButton.Click += BtnCreateProductsOnClick;
                        }
                        MyProductsTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    }
                } 
            }
            catch (Exception e)
            {
                MarketTab.SwipeRefreshLayout.Refreshing = false;
                MyProductsTab.SwipeRefreshLayout.Refreshing = false;
                Console.WriteLine(e);
            }
        }

        //Event Add New Product  >> CreateProduct_Activity
        private void BtnCreateProductsOnClick(object sender, EventArgs e)
        {
            try
            {
                var intent = new Intent(this, typeof(CreateProductActivity));
                StartActivity(intent);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //No Internet Connection 
        private void EmptyStateButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                StartApiService();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private async Task GetMarketByKey(string key = "", string categoriesId = "")
        {
            if (Methods.CheckConnectivity())
            { 
                int countList = MarketTab.MAdapter.MarketList.Count;
                (int apiStatus, var respond) = await RequestsAsync.Market.Get_Products("", "20", "0", categoriesId, key, UserDetails.MarketDistanceCount);
                if (apiStatus.Equals(200))
                {
                    if (respond is GetProductsObject result)
                    {
                        var respondList = result.Products.Count;
                        if (respondList > 0)
                        {
                            if (countList > 0)
                            {
                                foreach (var item in result.Products)
                                {
                                    var check = MarketTab.MAdapter.MarketList.FirstOrDefault(a => a.Id == item.Id);
                                    if (check == null)
                                    {
                                        MarketTab.MAdapter.MarketList.Add(item);
                                    }
                                }
                                RunOnUiThread(() => { MarketTab.MAdapter.NotifyItemRangeInserted(countList - 1, MarketTab.MAdapter.MarketList.Count - countList); });
                                 
                            }
                            else
                            {
                                MarketTab.MAdapter.MarketList = new ObservableCollection<ProductDataObject>(result.Products);
                                RunOnUiThread(() => { MarketTab.MAdapter.NotifyDataSetChanged(); });
                            }
                        }
                        else
                        {
                            if (MarketTab.MAdapter.MarketList.Count > 10 && !MarketTab.MRecycler.CanScrollVertically(1))
                                Toast.MakeText(this, GetText(Resource.String.Lbl_NoMoreProducts), ToastLength.Short).Show();
                        }
                    }
                }
                else Methods.DisplayReportResult(this, respond);

                MarketTab.MainScrollEvent.IsLoading = false;
                RunOnUiThread(() => { ShowEmptyPage("GetMarket"); });
            }
            else
            {
                MarketTab.Inflated = MarketTab.EmptyStateLayout.Inflate();
                EmptyStateInflater x = new EmptyStateInflater();
                x.InflateLayout(MarketTab.Inflated, EmptyStateInflater.Type.NoConnection);
                if (!x.EmptyStateButton.HasOnClickListeners)
                {
                    x.EmptyStateButton.Click += null;
                    x.EmptyStateButton.Click += EmptyStateButtonOnClick;
                }

                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            }
        }

        #endregion
         
    }
}