﻿using System;
using System.Collections.Generic;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics;
using Android.Locations;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using Debug = System.Diagnostics.Debug;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.AddPost
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme",ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.Orientation)]
    public class LocationActivity : AppCompatActivity, IOnMapReadyCallback, ILocationListener, GoogleMap.IOnInfoWindowClickListener
    {

        #region Variables Basic

        private AutoCompleteTextView AutoCompleteSearchView;
        private double CurrentLatitude;
        private double CurrentLongitude; 
        private LocationManager LocationManager;
        private GoogleMap Map;
        private string Provider;
        private List<string> Result;

        #endregion
         
        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.LocationMap_Activity);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();

                if (CheckSelfPermission(Manifest.Permission.AccessFineLocation) != Permission.Granted && CheckSelfPermission(Manifest.Permission.AccessCoarseLocation) != Permission.Granted)
                {
                    var location = LocationManager.GetLastKnownLocation(LocationManager.PassiveProvider);
                    if (location != null)
                    {
                        CurrentLatitude = location.Latitude;
                        CurrentLongitude = location.Longitude;
                        OnLocationChanged(location);
                    }

                    LocationManager.RequestLocationUpdates(LocationManager.GpsProvider, 400, 1, this);
                    LocationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 400, 1, this);
                }
                else
                {
                    new PermissionsController(this).RequestPermission(105);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                Result = new List<string>();
                LocationManager = (LocationManager)GetSystemService(LocationService);
                AutoCompleteSearchView = FindViewById<AutoCompleteTextView>(Resource.Id.searchView);

                var mapFragment = (MapFragment)FragmentManager.FindFragmentById(Resource.Id.map);
                mapFragment.GetMapAsync(this);

                Provider = LocationManager.GetBestProvider(new Criteria(), false);

                var location = LocationManager.GetLastKnownLocation(Provider);
                if (location == null)
                    Debug.WriteLine("No Location");

                location = LocationManager.GetLastKnownLocation(LocationManager.NetworkProvider);
                if (location != null)
                    Toast.MakeText(this, GetText(Resource.String.Lbl_Finding_your_Location), ToastLength.Short).Show();

                AutoCompleteSearchView.Hint = GetText(Resource.String.Lbl_SearchForPlace);
                AutoCompleteSearchView.Adapter =new ArrayAdapter(this, Android.Resource.Layout.SimpleDropDownItem1Line, Result);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = " ";
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
          
        #endregion

        #region Permissions 
         
        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 105)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        var location = LocationManager.GetLastKnownLocation(LocationManager.PassiveProvider);
                        if (location != null)
                        {
                            CurrentLatitude = location.Latitude;
                            CurrentLongitude = location.Longitude;
                            OnLocationChanged(location);
                        }

                        LocationManager.RequestLocationUpdates(Provider, 400, 1, this);
                        LocationManager.RequestLocationUpdates(LocationManager.GpsProvider, 400, 1, this);
                        LocationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 400, 1, this);
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion

        public void OnMapReady(GoogleMap googleMap)
        {
            try
            {
                Map = googleMap;

                //Optional
                googleMap.UiSettings.ZoomControlsEnabled = true;
                googleMap.UiSettings.CompassEnabled = true;
                googleMap.MoveCamera(CameraUpdateFactory.ZoomIn());
                googleMap.MoveCamera(CameraUpdateFactory.ZoomIn());
                googleMap.MoveCamera(CameraUpdateFactory.ZoomIn());
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnLocationChanged(Location location)
        {
            try
            { 
                double lat = location.Latitude;
                double lng = location.Longitude;

                var makerOptions = new MarkerOptions();
                makerOptions.SetPosition(new LatLng(lat, lng));
                makerOptions.SetTitle(GetText(Resource.String.Lbl_Title_Location));
                makerOptions.SetSnippet(GetText(Resource.String.Lbl_Snippet_Location));
                Map.AddMarker(makerOptions);
                Map.SetOnInfoWindowClickListener(this); // Add event click on marker icon
                Map.MapType = GoogleMap.MapTypeNormal;

                var builder = CameraPosition.InvokeBuilder();
                builder.Target(new LatLng(lat, lng));
                var cameraPosition = builder.Zoom(17).Target(new LatLng(lat, lng)).Build();
                cameraPosition.Zoom = 18;

                var cameraUpdate = CameraUpdateFactory.NewCameraPosition(cameraPosition);
                Map.MoveCamera(cameraUpdate);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnProviderDisabled(string provider)
        {
            try
            {

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnProviderEnabled(string provider)
        {
            try
            {

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnStatusChanged(string provider, Availability status, Bundle extras)
        {
            try
            {

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnInfoWindowClick(Marker marker)
        {
            try
            {

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}