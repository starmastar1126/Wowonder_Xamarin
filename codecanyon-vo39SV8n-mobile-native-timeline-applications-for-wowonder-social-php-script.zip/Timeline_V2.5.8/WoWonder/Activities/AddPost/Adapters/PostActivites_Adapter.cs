﻿using System;
using System.Collections.ObjectModel;
using Android.App;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;

namespace WoWonder.Activities.AddPost.Adapters
{
    public class PostActivitesAdapter : RecyclerView.Adapter
    {
        
        public Activity ActivityContext;

        public ObservableCollection<Classes.PostType> PostActivitesTypeList =
            new ObservableCollection<Classes.PostType>();

        public PostActivitesAdapter(Activity context)
        {
            try
            {
                ActivityContext = context;

                if (AppSettings.ShowListening)
                    PostActivitesTypeList.Add(new Classes.PostType
                    {
                        Id = 1,
                        TypeText = ActivityContext.GetText(Resource.String.Lbl_ListeningTo),
                        Image = Resource.Drawable.ic_attach_listening,
                        ImageColor = ""
                    });
                if (AppSettings.ShowPlaying)
                    PostActivitesTypeList.Add(new Classes.PostType
                    {
                        Id = 2,
                        TypeText = ActivityContext.GetText(Resource.String.Lbl_Playing),
                        Image = Resource.Drawable.ic_attach_playing,
                        ImageColor = ""
                    });
                if (AppSettings.ShowWatching)
                    PostActivitesTypeList.Add(new Classes.PostType
                    {
                        Id = 3,
                        TypeText = ActivityContext.GetText(Resource.String.Lbl_Watching),
                        Image = Resource.Drawable.ic_attach_watching,
                        ImageColor = ""
                    });
                if (AppSettings.ShowTraveling)
                    PostActivitesTypeList.Add(new Classes.PostType
                    {
                        Id = 4,
                        TypeText = ActivityContext.GetText(Resource.String.Lbl_Traveling),
                        Image = Resource.Drawable.ic_attach_traveling,
                        ImageColor = ""
                    });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (PostActivitesTypeList != null)
                    return PostActivitesTypeList.Count;
                return 0;
            }
        }

        public event EventHandler<PostActivitesAdapterClickEventArgs> ItemClick;
        public event EventHandler<PostActivitesAdapterClickEventArgs> ItemLongClick;

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_AddPost_View
                var itemView = LayoutInflater.From(parent.Context)
                    .Inflate(Resource.Layout.Style_AddPost_View, parent, false);
                var vh = new PostActivitesAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
               
                if (viewHolder is PostActivitesAdapterViewHolder holder)
                {
                    var item = PostActivitesTypeList[position];
                    if (item != null)
                    {
                        FontUtils.SetFont(holder.PostTypeText, Fonts.SfRegular);
                        holder.PostTypeText.Text = item.TypeText;
                        holder.PostImageIcon.SetImageResource(item.Image);

                        if (!string.IsNullOrEmpty(item.ImageColor))
                            holder.PostImageIcon.SetColorFilter(Color.ParseColor(item.ImageColor));
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public Classes.PostType GetItem(int position)
        {
            return PostActivitesTypeList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return base.GetItemId(position);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return base.GetItemViewType(position);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(PostActivitesAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(PostActivitesAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
    }

    public class PostActivitesAdapterViewHolder : RecyclerView.ViewHolder
    {
        public PostActivitesAdapterViewHolder(View itemView, Action<PostActivitesAdapterClickEventArgs> clickListener,
            Action<PostActivitesAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                //Get values         
                PostTypeText = (TextView) MainView.FindViewById(Resource.Id.type_name);
                PostImageIcon = (ImageView) MainView.FindViewById(Resource.Id.Iconimage);

                //Create an Event
                itemView.Click += (sender, e) => clickListener(new PostActivitesAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new PostActivitesAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        public View MainView { get; }

        public TextView PostTypeText { get; }
        public ImageView PostImageIcon { get; }

        #endregion
    }

    public class PostActivitesAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}