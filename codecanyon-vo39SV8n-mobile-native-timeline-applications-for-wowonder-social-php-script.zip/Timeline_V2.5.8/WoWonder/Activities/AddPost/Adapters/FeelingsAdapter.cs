﻿using System;
using System.Collections.ObjectModel;
using Android.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;

namespace WoWonder.Activities.AddPost.Adapters
{
    public class Feeling
    {
        public int Id { get; set; }
        public string FeelingText { get; set; }
        public string FeelingImageUrl { get; set; }
        public bool Selected { get; set; } = false;
    }

    public class FeelingsAdapter : RecyclerView.Adapter
    {
        
        public Activity ActivityContext;
        public ObservableCollection<Feeling> FeelingsList = new ObservableCollection<Feeling>();

        public FeelingsAdapter(Activity context)
        {
            try
            {
                ActivityContext = context;

                FeelingsList.Add(new Feeling
                {
                    Id = 1, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Angry), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f621.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 2, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Funny), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f602.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 3, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Loved), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f60d.png"
                });
                FeelingsList.Add(new Feeling
                    {Id = 4, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Cool), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f60e.png"});
                FeelingsList.Add(new Feeling
                {
                    Id = 5, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Happy), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f603.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 6, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Tired), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f62b.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 7, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Sleepy), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f634.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 8, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Expressionless),FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f611.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 9, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Confused), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f615.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 10, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Shocked), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f631.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 11, FeelingText = ActivityContext.GetText(Resource.String.Lbl_VerySad),FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f62d.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 12, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Blessed), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f607.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 13, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Bored), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f610.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 14, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Broken), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f494.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 15, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Lovely), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/2665.png"
                });
                FeelingsList.Add(new Feeling
                {
                    Id = 16, FeelingText = ActivityContext.GetText(Resource.String.Lbl_Hot), FeelingImageUrl = "https://abs.twimg.com/emoji/v1/72x72/1f60f.png"
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public override int ItemCount
        {
            get
            {
                if (FeelingsList != null)
                    return FeelingsList.Count;
                return 0;
            }
        }

        public event EventHandler<FeelingsAdapterClickEventArgs> ItemClick;
        public event EventHandler<FeelingsAdapterClickEventArgs> ItemLongClick;

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Feeling_View
                var itemView = LayoutInflater.From(parent.Context)
                    .Inflate(Resource.Layout.Style_Feeling_View, parent, false);
                var vh = new FeelingsAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
               
                if (viewHolder is FeelingsAdapterViewHolder holder)
                {
                    var item = FeelingsList[position];
                    if (item != null)
                    {
                        FontUtils.SetFont(holder.FeelingName, Fonts.SfRegular);
                        holder.FeelingName.Text = item.FeelingText;

                        if (!string.IsNullOrEmpty(item.FeelingImageUrl))
                        {
                            GlideImageLoader.LoadImage(ActivityContext, item.FeelingImageUrl, holder.Image,ImageStyle.RoundedCrop ,ImagePlaceholders.Drawable); 
                        }
                            
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public Feeling GetItem(int position)
        {
            return FeelingsList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return base.GetItemId(position);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return base.GetItemViewType(position);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(FeelingsAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(FeelingsAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
    }

    public class FeelingsAdapterViewHolder : RecyclerView.ViewHolder
    {
        public FeelingsAdapterViewHolder(View itemView, Action<FeelingsAdapterClickEventArgs> clickListener,Action<FeelingsAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                //Get values         
                FeelingName = (TextView) MainView.FindViewById(Resource.Id.feelingName);
                Image = (ImageView) MainView.FindViewById(Resource.Id.Image);

                //Create an Event
                itemView.Click += (sender, e) => clickListener(new FeelingsAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        public View MainView { get; }
        

        public TextView FeelingName { get; }
        public ImageView Image { get; }

        #endregion
    }

    public class FeelingsAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}