﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using WoWonderClient.Classes.Posts;

namespace WoWonder.Activities.AddPost.Adapters
{ 
    public class AttachmentsAdapter : RecyclerView.Adapter
    { 
        public readonly Activity ActivityContext;
        public ObservableCollection<Attachments> AttachemntsList = new ObservableCollection<Attachments>();

        public AttachmentsAdapter(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (AttachemntsList != null)
                    return AttachemntsList.Count;
                return 0;
            }
        }

        public event EventHandler<AttachmentsAdapterClickEventArgs> ItemClick;
        public event EventHandler<AttachmentsAdapterClickEventArgs> ItemLongClick;

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Attachment_View
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Attachment_View, parent, false);
                var vh = new AttachmentsAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            { 
                if (viewHolder is AttachmentsAdapterViewHolder holder)
                {
                    var item = AttachemntsList[position];
                    if (item != null)
                    {
                        Glide.With(ActivityContext).Load(item.FileSimple).Apply(new RequestOptions().Placeholder(Resource.Drawable.ImagePlacholder)).Into(holder.Image);
                         
                        switch (item.TypeAttachment)
                        {
                            case "postVideo":
                                holder.AttachType.Visibility = ViewStates.Visible;
                                break;
                            case "postPhotos":
                            case "postMusic":
                            case "postFile":
                                holder.AttachType.Visibility = ViewStates.Gone;
                                break;
                            case "Default":
                                holder.ImageDelete.Visibility = ViewStates.Invisible;
                                break;
                        }
                         
                        holder.ImageDelete.Click += delegate { Remove(item); };
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        // Function 
        public void Add(Attachments item)
        {
            try
            {
                AttachemntsList.Add(item);
                NotifyItemInserted(AttachemntsList.IndexOf(AttachemntsList.Last()));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void Remove(Attachments item)
        {
            try
            {
                var index = AttachemntsList.IndexOf(AttachemntsList.FirstOrDefault(a => a.Id == item.Id));
                if (index != -1)
                {
                    AttachemntsList.Remove(item);
                    NotifyItemRemoved(index);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        public void RemoveAll()
        {
            try
            {
                AttachemntsList.Clear();
                NotifyDataSetChanged();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
        
        public Attachments GetItem(int position)
        {
            return AttachemntsList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return base.GetItemId(position);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return base.GetItemViewType(position);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(AttachmentsAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(AttachmentsAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
    }

    public class AttachmentsAdapterViewHolder : RecyclerView.ViewHolder
    {
        #region Variables Basic

        public View MainView { get; set; }
         
        public ImageView AttachType { get; private set; }
        public ImageView Image { get; private set; }
        public CircleButton ImageDelete { get; private set; }

        #endregion

        public AttachmentsAdapterViewHolder(View itemView, Action<AttachmentsAdapterClickEventArgs> clickListener,Action<AttachmentsAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                //Get values         
                AttachType = (ImageView) MainView.FindViewById(Resource.Id.AttachType);
                Image = (ImageView) MainView.FindViewById(Resource.Id.Image);

                ImageDelete = MainView.FindViewById<CircleButton>(Resource.Id.ImageCircle);
                 
                //Create an Event
                itemView.Click += (sender, e) => clickListener(new AttachmentsAdapterClickEventArgs{View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new AttachmentsAdapterClickEventArgs{View = itemView, Position = AdapterPosition});
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }

    public class AttachmentsAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}