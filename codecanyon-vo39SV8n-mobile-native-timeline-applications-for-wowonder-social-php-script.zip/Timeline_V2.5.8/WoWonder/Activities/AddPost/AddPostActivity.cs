﻿using System;
using System.Collections.Generic;
using System.Linq;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Location.Places.UI;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Provider;
using Android.Support.V4.Content;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Text;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using AndroidHUD;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using Com.Luseen.Autolinklibrary;
using Com.Sothree.Slidinguppanel;
using Com.Theartofdev.Edmodo.Cropper;
using Java.IO;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.AddPost.Adapters;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Event;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using Console = System.Console;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.AddPost
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class AddPostActivity : AppCompatActivity, SlidingPaneLayout.IPanelSlideListener, SlidingUpPanelLayout.IPanelSlideListener, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback, MaterialDialog.IInputCallback
    {
        #region Variables Basic

        private Toolbar TopToolBar;
        private SlidingUpPanelLayout SlidingUpPanel;
        private ImageView PostSectionImage;
        private TextView TxtAddPost, TxtUserName;
        private EditText TxtContentPost;
        private RecyclerView PostTypeRecyclerView, AttachmentRecyclerView, PollRecyclerView, ColorBoxRecyclerView;
        private MainPostAdapter MainPostAdapter;
        private AttachmentsAdapter AttachmentsAdapter;
        private ImageView IconHappy, IconTag, IconImage, ColoredImage;
        private AddPollAdapter AddPollAnswerAdapter;
        private ColorBoxAdapter ColorBoxAdapter;
        private NestedScrollView ScrollView;
        private View ImportPanel;
        private Button AddAnswerButton, PostPrivacyButton;
        private AutoLinkTextView MentionTextView;
        private string MentionText = "", PlaceText = "", FeelingText = "";
        private readonly string ActivityText = "";
        private string ListeningText = "", PlayingText = "", WatchingText = "", TravelingText = "", GifFile = "";
        private string PagePost = "", IdPost = "", PostPrivacy = "", IdColor = "";
        private string PostFeelingType = "", PostFeelingText = "";
        private readonly string PostActivityType = "";
        private string TypeDialog = "", PermissionsType = "";

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.AddPost_Layout);

                var postdate = Intent.GetStringExtra("Type") ?? "Data not available";
                if (postdate != "Data not available" && !string.IsNullOrEmpty(postdate)) PagePost = postdate;

                var id = Intent.GetStringExtra("PostId") ?? "Data not available";
                if (id != "Data not available" && !string.IsNullOrEmpty(id)) IdPost = id;

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                GetPrivacyPost();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                TxtAddPost = FindViewById<TextView>(Resource.Id.toolbar_title);
                TxtContentPost = FindViewById<EditText>(Resource.Id.editTxtEmail);
                SlidingUpPanel = FindViewById<SlidingUpPanelLayout>(Resource.Id.sliding_layout);
                PostSectionImage = FindViewById<ImageView>(Resource.Id.postsectionimage);
                PostTypeRecyclerView = FindViewById<RecyclerView>(Resource.Id.Recyler);
                AttachmentRecyclerView = FindViewById<RecyclerView>(Resource.Id.AttachementRecyler);
                TxtUserName = FindViewById<TextView>(Resource.Id.card_name);
                IconImage = FindViewById<ImageView>(Resource.Id.ImageIcon);
                IconHappy = FindViewById<ImageView>(Resource.Id.Activtyicon);
                IconTag = FindViewById<ImageView>(Resource.Id.TagIcon);
                ScrollView = FindViewById<NestedScrollView>(Resource.Id.scroll_View);
                ColorBoxRecyclerView = FindViewById<RecyclerView>(Resource.Id.ColorboxRecyler);
                ColoredImage = FindViewById<ImageView>(Resource.Id.ColorImage);

                IconTag.Tag = "Close";

                MentionTextView = FindViewById<AutoLinkTextView>(Resource.Id.MentionTextview);
                PostPrivacyButton = FindViewById<Button>(Resource.Id.cont);

                TxtContentPost.ClearFocus();
                SlidingUpPanel.SetPanelState(SlidingUpPanelLayout.PanelState.Collapsed);
                SlidingUpPanel.AddPanelSlideListener(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                TopToolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (TopToolBar != null)
                {
                    TopToolBar.Title = GetText(Resource.String.Lbl_AddPost);
                    TopToolBar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(TopToolBar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                PostTypeRecyclerView.SetLayoutManager(new LinearLayoutManager(this));
                MainPostAdapter = new MainPostAdapter(this);
                PostTypeRecyclerView.SetAdapter(MainPostAdapter);

                AttachmentsAdapter = new AttachmentsAdapter(this);
                AttachmentRecyclerView.SetLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.Horizontal, false));
                AttachmentRecyclerView.SetAdapter(AttachmentsAdapter);
                AttachmentRecyclerView.NestedScrollingEnabled = false;

                if (AppSettings.ShowColor)
                {
                    ColorBoxAdapter = new ColorBoxAdapter(this, ColorBoxRecyclerView);
                    ColorBoxRecyclerView.NestedScrollingEnabled = false;

                    ColorBoxRecyclerView.Visibility = ViewStates.Visible;
                }
                else
                {
                    ColorBoxRecyclerView.Visibility = ViewStates.Invisible;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    PostPrivacyButton.Click += PostPrivacyButton_Click;
                    MainPostAdapter.ItemClick += MainPostAdapterOnItemClick;
                    TxtAddPost.Click += TxtAddPostOnClick;
                    if (AppSettings.ShowColor)
                        ColorBoxAdapter.ItemClick += ColorBoxAdapter_ItemClick;
                }
                else
                {
                    PostPrivacyButton.Click -= PostPrivacyButton_Click;
                    MainPostAdapter.ItemClick -= MainPostAdapterOnItemClick;
                    TxtAddPost.Click -= TxtAddPostOnClick;
                    if (AppSettings.ShowColor)
                        ColorBoxAdapter.ItemClick -= ColorBoxAdapter_ItemClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        //Event Add post 
        private async void TxtAddPostOnClick(object sender, EventArgs e)
        {
            try
            { 
                if (string.IsNullOrEmpty(TxtContentPost.Text) && string.IsNullOrEmpty(MentionTextView.Text) && AttachmentsAdapter.AttachemntsList.Count == 0)
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_YouCannot_PostanEmptyPost), ToastLength.Long).Show();
                }
                else
                {
                    if (Methods.CheckConnectivity())
                    {
                        string content = !string.IsNullOrEmpty(MentionText) ? TxtContentPost.Text + " " + GetText(Resource.String.Lbl_With) + " " + MentionText.Remove(MentionText.Length - 1, 1) : TxtContentPost.Text;

                        if (ListUtils.SettingsSiteList?.MaxCharacters != null)
                        {
                            int max = int.Parse(ListUtils.SettingsSiteList.MaxCharacters);
                            if (max < content.Length)
                            {
                                //You have exceeded the text limit, must be less than ListUtils.SettingsSiteList.MaxCharacters
                                Toast.MakeText(this, GetString(Resource.String.Lbl_Error_MaxCharacters) + " " + ListUtils.SettingsSiteList.MaxCharacters, ToastLength.Short).Show();
                                return;
                            }
                        } 

                        //Show a progress
                        AndHUD.Shared.Show(this, GetText(Resource.String.Lbl_Loading));

                        var (apiStatus, respond) = await ApiRequest.AddNewPost_Async(IdPost, PagePost, content,
                            PostPrivacy, PostFeelingType, PostFeelingText, PlaceText,
                            AttachmentsAdapter.AttachemntsList, AddPollAnswerAdapter?.AnswersList, IdColor);
                        if (apiStatus == 200)
                        {
                            if (respond is AddPostObject postObject)
                            {
                                AndHUD.Shared.Dismiss(this);
                                Toast.MakeText(this, GetText(Resource.String.Lbl_Post_Added), ToastLength.Short)
                                    .Show();

                                RunOnUiThread(() =>
                                {
                                    // put the String to pass back into an Intent and close this activity
                                    var resultIntent = new Intent();
                                    resultIntent.PutExtra("itemObject",
                                        JsonConvert.SerializeObject(postObject.PostData));
                                    SetResult(Result.Ok, resultIntent);

                                    Finish();
                                });
                            }
                        }
                        else
                        {
                            Methods.DisplayReportResult(this, respond);
                            //Show a Error image with a message
                            AndHUD.Shared.ShowError(this, GetText(Resource.String.Lbl_Post_Failed), MaskType.Clear,
                                TimeSpan.FromSeconds(2));
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    }

                    AndHUD.Shared.Dismiss(this);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                AndHUD.Shared.Dismiss(this);
            }
        }

        private void MainPostAdapterOnItemClick(object sender, MainPostAdapterClickEventArgs e)
        {
            try
            {
                if (ImportPanel != null)
                    ImportPanel.Visibility = ViewStates.Gone;

                if (MainPostAdapter.PostTypeList[e.Position] != null)
                {
                    if (MainPostAdapter.PostTypeList[e.Position].Id == 1) //Image Gallery
                    {
                        PermissionsType = "Image";

                        // Check if we're running on Android 5.0 or higher 
                        if ((int)Build.VERSION.SdkInt < 23)
                        {
                            if (AppSettings.ImageCropping)
                                OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                            else
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                        }
                        else
                        {
                            if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                      && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            {
                                if (AppSettings.ImageCropping)
                                    OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                                else
                                    new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                            }
                            else
                            {
                                new PermissionsController(this).RequestPermission(108);
                            }
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 2) //video Gallery
                    {
                        PermissionsType = "Video";

                        // Check if we're running on Android 5.0 or higher
                        if ((int)Build.VERSION.SdkInt < 23)
                        {
                            //requestCode >> 501 => video Gallery
                            new IntentController(this).OpenIntentVideoGallery();
                        }
                        else
                        {
                            if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                      && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            {
                                //requestCode >> 501 => video Gallery
                                new IntentController(this).OpenIntentVideoGallery();
                            }
                            else
                            {
                                new PermissionsController(this).RequestPermission(108);
                            }
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 3) // Mention
                    {
                        StartActivityForResult(new Intent(this, typeof(MentionActivity)), 3);
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 4) // Location
                    {
                        // Check if we're running on Android 5.0 or higher
                        if ((int)Build.VERSION.SdkInt < 23)
                        {
                            //Open intent Location when the request code of result is 502
                            new IntentController(this).OpenIntentLocation();
                        }
                        else
                        {
                            if (CheckSelfPermission(Manifest.Permission.AccessFineLocation) == Permission.Granted && CheckSelfPermission(Manifest.Permission.AccessCoarseLocation) == Permission.Granted)
                            {
                                //Open intent Location when the request code of result is 502
                                new IntentController(this).OpenIntentLocation();
                            }
                            else
                            {
                                new PermissionsController(this).RequestPermission(105);
                            }
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 5) // Feeling
                    {
                        //StartActivityForResult(new Intent(this, typeof(Feelings_Activity)), 5);
                        try
                        {
                            TypeDialog = "Feelings";

                            var arrayAdapter = new List<string>();
                            var dialogList = new MaterialDialog.Builder(this);

                            if (AppSettings.ShowFeeling)
                                arrayAdapter.Add(GetText(Resource.String.Lbl_Feeling));
                            if (AppSettings.ShowListening)
                                arrayAdapter.Add(GetText(Resource.String.Lbl_Listening));
                            if (AppSettings.ShowPlaying)
                                arrayAdapter.Add(GetText(Resource.String.Lbl_Playing));
                            if (AppSettings.ShowWatching)
                                arrayAdapter.Add(GetText(Resource.String.Lbl_Watching));
                            if (AppSettings.ShowTraveling)
                                arrayAdapter.Add(GetText(Resource.String.Lbl_Traveling));

                            dialogList.Title(GetString(Resource.String.Lbl_What_Are_You_Doing));
                            dialogList.Items(arrayAdapter);
                            dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                            dialogList.AlwaysCallSingleChoiceCallback();
                            dialogList.ItemsCallback(this).Build().Show();
                        }
                        catch (Exception exception)
                        {
                            Console.WriteLine(exception);
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 6) // Camera
                    {
                        PermissionsType = "Camera";

                        // Check if we're running on Android 5.0 or higher
                        if ((int)Build.VERSION.SdkInt < 23)
                        {
                            //requestCode >> 503 => Camera
                            new IntentController(this).OpenIntentCamera();
                        }
                        else
                        {
                            if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            {
                                //requestCode >> 503 => Camera
                                new IntentController(this).OpenIntentCamera();
                            }
                            else
                            {
                                new PermissionsController(this).RequestPermission(108);
                            }
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 7) // Gif
                    {
                        StartActivityForResult(new Intent(this, typeof(GifActivity)), 7);
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 8) // File
                    {
                        PermissionsType = "File";

                        // Check if we're running on Android 5.0 or higher
                        if ((int)Build.VERSION.SdkInt < 23)
                        {
                            //requestCode >> 504 => File
                            new IntentController(this).OpenIntentFile(GetText(Resource.String.Lbl_SelectFile));
                        }
                        else
                        {
                            if (CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                                CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                            {
                                //requestCode >> 504 => File
                                new IntentController(this).OpenIntentFile(GetText(Resource.String.Lbl_SelectFile));
                            }
                            else
                            {
                                new PermissionsController(this).RequestPermission(108);
                            }
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 9) // Music
                    {
                        PermissionsType = "Music";

                        // Check if we're running on Android 5.0 or higher
                        if ((int)Build.VERSION.SdkInt < 23)
                            new IntentController(this).OpenIntentAudio(); //505
                        else
                        {
                            if (CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                                new IntentController(this).OpenIntentAudio(); //505
                            else
                                new PermissionsController(this).RequestPermission(100);
                        }
                    }
                    else if (MainPostAdapter.PostTypeList[e.Position].Id == 10) // Polls
                    {
                        TxtContentPost.ClearFocus();
                        SlidingUpPanel.SetPanelState(SlidingUpPanelLayout.PanelState.Collapsed);

                        if (ImportPanel == null)
                            ImportPanel = ((ViewStub)FindViewById(Resource.Id.stub_import)).Inflate();

                        if (PollRecyclerView == null)
                            PollRecyclerView = (RecyclerView)ImportPanel.FindViewById(Resource.Id.Recyler);

                        AttachmentsAdapter?.AttachemntsList.Clear();
                        ImportPanel.Visibility = ViewStates.Visible;
                        AddPollAnswerAdapter = new AddPollAdapter(this);
                        PollRecyclerView.SetLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.Vertical, false));
                        PollRecyclerView.SetAdapter(AddPollAnswerAdapter);
                        AddPollAnswerAdapter.AnswersList.Add(new PollAnswers { Answer = GetText(Resource.String.Lbl2_Polls) + " 1", Id = 1 });
                        AddPollAnswerAdapter.AnswersList.Add(new PollAnswers { Answer = GetText(Resource.String.Lbl2_Polls) + " 2", Id = 2 });
                        AddPollAnswerAdapter.NotifyDataSetChanged();

                        AddAnswerButton = (Button)ImportPanel.FindViewById(Resource.Id.addanswer);

                        if (!AddAnswerButton.HasOnClickListeners)
                            AddAnswerButton.Click += AddAnswerButtonOnClick;

                        PollRecyclerView.NestedScrollingEnabled = false;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ColorBoxAdapter_ItemClick(object sender, ColorBoxAdapterClickEventArgs e)
        {
            try
            {
                var item = ColorBoxAdapter.ColorsList[e.Position];
                if (item == null)
                    return;

                if (AttachmentsAdapter.AttachemntsList.Count > 0)
                {
                    AttachmentsAdapter.AttachemntsList.Clear();
                    AttachmentsAdapter.NotifyDataSetChanged();
                }

                IdColor = item.Id.ToString();
                if (item.Color1 == "#ffffff" && item.Color2 == "#efefef")
                {
                    ColoredImage.Visibility = ViewStates.Gone;

                    TxtContentPost.SetTextColor(new Color(ContextCompat.GetColor(TxtContentPost.Context, Resource.Color.textDark_color)));
                    TxtContentPost.SetHintTextColor(new Color(ContextCompat.GetColor(TxtContentPost.Context, Resource.Color.textDark_color)));

                    return;
                }

                ColoredImage.Visibility = ViewStates.Visible;
                if (!string.IsNullOrEmpty(item.Image))
                {
                    Glide.With(this).Load(item.Image).Apply(new RequestOptions()).Into(ColoredImage);
                    //GlideImageLoader.LoadImage(this, item.Image, ColoredImage, ImageStyle.FitCenter, ImagePlaceholders.Color, false);
                }
                else
                {
                    var colorsList = new List<int>();

                    if (!string.IsNullOrEmpty(item.Color1))
                        colorsList.Add(Color.ParseColor(item.Color1));

                    if (!string.IsNullOrEmpty(item.Color2))
                        colorsList.Add(Color.ParseColor(item.Color2));

                    GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TopBottom, colorsList.ToArray());
                    gd.SetCornerRadius(0f);
                    ColoredImage.Background = (gd);
                }

                if (!string.IsNullOrEmpty(item.TextColor))
                {
                    TxtContentPost.SetTextColor(Color.ParseColor(item.TextColor));
                    TxtContentPost.SetHintTextColor(Color.ParseColor(item.TextColor));
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

                if (ColoredImage.Visibility != ViewStates.Gone)
                {
                    ColoredImage.Visibility = ViewStates.Gone;

                    TxtContentPost.SetTextColor(new Color(ContextCompat.GetColor(TxtContentPost.Context, Resource.Color.textDark_color)));
                    TxtContentPost.SetHintTextColor(new Color(ContextCompat.GetColor(TxtContentPost.Context, Resource.Color.textDark_color)));
                }

                if (requestCode == 500 && resultCode == Result.Ok) // Add image 
                {
                    var videoAttach = AttachmentsAdapter.AttachemntsList.Where(a => !a.TypeAttachment.Contains("postPhotos")).ToList();

                    if (videoAttach.Count > 0)
                        foreach (var video in videoAttach)
                            AttachmentsAdapter.Remove(video);

                    if (data.ClipData != null)
                    {
                        var mClipData = data.ClipData;
                        var mArrayUri = new List<Uri>();
                        for (var i = 0; i < mClipData.ItemCount; i++)
                        {
                            var item = mClipData.GetItemAt(i);
                            var uri = item.Uri;

                            mArrayUri.Add(Uri.Parse(Methods.AttachmentFiles.GetActualPathFromFile(this, uri)));
                        }

                        if (mArrayUri.Count > 0)
                        {
                            foreach (var item in mArrayUri)
                            {
                                var attach = new Attachments
                                {
                                    Id = AttachmentsAdapter.AttachemntsList.Count + 1,
                                    TypeAttachment = "postPhotos[]",
                                    FileSimple = item.Path,
                                    FileUrl = item.Path
                                };

                                AttachmentsAdapter.Add(attach);
                            }
                        }
                    }
                    else
                    {
                        var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                        if (filepath != null)
                        {
                            var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                            if (type == "Image")
                            {
                                var attach = new Attachments();
                                attach.Id = AttachmentsAdapter.AttachemntsList.Count + 1;
                                attach.TypeAttachment = "postPhotos";
                                attach.FileSimple = filepath;
                                attach.FileUrl = filepath;

                                AttachmentsAdapter.Add(attach);
                            }

                            if (AttachmentsAdapter.AttachemntsList.Count > 1)
                            {
                                foreach (var item in AttachmentsAdapter.AttachemntsList)
                                {
                                    item.TypeAttachment = "postPhotos[]";
                                }
                            }
                            else
                            {
                                foreach (var item in AttachmentsAdapter.AttachemntsList)
                                {
                                    item.TypeAttachment = "postPhotos";
                                }
                            }
                        } 
                    }
                }
                else if (requestCode == 501 && resultCode == Result.Ok) // Add video 
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Video")
                        {
                            var fileName = filepath.Split('/').Last();
                            var fileNameWithoutExtenion = fileName.Split('.').First();

                            var path = Methods.Path.FolderDcimPost + "/" + fileNameWithoutExtenion + ".png";

                            var vidoPlaceHolderImage = Methods.MultiMedia.GetMediaFrom_Gallery(Methods.Path.FolderDcimPost, fileNameWithoutExtenion + ".png");
                            if (vidoPlaceHolderImage == "File Dont Exists")
                            {
                                var bitmapImage = Methods.MultiMedia.Retrieve_VideoFrame_AsBitmap(filepath);
                                Methods.MultiMedia.Export_Bitmap_As_Image(bitmapImage, fileNameWithoutExtenion, Methods.Path.FolderDcimPost);
                            }

                            //remove file the type
                            var imageAttach = AttachmentsAdapter.AttachemntsList.Where(a => a.TypeAttachment != "postVideo").ToList();
                            if (imageAttach.Count > 0)
                                foreach (var image in imageAttach)
                                    AttachmentsAdapter.Remove(image);

                            var attach = new Attachments
                            {
                                Id = AttachmentsAdapter.AttachemntsList.Count + 1,
                                TypeAttachment = "postVideo",
                                FileSimple = path,
                                Thumb = new Attachments.VideoThumb()
                                {
                                    FileUrl = path
                                },

                                FileUrl = filepath
                            };

                            AttachmentsAdapter.Add(attach);
                        }
                    }
                }
                else if (requestCode == 3 && resultCode == Result.Ok) // Mention
                {
                    try
                    {
                        var dataUser = MentionActivity.MAdapter.MentionList.Where(a => a.Selected).ToList();
                        if (dataUser.Count > 0)
                        {
                            var textSanitizer = new TextSanitizer(MentionTextView, this);

                            foreach (var item in dataUser) MentionText += " @" + item.Username + " ,";

                            textSanitizer.Load(LoadPostStrings());
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (requestCode == 502 && resultCode == Result.Ok) // Location
                {
                    var placePicked = PlacePicker.GetPlace(this, data);

                    if (!string.IsNullOrEmpty(PlaceText))
                        PlaceText = string.Empty;

                    var textSanitizer = new TextSanitizer(MentionTextView, this);

                    if (placePicked?.NameFormatted?.ToString().Contains("°") == true)
                        PlaceText += " /" + placePicked.AddressFormatted?.ToString();
                    else
                        PlaceText += " /" + placePicked?.NameFormatted?.ToString();

                    textSanitizer.Load(LoadPostStrings());

                    PlaceText = placePicked?.NameFormatted?.ToString();
                }
                else if (requestCode == 5 && resultCode == Result.Ok) // Feeling
                {
                    var feelings = data.GetStringExtra("Feelings") ?? "Data not available";
                    var feelingsDisplayText = data.GetStringExtra("Feelings") ?? "Data not available";
                    if (feelings != "Data not available" && !string.IsNullOrEmpty(feelings))
                    {
                        var textSanitizer = new TextSanitizer(MentionTextView, this);
                        FeelingText = feelingsDisplayText; //This Will be displayed And translated
                        PostFeelingType = "feelings"; //Type Of feeling
                        PostFeelingText = feelings.ToLower(); //This will be send via API
                        textSanitizer.Load(LoadPostStrings());
                    }
                }
                else if (requestCode == 503) // Add image using camera
                {
                    if (IntentController.ImageCameraUri == null)
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                        return;
                    }

                    var thumbnail = MediaStore.Images.Media.GetBitmap(ContentResolver, IntentController.ImageCameraUri);

                    var path = GetRealPathFromUri(IntentController.ImageCameraUri);
                    if (Methods.MultiMedia.CheckFileIfExits(path) != "File Dont Exists")
                    {
                        //remove file the type
                        var videoAttach = AttachmentsAdapter.AttachemntsList.Where(a => !a.TypeAttachment.Contains("postPhotos")).ToList();
                        if (videoAttach.Count > 0)
                            foreach (var video in videoAttach)
                                AttachmentsAdapter.Remove(video);

                        var attach = new Attachments
                        {
                            Id = AttachmentsAdapter.AttachemntsList.Count + 1,
                            TypeAttachment = "postPhotos",
                            FileSimple = path,
                            FileUrl = path
                        };

                        AttachmentsAdapter.Add(attach);
                    }
                    else
                    {
                        //Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                    }
                }
                else if (requestCode == 7 && resultCode == Result.Ok) // Gif
                {
                    var giflink = data.GetStringExtra("gif") ?? "Data not available";
                    if (giflink != "Data not available" && !string.IsNullOrEmpty(giflink))
                    {
                        GifFile = giflink;

                        //remove file the type
                        AttachmentsAdapter.RemoveAll();

                        var attach = new Attachments
                        {
                            Id = AttachmentsAdapter.AttachemntsList.Count + 1,
                            TypeAttachment = "postPhotos",
                            FileSimple = GifFile,
                            FileUrl = GifFile
                        };

                        AttachmentsAdapter.Add(attach);
                    }
                }
                else if (requestCode == 504 && resultCode == Result.Ok) // File
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var fileName = filepath.Split('/').Last();
                        //var fileNameWithoutExtenion = fileName.Split('.').First();

                        //remove file the type
                        AttachmentsAdapter.RemoveAll();

                        var attach = new Attachments
                        {
                            Id = AttachmentsAdapter.AttachemntsList.Count + 1,
                            TypeAttachment = "postFile",
                            FileSimple = "Image_File.jpg",
                            FileUrl = filepath
                        };

                        AttachmentsAdapter.Add(attach);
                    }
                }
                else if (requestCode == 505 && resultCode == Result.Ok) // Music
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Audio")
                        {
                            var fileName = filepath.Split('/').Last();
                            var fileNameWithoutExtenion = fileName.Split('.').First();

                            //remove file the type
                            AttachmentsAdapter.RemoveAll();

                            var attach = new Attachments
                            {
                                Id = AttachmentsAdapter.AttachemntsList.Count + 1,
                                TypeAttachment = "postMusic",
                                FileSimple = "Audio_File.jpg",
                                FileUrl = filepath
                            };

                            AttachmentsAdapter.Add(attach);
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                        }
                    }
                }
                else if (requestCode == CropImage.CropImageActivityRequestCode) // Add image 
                {
                    var videoAttach = AttachmentsAdapter.AttachemntsList.Where(a => !a.TypeAttachment.Contains("postPhotos")).ToList();

                    if (videoAttach.Count > 0)
                        foreach (var video in videoAttach)
                            AttachmentsAdapter.Remove(video);

                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                var attach = new Attachments();
                                attach.Id = AttachmentsAdapter.AttachemntsList.Count + 1;
                                attach.TypeAttachment = "postPhotos";
                                attach.FileSimple = resultUri.Path;
                                attach.FileUrl = resultUri.Path;

                                AttachmentsAdapter.Add(attach);

                                if (AttachmentsAdapter.AttachemntsList.Count > 1)
                                {
                                    foreach (var item in AttachmentsAdapter.AttachemntsList)
                                    {
                                        item.TypeAttachment = "postPhotos[]";
                                    }
                                }
                                else
                                {
                                    foreach (var item in AttachmentsAdapter.AttachemntsList)
                                    {
                                        item.TypeAttachment = "postPhotos";
                                    }
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                    }
                }

                TxtContentPost.ClearFocus();
                SlidingUpPanel.SetPanelState(SlidingUpPanelLayout.PanelState.Collapsed);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        switch (PermissionsType)
                        {
                            //requestCode >> 500 => Image Gallery
                            case "Image" when AppSettings.ImageCropping:
                                OpenDialogGallery();
                                break;
                            case "Image": //requestCode >> 500 => Image Gallery
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures));
                                break;
                            case "Video":
                                //requestCode >> 501 => video Gallery
                                new IntentController(this).OpenIntentVideoGallery();
                                break;
                            case "Camera":
                                //requestCode >> 503 => Camera
                                new IntentController(this).OpenIntentCamera();
                                break;
                            case "File":
                                //requestCode >> 504 => File
                                new IntentController(this).OpenIntentFile(GetText(Resource.String.Lbl_SelectFile));
                                break;
                            case "Music":
                                //requestCode >> 505 => Music
                                new IntentController(this).OpenIntentAudio();
                                break;
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
                else if (requestCode == 105)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        //Open intent Location when the request code of result is 502
                        new IntentController(this).OpenIntentLocation();
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Panel Item Post

        public void OnPanelClosed(View panel)
        {
            try
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnPanelOpened(View panel)
        {
            try
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        void SlidingPaneLayout.IPanelSlideListener.OnPanelSlide(View panel, float slideOffset)
        {
            try
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnPanelStateChanged(View p0, SlidingUpPanelLayout.PanelState p1, SlidingUpPanelLayout.PanelState p2)
        {
            try
            {
                if (p1 == SlidingUpPanelLayout.PanelState.Expanded && p2 == SlidingUpPanelLayout.PanelState.Dragging)
                {
                    if (IconTag.Tag.ToString() == "Open")
                    {
                        IconTag.SetImageResource(Resource.Drawable.ic__Attach_tag);
                        IconTag.Tag = "Close";
                        IconImage.Visibility = ViewStates.Visible;
                        IconHappy.Visibility = ViewStates.Visible;
                    }
                }
                else if (p1 == SlidingUpPanelLayout.PanelState.Collapsed && p2 == SlidingUpPanelLayout.PanelState.Dragging)
                {
                    if (IconTag.Tag.ToString() == "Close")
                    {
                        IconTag.SetImageResource(Resource.Drawable.ic_action_arrow_down_sign);
                        IconTag.Tag = "Open";
                        IconImage.Visibility = ViewStates.Invisible;
                        IconHappy.Visibility = ViewStates.Invisible;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        void SlidingUpPanelLayout.IPanelSlideListener.OnPanelSlide(View p0, float p1)
        {
            try
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Privacy

        private void LoadDataUser()
        {
            try
            {
                var dataUser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (dataUser != null)
                {
                    GlideImageLoader.LoadImage(this, dataUser.Avatar, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);

                    TxtUserName.Text = dataUser.Name;

                    PostPrivacyButton.Text = GetString(Resource.String.Lbl_Everyone);

                    //if (dataUser.post_privacy.Contains("0"))
                    //    PostPrivacyButton.Text = GetString(Resource.String.Lbl_Everyone);
                    //else if (dataUser.post_privacy.Contains("ifollow"))
                    //    PostPrivacyButton.Text = GetString(Resource.String.Lbl_People_i_Follow);
                    //else if (dataUser.post_privacy.Contains("me"))
                    //    PostPrivacyButton.Text = GetString(Resource.String.Lbl_People_Follow_Me);
                    //else
                    //    PostPrivacyButton.Text = GetString(Resource.String.Lbl_No_body);

                    PostPrivacy = "0";
                }
                else
                {
                    TxtUserName.Text = UserDetails.Username;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void GetPrivacyPost()
        {
            try
            {
                if (PagePost == "Normal" || PagePost == "Normal_More" || PagePost == "Normal_Gallery")
                {
                    LoadDataUser();

                    switch (PagePost)
                    {
                        case "Normal_More":
                            SlidingUpPanel.SetPanelState(SlidingUpPanelLayout.PanelState.Expanded);
                            break;
                        case "Normal_Gallery":
                            {
                                PermissionsType = "Image";

                                // Check if we're running on Android 5.0 or higher 
                                if ((int)Build.VERSION.SdkInt < 23)
                                {
                                    if (AppSettings.ImageCropping)
                                        OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                                    else
                                        new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                                }
                                else
                                {
                                    if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                                                                                                              && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                                    {
                                        if (AppSettings.ImageCropping)
                                            OpenDialogGallery(); //requestCode >> 500 => Image Gallery
                                        else
                                            new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                                    }
                                    else
                                    {
                                        new PermissionsController(this).RequestPermission(108);
                                    }
                                }
                                break;
                            }
                    }
                }
                else if (PagePost == "SocialGroup")
                {
                    var dataGroup = JsonConvert.DeserializeObject<GroupClass>(Intent.GetStringExtra("itemObject"));
                    if (dataGroup != null)
                    {
                        PostPrivacyButton.Visibility = ViewStates.Gone;
                        GlideImageLoader.LoadImage(this, dataGroup.Avatar, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                        TxtUserName.Text = dataGroup.GroupName;
                    }
                    else
                    {
                        LoadDataUser();
                    }
                }
                else if (PagePost == "SocialPage")
                {
                    var dataPage = JsonConvert.DeserializeObject<PageClass>(Intent.GetStringExtra("itemObject"));
                    if (dataPage != null)
                    {
                        PostPrivacyButton.Visibility = ViewStates.Gone;
                        GlideImageLoader.LoadImage(this, dataPage.Avatar, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                        TxtUserName.Text = dataPage.PageName;
                    }
                    else
                    {
                        LoadDataUser();
                    }
                }
                else if (PagePost == "SocialEvent")
                {
                    var dataEvent = JsonConvert.DeserializeObject<EventDataObject>(Intent.GetStringExtra("itemObject"));
                    if (dataEvent != null)
                    {
                        PostPrivacyButton.Visibility = ViewStates.Gone;
                        GlideImageLoader.LoadImage(this, dataEvent.Cover, PostSectionImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                        TxtUserName.Text = dataEvent.Name;
                    }
                    else
                    {
                        LoadDataUser();
                    }
                }
                else
                {
                    LoadDataUser();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void PostPrivacyButton_Click(object sender, EventArgs e)
        {
            try
            {
                TypeDialog = "PostPrivacy";

                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetString(Resource.String.Lbl_Everyone));
                arrayAdapter.Add(GetString(Resource.String.Lbl_People_i_Follow));
                arrayAdapter.Add(GetText(Resource.String.Lbl_People_Follow_Me));
                arrayAdapter.Add(GetString(Resource.String.Lbl_No_body));

                dialogList.Title(GetText(Resource.String.Lbl_PostPrivacy));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.ItemsCallback(this).Build().Show();
                dialogList.AlwaysCallSingleChoiceCallback();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void AddAnswerButtonOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                if (AddPollAnswerAdapter.AnswersList.Count < 8)
                {
                    AddPollAnswerAdapter.AnswersList.Add(new PollAnswers { Answer = "", Id = AddPollAnswerAdapter.AnswersList.Count });
                    AddPollAnswerAdapter.NotifyItemInserted(AddPollAnswerAdapter.AnswersList.Count);
                    PollRecyclerView.ScrollToPosition(AddPollAnswerAdapter.AnswersList.Count);
                    ScrollView.ScrollTo(0, ScrollView.Bottom + 500);
                    ScrollView.SmoothScrollTo(0, ScrollView.Bottom + 200);
                }
                else
                {
                    Toast.MakeText(this, GetText(Resource.String.Lbl2_PollsLimitError), ToastLength.Long).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemid, ICharSequence itemString)
        {
            try
            {
                if (TypeDialog == "PostPrivacy")
                {
                    PostPrivacyButton.Text = itemString.ToString();
                    PostPrivacy = itemid.ToString();

                    //var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.user_id == UserDetails.UserId);
                    //if (datauser != null) datauser.post_privacy = PostPrivacy;

                    //Dictionary<string, string> dataPrivacy = new Dictionary<string, string>()
                    //{
                    //    {"post_privacy", PostPrivacy.ToString()},
                    //};

                    //var data = WoWonderClient.Requests.RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                }
                else if (TypeDialog == "Feelings")
                {
                    if (itemid == 0) // Feelings
                    {
                        StartActivityForResult(new Intent(this, typeof(FeelingsActivity)), 5);
                    }
                    else if (itemid == 1) //Listening
                    {
                        TypeDialog = "Listening";

                        var dialog = new MaterialDialog.Builder(this);

                        dialog.Title(Resource.String.Lbl_Listening);
                        dialog.Input(Resource.String.Lbl_Comment_Hint_Listening, 0, false, this);
                        dialog.InputType(InputTypes.TextFlagImeMultiLine);
                        dialog.PositiveText(GetText(Resource.String.Lbl_Submit)).OnPositive(this);
                        dialog.NegativeText(GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                        dialog.AlwaysCallSingleChoiceCallback();
                        dialog.Build().Show();
                    }
                    else if (itemid == 2) //Playing
                    {
                        TypeDialog = "Playing";

                        var dialog = new MaterialDialog.Builder(this);

                        dialog.Title(Resource.String.Lbl_Playing);
                        dialog.Input(Resource.String.Lbl_Comment_Hint_Playing, 0, false, this);
                        dialog.InputType(InputTypes.TextFlagImeMultiLine);
                        dialog.PositiveText(GetText(Resource.String.Lbl_Submit)).OnPositive(this);
                        dialog.NegativeText(GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                        dialog.AlwaysCallSingleChoiceCallback();
                        dialog.Build().Show();
                    }
                    else if (itemid == 3) //Watching
                    {
                        TypeDialog = "Watching";

                        var dialog = new MaterialDialog.Builder(this);

                        dialog.Title(Resource.String.Lbl_Watching);
                        dialog.Input(Resource.String.Lbl_Comment_Hint_Watching, 0, false, this);
                        dialog.InputType(InputTypes.TextFlagImeMultiLine);
                        dialog.PositiveText(GetText(Resource.String.Lbl_Submit)).OnPositive(this);
                        dialog.NegativeText(GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                        dialog.AlwaysCallSingleChoiceCallback();
                        dialog.Build().Show();
                    }
                    else if (itemid == 4) //Traveling
                    {
                        TypeDialog = "Traveling";

                        var dialog = new MaterialDialog.Builder(this);

                        dialog.Title(Resource.String.Lbl_Traveling);
                        dialog.Input(Resource.String.Lbl_Comment_Hint_Traveling, 0, false, this);
                        dialog.InputType(InputTypes.TextFlagImeMultiLine);
                        dialog.PositiveText(GetText(Resource.String.Lbl_Submit)).OnPositive(this);
                        dialog.NegativeText(GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                        dialog.AlwaysCallSingleChoiceCallback();
                        dialog.Build().Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (TypeDialog == "PostPrivacy")
                {
                    if (p1 == DialogAction.Positive) p0.Dismiss();
                }
                else if (TypeDialog == "PostBack")
                {
                    if (p1 == DialogAction.Positive)
                    {
                        p0.Dismiss();
                        Finish();
                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }
                }
                else
                {
                    if (p1 == DialogAction.Positive)
                    {
                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnInput(MaterialDialog p0, ICharSequence p1)
        {
            try
            {
                if (TypeDialog == "Listening")
                {
                    if (p1.Length() > 0)
                    {
                        var strName = p1.ToString();
                        ListeningText = strName;
                        PostFeelingText = strName;
                        PostFeelingType = "listening"; //Type Of listening
                    }
                }
                else if (TypeDialog == "Playing")
                {
                    if (p1.Length() > 0)
                    {
                        var strName = p1.ToString();
                        PlayingText = strName;
                        PostFeelingText = strName;
                        PostFeelingType = "playing"; //Type Of playing
                    }
                }
                else if (TypeDialog == "Watching")
                {
                    if (p1.Length() > 0)
                    {
                        var strName = p1.ToString();
                        WatchingText = strName;
                        PostFeelingText = strName;
                        PostFeelingType = "watching"; //Type Of watching
                    }
                }
                else if (TypeDialog == "Traveling")
                {
                    if (p1.Length() > 0)
                    {
                        var strName = p1.ToString();
                        TravelingText = strName;
                        PostFeelingText = strName;
                        PostFeelingType = "traveling"; //Type Of traveling
                    }
                }

                var textSanitizer = new TextSanitizer(MentionTextView, this);
                textSanitizer.Load(LoadPostStrings());

                var inputManager = (InputMethodManager)GetSystemService(InputMethodService);
                inputManager.HideSoftInputFromWindow(TopToolBar.WindowToken, 0);

                TopToolBar.ClearFocus();

                SlidingUpPanel.SetPanelState(SlidingUpPanelLayout.PanelState.Collapsed);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        // Event Back
        public override void OnBackPressed()
        {
            try
            {
                if (!string.IsNullOrEmpty(TxtContentPost.Text) || !string.IsNullOrEmpty(MentionText) || AttachmentsAdapter.AttachemntsList.Count > 0)
                {
                    TypeDialog = "PostBack";

                    var dialog = new MaterialDialog.Builder(this);

                    dialog.Title(GetText(Resource.String.Lbl_Title_Back));
                    dialog.Content(GetText(Resource.String.Lbl_Content_Back));
                    dialog.PositiveText(GetText(Resource.String.Lbl_PositiveText_Back)).OnPositive(this);
                    dialog.NegativeText(GetText(Resource.String.Lbl_NegativeText_Back)).OnNegative(this);
                    dialog.AlwaysCallSingleChoiceCallback();
                    dialog.ItemsCallback(this).Build().Show();
                }
                else
                {
                    base.OnBackPressed();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void OpenDialogGallery()
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private string GetRealPathFromUri(Uri contentUri)
        {
            try
            {
                string[] proj = { MediaStore.Images.Media.InterfaceConsts.Data };
                var cursor = ContentResolver.Query(contentUri, proj, null, null, null);
                int columnIndex = cursor.GetColumnIndexOrThrow(MediaStore.Images.Media.InterfaceConsts.Data);
                cursor.MoveToNext();
                return cursor.GetString(columnIndex);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }

        private string LoadPostStrings()
        {
            try
            {
                var newActivityText = string.Empty;
                var newFeelingText = string.Empty;
                var newMentionText = string.Empty;
                var newPlaceText = string.Empty;

                if (!string.IsNullOrEmpty(ActivityText))
                    newActivityText = PostActivityType + " " + ActivityText;

                if (!string.IsNullOrEmpty(ListeningText))
                    newFeelingText = GetText(Resource.String.Lbl_ListeningTo) + " " + ListeningText;

                if (!string.IsNullOrEmpty(PlayingText))
                    newFeelingText = GetText(Resource.String.Lbl_Playing) + " " + PlayingText;

                if (!string.IsNullOrEmpty(WatchingText))
                    newFeelingText = GetText(Resource.String.Lbl_Watching) + " " + WatchingText;

                if (!string.IsNullOrEmpty(TravelingText))
                    newFeelingText = GetText(Resource.String.Lbl_Traveling) + " " + TravelingText;

                if (!string.IsNullOrEmpty(FeelingText))
                    newFeelingText = GetText(Resource.String.Lbl_Feeling) + " " + FeelingText;

                if (!string.IsNullOrEmpty(MentionText))
                    newMentionText += " " + GetText(Resource.String.Lbl_With) + " " +
                                      MentionText.Remove(MentionText.Length - 1, 1);

                if (!string.IsNullOrEmpty(PlaceText))
                    newPlaceText += " " + GetText(Resource.String.Lbl_At) + " " + PlaceText;

                var mainString = newActivityText + newFeelingText + newMentionText + newPlaceText;
                return mainString;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }

    }
}