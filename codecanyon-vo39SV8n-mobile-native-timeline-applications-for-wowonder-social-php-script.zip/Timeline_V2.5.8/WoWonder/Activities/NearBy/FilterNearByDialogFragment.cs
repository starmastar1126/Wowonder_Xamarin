﻿using System;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.SQLite;

namespace WoWonder.Activities.NearBy
{ 
    public class FilterNearByDialogFragment : BottomSheetDialogFragment, SeekBar.IOnSeekBarChangeListener
    {
        #region Variables Basic

        private PeopleNearByActivity ContexteNearBy;
        private TextView IconBack, IconGender, IconDistance, IconOnline, TxtDistanceCount;
        private TextView ResetTextView;
        private SeekBar DistanceBar;
        private Button ButtonMale, ButtonFemale, ButtonBothGender, ButtonOffline, ButtonOnline, BothStatusButton, BtnApply;  
        private int DistanceCount, Gender, Status;

        #endregion

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Create your fragment here
            ContexteNearBy = (PeopleNearByActivity)Activity;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.BottomSheetNearByFilter, container, false);

                InitComponent(view);

                IconBack.Click += IconBackOnClick;
                ButtonMale.Click += ButtonMaleOnClick;
                ButtonFemale.Click += ButtonFemaleOnClick;
                ButtonBothGender.Click += ButtonBothOnClick;
                ButtonOffline.Click += ButtonOfflineOnClick;
                ButtonOnline.Click += ButtonOnlineOnClick;
                BothStatusButton.Click += BothStatusButtonOnClick;
                BtnApply.Click += BtnApplyOnClick;
                ResetTextView.Click += ResetTextViewOnClick;
                 
                return view;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                IconBack = view.FindViewById<TextView>(Resource.Id.IconBack);
                IconGender = view.FindViewById<TextView>(Resource.Id.IconGender);
                ButtonMale = view.FindViewById<Button>(Resource.Id.MaleButton);
                ButtonFemale = view.FindViewById<Button>(Resource.Id.FemaleButton);
                ButtonBothGender = view.FindViewById<Button>(Resource.Id.BothGenderButton);
                IconDistance = view.FindViewById<TextView>(Resource.Id.IconDistance);
                TxtDistanceCount = view.FindViewById<TextView>(Resource.Id.Distancenumber);
                DistanceBar = view.FindViewById<SeekBar>(Resource.Id.distanceSeeker);
                IconOnline = view.FindViewById<TextView>(Resource.Id.IconOnline);
                ButtonOffline = view.FindViewById<Button>(Resource.Id.OfflineButton);
                ButtonOnline = view.FindViewById<Button>(Resource.Id.OnlineButton);
                BothStatusButton = view.FindViewById<Button>(Resource.Id.BothStatusButton);
                BtnApply = view.FindViewById<Button>(Resource.Id.ApplyButton);
                ResetTextView = view.FindViewById<TextView>(Resource.Id.Resetbutton);
                 
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconBack, IonIconsFonts.ChevronLeft);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconGender, IonIconsFonts.IosPersonOutline);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, IconDistance, FontAwesomeIcon.StreetView);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconOnline, IonIconsFonts.Ionic);
                 
                DistanceBar.Max = 300;
                DistanceBar.SetOnSeekBarChangeListener(this);

                GetFilter();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion
         
        #region Event

        //Back
        private void IconBackOnClick(object sender, EventArgs e)
        {
            try
            {
                Dismiss();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Save data 
        private void BtnApplyOnClick(object sender, EventArgs e)
        {
            try
            { 
                UserDetails.NearByGender = Gender.ToString();
                UserDetails.NearByDistanceCount = DistanceCount.ToString();
                UserDetails.NearByStatus = Status.ToString();
                 
                var dbDatabase = new SqLiteDatabase();
                var newSettingsFilter = new DataTables.NearByFilterTb
                {
                    DistanceValue = DistanceCount,
                    Gender = Gender,
                    Status = Status
                };
                dbDatabase.InsertOrUpdate_NearByFilter(newSettingsFilter);
                dbDatabase.Dispose();

                ContexteNearBy.MAdapter.NearByList.Clear();
                ContexteNearBy.MAdapter.NotifyDataSetChanged();

                ContexteNearBy.StartApiService();

                Dismiss();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Reset Value
        private void ResetTextViewOnClick(object sender, EventArgs e)
        {
            try
            { 
                Gender = 0;
                DistanceCount = 0;
                Status = 0;

                //////////////////////////// Gender //////////////////////////////
                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonFemale.SetTextColor(Color.ParseColor("#444444"));

                ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonMale.SetTextColor(Color.ParseColor("#444444"));

                //////////////////////////// Status ////////////////////////////// 
                BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                BothStatusButton.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonOnline.SetTextColor(Color.ParseColor("#444444"));

                ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonOffline.SetTextColor(Color.ParseColor("#444444"));


                TxtDistanceCount.Text = DistanceCount + " " + GetText(Resource.String.Lbl_km);
                DistanceBar.Progress = DistanceCount; 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        //Select gender >> Both (0)
        private void ButtonBothOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonFemale.SetTextColor(Color.ParseColor("#444444"));

                ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonMale.SetTextColor(Color.ParseColor("#444444"));

                Gender = 0;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select gender >> Girls (2)
        private void ButtonFemaleOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonFemale.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonBothGender.SetTextColor(Color.ParseColor("#444444"));

                ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonMale.SetTextColor(Color.ParseColor("#444444"));
                Gender = 2;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select gender >> Man (1)
        private void ButtonMaleOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonMale.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonBothGender.SetTextColor(Color.ParseColor("#444444"));

                ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonFemale.SetTextColor(Color.ParseColor("#444444"));

                Gender = 1;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select Status >> Both (0)
        private void BothStatusButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                BothStatusButton.SetTextColor(Color.ParseColor("#ffffff"));

                ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonOnline.SetTextColor(Color.ParseColor("#444444"));

                ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonOffline.SetTextColor(Color.ParseColor("#444444"));

                Status = 0;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select Status >> Online (2)
        private void ButtonOnlineOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonOnline.SetTextColor(Color.ParseColor("#ffffff"));

                BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                BothStatusButton.SetTextColor(Color.ParseColor("#444444"));

                ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonOffline.SetTextColor(Color.ParseColor("#444444"));

                Status = 2;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Select Status >> Offline (1)
        private void ButtonOfflineOnClick(object sender, EventArgs e)
        {
            try
            {
                //follow_button_profile_friends >> Un click
                //follow_button_profile_friends_pressed >> click
                ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                ButtonOffline.SetTextColor(Color.ParseColor("#ffffff"));

                BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                BothStatusButton.SetTextColor(Color.ParseColor("#444444"));

                ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                ButtonOnline.SetTextColor(Color.ParseColor("#444444"));

                Status = 1; 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        #region SeekBar

        public void OnProgressChanged(SeekBar seekBar, int progress, bool fromUser)
        {
            try
            {
                TxtDistanceCount.Text = progress + " " + GetText(Resource.String.Lbl_km);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnStartTrackingTouch(SeekBar seekBar)
        {

        }

        public void OnStopTrackingTouch(SeekBar seekBar)
        {
            try
            {
                DistanceCount = seekBar.Progress;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void GetFilter()
        {
            try
            {
                var dbDatabase = new SqLiteDatabase();

                var data = dbDatabase.GetNearByFilterById();
                if (data != null)
                {
                    Gender = data.Gender;
                    DistanceCount = data.DistanceValue;
                    Status = data.Status;

                    //////////////////////////// Gender //////////////////////////////
                    switch (data.Gender)
                    { 
                        case 0:
                            ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonFemale.SetTextColor(Color.ParseColor("#444444"));

                            ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonMale.SetTextColor(Color.ParseColor("#444444"));

                            Gender = 0;
                            break;
                        case 1:
                            ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonMale.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonBothGender.SetTextColor(Color.ParseColor("#444444"));

                            ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonFemale.SetTextColor(Color.ParseColor("#444444"));

                            Gender = 1;
                            break;
                        case 2:
                            ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonFemale.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonBothGender.SetTextColor(Color.ParseColor("#444444"));

                            ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonMale.SetTextColor(Color.ParseColor("#444444"));
                            Gender = 2;
                            break;
                    }

                    TxtDistanceCount.Text = DistanceCount + " " + GetText(Resource.String.Lbl_km);
                    DistanceBar.Progress = DistanceCount;

                    //////////////////////////// Status ////////////////////////////// 
                    switch (data.Status)
                    {
                        case 0:
                            BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            BothStatusButton.SetTextColor(Color.ParseColor("#ffffff"));

                            ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonOnline.SetTextColor(Color.ParseColor("#444444"));

                            ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonOffline.SetTextColor(Color.ParseColor("#444444"));

                            Status = 0;
                            break;
                        case 1:
                            ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonOffline.SetTextColor(Color.ParseColor("#ffffff"));

                            BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            BothStatusButton.SetTextColor(Color.ParseColor("#444444"));

                            ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonOnline.SetTextColor(Color.ParseColor("#444444"));

                            Status = 1;
                            break;
                        case 2:
                            ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                            ButtonOnline.SetTextColor(Color.ParseColor("#ffffff"));

                            BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            BothStatusButton.SetTextColor(Color.ParseColor("#444444"));

                            ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                            ButtonOffline.SetTextColor(Color.ParseColor("#444444"));

                            Status = 2;
                            break;
                    }
                }
                else
                {
                    var newSettingsFilter = new DataTables.NearByFilterTb
                    {
                        DistanceValue = 0,
                        Gender = 0,
                        Status = 0
                    };
                    dbDatabase.InsertOrUpdate_NearByFilter(newSettingsFilter);

                    Gender = 0;
                    DistanceCount = 0;
                    Status = 0;

                    //////////////////////////// Gender //////////////////////////////
                    ButtonBothGender.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                    ButtonBothGender.SetTextColor(Color.ParseColor("#ffffff"));

                    ButtonFemale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    ButtonFemale.SetTextColor(Color.ParseColor("#444444"));

                    ButtonMale.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    ButtonMale.SetTextColor(Color.ParseColor("#444444"));

                    //////////////////////////// Status ////////////////////////////// 
                    BothStatusButton.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                    BothStatusButton.SetTextColor(Color.ParseColor("#ffffff"));

                    ButtonOnline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    ButtonOnline.SetTextColor(Color.ParseColor("#444444"));

                    ButtonOffline.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends);
                    ButtonOffline.SetTextColor(Color.ParseColor("#444444"));


                    TxtDistanceCount.Text = DistanceCount + " " + GetText(Resource.String.Lbl_km);
                    DistanceBar.Progress = DistanceCount; 
                }

                dbDatabase.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

    }
}