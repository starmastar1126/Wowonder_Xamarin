﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using Com.Tuyenmonkey.Textdecorator;
using Java.Lang;
using Newtonsoft.Json;
using Plugin.Share;
using Plugin.Share.Abstractions;
using WoWonder.Activities.Contacts;
using WoWonder.Activities.Gift;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.UsersPages;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Album;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using Console = System.Console;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.UserProfile
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class UserProfileActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private CollapsingToolbarLayout CollapsingToolbar;
        private AppBarLayout AppBarLayout;
        private WRecyclerView MainRecyclerView;
        private NativePostAdapter PostFeedAdapter;
        private SwipeRefreshLayout SwipeRefreshLayout;
        private CircleButton BtnAddUser, BtnMessage, BtnMore;
        private TextView TxtUsername, TxtFollowers, TxtFollowing, TxtLikes, TxtPoints;
        private TextView TxtCountFollowers, TxtCountLikes, TxtCountFollowing, TxtCountPoints;
        private ImageView UserProfileImage, CoverImage, IconBack;
        private View OnlineView;
        private UserDataObject UserData;
        private LinearLayout LayoutCountFollowers, LayoutCountFollowing, LayoutCountLikes, CountPointsLayout, HeaderSection;
        private string SPrivacyBirth, SPrivacyFollow, SPrivacyFriend, SPrivacyMessage;
        private string SUserId, SUrlUser, SCanFollow, SUserName;
        private bool IsPassedDataLoaded, IsPoked, IsFamily;
        private View ViewPoints, ViewLikes, ViewFollowers;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                View mContentView = Window.DecorView;
                var uiOptions = (int)mContentView.SystemUiVisibility;
                var newUiOptions = (int)uiOptions;

               // newUiOptions |= (int)SystemUiFlags.Fullscreen;
                newUiOptions |= (int)SystemUiFlags.LayoutStable;
                mContentView.SystemUiVisibility = (StatusBarVisibility)newUiOptions;

                //Window.AddFlags(WindowManagerFlags.Fullscreen);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Native_UserProfile);

                SUserName = Intent.GetStringExtra("name") ?? string.Empty;

                SUserId = Intent.GetStringExtra("UserId") ?? string.Empty;
                var userObject = Intent.GetStringExtra("UserObject");
                if (!string.IsNullOrEmpty(userObject))
                    UserData = JsonConvert.DeserializeObject<UserDataObject>(userObject);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                if (!string.IsNullOrEmpty(SUserName))
                {
                    GetDataUserByName();
                }
                else
                {
                    if (UserData != null)
                        LoadPassedDate(UserData);

                    StartApiService();
                }
                GetGiftsLists();

                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                MainRecyclerView.ReleasePlayer();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                CollapsingToolbar = (CollapsingToolbarLayout)FindViewById(Resource.Id.collapsingToolbar);
                CollapsingToolbar.Title = "";

                AppBarLayout = FindViewById<AppBarLayout>(Resource.Id.appBarLayout);
                AppBarLayout.SetExpanded(true);

                BtnAddUser = (CircleButton)FindViewById(Resource.Id.AddUserbutton);
                BtnMessage = (CircleButton)FindViewById(Resource.Id.message_button);
                BtnMore = (CircleButton)FindViewById(Resource.Id.morebutton);
                IconBack = (ImageView)FindViewById(Resource.Id.back);
                TxtUsername = (TextView)FindViewById(Resource.Id.username_profile);
                TxtCountFollowers = (TextView)FindViewById(Resource.Id.CountFollowers);
                TxtCountFollowing = (TextView)FindViewById(Resource.Id.CountFollowing);
                TxtCountLikes = (TextView)FindViewById(Resource.Id.CountLikes);
                TxtCountPoints = (TextView)FindViewById(Resource.Id.CountPoints);
                TxtFollowers = FindViewById<TextView>(Resource.Id.txtFollowers);
                TxtFollowing = FindViewById<TextView>(Resource.Id.txtFollowing);
                TxtLikes = FindViewById<TextView>(Resource.Id.txtLikes);
                TxtPoints = FindViewById<TextView>(Resource.Id.txtPoints);
                UserProfileImage = (ImageView)FindViewById(Resource.Id.profileimage_head);
                CoverImage = (ImageView)FindViewById(Resource.Id.cover_image);
                OnlineView = FindViewById<View>(Resource.Id.online_view);
                MainRecyclerView = FindViewById<WRecyclerView>(Resource.Id.newsfeedRecyler);
                HeaderSection = FindViewById<LinearLayout>(Resource.Id.headerSection);
                LayoutCountFollowers = FindViewById<LinearLayout>(Resource.Id.CountFollowersLayout);
                LayoutCountFollowing = FindViewById<LinearLayout>(Resource.Id.CountFollowingLayout);
                LayoutCountLikes = FindViewById<LinearLayout>(Resource.Id.CountLikesLayout);
                CountPointsLayout = FindViewById<LinearLayout>(Resource.Id.CountPointsLayout);

                ViewPoints = FindViewById<View>(Resource.Id.ViewPoints); 
                ViewLikes = FindViewById<View>(Resource.Id.ViewLikes);
                ViewFollowers = FindViewById<View>(Resource.Id.ViewFollowers);

                SwipeRefreshLayout = FindViewById<SwipeRefreshLayout>(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = false;

                if (AppSettings.FlowDirectionRightToLeft)
                    IconBack.SetImageResource(Resource.Drawable.ic_action_ic_back_rtl);

                if (AppSettings.ConnectivitySystem == 1) // Following
                {
                    TxtFollowers.Text = GetText(Resource.String.Lbl_Followers);
                    TxtFollowing.Text = GetText(Resource.String.Lbl_Following);
                }
                else // Friend
                {
                    TxtFollowers.Text = GetText(Resource.String.Lbl_Friends);
                    TxtFollowing.Text = GetText(Resource.String.Lbl_Post);
                }

                BtnAddUser.Visibility = ViewStates.Invisible;
                BtnMore.Visibility = ViewStates.Invisible;
                BtnMessage.Visibility = ViewStates.Invisible;

                if (!AppSettings.ShowUserPoint)
                {
                    ViewPoints.Visibility = ViewStates.Gone; 
                    CountPointsLayout.Visibility = ViewStates.Gone;
                     
                    HeaderSection.WeightSum = 3; 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = " ";
                    toolbar.SetTitleTextColor(Color.Black);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                PostFeedAdapter = new NativePostAdapter(this, MainRecyclerView, NativeFeedType.User)
                {
                    ApiIdParameter = SUserId
                };
                 
                MainRecyclerView.SetXAdapter(PostFeedAdapter, SwipeRefreshLayout);
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    BtnAddUser.Click += BtnAddUserOnClick;
                    BtnMessage.Click += BtnMessageOnClick;
                    BtnMore.Click += BtnMoreOnClick;
                    IconBack.Click += IconBackOnClick;
                    LayoutCountFollowers.Click += LayoutCountFollowersOnClick;
                    LayoutCountFollowing.Click += LayoutCountFollowingOnClick;
                    LayoutCountLikes.Click += LayoutCountLikesOnClick; 
                }
                else
                {
                    BtnAddUser.Click -= BtnAddUserOnClick;
                    BtnMessage.Click -= BtnMessageOnClick;
                    BtnMore.Click -= BtnMoreOnClick;
                    IconBack.Click -= IconBackOnClick;
                    LayoutCountFollowers.Click -= LayoutCountFollowersOnClick;
                    LayoutCountFollowing.Click -= LayoutCountFollowingOnClick;
                    LayoutCountLikes.Click -= LayoutCountLikesOnClick; 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Get Profile

        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { GetProfileApi, GetAlbumUserApi, () => MainRecyclerView.FetchNewsFeedApiPosts("0")});
        }

        private async Task GetProfileApi()
        {
            var (apiStatus, respond) = await RequestsAsync.Global.Get_User_Data(SUserId);

            if (apiStatus != 200 || !(respond is GetUserDataObject result) || result.UserData == null)
            {
                Methods.DisplayReportResult(this, respond);
            }
            else
            {
                if (!IsPassedDataLoaded)
                    LoadPassedDate(result.UserData);

                if (result.Family.Count > 0 )
                {
                    var data = result.Family.FirstOrDefault(o => o.UserData.UserId == UserDetails.UserId);
                    IsFamily = data != null;
                }
                else
                {
                    IsFamily = false;
                }
                 
                BtnMore.Visibility = ViewStates.Visible;

                if (result.UserData.UserId != UserDetails.UserId)
                {
                    SCanFollow = result.UserData.CanFollow;

                    if (SCanFollow == "0" && result.UserData.IsFollowing == "0")
                        BtnAddUser.Visibility = ViewStates.Gone;

                    SetProfilePrivacy(result.UserData);
                }
                else
                {
                    BtnAddUser.Visibility = ViewStates.Gone;
                }

                if (result.Followers.Count > 0)
                {
                   //var ListDataUserFollowers = new ObservableCollection<UserDataObject>(result.Followers);
                }

                if (result.LikedPages.Count > 0)
                    RunOnUiThread(() => { LoadPagesLayout(result.LikedPages); });

                if (result.JoinedGroups.Count > 0)
                    RunOnUiThread(() => { LoadGroupsLayout(result.JoinedGroups, Methods.FunString.FormatPriceValue(int.Parse(result.UserData.Details.GroupsCount))); });

                if (SPrivacyFriend == "0" || result.UserData?.IsFollowing == "1" && SPrivacyFriend == "1" || SPrivacyFriend == "2")
                    if (result.Followers.Count > 0)
                        RunOnUiThread(() => { LoadFriendsLayout(result.Followers, Methods.FunString.FormatPriceValue(int.Parse(result.UserData.Details.FollowersCount))); });

                var postPrivacy = "0"; 
                if (result.UserData.PostPrivacy.Contains("everyone"))
                {
                    postPrivacy = "1";
                }
                else if (result.UserData.PostPrivacy.Contains("ifollow") && result.UserData?.IsFollowing == "1" && result.UserData?.IsFollowingMe == "1")
                {
                    postPrivacy = "1";
                }
                else if (result.UserData.PostPrivacy.Contains("me")) //Lbl_People_Follow_Me
                {
                    postPrivacy = "1";
                }
                else // Lbl_No_body
                {
                    postPrivacy = "0";
                }

                if (postPrivacy == "1")
                {
                    var addPostBox = new AdapterModelsClass
                    {
                        TypeView = PostModelType.AddPostBox,
                        Id = 2
                    };

                    //##Set the AddBox place on Main RecyclerView
                    //------------------------------------------------------------------------
                    var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.PagesBox);
                    var check2 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.GroupsBox);
                    var check3 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.FollowersBox);
                    var check4 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.ImagesBox);
                    var check5 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AboutBox);
                    var check6 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.EmptyState);

                    if (check != null)
                    {
                        PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check) + 1, addPostBox);
                        PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check) + 1);
                    }
                    else if (check2 != null)
                    {
                        PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check2) + 1, addPostBox);
                        PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check2) + 1);
                    }
                    else if (check3 != null)
                    {
                        PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check3) + 1, addPostBox);
                        PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check3) + 1);
                    }
                    else if (check4 != null)
                    {
                        PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check4) + 1, addPostBox);
                        PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check4) + 1);
                    }
                    else if (check5 != null)
                    {
                        PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check5) + 1, addPostBox);
                        PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check5) + 1);
                    }
                    else if (check6 != null)
                    {
                        PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check6) + 1, addPostBox);
                        PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check6) + 1);
                    }
                    //------------------------------------------------------------------------

                }

            } 
        }

        private async Task GetAlbumUserApi()
        {
            var (apiStatus, respond) = await RequestsAsync.Album.Get_User_Image(SUserId); 
            if (apiStatus != 200 || !(respond is GetImagesObject result) || result.Albums == null)
            {
                Methods.DisplayReportResult(this, respond);
            }
            else
            {
                BtnMore.Visibility = ViewStates.Visible;
                if (result.Albums.Count > 0)
                {
                    var listPhoto = new List<PostDataObject>();

                    foreach (var photo in result.Albums)
                        if (!string.IsNullOrEmpty(photo.PostFileFull))
                            listPhoto.Add(photo);

                    var count = listPhoto.Count;
                    if (count > 10)
                        RunOnUiThread(() => { LoadImagesLayout(listPhoto.Take(9).ToList(), Methods.FunString.FormatPriceValue(int.Parse(count.ToString()))); });
                    else if (count > 5)
                        RunOnUiThread(() => { LoadImagesLayout(listPhoto.Take(6).ToList(), Methods.FunString.FormatPriceValue(int.Parse(count.ToString()))); });
                    else if (count > 0)
                        RunOnUiThread(() => { LoadImagesLayout(listPhoto.ToList(), Methods.FunString.FormatPriceValue(int.Parse(count.ToString()))); });
                }
            }
        }

        private void LoadPassedDate(UserDataObject result)
        {
            try
            {
                UserData = result;
                //TxtUsername.Text = result.Name;
                SUrlUser = result.Url;

                var font = Typeface.CreateFromAsset(Application.Context.Resources.Assets, "ionicons.ttf");
                TxtUsername.SetTypeface(font, TypefaceStyle.Normal);

                var textHighLighter = result.Name;
                var textIsPro = string.Empty;


                if (result.Verified == "1")
                    textHighLighter += " " + IonIconsFonts.CheckmarkCircled;

                if (result.IsPro == "1")
                {
                    textIsPro = " " + IonIconsFonts.Flash;
                    textHighLighter += textIsPro;
                }
                 
                var decorator = TextDecorator.Decorate(TxtUsername, textHighLighter);

                if (result.Verified == "1")
                    decorator.SetTextColor(Resource.Color.Post_IsVerified, IonIconsFonts.CheckmarkCircled);

                if (result.IsPro == "1") { }
                decorator.SetTextColor(Resource.Color.white, textIsPro);

                decorator.Build();


                if (result.LastseenStatus == "on")
                    OnlineView.Visibility = ViewStates.Visible;

                if (result.UserId == UserDetails.UserId)
                    BtnAddUser.Visibility = ViewStates.Gone;

                var checkAboutBox = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AboutBox);
                if (checkAboutBox == null)
                {
                    var aboutBox = new AdapterModelsClass
                    {
                        TypeView = PostModelType.AboutBox,
                        Id = 0000,
                        AboutModel = new AboutModelClass { Description = WoWonderTools.GetAboutFinal(result) },
                    };
                     
                    PostFeedAdapter.PostFeedList.Insert(0, aboutBox);
                    PostFeedAdapter.NotifyItemInserted(0);
                }
                else
                {
                    checkAboutBox.AboutModel.Description = WoWonderTools.GetAboutFinal(result); 
                    PostFeedAdapter.NotifyItemChanged(0);
                }

                GlideImageLoader.LoadImage(this, result.Avatar, UserProfileImage, ImageStyle.CircleCrop, ImagePlaceholders.Color, false);
                //GlideImageLoader.LoadImage(this, result.Cover, CoverImage, ImageStyle.FitCenter, ImagePlaceholders.Color, false);
                Glide.With(this).Load(result.Cover).Apply(new RequestOptions()).Into(CoverImage);

                //Set Privacy User
                //==================================
                SPrivacyBirth = result.BirthPrivacy;
                SPrivacyFollow = result.FollowPrivacy;
                SPrivacyFriend = result.FriendPrivacy;
                SPrivacyMessage = result.MessagePrivacy;
                TxtCountLikes.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Details.LikesCount));

                SetProfilePrivacy(result);

                if (AppSettings.ShowUserPoint)
                    TxtCountPoints.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Points));  

                if (result.Details != null)
                {
                    // Following
                    if (AppSettings.ConnectivitySystem == 1)
                    {
                        TxtFollowers.Text = GetText(Resource.String.Lbl_Followers);
                        TxtFollowing.Text = GetText(Resource.String.Lbl_Following);

                        TxtCountFollowers.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Details.FollowersCount));
                        TxtCountFollowing.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Details.FollowingCount));

                        LayoutCountFollowing.Tag = "Following";
                    }
                    else // Friend
                    {
                        TxtFollowers.Text = GetText(Resource.String.Lbl_Friends);
                        TxtFollowing.Text = GetText(Resource.String.Lbl_Post);

                        TxtCountFollowers.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Details.FollowersCount));
                        TxtCountFollowing.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Details.PostCount));

                        LayoutCountFollowing.Tag = "Post";
                    }
                }

                IsPassedDataLoaded = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        private void SetAddFriendCondition()
        {
            try
            {
                if (BtnAddUser.Tag?.ToString() == "Add") //(is_following == "0") >> Not Friend
                {
                    BtnAddUser.SetColor(Color.ParseColor("#efefef"));
                    BtnAddUser.SetImageResource(Resource.Drawable.ic_tick);
                    BtnAddUser.Drawable.SetTint(Color.ParseColor("#444444"));
                    BtnAddUser.Tag = "friends";
                }
                else if (BtnAddUser.Tag?.ToString() == "request") //(is_following == "2") >> Request
                {
                    BtnAddUser.SetColor(Color.ParseColor("#efefef"));
                    BtnAddUser.SetImageResource(Resource.Drawable.ic_tick);
                    BtnAddUser.Drawable.SetTint(Color.ParseColor("#444444"));
                    BtnAddUser.Tag = "Add";
                }
                else //(is_following == "1") >> Friend
                {
                    BtnAddUser.SetColor(Color.ParseColor("#6666ff"));
                    BtnAddUser.SetImageResource(Resource.Drawable.ic_add);
                    BtnAddUser.Drawable.SetTint(Color.ParseColor("#ffffff"));
                    BtnAddUser.Tag = "Add";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            } 
        }

        private void SetProfilePrivacy(UserDataObject result)
        {
            try
            {
                if (result.IsFollowing == "0")
                    BtnAddUser.Tag = "friends";
                else if (result.IsFollowing == "1")
                    BtnAddUser.Tag = "Add";
                 
                SetAddFriendCondition();
                 
                switch (SPrivacyFollow)
                {
                    // Everyone
                    case "0":
                        BtnAddUser.Visibility = ViewStates.Visible;
                        break;
                    // People i Follow
                    case "1":
                        if (result.IsFollowingMe == "0" && result.IsFollowing == "0")
                            BtnAddUser.Visibility = ViewStates.Gone;
                        else
                            BtnAddUser.Visibility = result.IsFollowingMe == "0" ? ViewStates.Visible : ViewStates.Gone;
                        break;
                    //Nobody
                    default:
                        BtnAddUser.Visibility = ViewStates.Gone;
                        break;
                }

                if (AppSettings.MessengerIntegration)
                {
                    switch (SPrivacyMessage)
                    {
                        // Everyone
                        case "0":
                            BtnMessage.Visibility = ViewStates.Visible;
                            break;
                        // People i Follow
                        case "1":
                            if (result.IsFollowingMe == "0" && result.IsFollowing == "0")
                                BtnMessage.Visibility = ViewStates.Gone;
                            else
                                BtnMessage.Visibility = result.IsFollowingMe == "0" ? ViewStates.Visible : ViewStates.Gone;
                            break;
                        //Nobody
                        default:
                            BtnMessage.Visibility = ViewStates.Gone;
                            break;
                    }
                }
                else
                {
                    BtnMessage.Visibility = ViewStates.Gone;
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            } 
        }

        private void LoadFriendsLayout(List<UserDataObject> followers, string friendsCounter)
        {
            try
            {
                BtnMore.Visibility = ViewStates.Visible;


                var followersClass = new FollowersModelClass();
                followersClass.TitleHead = GetText(AppSettings.ConnectivitySystem == 1 ? Resource.String.Lbl_Following : Resource.String.Lbl_Friends);
                followersClass.FollowersList = new List<UserDataObject>(followers.Take(12));
                followersClass.More = friendsCounter;

                var followersBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.FollowersBox,
                    Id = 1111111111,
                    FollowersModel = followersClass
                };

                var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.ImagesBox);
                if (check != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check) + 1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check) + 1);
                }
                else
                {
                    PostFeedAdapter.PostFeedList.Insert(1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(1);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadImagesLayout(List<PostDataObject> images, string imagesCounter)
        {
            try
            { 
                var imagesClass = new ImagesModelClass
                {
                    TitleHead = GetText(Resource.String.Lbl_Profile_Picture),
                    ImagesList = images,
                    More = images.Count.ToString()
                };
                var imagesBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.ImagesBox,
                    Id = 444444444,
                    ImagesModel = imagesClass
                };
                 
                PostFeedAdapter.PostFeedList.Insert(1, imagesBox);
                PostFeedAdapter.NotifyItemInserted(1);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadPagesLayout(List<PageClass> pages)
        {
            try
            {
                var pagesClass = new PagesModelClass { PagesList = new List<PageClass>(pages) };

                var followersBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.PagesBox,
                    Id = 333333333,
                    PagesModel = pagesClass
                };

                var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.ImagesBox);
                if (check != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check) + 1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check) + 1);
                }
                else
                {
                    PostFeedAdapter.PostFeedList.Insert(1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(1);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadGroupsLayout(List<GroupClass> groups, string groupsCounter)
        {
            try
            {
                var groupsClass = new GroupsModelClass
                {
                    TitleHead = GetText(Resource.String.Lbl_Groups),
                    GroupsList = new List<GroupClass>(groups.Take(12)),
                    More = groupsCounter,
                    UserProfileId = SUserId
                };

                var followersBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.GroupsBox,
                    Id = 222222222,
                    GroupsModel = groupsClass
                };

                var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.ImagesBox);
                if (check != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check) + 1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check) + 1);
                }
                else
                {
                    PostFeedAdapter.PostFeedList.Insert(1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(1);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Event

        //Event Show More : Block User , Copy Link To Profile
        private void BtnMoreOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetText(Resource.String.Lbl_Block));
                arrayAdapter.Add(GetText(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Share));

                arrayAdapter.Add(IsPoked ? GetText(Resource.String.Lbl_Poked) : GetText(Resource.String.Lbl_Poke));
                 
                if (!IsFamily)
                    arrayAdapter.Add(GetText(Resource.String.Lbl_AddToFamily));

                if (ListUtils.GiftsList.Count > 0)
                    arrayAdapter.Add(GetText(Resource.String.Lbl_SentGift));
                 
                dialogList.Title(Resource.String.Lbl_More);
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Send Messages To User
        private void BtnMessageOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                Methods.App.OpenAppByPackageName(this, AppSettings.MessengerPackageName, SUserId, UserData);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Add Friends Or Follower User
        private async void BtnAddUserOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short)
                        .Show();
                }
                else
                {
                    SetAddFriendCondition();

                    var (apiStatus, respond) = await RequestsAsync.Global.Follow_User(SUserId).ConfigureAwait(false);

                    if (apiStatus != 200 || !(respond is FollowUserObject result) || result.FollowStatus == null)
                    {
                        Methods.DisplayReportResult(this, respond);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Back
        private void IconBackOnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                Finish();
                OverridePendingTransition(Resource.Animation.slide_out_left, Resource.Animation.slide_out_left);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Show All Users Followers 
        private void LayoutCountFollowersOnClick(object sender, EventArgs e)
        {
            try
            {
                var intent = new Intent(this, typeof(MyContactsActivity));
                intent.PutExtra("ContactsType", "Followers");
                intent.PutExtra("UserId", SUserId);
                StartActivity(intent);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Show All Page Likes
        private void LayoutCountLikesOnClick(object sender, EventArgs e)
        {
            try
            {
                var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.PagesBox);
                if (check != null)
                { 
                    var Int = new Intent(this, typeof(AllViewerActivity));
                    Int.PutExtra("Type", "PagesModel"); //StoryModel , FollowersModel , GroupsModel , PagesModel
                    Int.PutExtra("itemObject", JsonConvert.SerializeObject(check));
                    StartActivity(Int);
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Show All Users Following  
        private void LayoutCountFollowingOnClick(object sender, EventArgs e)
        {
            try
            {
                if (LayoutCountFollowing.Tag.ToString() == "Following")
                {
                    var intent = new Intent(this, typeof(MyContactsActivity));
                    intent.PutExtra("ContactsType", "Following");
                    intent.PutExtra("UserId", SUserId);
                    StartActivity(intent);
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion Event

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == GetText(Resource.String.Lbl_Block))
                {
                    BlockUserButtonClick();
                }
                else if (text == GetText(Resource.String.Lbl_CopeLink))
                {
                    OnCopeLinkToProfile_Button_Click();
                }
                else if (text == GetText(Resource.String.Lbl_Share))
                {
                    OnShare_Button_Click();
                }
                else if (text == GetText(Resource.String.Lbl_Poke))
                {
                    if (Methods.CheckConnectivity())
                    {
                        IsPoked = true;
                        Toast.MakeText(this, GetString(Resource.String.Lbl_YouHavePoked), ToastLength.Short).Show();

                        RequestsAsync.Global.CreatePoke(SUserId).ConfigureAwait(false);
                    }
                    else
                        Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else if (text == GetText(Resource.String.Lbl_Poked))
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_YouSentPoked), ToastLength.Short).Show(); 
                } 
                else if (text == GetText(Resource.String.Lbl_AddToFamily))
                {
                    if (ListUtils.FamilyList.Count > 0)
                    {
                        var arrayAdapter = new List<string>();
                        var dialogList = new MaterialDialog.Builder(this);

                        foreach (var item in ListUtils.FamilyList)
                            arrayAdapter.Add(item.FamilyName.Replace("_"," "));

                        dialogList.Title(GetText(Resource.String.Lbl_AddToFamily));
                        dialogList.Items(arrayAdapter);
                        dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                        dialogList.AlwaysCallSingleChoiceCallback();
                        dialogList.ItemsCallback(this).Build().Show();
                    }
                }
                else if (text == GetText(Resource.String.Lbl_SentGift))
                {
                    GiftButtonOnClick();
                }
                else
                { 
                   var familyId = ListUtils.FamilyList.FirstOrDefault(a => a.FamilyName == itemString.ToString())?.FamilyId;
                   if (!string.IsNullOrEmpty(familyId))
                   {
                       IsFamily = true;
                       Toast.MakeText(this,GetText(Resource.String.Lbl_Sent_successfully), ToastLength.Short).Show();
                       RequestsAsync.Global.AddToFamilyAsync(SUserId, familyId).ConfigureAwait(false);
                   } 
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Block User
        private async void BlockUserButtonClick()
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short)
                        .Show();
                }
                else
                {
                    var (apiStatus, respond) = await RequestsAsync.Global.Block_User(SUserId, true).ConfigureAwait(true); //true >> "block"
                    if (apiStatus == 200)
                    {
                        var dbDatabase = new SqLiteDatabase();
                        dbDatabase.Delete_UsersContact(SUserId);
                        dbDatabase.Dispose();

                        Toast.MakeText(this, GetString(Resource.String.Lbl_Blocked_successfully), ToastLength.Short).Show();
                        Finish();
                    }
                    else Methods.DisplayReportResult(this, respond);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Cope Link To Profile
        private void OnCopeLinkToProfile_Button_Click()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", SUrlUser);
                clipboardManager.PrimaryClip = clipData;


                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Share
        private async void OnShare_Button_Click()
        {
            try
            {
                //Share Plugin same as video
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = UserDetails.Username,
                    Text = "",
                    Url = SUrlUser
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Sent Gift
        private void GiftButtonOnClick()
        {
            try
            {
                Bundle bundle = new Bundle();
                bundle.PutString("UserId", SUserId);

                GiftDialogFragment mGiftFragment = new GiftDialogFragment
                {
                    Arguments = bundle
                };

                mGiftFragment.Show(SupportFragmentManager, mGiftFragment.Tag);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Result

        //Result
        protected override async void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

                if (requestCode == 2500 && resultCode == Result.Ok) //add post
                {
                    var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                   if (postData != null)
                   {
                       var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                       MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                       {
                           TypeView = postType,
                           Id = int.Parse(postData.Id),
                           PostData = postData,
                           IsDefaultFeedPost = true,
                       });
                   }
                   else
                    await MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                }
                else if (requestCode == 3950 && resultCode == Result.Ok) //Edit post
                {
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemChanged(index);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void GetGiftsLists()
        {
            try
            {
                var sqlEntity = new SqLiteDatabase();

                var listGifts = sqlEntity.GetGiftsList();

                if (ListUtils.GiftsList.Count > 0 && listGifts != null)
                    ListUtils.GiftsList = listGifts;
                else
                    ApiRequest.GetGifts().ConfigureAwait(false);

                sqlEntity.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void GetDataUserByName()
        {
            try
            {
                var dictionary = new Dictionary<string, string>
                {
                    {"user_id", UserDetails.UserId},
                    {"limit", "30"},
                    {"user_offset", "0"},
                    {"gender", UserDetails.SearchGender},
                    {"search_key", SUserName},
                };

                (int apiStatus, var respond) = await RequestsAsync.Global.Get_Search(dictionary);
                if (apiStatus == 200)
                {
                    if (respond is GetSearchObject result)
                    {
                        var respondUserList = result.Users?.Count;
                        if (respondUserList > 0)
                        {
                            UserData = result.Users.FirstOrDefault(a => a.Username == SUserName);
                            if (UserData != null)
                            {
                                SUserId = UserData.UserId;

                                SetRecyclerViewAdapters();

                                LoadPassedDate(UserData);
                                 
                                StartApiService();
                            }
                            else
                            {
                                Finish();
                                Toast.MakeText(this, GetText(Resource.String.Lbl_NotHaveThisUser), ToastLength.Short).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_No_more_users), ToastLength.Short).Show();
                        }
                    }
                }
                else Methods.DisplayReportResult(this, respond);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}