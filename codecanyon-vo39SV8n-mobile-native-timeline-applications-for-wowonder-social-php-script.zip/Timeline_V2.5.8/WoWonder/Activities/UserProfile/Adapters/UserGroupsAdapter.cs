﻿using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.App;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using Java.Util;
using WoWonder.Activities.Communities.Groups;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using IList = System.Collections.IList;

namespace WoWonder.Activities.userProfile.Adapters
{
    public class UserGroupsAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<UserGroupsAdapterClickEventArgs> ItemClick;
        public event EventHandler<UserGroupsAdapterClickEventArgs> ItemLongClick;

        private readonly Activity ActivityContext;
        public ObservableCollection<GroupClass> UserGroupsList = new ObservableCollection<GroupClass>();

        public UserGroupsAdapter(Activity context)
        {
            try
            { 
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (UserGroupsList != null)
                    return UserGroupsList.Count;
                return 0;
            }
        }


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Group_Simple
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Group_Simple, parent, false);
                var vh = new UserGroupsAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (!(viewHolder is UserGroupsAdapterViewHolder holder))
                    return;

                var item = UserGroupsList[position];
                if (item == null)
                    return;

                GlideImageLoader.LoadImage(ActivityContext, item.Avatar, holder.Image, ImageStyle.CenterCrop,ImagePlaceholders.Drawable, false);

                var name = Methods.FunString.DecodeString(item.Name);
                holder.Name.Text = Methods.FunString.SubStringCutOf(name, 20);

                item.IsOwner = item.UserId == UserDetails.UserId;

                if (!holder.MainView.HasOnClickListeners)
                {
                    holder.MainView.Click += (sender, args) =>
                    {
                        MainApplication.GetInstance()?.NavigateTo(ActivityContext, typeof(GroupProfileActivity), item);
                    };
                }
                
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        public GroupClass GetItem(int position)
        {
            return UserGroupsList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(UserGroupsList[position].UserId);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(UserGroupsAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(UserGroupsAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }


        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = UserGroupsList[p0];
                if (item == null)
                    return d;
                else
                {
                    if (!string.IsNullOrEmpty(item.Avatar))
                        d.Add(item.Avatar);

                    return d;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
               return Collections.SingletonList(p0);
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Java.Lang.Object p0)
        {
            return Glide.With(ActivityContext).Load(p0.ToString())
                .Apply(new RequestOptions().CircleCrop());
        } 
    }

    public class UserGroupsAdapterViewHolder : RecyclerView.ViewHolder
    {
        public UserGroupsAdapterViewHolder(View itemView, Action<UserGroupsAdapterClickEventArgs> clickListener,Action<UserGroupsAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;
                Image = MainView.FindViewById<ImageView>(Resource.Id.ImageGroup);
                Name = MainView.FindViewById<TextView>(Resource.Id.Group_titile);

                itemView.Click += (sender, e) => clickListener(new UserGroupsAdapterClickEventArgs { View = itemView, Position = AdapterPosition });
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic

        public View MainView { get; }
        public ImageView Image { get; set;}
        public TextView Name { get; set;}

        #endregion
    }

    public class UserGroupsAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}