﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Preferences;
using WoWonderClient;

namespace WoWonder.Activities.SettingsPreferences.Support
{
    public class SettingsSupportPrefsFragment : PreferenceFragment, ISharedPreferencesOnSharedPreferenceChangeListener
    {
        public SettingsSupportPrefsFragment(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //On Change
        public void OnSharedPreferenceChanged(ISharedPreferences sharedPreferences, string key)
        {
            try
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

      
        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                // Create your fragment here
                AddPreferencesFromResource(Resource.Xml.SettingsPrefs_Help_Support);

                WowTimeMainSettings.SharedData = PreferenceManager.SharedPreferences;

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                HelpPref = FindPreference("help_key");
                ReportProblemPref = FindPreference("Report_key");
                AboutAppPref = FindPreference("About_key");
                PrivacyPolicyPref = FindPreference("PrivacyPolicy_key");
                TermsOfUsePref = FindPreference("TermsOfUse_key");

                //Delete Preference
                var mCategorySupport = (PreferenceCategory) FindPreference("SectionSupport_key");
                if (!AppSettings.ShowSettingsHelp)
                    mCategorySupport.RemovePreference(HelpPref);

                if (!AppSettings.ShowSettingsReportProblem)
                    mCategorySupport.RemovePreference(ReportProblemPref);

                var mCategoryAbout = (PreferenceCategory) FindPreference("SectionAbout_key");
                if (!AppSettings.ShowSettingsAbout)
                    mCategoryAbout.RemovePreference(AboutAppPref);

                if (!AppSettings.ShowSettingsPrivacyPolicy)
                    mCategoryAbout.RemovePreference(PrivacyPolicyPref);

                if (!AppSettings.ShowSettingsTermsOfUse)
                    mCategoryAbout.RemovePreference(TermsOfUsePref);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnResume()
        {
            try
            {
                base.OnResume();
                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                //Add OnChange event to Preferences
                HelpPref.PreferenceClick += HelpPref_OnPreferenceClick;
                ReportProblemPref.PreferenceClick += ReportProblemPref_OnPreferenceClick;
                AboutAppPref.PreferenceClick += AboutAppPref_OnPreferenceClick;
                PrivacyPolicyPref.PreferenceClick += PrivacyPolicyPref_OnPreferenceClick;
                TermsOfUsePref.PreferenceClick += TermsOfUsePref_OnPreferenceClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnPause()
        {
            try
            {
                base.OnPause();
                PreferenceScreen.SharedPreferences.UnregisterOnSharedPreferenceChangeListener(this);

                //Close OnChange event to Preferences
                HelpPref.PreferenceClick -= HelpPref_OnPreferenceClick;
                ReportProblemPref.PreferenceClick -= ReportProblemPref_OnPreferenceClick;
                AboutAppPref.PreferenceClick -= AboutAppPref_OnPreferenceClick;
                PrivacyPolicyPref.PreferenceClick -= PrivacyPolicyPref_OnPreferenceClick;
                TermsOfUsePref.PreferenceClick -= TermsOfUsePref_OnPreferenceClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        //Terms Of Use
        private void TermsOfUsePref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                intent.PutExtra("URL", Client.WebsiteUrl + "/terms/terms");
                intent.PutExtra("Type",ActivityContext.GetString(Resource.String.Lbl_TermsOfUse));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Privacy Policy
        private void PrivacyPolicyPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                intent.PutExtra("URL", Client.WebsiteUrl + "/terms/privacy-policy");
                intent.PutExtra("Type", ActivityContext.GetString(Resource.String.Privacy_Policy));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //About Us
        private void AboutAppPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                intent.PutExtra("URL", Client.WebsiteUrl + "/terms/about-us");
                intent.PutExtra("Type", ActivityContext.GetString(Resource.String.Lbl_About_App));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Report a Problem
        private void ReportProblemPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                intent.PutExtra("URL", Client.WebsiteUrl + "/contact-us");
                intent.PutExtra("Type", ActivityContext.GetString(Resource.String.Lbl_Report_Problem));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Help
        private void HelpPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(LocalWebViewActivity));
                intent.PutExtra("URL", Client.WebsiteUrl + "/contact-us");
                intent.PutExtra("Type", ActivityContext.GetString(Resource.String.Lbl_Help));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        private Preference HelpPref;
        private Preference ReportProblemPref;
        private Preference AboutAppPref;
        private Preference PrivacyPolicyPref;
        private Preference TermsOfUsePref;

        private readonly Activity ActivityContext;

        #endregion
    }
}