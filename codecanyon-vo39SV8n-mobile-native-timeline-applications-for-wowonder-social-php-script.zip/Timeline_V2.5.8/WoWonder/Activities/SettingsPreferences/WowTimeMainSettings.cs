﻿using System;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Preferences;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;

namespace WoWonder.Activities.SettingsPreferences
{
    public static class WowTimeMainSettings
    {
        public static ISharedPreferences SharedData;
        public static string LocalLanguage = "";

        public static void Init()
        {
            try
            {
                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                dbDatabase.CheckTablesStatus();
                dbDatabase.OpenConnection();
                dbDatabase.Get_MyProfile();

                SharedData = PreferenceManager.GetDefaultSharedPreferences(Application.Context);
                var data = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (data != null)
                {
                    SharedData.Edit().PutString("whocanfollow_key", data.FollowPrivacy).Commit();
                    SharedData.Edit().PutString("whocanMessage_key", data.MessagePrivacy).Commit();
                    SharedData.Edit().PutString("whoCanSeeMyfriends_key", data.FriendPrivacy).Commit();
                    SharedData.Edit().PutString("whoCanPostOnMyTimeline_key", data.PostPrivacy).Commit();
                    SharedData.Edit().PutString("whoCanSeeMyBirthday_key", data.BirthPrivacy).Commit();
                    SharedData.Edit().PutString("ConfirmRequestFollows_key", data.ConfirmFollowers).Commit();
                    SharedData.Edit().PutString("ShowMyActivities_key", data.ShowActivitiesPrivacy).Commit();
                    SharedData.Edit().PutString("Status_key", data.Status).Commit();
                    SharedData.Edit().PutString("ShareMyLocation_key", data.ShareMyLocation).Commit();
                }

                //SetDefaultSettings(); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //public static void SetDefaultSettings()
        //{
        //    try
        //    {
              
        //        if (AppSettings.Lang != "")
        //        {
        //            if (AppSettings.Lang == "ar")
        //            {
        //                SharedData.Edit().PutString("Lang_key", "ar").Commit();
        //                AppSettings.Lang = "ar";
        //                AppSettings.FlowDirectionRightToLeft = true;
        //            }
        //            else
        //            {
        //                SharedData.Edit().PutString("Lang_key", AppSettings.Lang).Commit();
        //                AppSettings.FlowDirectionRightToLeft = false;
        //            }
        //        }
        //        else
        //        {
        //            AppSettings.FlowDirectionRightToLeft = false;

        //            var lang = SharedData.GetString("Lang_key", AppSettings.Lang);
        //            if (lang == "ar")
        //            {
        //                SharedData.Edit().PutString("Lang_key", "ar").Commit();
        //                AppSettings.Lang = "ar";
        //                AppSettings.FlowDirectionRightToLeft = true;
        //            }
        //            else if (lang == "Auto")
        //            {
        //                SharedData.Edit().PutString("Lang_key", "Auto").Commit();
        //            }
        //            else
        //            {
        //                SharedData.Edit().PutString("Lang_key", lang).Commit();
        //            }
        //        }
        //    }
        //    catch (Exception exception)
        //    {
        //        Console.WriteLine(exception);
        //    }
        //}

        //public static void SetApplicationLang(Context context, string lang)
        //{
        //    try
        //    { 
        //        var config = new Configuration();
        //        AppSettings.Lang = lang;

        //        if (string.IsNullOrEmpty(lang))
        //        {
        //            if (lang == "Auto" || lang == "")
        //            {
        //                config.Locale = Locale.Default;
        //                LocalLanguage = config.Locale.Language;
        //            }
        //            else
        //            {
        //                config.Locale = Locale.Default = new Locale(lang);
        //            }

        //            if (config.Locale.Language.Contains("ar"))
        //            {
        //                AppSettings.Lang = "ar";
        //                AppSettings.FlowDirectionRightToLeft = true;
        //            }
        //            else
        //            {
        //                AppSettings.FlowDirectionRightToLeft = false;
        //            }
        //        }
        //        else
        //        {
        //            config.Locale = Locale.Default = new Locale(lang);
        //            context.Resources.Configuration.Locale = Locale.Default = new Locale(lang);
        //            SharedData.Edit().PutString("Lang_key", lang).Commit();

        //            if (lang.Contains("ar"))
        //            {
        //                AppSettings.Lang = "ar";
        //                AppSettings.FlowDirectionRightToLeft = true;
        //            }
        //            else 
        //            {
        //                AppSettings.Lang = lang;
        //            }
        //        }

              

        //        SetDefaultSettings();


               
        //    }
        //    catch (Exception exception)
        //    {
        //        Console.WriteLine(exception);
        //    }
        //}
    }
}