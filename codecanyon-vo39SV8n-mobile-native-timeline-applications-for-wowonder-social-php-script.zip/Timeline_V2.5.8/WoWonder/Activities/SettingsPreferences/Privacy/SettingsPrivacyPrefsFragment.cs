﻿using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Preferences;
using Android.Widget;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Requests;

namespace WoWonder.Activities.SettingsPreferences.Privacy
{
    public class SettingsPrivacyPrefsFragment : PreferenceFragment, ISharedPreferencesOnSharedPreferenceChangeListener
    {
        public SettingsPrivacyPrefsFragment(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //On Change 
        public void OnSharedPreferenceChanged(ISharedPreferences sharedPreferences, string key)
        {
            try
            {
                var dataUser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (key.Equals("whocanfollow_key"))
                {
                    try
                    {
                        var valueAsText = PrivacyCanFollowPref.Entry;
                        if (!string.IsNullOrEmpty(valueAsText))
                        {
                            if (dataUser != null)
                            {
                                WowTimeMainSettings.SharedData.Edit()
                                    .PutString("whocanfollow_key", dataUser.FollowPrivacy).Commit();
                                PrivacyCanFollowPref.SetValueIndex(int.Parse(dataUser.FollowPrivacy));

                                SCanFollowPref = dataUser.FollowPrivacy;
                                if (SCanFollowPref == "0")
                                    PrivacyCanFollowPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_Everyone);
                                else
                                    PrivacyCanFollowPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_People_i_Follow);
                            }
                        }
                        else
                        {
                            SCanFollowPref = PrivacyCanFollowPref.Value;
                            PrivacyCanFollowPref.Summary = SCanFollowPref;
                            PrivacyCanFollowPref.SetValueIndex(dataUser != null ? int.Parse(dataUser?.MessagePrivacy): 0);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("whocanMessage_key"))
                {
                    try
                    {
                        var valueAsText = PrivacyCanMessagePref.Entry;
                        if (!string.IsNullOrEmpty(valueAsText))
                        {
                            if (dataUser != null)
                            {
                                WowTimeMainSettings.SharedData.Edit().PutString("whocanMessage_key", dataUser.MessagePrivacy).Commit();
                                PrivacyCanMessagePref.SetValueIndex(int.Parse(dataUser.MessagePrivacy));

                                SCanMessagePref = dataUser.MessagePrivacy;
                                if (SCanMessagePref == "0")
                                    PrivacyCanMessagePref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_Everyone);
                                else
                                    PrivacyCanMessagePref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_People_i_Follow);
                            }
                        }
                        else
                        {
                            SCanMessagePref = PrivacyCanMessagePref.Value;
                            PrivacyCanMessagePref.Summary = SCanMessagePref;
                            PrivacyCanMessagePref.SetValueIndex(dataUser != null
                                ? int.Parse(dataUser?.MessagePrivacy)
                                : 0);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("whoCanSeeMyfriends_key"))
                {
                    try
                    {
                        var valueAsText = PrivacyCanSeeMyfriendsPref.Entry;
                        if (!string.IsNullOrEmpty(valueAsText))
                        {
                            if (dataUser != null)
                            {
                                WowTimeMainSettings.SharedData.Edit()
                                    .PutString("whoCanSeeMyfriends_key", dataUser.FriendPrivacy).Commit();
                                PrivacyCanSeeMyfriendsPref.SetValueIndex(int.Parse(dataUser.FriendPrivacy));

                                SCanSeeMyfriendsPref = dataUser.FriendPrivacy;
                                if (SCanSeeMyfriendsPref == "0")
                                    PrivacyCanSeeMyfriendsPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_Everyone);
                                else if (SCanSeeMyfriendsPref == "1")
                                    PrivacyCanSeeMyfriendsPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_People_i_Follow);
                                else if (SCanSeeMyfriendsPref == "2")
                                    PrivacyCanSeeMyfriendsPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_People_Follow_Me);
                                else
                                    PrivacyCanSeeMyfriendsPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_No_body);
                            }
                        }
                        else
                        {
                            SCanSeeMyfriendsPref = PrivacyCanSeeMyfriendsPref.Value;
                            PrivacyCanSeeMyfriendsPref.Summary = SCanSeeMyfriendsPref;
                            PrivacyCanSeeMyfriendsPref.SetValueIndex(dataUser != null
                                ? int.Parse(dataUser?.FriendPrivacy)
                                : 0);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("whoCanPostOnMyTimeline_key"))
                {
                    try
                    {
                        var valueAsText = PrivacyCanPostOnMyTimelinePref.Entry;
                        if (!string.IsNullOrEmpty(valueAsText))
                        {
                            if (dataUser != null)
                            {
                                WowTimeMainSettings.SharedData.Edit()
                                    .PutString("whoCanPostOnMyTimeline_key", dataUser.PostPrivacy).Commit();
                                PrivacyCanPostOnMyTimelinePref.SetValueIndex(int.Parse(dataUser.PostPrivacy));

                                SCanPostOnMyTimelinePref = dataUser.PostPrivacy;

                                if (dataUser.PostPrivacy.Contains("everyone"))
                                {
                                    PrivacyCanPostOnMyTimelinePref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_Everyone);
                                }
                                else if (dataUser.PostPrivacy.Contains("ifollow"))
                                {
                                    PrivacyCanPostOnMyTimelinePref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_People_i_Follow);
                                }
                                else if (dataUser.PostPrivacy.Contains("me"))
                                {
                                    //PostPrivacyButton.Text = this.GetString(Resource.String.Lbl_People_Follow_Me);
                                }
                                else
                                {
                                    PrivacyCanPostOnMyTimelinePref.Summary = ActivityContext.GetString(Resource.String.Lbl_No_body);
                                }
                            }
                        }
                        else
                        {
                            SCanPostOnMyTimelinePref = PrivacyCanPostOnMyTimelinePref.Value;
                            PrivacyCanPostOnMyTimelinePref.Summary = SCanPostOnMyTimelinePref;

                            if (dataUser != null && dataUser.PostPrivacy.Contains("everyone"))
                                PrivacyCanPostOnMyTimelinePref.SetValueIndex(0);
                            else if (dataUser != null && dataUser.PostPrivacy.Contains("ifollow"))
                                PrivacyCanPostOnMyTimelinePref.SetValueIndex(1);
                            else
                                PrivacyCanPostOnMyTimelinePref.SetValueIndex(0);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("whoCanSeeMyBirthday_key"))
                {
                    try
                    {
                        var valueAsText = PrivacyCanSeeMyBirthdayPref.Entry;
                        if (!string.IsNullOrEmpty(valueAsText))
                        {
                            if (dataUser != null)
                            {
                                WowTimeMainSettings.SharedData.Edit()
                                    .PutString("whoCanSeeMyBirthday_key", dataUser.BirthPrivacy).Commit();
                                PrivacyCanSeeMyBirthdayPref.SetValueIndex(int.Parse(dataUser.BirthPrivacy));

                                SCanSeeMyBirthdayPref = dataUser.BirthPrivacy;
                                if (SCanSeeMyBirthdayPref == "0")
                                    PrivacyCanSeeMyBirthdayPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_Everyone);
                                else if (SCanSeeMyBirthdayPref == "1")
                                    PrivacyCanSeeMyBirthdayPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_People_i_Follow);
                                else
                                    PrivacyCanSeeMyBirthdayPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_No_body);
                            }
                        }
                        else
                        {
                            SCanSeeMyBirthdayPref = PrivacyCanSeeMyBirthdayPref.Value;
                            PrivacyCanSeeMyBirthdayPref.Summary = SCanSeeMyBirthdayPref;
                            PrivacyCanSeeMyBirthdayPref.SetValueIndex(dataUser != null
                                ? int.Parse(dataUser?.BirthPrivacy)
                                : 0);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("ConfirmRequestFollows_key"))
                {
                    try
                    {
                        var getvalue = WowTimeMainSettings.SharedData.GetBoolean("ConfirmRequestFollows_key", true);
                        PrivacyConfirmRequestFollowsPref.Checked = getvalue; 
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("ShowMyActivities_key"))
                {
                    try
                    {
                        var getvalue = WowTimeMainSettings.SharedData.GetBoolean("ShowMyActivities_key", true);
                        PrivacyShowMyActivitiesPref.Checked = getvalue;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("Status_key"))
                {
                    try
                    {
                        var valueAsText = PrivacyStatusPref.Entry;
                        if (!string.IsNullOrEmpty(valueAsText))
                        {
                            if (dataUser != null)
                            {
                                WowTimeMainSettings.SharedData.Edit().PutString("Status_key", dataUser.Status)
                                    .Commit();
                                PrivacyStatusPref.SetValueIndex(int.Parse(dataUser.Status));

                                SStatusPref = dataUser.Status;
                                if (SStatusPref == "0")
                                    PrivacyStatusPref.Summary = ActivityContext.GetString(Resource.String.Lbl_Online);
                                else
                                    PrivacyStatusPref.Summary =
                                        ActivityContext.GetString(Resource.String.Lbl_Offline);
                            }
                        }
                        else
                        {
                            SStatusPref = PrivacyStatusPref.Value;
                            PrivacyStatusPref.Summary = SStatusPref;
                            PrivacyStatusPref.SetValueIndex(dataUser != null ? int.Parse(dataUser?.Status) : 0);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else if (key.Equals("ShareMyLocation_key"))
                {
                    try
                    {
                        var getvalue = WowTimeMainSettings.SharedData.GetBoolean("ShareMyLocation_key", true);
                        PrivacyShareMyLocationPref.Checked = getvalue;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                // Create your fragment here
                AddPreferencesFromResource(Resource.Xml.SettingsPrefs_Privacy);

                WowTimeMainSettings.SharedData = PreferenceManager.SharedPreferences;

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                PrivacyCanFollowPref = (ListPreference) FindPreference("whocanfollow_key");
                PrivacyCanMessagePref = (ListPreference) FindPreference("whocanMessage_key");
                PrivacyCanSeeMyfriendsPref = (ListPreference) FindPreference("whoCanSeeMyfriends_key");
                PrivacyCanPostOnMyTimelinePref = (ListPreference) FindPreference("whoCanPostOnMyTimeline_key");
                PrivacyCanSeeMyBirthdayPref = (ListPreference) FindPreference("whoCanSeeMyBirthday_key");
                PrivacyConfirmRequestFollowsPref = (SwitchPreference) FindPreference("ConfirmRequestFollows_key");
                PrivacyShowMyActivitiesPref = (SwitchPreference) FindPreference("ShowMyActivities_key");
                PrivacyStatusPref = (ListPreference) FindPreference("Status_key");
                PrivacyShareMyLocationPref = (SwitchPreference) FindPreference("ShareMyLocation_key");

                if (ListUtils.MyProfileList.Count == 0)
                {
                    SqLiteDatabase sdDatabase = new SqLiteDatabase();
                    sdDatabase.Get_MyProfile();
                    sdDatabase.Dispose();
                }

                //Update Preferences data on Load
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "whocanfollow_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "whocanMessage_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "whoCanSeeMyfriends_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "whoCanPostOnMyTimeline_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "whoCanSeeMyBirthday_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "ConfirmRequestFollows_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "ShowMyActivities_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "Status_key");
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "ShareMyLocation_key");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnResume()
        {
            try
            {
                base.OnResume();
                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                //Add OnChange event to Preferences
                PrivacyCanFollowPref.PreferenceChange += PrivacyCanFollowPref_OnPreferenceChange;
                PrivacyCanMessagePref.PreferenceChange += PrivacyCanMessagePref_OnPreferenceChange;
                PrivacyCanSeeMyfriendsPref.PreferenceChange += PrivacyCanSeeMyfriendsPref_OnPreferenceChange;
                PrivacyCanPostOnMyTimelinePref.PreferenceChange += PrivacyCanPostOnMyTimelinePref_OnPreferenceChange;
                PrivacyCanSeeMyBirthdayPref.PreferenceChange += PrivacyCanSeeMyBirthdayPref_OnPreferenceChange;
                PrivacyConfirmRequestFollowsPref.PreferenceChange += PrivacyConfirmRequestFollowsPref_OnPreferenceChange;
                PrivacyShowMyActivitiesPref.PreferenceChange += PrivacyShowMyActivitiesPref_OnPreferenceChange;
                PrivacyStatusPref.PreferenceChange += PrivacyStatusPref_OnPreferenceChange;
                PrivacyShareMyLocationPref.PreferenceChange += PrivacyShareMyLocationPref_OnPreferenceChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnPause()
        {
            try
            {
                base.OnPause();
                PreferenceScreen.SharedPreferences.UnregisterOnSharedPreferenceChangeListener(this);

                //Close OnChange event to Preferences
                PrivacyCanFollowPref.PreferenceChange -= PrivacyCanFollowPref_OnPreferenceChange;
                PrivacyCanMessagePref.PreferenceChange -= PrivacyCanMessagePref_OnPreferenceChange;
                PrivacyCanSeeMyfriendsPref.PreferenceChange -= PrivacyCanSeeMyfriendsPref_OnPreferenceChange;
                PrivacyCanPostOnMyTimelinePref.PreferenceChange -= PrivacyCanPostOnMyTimelinePref_OnPreferenceChange;
                PrivacyCanSeeMyBirthdayPref.PreferenceChange -= PrivacyCanSeeMyBirthdayPref_OnPreferenceChange;
                PrivacyConfirmRequestFollowsPref.PreferenceChange -=PrivacyConfirmRequestFollowsPref_OnPreferenceChange;
                PrivacyShowMyActivitiesPref.PreferenceChange -= PrivacyShowMyActivitiesPref_OnPreferenceChange;
                PrivacyStatusPref.PreferenceChange -= PrivacyStatusPref_OnPreferenceChange;
                PrivacyShareMyLocationPref.PreferenceChange -= PrivacyShareMyLocationPref_OnPreferenceChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Who can follow me
        private void PrivacyCanFollowPref_OnPreferenceChange(object sender,Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (ListPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[int.Parse(value)];
                    etp.Summary = valueAsText;

                    SCanFollowPref = value;

                    if (Methods.CheckConnectivity())
                    {
                        var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (datauser != null) datauser.FollowPrivacy = SCanFollowPref;

                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"follow_privacy", SCanFollowPref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Who can message me
        private void PrivacyCanMessagePref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (ListPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[int.Parse(value)];
                    etp.Summary = valueAsText;

                    SCanMessagePref = value;

                    if (Methods.CheckConnectivity())
                    {
                        var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (datauser != null) datauser.MessagePrivacy = SCanMessagePref;

                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"message_privacy", SCanMessagePref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Who can see my friends
        private void PrivacyCanSeeMyfriendsPref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (ListPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[int.Parse(value)];
                    etp.Summary = valueAsText;

                    SCanSeeMyfriendsPref = value;

                    if (Methods.CheckConnectivity())
                    {
                        var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (datauser != null) datauser.FriendPrivacy = SCanSeeMyfriendsPref;

                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"friend_privacy", SCanSeeMyfriendsPref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Who can post on my timeline
        private void PrivacyCanPostOnMyTimelinePref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (ListPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[int.Parse(value)];
                    etp.Summary = valueAsText;

                    SCanPostOnMyTimelinePref = value;

                    if (Methods.CheckConnectivity())
                    {
                        var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (datauser != null) datauser.PostPrivacy = SCanPostOnMyTimelinePref;


                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"post_privacy", SCanPostOnMyTimelinePref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Who can see my birthday
        private void PrivacyCanSeeMyBirthdayPref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (ListPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[int.Parse(value)];
                    etp.Summary = valueAsText;

                    SCanSeeMyBirthdayPref = value;


                    if (Methods.CheckConnectivity())
                    {
                        var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (datauser != null) datauser.BirthPrivacy = SCanSeeMyBirthdayPref;

                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"birth_privacy", SCanSeeMyBirthdayPref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Confirm request when someone follows you
        private void PrivacyConfirmRequestFollowsPref_OnPreferenceChange(object sender,Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);

                    var etp = (SwitchPreference)sender;
                    var value = eventArgs.NewValue.ToString();
                    etp.Checked = bool.Parse(value);
                    if (etp.Checked)
                    {
                        SConfirmRequestFollowsPref = "1";
                        if (datauser != null) datauser.ConfirmFollowers = "1";
                    }
                    else
                    {
                        SConfirmRequestFollowsPref = "0";
                        if (datauser != null) datauser.ConfirmFollowers = "0";
                    }
                     
                    if (Methods.CheckConnectivity())
                    {
                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"confirm_followers", SConfirmRequestFollowsPref}
                        };
                       
                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        //Show my activities
        private void PrivacyShowMyActivitiesPref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                    var etp = (SwitchPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    etp.Checked = bool.Parse(value);
                    if (etp.Checked)
                    {
                        if (datauser != null) datauser.ShowActivitiesPrivacy = "1";
                        SShowMyActivitiesPref = "1";
                    }
                    else
                    {
                        if (datauser != null) datauser.ShowActivitiesPrivacy = "0";
                        SShowMyActivitiesPref = "0";
                    }

                    if (Methods.CheckConnectivity())
                    {
                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"show_activities_privacy", SShowMyActivitiesPref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Status
        private void PrivacyStatusPref_OnPreferenceChange(object sender, Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (ListPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    var valueAsText = etp.GetEntries()[int.Parse(value)];
                    etp.Summary = valueAsText;

                    SStatusPref = value;

                    if (Methods.CheckConnectivity())
                    {
                        var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                        if (datauser != null) datauser.Status = SStatusPref;

                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"status", SStatusPref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Share my location with public
        private void PrivacyShareMyLocationPref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                    var etp = (SwitchPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    etp.Checked = bool.Parse(value);
                    if (etp.Checked)
                    {
                        if (datauser != null) datauser.ShareMyLocation = "1";
                        SShareMyLocationPref = "1";
                    }
                    else
                    {
                        if (datauser != null) datauser.ShareMyLocation = "0";
                        SShareMyLocationPref = "0";
                    }

                   
                    if (datauser != null) datauser.ShareMyLocation = SShareMyLocationPref;

                    if (Methods.CheckConnectivity())
                    { 
                        var dataPrivacy = new Dictionary<string, string>
                        {
                            {"share_my_location", SShareMyLocationPref}
                        };

                        var data = RequestsAsync.Global.Update_User_Data(dataPrivacy).ConfigureAwait(false);
                    }
                    else
                    {
                        Toast.MakeText(ActivityContext,
                                ActivityContext.GetText(Resource.String.Lbl_CheckYourInternetConnection),
                                ToastLength.Long)
                            .Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        private ListPreference PrivacyCanFollowPref;
        private ListPreference PrivacyCanMessagePref;
        private ListPreference PrivacyCanSeeMyfriendsPref;
        private ListPreference PrivacyCanPostOnMyTimelinePref;
        private ListPreference PrivacyCanSeeMyBirthdayPref;
        private SwitchPreference PrivacyConfirmRequestFollowsPref;
        private SwitchPreference PrivacyShowMyActivitiesPref;
        private ListPreference PrivacyStatusPref;
        private SwitchPreference PrivacyShareMyLocationPref;
        public string SCanFollowPref = "0";
        public string SCanMessagePref = "0";
        public string SCanSeeMyfriendsPref = "0";
        public string SCanPostOnMyTimelinePref = "0";
        public string SCanSeeMyBirthdayPref = "0";
        public string SConfirmRequestFollowsPref = "0";
        public string SShowMyLastSeenPref = "0";
        public string SShowMyActivitiesPref = "0";
        public string SStatusPref = "0";
        public string SShareMyLocationPref = "0";

        private readonly Activity ActivityContext;

        #endregion
    }
}