﻿using System;
using System.Collections.Generic;
using System.Linq;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Preferences;
using Android.Widget;
using AndroidHUD;
using WoWonder.Activities.BlockedUsers;
using WoWonder.Activities.MyProfile;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Requests;
using Exception = System.Exception;

namespace WoWonder.Activities.SettingsPreferences.General
{
    public class GeneralAccountPrefsFragment : PreferenceFragment, ISharedPreferencesOnSharedPreferenceChangeListener,MaterialDialog.ISingleButtonCallback
    {
        public GeneralAccountPrefsFragment(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
 
        //On Change 
        public void OnSharedPreferenceChanged(ISharedPreferences sharedPreferences, string key)
        {
            try
            {
                var dataUser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);

                if (key.Equals("about_me_key"))
                {
                    // Set summary to be the user-description for the selected value
                    var etp = (EditTextPreference) FindPreference("about_me_key");
                    if (dataUser != null)
                    {
                        var about = WoWonderTools.GetAboutFinal(dataUser);
                        etp.EditText.Text = about;
                        etp.Text = about;
                    }

                    var getvalue = WowTimeMainSettings.SharedData.GetString("about_me_key", SAbout);
                    etp.EditText.Text = Methods.FunString.DecodeString(getvalue);
                    etp.Summary = Methods.FunString.DecodeString(getvalue);
                }
                //else if (key.Equals("Lang_key"))
                //{
                //    var valueAsText = LangPref.Entry;
                //    if (!string.IsNullOrEmpty(valueAsText))
                //    {
                //        AppSettings.FlowDirectionRightToLeft = false;
                //        if (valueAsText.ToLower().Contains("english"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "en").Commit();
                //            LangPref.SetValueIndex(1);
                //        }
                //        else if (valueAsText.ToLower().Contains("arabic"))
                //        {
                //            //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "ar").Commit();
                //            LangPref.SetValueIndex(2);
                //            AppSettings.FlowDirectionRightToLeft = true;
                //        }
                //        else if (valueAsText.ToLower().Contains("german"))
                //        {
                //            //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "de").Commit();
                //            LangPref.SetValueIndex(3);
                //        }
                //        else if (valueAsText.ToLower().Contains("greek"))
                //        {
                //            //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "el").Commit();
                //            LangPref.SetValueIndex(4);
                //        }
                //        else if (valueAsText.ToLower().Contains("spanish"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "es").Commit();
                //            LangPref.SetValueIndex(5);
                //        }
                //        else if (valueAsText.ToLower().Contains("french"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "fr").Commit();
                //            LangPref.SetValueIndex(6);
                //        }
                //        else if (valueAsText.ToLower().Contains("italian"))
                //        {
                //          //  WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "it").Commit();
                //            LangPref.SetValueIndex(7);
                //        }
                //        else if (valueAsText.ToLower().Contains("japanese"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "ja").Commit();
                //            LangPref.SetValueIndex(8);
                //        }
                //        else if (valueAsText.ToLower().Contains("dutch"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "nl").Commit();
                //            LangPref.SetValueIndex(9);
                //        }
                //        else if (valueAsText.ToLower().Contains("portuguese"))
                //        {
                //          //  WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "pt").Commit();
                //            LangPref.SetValueIndex(10);
                //        }
                //        else if (valueAsText.ToLower().Contains("romanian"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "ro").Commit();
                //            LangPref.SetValueIndex(11);
                //        }
                //        else if (valueAsText.ToLower().Contains("russian"))
                //        {
                //          //  WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "ru").Commit();
                //            LangPref.SetValueIndex(12);
                //        }
                //        else if (valueAsText.ToLower().Contains("russian"))
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "ru").Commit();
                //            LangPref.SetValueIndex(13);
                //        }
                //        else if (valueAsText.ToLower().Contains("albanian"))
                //        {
                //            //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "sq").Commit();
                //            LangPref.SetValueIndex(14);
                //        }
                //        else if (valueAsText.ToLower().Contains("serbian"))
                //        {
                //            //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "sr").Commit();
                //            LangPref.SetValueIndex(15);
                //        }
                //        else if (valueAsText.ToLower().Contains("turkish"))
                //        {
                //            //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "tr").Commit();
                //            LangPref.SetValueIndex(16);
                //        }
                //        else
                //        {
                //           // WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "Auto").Commit();
                //            LangPref.SetValueIndex(0);
                //        }
                //    }
                //    else
                //    {
                //        //WowTimeMainSettings.SharedData.Edit().PutString("Lang_key", "Auto").Commit();
                //        LangPref.SetValueIndex(0);
                //    }
                //}
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                    var intent = new Intent(ActivityContext, typeof(DeleteAccountActivity));
                    StartActivity(intent);

                   
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                AddPreferencesFromResource(Resource.Xml.SettingsPrefs_GeneralAccount);

                WowTimeMainSettings.SharedData = PreferenceManager.SharedPreferences;

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                EditProfilePref = FindPreference("editprofile_key");
                AboutMePref = (EditTextPreference) FindPreference("about_me_key");
                EditAccountPref = FindPreference("editAccount_key");
                EditSocialLinksPref = FindPreference("editSocialLinks_key");
                EditPasswordPref = FindPreference("editpassword_key");
                BlockedUsersPref = FindPreference("blocked_key");
                DeleteAccountPref = FindPreference("deleteaccount_key");

                //LangPref = (ListPreference) FindPreference("Lang_key");

                //Update Preferences data on Load
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "about_me_key");
                //OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "Lang_key");

                //Delete Preference
                var mCategoryAccount = (PreferenceCategory) FindPreference("SectionAccount_key");
                if (!AppSettings.ShowSettingsAccount)
                    mCategoryAccount.RemovePreference(EditAccountPref);

                if (!AppSettings.ShowSettingsSocialLinks)
                    mCategoryAccount.RemovePreference(EditSocialLinksPref);

                if (!AppSettings.ShowSettingsPassword)
                    mCategoryAccount.RemovePreference(EditPasswordPref);

                if (!AppSettings.ShowSettingsBlockedUsers)
                    mCategoryAccount.RemovePreference(BlockedUsersPref);

                if (!AppSettings.ShowSettingsDeleteAccount)
                    mCategoryAccount.RemovePreference(DeleteAccountPref);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnResume()
        {
            try
            {
                base.OnResume();
                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                //Add OnChange event to Preferences
                AboutMePref.PreferenceChange += AboutMePref_OnPreferenceChange;
                //LangPref.PreferenceChange += LangPref_OnPreferenceChange;

                EditProfilePref.PreferenceClick += EditProfilePref_OnPreferenceClick;
                EditAccountPref.PreferenceClick += EditAccountPrefOnPreferenceClick;
                EditSocialLinksPref.PreferenceClick += EditSocialLinksPref_OnPreferenceClick;
                EditPasswordPref.PreferenceClick += EditPasswordPref_OnPreferenceClick;
                BlockedUsersPref.PreferenceClick += BlockedUsersPref_OnPreferenceClick;
                DeleteAccountPref.PreferenceClick += DeleteAccountPref_OnPreferenceClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnPause()
        {
            try
            {
                base.OnPause();
                PreferenceScreen.SharedPreferences.UnregisterOnSharedPreferenceChangeListener(this);

                //Close OnChange event to Preferences
                AboutMePref.PreferenceChange -= AboutMePref_OnPreferenceChange;
                //LangPref.PreferenceChange -= LangPref_OnPreferenceChange;

                EditProfilePref.PreferenceClick -= EditProfilePref_OnPreferenceClick;
                EditAccountPref.PreferenceClick -= EditAccountPrefOnPreferenceClick;
                EditSocialLinksPref.PreferenceClick -= EditSocialLinksPref_OnPreferenceClick;
                EditPasswordPref.PreferenceClick -= EditPasswordPref_OnPreferenceClick;
                BlockedUsersPref.PreferenceClick -= BlockedUsersPref_OnPreferenceClick;
                DeleteAccountPref.PreferenceClick -= DeleteAccountPref_OnPreferenceClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Lang
        //private void LangPref_OnPreferenceChange(object sender, Preference.PreferenceChangeEventArgs eventArgs)
        //{
        //    try
        //    {
        //        if (eventArgs.Handled)
        //        {
        //            var etp = (ListPreference) sender;
        //            var value = eventArgs.NewValue;

        //            AppSettings.Lang = value.ToString();

        //            WowTimeMainSettings.SetApplicationLang(Activity, AppSettings.Lang);

        //            Toast.MakeText(ActivityContext, GetText(Resource.String.Lbl_Application_Restart), ToastLength.Long).Show();

        //            var intent = new Intent(Activity, typeof(SplashScreenActivity));
        //            intent.AddCategory(Intent.CategoryHome);
        //            intent.SetAction(Intent.ActionMain);
        //            intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
        //            Activity.StartActivity(intent);
        //            Activity.FinishAffinity();

        //            AppSettings.Lang = value.ToString();
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e);
        //    }
        //}

        //About me 
        private async void AboutMePref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs preferenceChangeEventArgs)
        {
            try
            {
                var etp = (EditTextPreference) sender;
                var value = etp.EditText.Text;
                etp.Summary = value;

                var datauser = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (datauser != null)
                {
                    datauser.About = etp.EditText.Text;
                    SAbout = etp.EditText.Text;
                }

                if (Methods.CheckConnectivity())
                {
                    var dictionaryProfile = new Dictionary<string, string>
                    {
                        {"about", SAbout}
                    };
                   
                    var (apiStatus, respond) = await RequestsAsync.Global.Update_User_Data(dictionaryProfile);
                    if (apiStatus == 200)
                    {
                        if (respond is MessageObject result)
                        {
                            if (result.Message.Contains("updated"))
                            {
                                Toast.MakeText(ActivityContext, result.Message, ToastLength.Short).Show();
                                AndHUD.Shared.Dismiss(ActivityContext);
                            }
                            else
                            {
                                //Show a Error image with a message
                                AndHUD.Shared.ShowError(ActivityContext, result.Message, MaskType.Clear,
                                    TimeSpan.FromSeconds(2));
                            }
                        }
                    }
                    else Methods.DisplayReportResult(ActivityContext, respond);
                }
                else
                {
                    Toast.MakeText(ActivityContext,
                            ActivityContext.GetString(Resource.String.Lbl_CheckYourInternetConnection),
                            ToastLength.Short)
                        .Show();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                AndHUD.Shared.Dismiss(ActivityContext);
            }
        }

        //Edit Profile
        private void EditProfilePref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(EditMyProfileActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Edit Account
        private void EditAccountPrefOnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(MyAccountActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Edit Social Links
        private void EditSocialLinksPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(EditSocialLinksActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Edit Password
        private void EditPasswordPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(PasswordActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Block users
        private void BlockedUsersPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var intent = new Intent(ActivityContext, typeof(BlockedUsersActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Delete Account  
        private void DeleteAccountPref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                var dialog = new MaterialDialog.Builder(ActivityContext);

                dialog.Title(Resource.String.Lbl_Warning);
                dialog.Content(ActivityContext.GetText(Resource.String.Lbl_Are_you_DeleteAccount) + " " + AppSettings.ApplicationName);
                dialog.PositiveText(ActivityContext.GetText(Resource.String.Lbl_Ok)).OnPositive(this);
                dialog.NegativeText(ActivityContext.GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                dialog.Build().Show();
                dialog.AlwaysCallSingleChoiceCallback();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        private Preference EditProfilePref;
        private EditTextPreference AboutMePref;
        private Preference EditAccountPref;
        private Preference EditSocialLinksPref;
        private Preference EditPasswordPref;
        private Preference BlockedUsersPref;
        private Preference DeleteAccountPref;

        //private ListPreference LangPref;
        private string SAbout = "";

        private readonly Activity ActivityContext;

        #endregion
    }
}