﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AndroidHUD;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.SettingsPreferences.General
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MyAccountActivity : AppCompatActivity, View.IOnClickListener
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                SetContentView(Resource.Layout.Settings_MyAccount_Layout);


                //Set ToolBar
                var toolBar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolBar != null)
                {
                    toolBar.Title = GetText(Resource.String.Lbl_My_Account);

                    SetSupportActionBar(toolBar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }

                //Get values
                TxtUsernameText = FindViewById<EditText>(Resource.Id.Username_text);

                TxtEmailText = FindViewById<EditText>(Resource.Id.Email_text);
                TxtBirthdayText = FindViewById<EditText>(Resource.Id.Birthday_text);
                TxtBirthdayText.SetOnClickListener(this);

                TxtGenderIcon = FindViewById<TextView>(Resource.Id.Gender_icon);
                RbMale = (RadioButton) FindViewById(Resource.Id.radioMale);
                RbFemale = (RadioButton) FindViewById(Resource.Id.radioFemale);

                TxtSave = FindViewById<TextView>(Resource.Id.toolbar_title);
               
                Get_Data_User();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();

                //Add Event
                RbMale.CheckedChange += RbMaleOnCheckedChange;
                RbFemale.CheckedChange += RbFemaleOnCheckedChange;
                TxtSave.Click += SaveData_OnClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();

                //Close Event
                RbMale.CheckedChange -= RbMaleOnCheckedChange;
                RbFemale.CheckedChange -= RbFemaleOnCheckedChange;
                TxtSave.Click -= SaveData_OnClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void Get_Data_User()
        {
            try
            {
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, TxtGenderIcon, IonIconsFonts.Male);

                var local = ListUtils.MyProfileList.FirstOrDefault(a => a.UserId == UserDetails.UserId);
                if (local != null)
                {
                    TxtUsernameText.Text = local.Username;
                    TxtEmailText.Text = local.Email;

                    try
                    {
                        DateTime date = DateTime.Parse(local.Birthday);
                        string newFormat = date.Day + "/" + date.Month + "/" + date.Year;
                        TxtBirthdayText.Text = newFormat;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        TxtBirthdayText.Text = local.Birthday;
                    }
                    
                    if (local.Gender == "male" || local.Gender == "Male")
                    {
                        RbMale.Checked = true;
                        RbFemale.Checked = false;
                        GenderStatus = "male";
                    }
                    else
                    {
                        RbMale.Checked = false;
                        RbFemale.Checked = true;
                        GenderStatus = "female";
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Save data 
        private async void SaveData_OnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    //Show a progress
                    AndHUD.Shared.Show(this, GetText(Resource.String.Lbl_Loading));

                    string newFormat = DateTime.ParseExact(TxtBirthdayText.Text, "dd'.'MM'.'yyyy", CultureInfo.InvariantCulture).ToString("dd-MM-yyyy");
                    var dictionary = new Dictionary<string, string>
                    {
                        {"username", TxtUsernameText.Text},
                        {"email", TxtEmailText.Text},
                        {"birthday", newFormat},
                        {"gender", GenderStatus}
                    };

                    var (apiStatus, respond) = await WoWonderClient.Requests.RequestsAsync.Global.Update_User_Data(dictionary);
                    if (apiStatus == 200)
                    {
                        if (respond is MessageObject result)
                        {
                            if (result.Message.Contains("updated"))
                            {
                                Toast.MakeText(this, result.Message, ToastLength.Short).Show();
                                AndHUD.Shared.Dismiss(this);
                            }
                            else
                            {
                                //Show a Error image with a message
                                AndHUD.Shared.ShowError(this, result.Message, MaskType.Clear, TimeSpan.FromSeconds(2));
                            }
                        }
                    }
                    else Methods.DisplayReportResult(this, respond);

                    AndHUD.Shared.Dismiss(this);
                }
                else
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short)
                        .Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                //Show a Error image with a message
                AndHUD.Shared.ShowError(this, e.Message, MaskType.Clear, TimeSpan.FromSeconds(2));
            }
        }


        private void RbFemaleOnCheckedChange(object sender,
            CompoundButton.CheckedChangeEventArgs checkedChangeEventArgs)
        {
            try
            {
                var isChecked = RbFemale.Checked;
                if (isChecked)
                {
                    RbMale.Checked = false;
                    GenderStatus = "female";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void RbMaleOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs checkedChangeEventArgs)
        {
            try
            {
                var isChecked = RbMale.Checked;
                if (isChecked)
                {
                    RbFemale.Checked = false;
                    GenderStatus = "male";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            { 
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         

        #region Variables Basic

        private EditText TxtUsernameText;
               
        private EditText TxtEmailText;
        private EditText TxtBirthdayText;
               
        private TextView TxtGenderIcon;
        private RadioButton RbMale;
        private RadioButton RbFemale;

        private TextView TxtSave;

        public string GenderStatus = "";

        #endregion

        public void OnClick(View v)
        {
            try
            {
                if (v.Id == TxtBirthdayText.Id)
                {
                    var frag = PopupDialogController.DatePickerFragment.NewInstance(delegate (DateTime time)
                    {
                        TxtBirthdayText.Text = time.ToShortDateString();
                    });
                    frag.Show(FragmentManager, PopupDialogController.DatePickerFragment.Tag);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}