﻿using System;
using Android.Content;
using Android.OS;
using Android.Preferences;
using WoWonder.Library.OneSignal;

namespace WoWonder.Activities.SettingsPreferences.Notification
{
    public class SettingsNotificationPrefsFragment : PreferenceFragment,
        ISharedPreferencesOnSharedPreferenceChangeListener
    {
        private SwitchPreference NotifcationPopupPref;

        //On Change
        public void OnSharedPreferenceChanged(ISharedPreferences sharedPreferences, string key)
        {
            try
            {
                if (key.Equals("notifications_key"))
                {
                    var getvalue = WowTimeMainSettings.SharedData.GetBoolean("notifications_key", true);
                    NotifcationPopupPref.Checked = getvalue;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

      
        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                // Create your fragment here
                AddPreferencesFromResource(Resource.Xml.SettingsPrefs_Notification);

                WowTimeMainSettings.SharedData = PreferenceManager.SharedPreferences;

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                NotifcationPopupPref = (SwitchPreference) FindPreference("notifications_key");


                //Update Preferences data on Load
                OnSharedPreferenceChanged(WowTimeMainSettings.SharedData, "notifications_key");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnResume()
        {
            try
            {
                base.OnResume();

                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                //Add OnChange event to Preferences
                NotifcationPopupPref.PreferenceChange += NotificationPopupPref_OnPreferenceChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnPause()
        {
            try
            {
                base.OnPause();
                PreferenceScreen.SharedPreferences.UnregisterOnSharedPreferenceChangeListener(this);

                //Close OnChange event to Preferences
                NotifcationPopupPref.PreferenceChange -= NotificationPopupPref_OnPreferenceChange;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Notification >> Popup 
        private void NotificationPopupPref_OnPreferenceChange(object sender,
            Preference.PreferenceChangeEventArgs eventArgs)
        {
            try
            {
                if (eventArgs.Handled)
                {
                    var etp = (SwitchPreference) sender;
                    var value = eventArgs.NewValue.ToString();
                    etp.Checked = bool.Parse(value);
                    if (etp.Checked)
                        OneSignalNotification.RegisterNotificationDevice();
                    else
                        OneSignalNotification.Un_RegisterNotificationDevice();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}