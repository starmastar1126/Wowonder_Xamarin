﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Preferences;
using Plugin.Share;
using Plugin.Share.Abstractions;

namespace WoWonder.Activities.SettingsPreferences.TellFriend
{
    public class TellFriendPrefsFragment : PreferenceFragment, ISharedPreferencesOnSharedPreferenceChangeListener
    {
        public TellFriendPrefsFragment(Activity context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //On Change 
        public void OnSharedPreferenceChanged(ISharedPreferences sharedPreferences, string key)
        {
            try
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                AddPreferencesFromResource(Resource.Xml.SettingsPrefs_TellFriend);

                WowTimeMainSettings.SharedData = PreferenceManager.SharedPreferences;

                SharePref = FindPreference("Share_key");
                MyAffiliatesPref = FindPreference("MyAffiliates_key");


                //Delete Preference
                var mCategoryInvite = (PreferenceCategory) FindPreference("SectionInvite_key");

                if (!AppSettings.ShowSettingsShare)
                    mCategoryInvite.RemovePreference(SharePref);

                if (!AppSettings.ShowSettingsMyAffiliates)
                    mCategoryInvite.RemovePreference(MyAffiliatesPref);

                InviteSmsText = GetText(Resource.String.Lbl_InviteSMSText_1) + " " + AppSettings.ApplicationName + " " +
                                GetText(Resource.String.Lbl_InviteSMSText_2);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnResume()
        {
            try
            {
                base.OnResume();
                PreferenceManager.SharedPreferences.RegisterOnSharedPreferenceChangeListener(this);

                //Add event to Preferences
                SharePref.PreferenceClick += SharePref_OnPreferenceClick;
                MyAffiliatesPref.PreferenceClick += MyAffiliatesPref_OnPreferenceClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnPause()
        {
            try
            {
                base.OnPause();
                PreferenceScreen.SharedPreferences.UnregisterOnSharedPreferenceChangeListener(this);

                //Add event to Preferences
                SharePref.PreferenceClick -= SharePref_OnPreferenceClick;
                MyAffiliatesPref.PreferenceClick -= MyAffiliatesPref_OnPreferenceClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        //Share App with your friends using Url This App in Market Google play 
        private async void SharePref_OnPreferenceClick(object sender,
            Preference.PreferenceClickEventArgs preferenceClickEventArgs)
        {
            try
            {
                //Share Plugin same as flame
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = AppSettings.ApplicationName,
                    Text = InviteSmsText,
                    Url = "http://play.google.com/store/apps/details?id=" + ActivityContext.PackageName
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        //My Affiliates
        private void MyAffiliatesPref_OnPreferenceClick(object sender, Preference.PreferenceClickEventArgs e)
        {
            try
            {
                var intent = new Intent(Application.Context, typeof(MyAffiliatesActivity));
                StartActivity(intent);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic

        private Preference SharePref;
        private Preference MyAffiliatesPref;
        private string InviteSmsText = "";
        private readonly Activity ActivityContext;

        #endregion
    }
}