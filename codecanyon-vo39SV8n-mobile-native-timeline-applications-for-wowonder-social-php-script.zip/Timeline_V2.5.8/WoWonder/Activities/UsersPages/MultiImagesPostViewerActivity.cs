﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.PostData;
using WoWonder.Activities.UsersPages.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.Library.Anjo;
using WoWonderClient.Classes.Album;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.UsersPages
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MultiImagesPostViewerActivity : AppCompatActivity 
    {
        #region Variables Basic

        private ViewPager ViewPager;
        private ImageView ImgLike, ImgWoWonder, ImgWonder;
        private TextView TxtDescription, TxtCountLike, TxtCountWoWonder, TxtWonder, ShareText;
        private LinearLayout MainSectionButton, BtnCountLike, BtnCountWoWonder, BtnLike, BtnComment, BtnShare, BtnWonder, InfoImageLiner;
        private RelativeLayout MainLayout;
        private PostDataObject PostData;
        private ReactButton LikeButton;
        private PostClickListener ClickListener;
        private int IndexImage;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            { 
                
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.MultiImagesPostViewerLayout);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                Get_DataImage();

                ClickListener = new PostClickListener(this);

                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            MenuInflater.Inflate(Resource.Menu.ImagePost, menu);

            return base.OnCreateOptionsMenu(menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;

                case Resource.Id.download:
                    Download_OnClick();
                    break;

                case Resource.Id.ic_action_comment:
                    Copy_OnClick();
                    break;
            }

            return base.OnOptionsItemSelected(item);
        }

        //Event Download Image  
        private void Download_OnClick()
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    var photos = PostData.PhotoMulti ?? PostData.PhotoAlbum;
                    IndexImage = ViewPager.CurrentItem;

                    Methods.MultiMedia.DownloadMediaTo_GalleryAsync(Methods.Path.FolderDcimImage, photos[IndexImage].Image);
                    Toast.MakeText(this, GetText(Resource.String.Lbl_ImageSaved), ToastLength.Short).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Copy link image 
        private void Copy_OnClick()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", PostData.Url);
                clipboardManager.PrimaryClip = clipData;

                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                ViewPager = (ViewPager)FindViewById(Resource.Id.view_pager);
                 
                TxtDescription = FindViewById<TextView>(Resource.Id.tv_description);
                ImgLike = FindViewById<ImageView>(Resource.Id.image_like1);
                ImgWoWonder = FindViewById<ImageView>(Resource.Id.image_wowonder);
                TxtCountLike = FindViewById<TextView>(Resource.Id.LikeText1);
                TxtCountWoWonder = FindViewById<TextView>(Resource.Id.WoWonderTextCount);
                 
                MainLayout = FindViewById<RelativeLayout>(Resource.Id.main);
                InfoImageLiner = FindViewById<LinearLayout>(Resource.Id.infoImageLiner);
                InfoImageLiner.Visibility = ViewStates.Visible;

                BtnCountLike = FindViewById<LinearLayout>(Resource.Id.linerlikeCount);
                BtnCountWoWonder = FindViewById<LinearLayout>(Resource.Id.linerwowonderCount);

                BtnLike = FindViewById<LinearLayout>(Resource.Id.linerlike);
                BtnComment = FindViewById<LinearLayout>(Resource.Id.linercomment);
                BtnShare = FindViewById<LinearLayout>(Resource.Id.linershare);

                MainSectionButton = FindViewById<LinearLayout>(Resource.Id.mainsection);
                BtnWonder = FindViewById<LinearLayout>(Resource.Id.linerSecondReaction);
                ImgWonder = FindViewById<ImageView>(Resource.Id.image_SecondReaction);
                TxtWonder = FindViewById<TextView>(Resource.Id.SecondReactionText);
                 
                LikeButton = FindViewById<ReactButton>(Resource.Id.beactButton);

                ShareText = FindViewById<TextView>(Resource.Id.ShareText);

                if (!AppSettings.ShowTextShareButton && ShareText != null)
                    ShareText.Visibility = ViewStates.Gone;

                if (AppSettings.PostButton == PostButtonSystem.Reaction || AppSettings.PostButton == PostButtonSystem.Like)
                {
                    MainSectionButton.WeightSum = 3;
                    BtnWonder.Visibility = ViewStates.Gone;

                    TxtCountWoWonder.Visibility = ViewStates.Gone;
                    BtnCountWoWonder.Visibility = ViewStates.Gone;
                    ImgWoWonder.Visibility = ViewStates.Gone;

                }
                else if (AppSettings.PostButton == PostButtonSystem.Wonder)
                {
                    MainSectionButton.WeightSum = 4;
                    BtnWonder.Visibility = ViewStates.Visible;

                    TxtCountWoWonder.Visibility = ViewStates.Visible;
                    BtnCountWoWonder.Visibility = ViewStates.Visible;
                    ImgWoWonder.Visibility = ViewStates.Visible;

                    ImgWoWonder.SetImageResource(Resource.Drawable.ic_action_wowonder);
                    ImgWonder.SetImageResource(Resource.Drawable.ic_action_wowonder);
                    TxtWonder.Text = Application.Context.GetText(Resource.String.Btn_Wonder);
                }
                else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                {
                    MainSectionButton.WeightSum = 4;
                    BtnWonder.Visibility = ViewStates.Visible;

                    TxtCountWoWonder.Visibility = ViewStates.Visible;
                    BtnCountWoWonder.Visibility = ViewStates.Visible;
                    ImgWoWonder.Visibility = ViewStates.Visible;

                    ImgWoWonder.SetImageResource(Resource.Drawable.ic_action_dislike);
                    ImgWonder.SetImageResource(Resource.Drawable.ic_action_dislike);
                    TxtWonder.Text = Application.Context.GetText(Resource.String.Btn_Dislike);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = " ";
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    BtnComment.Click += BtnCommentOnClick;
                    BtnShare.Click += BtnShareOnClick;
                    BtnCountLike.Click += BtnCountLikeOnClick;
                    BtnCountWoWonder.Click += BtnCountWoWonderOnClick;
                    InfoImageLiner.Click += MainLayoutOnClick;
                    MainLayout.Click += MainLayoutOnClick;

                    if (AppSettings.PostButton == PostButtonSystem.Wonder || AppSettings.PostButton == PostButtonSystem.DisLike)
                        BtnWonder.Click += BtnWonderOnClick;

                    LikeButton.Click += (sender, args) => LikeButton.ClickLikeAndDisLike(new GlobalClickEventArgs()
                    {
                        NewsFeedClass = PostData,
                        View = TxtCountLike,
                    }, "MultiImagesPostViewerActivity");

                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                        LikeButton.LongClick += (sender, args) => LikeButton.LongClickDialog(new GlobalClickEventArgs()
                        {
                            NewsFeedClass = PostData,
                            View = TxtCountLike,
                        }, "MultiImagesPostViewerActivity"); 
                }
                else
                {
                    BtnComment.Click -= BtnCommentOnClick;
                    BtnShare.Click -= BtnShareOnClick;
                    BtnCountLike.Click -= BtnCountLikeOnClick;
                    BtnCountWoWonder.Click -= BtnCountWoWonderOnClick;
                    InfoImageLiner.Click -= MainLayoutOnClick;
                    MainLayout.Click -= MainLayoutOnClick;

                    if (AppSettings.PostButton == PostButtonSystem.Wonder || AppSettings.PostButton == PostButtonSystem.DisLike)
                        BtnWonder.Click -= BtnWonderOnClick;

                    LikeButton.Click += null;
                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                        LikeButton.LongClick -= null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        private void MainLayoutOnClick(object sender, EventArgs e)
        {
            try
            {
                InfoImageLiner.Visibility = InfoImageLiner.Visibility != ViewStates.Visible ? ViewStates.Visible : ViewStates.Invisible;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Add Wonder
        private void BtnWonderOnClick(object sender, EventArgs e)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(Application.Context, Application.Context.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    return;
                }

                if (PostData.IsWondered)
                {
                    var x = Convert.ToInt32(PostData.PostWonders);
                    if (x > 0)
                        x--;
                    else
                        x = 0;

                    ImgWonder.SetColorFilter(Color.White);
                    ImgWoWonder.SetColorFilter(Color.White);

                    PostData.IsWondered = false;
                    PostData.PostWonders = Convert.ToString(x, CultureInfo.InvariantCulture);

                    TxtCountWoWonder.Text = Methods.FunString.FormatPriceValue(x);

                    if (AppSettings.PostButton == PostButtonSystem.Wonder)
                        TxtWonder.Text = GetText(Resource.String.Btn_Wonder);
                    else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                        TxtWonder.Text = GetText(Resource.String.Btn_Dislike);

                    BtnWonder.Tag = "false";
                }
                else
                {
                    var x = Convert.ToInt32(PostData.PostWonders);
                    x++;

                    PostData.PostWonders = Convert.ToString(x, CultureInfo.InvariantCulture);
                     
                    PostData.IsWondered = true;
                    
                    ImgWonder.SetColorFilter(Color.ParseColor("#f89823"));
                    ImgWoWonder.SetColorFilter(Color.ParseColor("#f89823"));

                    TxtCountWoWonder.Text = Methods.FunString.FormatPriceValue(x);

                    if (AppSettings.PostButton == PostButtonSystem.Wonder)
                        TxtWonder.Text = GetText(Resource.String.Lbl_wondered);
                    else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                        TxtWonder.Text = GetText(Resource.String.Lbl_disliked);

                    BtnWonder.Tag = "true";
                }

                TxtCountWoWonder.Text = Methods.FunString.FormatPriceValue(int.Parse(PostData.PostWonders));

                if (AppSettings.PostButton == PostButtonSystem.Wonder)
                    RequestsAsync.Global.Post_Actions(PostData.PostId, "wonder").ConfigureAwait(false);
                else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                    RequestsAsync.Global.Post_Actions(PostData.PostId, "dislike").ConfigureAwait(false);

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        //Event Show all users Wowonder >> Open Post PostData_Activity
        private void BtnCountWoWonderOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(ApplicationContext, typeof(PostDataActivity));
                Int.PutExtra("PostId", PostData.PostId);
                Int.PutExtra("PostType", "post_wonders");
                ApplicationContext.StartActivity(Int);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Show all users liked >> Open Post PostData_Activity
        private void BtnCountLikeOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(ApplicationContext, typeof(PostDataActivity));
                Int.PutExtra("PostId", PostData.PostId);
                Int.PutExtra("PostType", "post_likes");
                ApplicationContext.StartActivity(Int);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Share
        private void BtnShareOnClick(object sender, EventArgs e)
        {
            try
            {
                ClickListener.SharePostClick(new GlobalClickEventArgs()
                {
                    NewsFeedClass = PostData,
                }, ClickType.Images);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Add Comment
        private void BtnCommentOnClick(object sender, EventArgs e)
        {
            try
            {
                ClickListener.CommentPostClick(new CommentClickEventArgs()
                {
                    NewsFeedClass = PostData,
                });
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        //Get Data 
        private void Get_DataImage()
        {
            try
            {
                IndexImage = int.Parse(Intent.GetStringExtra("indexImage")); 
                PostData = JsonConvert.DeserializeObject<PostDataObject>(Intent.GetStringExtra("AlbumObject"));
                if (PostData != null)
                {
                    var photos = PostData.PhotoMulti ?? PostData.PhotoAlbum;
                    ViewPager.Adapter = new TouchImageAdapter(this, new ObservableCollection<PhotoAlbumObject>(photos));
                    ViewPager.CurrentItem = IndexImage;
                    ViewPager.Adapter.NotifyDataSetChanged();
                    
                    TxtDescription.Text = Methods.FunString.DecodeString(PostData.Orginaltext);

                    if (PostData.IsLiked)
                    {
                        BtnLike.Tag = "true";
                        ImgLike.SetColorFilter(Color.ParseColor(AppSettings.MainColor));
                    }
                    else
                    {
                        BtnLike.Tag = "false";
                        ImgLike.SetColorFilter(Color.White);
                    }

                    if (PostData.IsWondered)
                    {
                        BtnWonder.Tag = "true";
                        ImgWonder.SetColorFilter(Color.ParseColor("#f89823"));
                        ImgWoWonder.SetColorFilter(Color.ParseColor("#f89823"));

                        TxtWonder.Text = GetText(Resource.String.Lbl_wondered);
                    }
                    else
                    {
                        BtnWonder.Tag = "false";
                        ImgWonder.SetColorFilter(Color.White);
                        ImgWoWonder.SetColorFilter(Color.White);
                        TxtWonder.Text = GetText(Resource.String.Btn_Wonder); 
                    }

                    TxtCountWoWonder.Text = Methods.FunString.FormatPriceValue(int.Parse(PostData.PostWonders));

                    if (AppSettings.PostButton == PostButtonSystem.Reaction)
                    {
                        if (PostData.Reaction == null)
                            PostData.Reaction = new WoWonderClient.Classes.Posts.Reaction();

                        TxtCountLike.Text = Methods.FunString.FormatPriceValue(PostData.Reaction.Count);
                         
                        if ((bool)(PostData.Reaction != null & PostData.Reaction?.IsReacted))
                        {
                            

                            if (!string.IsNullOrEmpty(PostData.Reaction.Type))
                            {
                                switch (PostData.Reaction.Type)
                                {
                                    case "Like":
                                        LikeButton.SetReactionPack(ReactConstants.Like);
                                        break;
                                    case "Love":
                                        LikeButton.SetReactionPack(ReactConstants.Love);
                                        break;
                                    case "HaHa":
                                        LikeButton.SetReactionPack(ReactConstants.HaHa);
                                        break;
                                    case "Wow":
                                        LikeButton.SetReactionPack(ReactConstants.Wow);
                                        break;
                                    case "Sad":
                                        LikeButton.SetReactionPack(ReactConstants.Sad);
                                        break;
                                    case "Angry":
                                        LikeButton.SetReactionPack(ReactConstants.Angry);
                                        break;
                                }
                            }
                        } 
                    }
                    else
                    {
                        if (PostData.IsLiked)
                            LikeButton.SetReactionPack(ReactConstants.Like);

                        TxtCountLike.Text = Methods.FunString.FormatPriceValue(int.Parse(PostData.PostLikes));

                        if (AppSettings.PostButton == PostButtonSystem.Wonder)
                        {
                            if (PostData.IsWondered)
                            {
                                ImgWonder.SetImageResource(Resource.Drawable.ic_action_wowonder);
                                ImgWonder.SetColorFilter(Color.ParseColor(AppSettings.MainColor));

                                TxtWonder.Text = GetString(Resource.String.Lbl_wondered);
                                TxtWonder.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                            }
                            else
                            {
                                ImgWonder.SetImageResource(Resource.Drawable.ic_action_wowonder);
                                ImgWonder.SetColorFilter(Color.ParseColor("#666666"));

                                TxtWonder.Text = GetString(Resource.String.Btn_Wonder);
                                TxtWonder.SetTextColor(Color.ParseColor("#444444"));
                            }
                        }
                        else if (AppSettings.PostButton == PostButtonSystem.DisLike)
                        {
                            if (PostData.IsWondered)
                            {
                                ImgWonder.SetImageResource(Resource.Drawable.ic_action_dislike);
                                ImgWonder.SetColorFilter(Color.ParseColor(AppSettings.MainColor));

                                TxtWonder.Text = GetString(Resource.String.Lbl_disliked);
                                TxtWonder.SetTextColor(Color.ParseColor(AppSettings.MainColor));
                            }
                            else
                            {
                                ImgWonder.SetImageResource(Resource.Drawable.ic_action_dislike);
                                ImgWonder.SetColorFilter(Color.ParseColor("#666666"));

                                TxtWonder.Text = GetString(Resource.String.Btn_Dislike);
                                TxtWonder.SetTextColor(Color.ParseColor("#444444"));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        } 
    }
}