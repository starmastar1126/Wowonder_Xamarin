﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using Newtonsoft.Json;
using WoWonder.Activities.Communities.Adapters;
using WoWonder.Activities.Communities.Groups;
using WoWonder.Activities.Communities.Pages;
using WoWonder.Activities.Contacts.Adapters;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.Search.Adapters;
using WoWonder.Activities.Story;
using WoWonder.Activities.Story.Adapters;
using WoWonder.Activities.userProfile.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.Story;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.UsersPages
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class AllViewerActivity : AppCompatActivity
    {
        #region Variables Basic

        private dynamic MAdapter;
        private SwipeRefreshLayout SwipeRefreshLayout;
        private RecyclerView MRecycler;
        private LinearLayoutManager LayoutManager;
        private GridLayoutManager GridLayoutManager;
        private ViewStub EmptyStateLayout;
        private View Inflated;
        //Type = MangedGroupsModel , MangedPagesModel >> itemObject =  SocialModelsClass
        //Type = StoryModel , FollowersModel , GroupsModel , PagesModel >> itemObject = AdapterModelsClass
        private SocialModelsClass ModelsClass;
        private AdapterModelsClass AdapterModelsClass;
        private string Type;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.RecyclerDefaultLayout);

                Type = Intent.GetStringExtra("Type");

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                SetData();
                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu 

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                MRecycler = (RecyclerView)FindViewById(Resource.Id.recyler);
                EmptyStateLayout = FindViewById<ViewStub>(Resource.Id.viewStub);

                SwipeRefreshLayout = (SwipeRefreshLayout)FindViewById(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = true; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    switch (Type)
                    {
                        case "MangedGroupsModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Manage_Groups);
                            break;
                        case "MangedPagesModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Manage_Pages);
                            break;
                        case "StoryModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Story);
                            break;
                        case "FollowersModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Following);
                            break;
                        case "GroupsModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Groups);
                            break;
                        case "PagesModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Pages);
                            break;
                        case "ImagesModel":
                            toolbar.Title = GetString(Resource.String.Lbl_Photos);
                            break;
                    }
                     
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                dynamic preLoader = null;
                var sizeProvider = new FixedPreloadSizeProvider(10, 10);

                switch (Type)
                {
                    case "GroupsModel":
                    case "MangedGroupsModel":
                        LayoutManager = new LinearLayoutManager(this);
                        MAdapter = new SearchGroupAdapter(this) {GroupList = new ObservableCollection<GroupClass>()};
                        var adapter1 = MAdapter as SearchGroupAdapter;
                        adapter1.ItemClick += GroupsModelOnItemClick; 
                        preLoader = new RecyclerViewPreloader<GroupClass>(this, MAdapter, sizeProvider, 10);
                        break;
                    case "PagesModel":
                    case "MangedPagesModel":
                        LayoutManager = new LinearLayoutManager(this);
                        MAdapter = new SearchPageAdapter(this) {PageList = new ObservableCollection<PageClass>()};
                        var adapter2 = MAdapter as SearchPageAdapter;
                        adapter2.ItemClick += PagesModelOnItemClick;
                        preLoader = new RecyclerViewPreloader<PageClass>(this, MAdapter, sizeProvider, 10);
                        break;
                    case "StoryModel":
                        LayoutManager = new LinearLayoutManager(this);
                        MAdapter = new RowStoryAdapter(this) { StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>() };
                        var adapter3 = MAdapter as RowStoryAdapter;
                        adapter3.ItemClick += StoryModelOnItemClick;
                        preLoader = new RecyclerViewPreloader<GetUserStoriesObject.StoryObject>(this, MAdapter, sizeProvider, 10);
                        break;
                    case "FollowersModel":
                        LayoutManager = new LinearLayoutManager(this);
                        MAdapter = new ContactsAdapter(this, true, ContactsAdapter.TypeTextSecondary.LastSeen){UserList = new ObservableCollection<UserDataObject>()};
                        var adapter4 = MAdapter as ContactsAdapter;
                        adapter4.ItemClick += AdapterFollowersOnItemClick;
                        preLoader = new RecyclerViewPreloader<UserDataObject>(this, MAdapter, sizeProvider, 10);
                        break;
                    case "ImagesModel":
                        GridLayoutManager = new GridLayoutManager(this, 3);
                        GridLayoutManager.SetSpanSizeLookup(new MySpanSizeLookup(4, 1, 1)); //5, 1, 2 
                        MAdapter = new UserPhotosAdapter(this){MUserAlbumsList =new ObservableCollection<PostDataObject>()};
                        var adapter5 = MAdapter as UserPhotosAdapter;
                        adapter5.ItemClick += AdapterPhotosOnItemClick;
                        preLoader = new RecyclerViewPreloader<PostDataObject>(this, MAdapter, sizeProvider, 10);
                        break; 
                }

                MRecycler.SetLayoutManager(LayoutManager ?? GridLayoutManager);
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true; 
                MRecycler.AddOnScrollListener(preLoader);
                MRecycler.SetAdapter(MAdapter);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Events
         
        private void PagesModelOnItemClick(object sender, SearchPageAdapterClickEventArgs e)
        {
            try
            {
                if (MAdapter is SearchPageAdapter adapter)
                {
                    var item = adapter.GetItem(e.Position);
                    if (item != null)
                    {
                        MainApplication.GetInstance()?.NavigateTo(this, typeof(PageProfileActivity), item);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            } 
        }

        private void GroupsModelOnItemClick(object sender, SearchGroupAdapterClickEventArgs e)
        {
            try
            {
                if (MAdapter is SearchGroupAdapter adapter)
                {
                    var item = adapter.GetItem(e.Position);
                    if (item != null)
                    {
                        MainApplication.GetInstance()?.NavigateTo(this, typeof(GroupProfileActivity), item);
                    }
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void AdapterFollowersOnItemClick(object sender, ContactsAdapterClickEventArgs e)
        {
            try
            {
                if (MAdapter is ContactsAdapter adapter)
                {
                    var item = adapter.GetItem(e.Position);
                    if (item != null)
                    {
                        WoWonderTools.OpenProfile(this, item.UserId, item);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void StoryModelOnItemClick(object sender, RowStoryAdapterClickEventArgs e)
        {
            try
            {
                if (MAdapter is RowStoryAdapter adapter)
                {
                    try
                    {
                        //Open View Story Or Create New Story
                        var item = adapter.GetItem(e.Position);
                        if (item != null)
                        { 
                            if (item.Type != "Your")
                            {
                                Intent Int = new Intent(this, typeof(ViewStoryActivity));
                                Int.PutExtra("UserId", item.UserId);
                                Int.PutExtra("DataItem", JsonConvert.SerializeObject(item));
                                StartActivity(Int);
                            } 
                        }
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    } 
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void AdapterPhotosOnItemClick(object sender, UserPhotosAdapterClickEventArgs e)
        {
            try
            {
                if (MAdapter is UserPhotosAdapter adapter)
                {
                    try
                    {
                        //Open View Story Or Create New Story
                        var item = adapter.GetItem(e.Position);
                        if (item != null)
                        {
                            var Int = new Intent(this, typeof(ImagePostViewerActivity));
                            Int.PutExtra("itemIndex", "00"); 
                            Int.PutExtra("AlbumObject", JsonConvert.SerializeObject(item)); // PostDataObject
                            StartActivity(Int); 
                        }
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        private void SetData()
        {
            try
            {
                switch (Type)
                {
                    case "MangedGroupsModel":
                    case "MangedPagesModel":
                    {
                        ModelsClass = JsonConvert.DeserializeObject<SocialModelsClass>(Intent.GetStringExtra("itemObject"));
                        if (ModelsClass != null)
                        {
                            if (MAdapter is SearchGroupAdapter adapter1)
                            {
                                adapter1.GroupList =new ObservableCollection<GroupClass>(ModelsClass.MangedGroupsModel.GroupsList);
                                adapter1.NotifyDataSetChanged();
                            }
                            else if (MAdapter is SearchPageAdapter adapter2)
                            {
                                adapter2.PageList = new ObservableCollection<PageClass>(ModelsClass.PagesModelClass.PagesList);
                                adapter2.NotifyDataSetChanged();
                            }
                        }
                        break;
                    } 
                    case "StoryModel":
                    case "FollowersModel":
                    case "GroupsModel":
                    case "PagesModel":
                    case "ImagesModel":
                        {
                        AdapterModelsClass = JsonConvert.DeserializeObject<AdapterModelsClass>(Intent.GetStringExtra("itemObject"));
                        if (AdapterModelsClass != null)
                        {
                            if (MAdapter is SearchGroupAdapter adapter1)
                            {
                                adapter1.GroupList = new ObservableCollection<GroupClass>(AdapterModelsClass.GroupsModel.GroupsList);
                                adapter1.NotifyDataSetChanged();
                            }
                            else if (MAdapter is SearchPageAdapter adapter2)
                            {
                                adapter2.PageList = new ObservableCollection<PageClass>(AdapterModelsClass.PagesModel.PagesList);
                                adapter2.NotifyDataSetChanged();
                            }
                            else if (MAdapter is ContactsAdapter adapter3)
                            {
                                adapter3.UserList = new ObservableCollection<UserDataObject>(AdapterModelsClass.FollowersModel.FollowersList);
                                adapter3.NotifyDataSetChanged();
                            }
                            else if (MAdapter is RowStoryAdapter adapter4)
                            { 
                                adapter4.StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>(AdapterModelsClass.StoryList);
                                adapter4.StoryList.Remove(adapter4.StoryList.FirstOrDefault(a => a.Type == "Your"));
                                adapter4.NotifyDataSetChanged();
                            }
                            else if (MAdapter is UserPhotosAdapter adapter5)
                            {
                                adapter5.MUserAlbumsList = new ObservableCollection<PostDataObject>(AdapterModelsClass.ImagesModel.ImagesList);  
                                adapter5.NotifyDataSetChanged();
                            }
                        }
                        break;
                    } 
                }

                if (MAdapter?.ItemCount > 0)
                {
                    MRecycler.Visibility = ViewStates.Visible;
                    EmptyStateLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    MRecycler.Visibility = ViewStates.Gone;

                    if (Inflated == null)
                        Inflated = EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();

                    switch (Type)
                    {
                        case "GroupsModel":
                        case "MangedGroupsModel":
                            x.InflateLayout(Inflated, EmptyStateInflater.Type.NoGroup);
                            break;
                        case "PagesModel":
                        case "MangedPagesModel":
                            x.InflateLayout(Inflated, EmptyStateInflater.Type.NoPage);
                            break;
                        case "StoryModel":
                            x.InflateLayout(Inflated, EmptyStateInflater.Type.NoGroup);
                            break;
                        case "FollowersModel":
                            x.InflateLayout(Inflated, EmptyStateInflater.Type.NoUsers);
                            break;
                        case "ImagesModel":
                            x.InflateLayout(Inflated, EmptyStateInflater.Type.NoAlbum);
                            break; 
                    }
                     
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                    }
                    EmptyStateLayout.Visibility = ViewStates.Visible;
                }
                
                SwipeRefreshLayout.Refreshing = false;
                SwipeRefreshLayout.Enabled = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                SwipeRefreshLayout.Refreshing = false;
                SwipeRefreshLayout.Enabled = false;
            }
        }
    }
}