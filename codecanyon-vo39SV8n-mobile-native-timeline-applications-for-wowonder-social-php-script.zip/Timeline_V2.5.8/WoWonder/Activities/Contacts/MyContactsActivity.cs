﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using WoWonder.Activities.Contacts.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.Contacts
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MyContactsActivity : AppCompatActivity
    {
        #region Variables Basic

        private ContactsAdapter MAdapter;
        private SwipeRefreshLayout SwipeRefreshLayout;
        private RecyclerView MRecycler;
        private LinearLayoutManager LayoutManager;
        private ViewStub EmptyStateLayout;
        private View Inflated;
        private RecyclerViewOnScrollListener MainScrollEvent;
        private string TypeContacts = "" , UserId = "";

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.RecyclerDefaultLayout);

                var contactsType = Intent.GetStringExtra("ContactsType") ?? "Data not available";
                if (contactsType != "Data not available" && !string.IsNullOrEmpty(contactsType))
                    TypeContacts = contactsType;

                UserId = Intent.GetStringExtra("UserId");
                 
                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                LoadContacts();
                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            { 
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu 
         
        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true; 
            }

            return base.OnOptionsItemSelected(item);
        }
          
        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                MRecycler = (RecyclerView)FindViewById(Resource.Id.recyler);
                EmptyStateLayout = FindViewById<ViewStub>(Resource.Id.viewStub);

                SwipeRefreshLayout = (SwipeRefreshLayout)FindViewById(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = true;
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = AppSettings.ConnectivitySystem == 1 ? GetText(TypeContacts == "Following" ? Resource.String.Lbl_Following : Resource.String.Lbl_Followers) : GetText(Resource.String.Lbl_Friends);

                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                MAdapter = new ContactsAdapter(this,true,ContactsAdapter.TypeTextSecondary.About)
                {
                    UserList = new ObservableCollection<UserDataObject>(),
                };
                LayoutManager = new LinearLayoutManager(this);
                MRecycler.SetLayoutManager(LayoutManager); 
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true;
                var sizeProvider = new FixedPreloadSizeProvider(10, 10);
                var preLoader = new RecyclerViewPreloader<UserDataObject>(this, MAdapter, sizeProvider, 10);
                MRecycler.AddOnScrollListener(preLoader);
                MRecycler.SetAdapter(MAdapter);

                RecyclerViewOnScrollListener xamarinRecyclerViewOnScrollListener = new RecyclerViewOnScrollListener(LayoutManager);
                MainScrollEvent = xamarinRecyclerViewOnScrollListener;
                MainScrollEvent.LoadMoreEvent += MainScrollEventOnLoadMoreEvent;
                MRecycler.AddOnScrollListener(xamarinRecyclerViewOnScrollListener);
                MainScrollEvent.IsLoading = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    MAdapter.ItemClick += MAdapterOnItemClick;
                    SwipeRefreshLayout.Refresh += SwipeRefreshLayoutOnRefresh;
                }
                else
                {
                    MAdapter.ItemClick -= MAdapterOnItemClick;
                    SwipeRefreshLayout.Refresh -= SwipeRefreshLayoutOnRefresh;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        //Refresh
        private void SwipeRefreshLayoutOnRefresh(object sender, EventArgs e)
        {
            try
            {
                MAdapter.UserList.Clear();
                MAdapter.NotifyDataSetChanged();

                StartApiService();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Scroll
        private void MainScrollEventOnLoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                //Code get last id where LoadMore >>
                var item = MAdapter.UserList.LastOrDefault();
                if (item != null && !string.IsNullOrEmpty(item.UserId))
                    LoadContactsAsync().ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void MAdapterOnItemClick(object sender, ContactsAdapterClickEventArgs e)
        {
            try
            {
                var item = MAdapter.GetItem(e.Position);
                if (item != null)
                {
                    WoWonderTools.OpenProfile(this, item.UserId, item); 
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Load Contacts 

        private void LoadContacts()
        {
            try
            {
                //if (UserId == UserDetails.UserId)
                //{
                //    var sqlEntity = new SqLiteDatabase();
                //    var userList = TypeContacts == "Following" ? sqlEntity.Get_MyContact() : sqlEntity.Get_MyFollowers();

                //    MAdapter.UserList = new ObservableCollection<UserDataObject>(userList);
                //    MAdapter.NotifyDataSetChanged();

                //    sqlEntity.Dispose();
                //}
                //else
                //{
                //    if (TypeContacts != "Following" && UserProfileActivity.ListDataUserFollowers.Count > 0)
                //    {
                //        MAdapter.UserList = UserProfileActivity.ListDataUserFollowers;
                //        MAdapter.NotifyDataSetChanged();
                //    }
                //}

                StartApiService();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
            {
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { LoadContactsAsync });
            }
        }

        private async Task LoadContactsAsync()
        {
            try
            { 
                var lastIdUser = MAdapter.UserList.LastOrDefault()?.UserId ?? "0";
                if (Methods.CheckConnectivity())
                { 
                    if (TypeContacts == "Following")
                    {
                        int countList = MAdapter.UserList.Count;
                        (int apiStatus, var respond) = await RequestsAsync.Global.GetFriendsAsync(UserId, "following", "35", lastIdUser);
                        if (apiStatus != 200 || !(respond is GetFriendsObject result) || result.DataFriends == null)
                        {
                            Methods.DisplayReportResult(this, respond);
                        }
                        else
                        {
                            var respondList = result.DataFriends.Following.Count;
                            if (respondList > 0)
                            {
                                if (countList > 0)
                                {
                                    foreach (var item in result.DataFriends.Following)
                                    {
                                        var check = MAdapter.UserList.FirstOrDefault(a => a.UserId == item.UserId);
                                        if (check == null)
                                        {
                                            MAdapter.UserList.Add(item);
                                        }
                                    }
                                    RunOnUiThread(() => { MAdapter.NotifyItemRangeInserted(countList - 1, MAdapter.UserList.Count - countList); }); 
                                }
                                else
                                {
                                    MAdapter.UserList = new ObservableCollection<UserDataObject>(result.DataFriends.Following);
                                    RunOnUiThread(() => { MAdapter.NotifyDataSetChanged(); });
                                }
                            }
                            else
                            {
                                if (MAdapter.UserList.Count > 10 && !MRecycler.CanScrollVertically(1))
                                    Toast.MakeText(this, GetText(Resource.String.Lbl_No_more_users), ToastLength.Short).Show();
                            }
                        } 
                    }
                    else
                    {
                        int countList = MAdapter.UserList.Count;
                        (int apiStatus, var respond) = await RequestsAsync.Global.GetFriendsAsync(UserId, "followers", "35","", lastIdUser);
                        if (apiStatus != 200 || !(respond is GetFriendsObject result) || result.DataFriends == null)
                        {
                            Methods.DisplayReportResult(this, respond);
                        }
                        else
                        {
                            var respondList = result.DataFriends.Followers.Count;
                            if (respondList > 0)
                            {
                                if (countList > 0)
                                {
                                    foreach (var item in result.DataFriends.Followers)
                                    {
                                        var check = MAdapter.UserList.FirstOrDefault(a => a.UserId == item.UserId);
                                        if (check == null)
                                        {
                                            MAdapter.UserList.Add(item);
                                        }
                                    } 
                                }
                                else
                                {
                                    MAdapter.UserList = new ObservableCollection<UserDataObject>(result.DataFriends.Followers);
                                    MAdapter.NotifyDataSetChanged();
                                }
                            }
                            else
                            {
                                if (MAdapter.UserList.Count > 10 && !MRecycler.CanScrollVertically(1))
                                    Toast.MakeText(this, GetText(Resource.String.Lbl_No_more_users), ToastLength.Short).Show();
                            }
                        } 
                    }
                     
                    MainScrollEvent.IsLoading = false;
                    RunOnUiThread(ShowEmptyPage);
                }
                else
                {
                    Inflated = EmptyStateLayout.Inflate();
                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(Inflated, EmptyStateInflater.Type.NoConnection);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                        x.EmptyStateButton.Click += EmptyStateButtonOnClick;
                    }

                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception e)
            {
                await LoadContactsAsync();
                Console.WriteLine(e);
            }
        }

        private void ShowEmptyPage()
        {
            try
            {
                SwipeRefreshLayout.Refreshing = false;

                if (MAdapter.UserList.Count > 0)
                {
                    MRecycler.Visibility = ViewStates.Visible;
                    EmptyStateLayout.Visibility = ViewStates.Gone;
                   
                    if (UserId == UserDetails.UserId)
                    {
                        var sqlEntity = new SqLiteDatabase();
                        if (TypeContacts == "Following")
                            sqlEntity.Insert_Or_Replace_MyContactTable(MAdapter.UserList);
                        else
                            sqlEntity.Insert_Or_Replace_MyFollowersTable(MAdapter.UserList);
                        sqlEntity.Dispose();
                    }
                }
                else
                {
                    MRecycler.Visibility = ViewStates.Gone;

                    if (Inflated == null)
                        Inflated = EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(Inflated, EmptyStateInflater.Type.NoUsers);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                    }
                    EmptyStateLayout.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception e)
            {
                SwipeRefreshLayout.Refreshing = false;
                Console.WriteLine(e);
            }
        }

        //No Internet Connection 
        private void EmptyStateButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                StartApiService();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

    }
}