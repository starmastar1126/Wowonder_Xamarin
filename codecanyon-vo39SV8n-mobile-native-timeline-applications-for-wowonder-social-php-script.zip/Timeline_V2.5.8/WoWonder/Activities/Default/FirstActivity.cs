﻿using System;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Utils;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Default
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/ProfileTheme",
        ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.Orientation)]
    public class FirstActivity : AppCompatActivity
    {
        private View IncludeLayout;
        private RelativeLayout LayoutBase;
        private Button LoginButton;
        private Button RegisterButton;

        private VideoView VideoViewer;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);


                SetContentView(Resource.Layout.First_Layout);

                LoginButton = FindViewById<Button>(Resource.Id.LoginButton);
                RegisterButton = FindViewById<Button>(Resource.Id.RegisterButton);

                IncludeLayout = FindViewById<View>(Resource.Id.IncludeLayout);
                VideoViewer = FindViewById<VideoView>(Resource.Id.videoView);


                LayoutBase = FindViewById<RelativeLayout>(Resource.Id.Layout_Base);

                //Set Theme
                if (AppSettings.BackgroundScreenWelcomeType == "Image")
                {
                    LayoutBase.SetBackgroundResource(Resource.Drawable.loginBackground);
                    IncludeLayout.Visibility = ViewStates.Gone;
                }
                else if (AppSettings.BackgroundScreenWelcomeType == "Video")
                {
                    var uri = Uri.Parse("android.resource://" + PackageName + "/" + Resource.Raw.MainVideo);
                    VideoViewer.SetVideoURI(uri);
                    VideoViewer.Start();
                }
                else if (AppSettings.BackgroundScreenWelcomeType == "Gradient")
                {
                    IncludeLayout.Visibility = ViewStates.Gone;
                    LayoutBase.SetBackgroundResource(Resource.Xml.login_background_shape);
                }

                // Check if we're running on Android 5.0 or higher
                if ((int) Build.VERSION.SdkInt < 23)
                {
                }
                else
                {
                    if (CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                    {
                    }
                    else
                    {
                        RequestPermissions(new[]
                        {
                            Manifest.Permission.ReadExternalStorage,
                            Manifest.Permission.WriteExternalStorage
                        }, 101);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();

                if (AppSettings.BackgroundScreenWelcomeType == "Video")
                {
                    if (!VideoViewer.IsPlaying)
                        VideoViewer.Start();

                    VideoViewer.Completion += VideoViewer_Completion;
                }


                RegisterButton.Click += RegisterButton_Click;
                LoginButton.Click += LoginButton_Click;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();

                //Close Event

                RegisterButton.Click -= RegisterButton_Click;
                LoginButton.Click -= LoginButton_Click;

                if (AppSettings.BackgroundScreenWelcomeType == "Video")
                    VideoViewer.Completion -= VideoViewer_Completion;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnStop()
        {
            try
            {
                base.OnStop();

                if (AppSettings.BackgroundScreenWelcomeType == "Video")
                    VideoViewer.StopPlayback();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions,
            Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 101)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long)
                            .Show();
                        Finish();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        private void RegisterButton_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(RegisterActivity)));
                Finish();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                Finish();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void VideoViewer_Completion(object sender, EventArgs e)
        {
            try
            {
                VideoViewer.Start();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {

                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnDestroy()
        {
            try
            {

                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}