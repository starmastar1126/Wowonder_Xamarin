﻿using System;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Ads;
using Android.OS;
using Android.Widget;
using WoWonder.Activities.Default;
using WoWonder.Activities.Tabbes;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.SQLite;

namespace WoWonder.Activities
{
    [Activity(MainLauncher = true, Icon = "@drawable/icon", Theme = "@style/SplashScreenTheme", NoHistory = true, ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class SplashScreenActivity : Activity
    {
        private SqLiteDatabase DbDatabase;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {   
                base.OnCreate(savedInstanceState);

                DbDatabase = new SqLiteDatabase();
                DbDatabase.CheckTablesStatus();

                if (AppSettings.Lang != "")
                { 
                    LangController.SetApplicationLang(this, AppSettings.Lang);
                }
                else
                {
                    UserDetails.LangName = Resources.Configuration.Locale.Language;
                    LangController.SetAppLanguage(this);
                }

                if (AppSettings.ShowAdmobBanner || AppSettings.ShowAdmobInterstitial || AppSettings.ShowAdmobRewardVideo || AppSettings.ShowAdmobNative)
                    MobileAds.Initialize(this, GetString(Resource.String.admob_app_id)); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                
                var startupWork = new Task(SimulateStartup);
                startupWork.Start();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void SimulateStartup()
        {
            try
            {
                FirstRunExcute();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void FirstRunExcute()
        {
            try
            { 
                var result = DbDatabase.Get_data_Login_Credentials();
                if (result != null)
                { 
                    switch (result.Status)
                    {
                        case "Active":
                        case "Pending":
                            StartActivity(new Intent(Application.Context, typeof(TabbedMainActivity)));
                            break;
                        default:
                            StartActivity(new Intent(Application.Context, typeof(FirstActivity)));
                            break;
                    }
                }
                else
                {
                    StartActivity(new Intent(Application.Context, typeof(FirstActivity)));
                }

                DbDatabase.Dispose();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                Toast.MakeText(this, exception.Message, ToastLength.Short).Show();
            }
        } 
    }
}