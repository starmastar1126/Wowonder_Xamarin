﻿using System;
using System.Collections.Generic;
using System.Linq;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AndroidHUD;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Requests;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.Communities.Groups
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class EditInfoGroupActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private TextView TxtSave, TxtCategory;
        private EditText TxtTitle,TxtName, TxtAbout;
        private RadioButton RbPublic,RbPrivate;
        private string GroupsId = "", GroupPrivacy = "", CategoryId = "";
        private GroupClass GroupData;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.EditInfoGroup_Layout);

                var id = Intent.GetStringExtra("GroupsId") ?? "Data not available";
                if (id != "Data not available" && !string.IsNullOrEmpty(id)) GroupsId = id;

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();

                Get_Data_Group();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                TxtSave = FindViewById<TextView>(Resource.Id.toolbar_title); 
                TxtTitle = FindViewById<EditText>(Resource.Id.titleet);
                TxtName = FindViewById<EditText>(Resource.Id.nameet);
                TxtAbout = FindViewById<EditText>(Resource.Id.aboutet); 
                RbPublic = FindViewById<RadioButton>(Resource.Id.rad_Public);
                RbPrivate = FindViewById<RadioButton>(Resource.Id.rad_Private);
                TxtCategory = FindViewById<EditText>(Resource.Id.categorieset);

                TxtCategory.SetFocusable(ViewFocusability.NotFocusable);
                TxtCategory.Focusable = true;
                TxtCategory.FocusableInTouchMode = true;
                TxtCategory.ClearFocus();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = GetString(Resource.String.Lbl_Update_Data_Group);
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    RbPublic.CheckedChange += RbPublicOnCheckedChange;
                    RbPrivate.CheckedChange += RbPrivateOnCheckedChange;
                    TxtSave.Click += TxtSaveOnClick;
                    TxtCategory.Touch += TxtCategoryOnClick;
                }
                else
                {
                    RbPublic.CheckedChange -= RbPublicOnCheckedChange;
                    RbPrivate.CheckedChange -= RbPrivateOnCheckedChange;
                    TxtSave.Click -= TxtSaveOnClick;
                    TxtCategory.Touch -= TxtCategoryOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        private void TxtCategoryOnClick(object sender, View.TouchEventArgs e)
        {
            try
            {
                if (e.Event.Action == MotionEventActions.Down)
                {
                    if (CategoriesController.ListCategoriesGroup.Count > 0)
                    {
                        var arrayAdapter = new List<string>();
                        var dialogList = new MaterialDialog.Builder(this);

                        foreach (var item in CategoriesController.ListCategoriesGroup)
                            arrayAdapter.Add(item.CategoriesName);

                        dialogList.Title(GetText(Resource.String.Lbl_SelectCategories));
                        dialogList.Items(arrayAdapter);
                        dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                        dialogList.AlwaysCallSingleChoiceCallback();
                        dialogList.ItemsCallback(this).Build().Show();
                    }
                    else
                    {
                        Methods.DisplayReportResult(this, "Not have List Categories Group");
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        private async void TxtSaveOnClick(object sender, EventArgs e)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    //Show a progress
                    AndHUD.Shared.Show(this, GetText(Resource.String.Lbl_Loading) + "...");

                    var dictionary = new Dictionary<string, string>
                    {
                        {"group_name", TxtName.Text},
                        {"group_title", TxtTitle.Text},
                        {"about", TxtAbout.Text},
                        {"category", CategoryId},
                        {"privacy", GroupPrivacy}
                    };

                    var (apiStatus, respond) = await RequestsAsync.Group.Update_Group_Data(GroupsId, dictionary);
                    if (apiStatus == 200)
                    { 
                        GroupData.GroupName = TxtName.Text; 
                        GroupData.GroupTitle = TxtTitle.Text;
                        GroupData.Username = TxtName.Text;
                        GroupData.About = TxtAbout.Text; 
                        GroupData.Privacy = GroupPrivacy;
                        GroupData.CategoryId = CategoryId; 
                        GroupData.Category = TxtCategory.Text;

                        AndHUD.Shared.ShowSuccess(this, GetText(Resource.String.Lbl_YourGroupWasUpdated), MaskType.Clear, TimeSpan.FromSeconds(2));
                         
                        Intent returnIntent = new Intent();
                        returnIntent.PutExtra("groupItem", JsonConvert.SerializeObject(GroupData));
                        SetResult(Result.Ok, returnIntent);
                        Finish();
                    }
                    else if (apiStatus == 400)
                    {
                        if (respond is ErrorObject error)
                        {
                            var errorText = error._errors.ErrorText;
                            //Show a Error 
                            AndHUD.Shared.ShowError(this, errorText, MaskType.Clear, TimeSpan.FromSeconds(2));

                            if (errorText.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);
                        }
                    }
                    else if (apiStatus == 404)
                    {
                        var error = respond.ToString();
                        //Show a Error
                        AndHUD.Shared.ShowError(this, error, MaskType.Clear, TimeSpan.FromSeconds(2));
                    }

                    AndHUD.Shared.Dismiss(this);
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                AndHUD.Shared.Dismiss(this);
            }
        }

        private void RbPrivateOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                var isChecked = RbPrivate.Checked;
                if (isChecked)
                {
                    RbPublic.Checked = false;
                    GroupPrivacy = "0";
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void RbPublicOnCheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            try
            {
                var isChecked = RbPublic.Checked;
                if (isChecked)
                {
                    RbPrivate.Checked = false;
                    GroupPrivacy = "1";
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion
         
        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                CategoryId = CategoriesController.ListCategoriesGroup.FirstOrDefault(categories => categories.CategoriesName == itemString.ToString())?.CategoriesId; 
                TxtCategory.Text = itemString.ToString();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        //Get Data Group and set Categories
        private void Get_Data_Group()
        {
            try
            {
                GroupData = JsonConvert.DeserializeObject<GroupClass>(Intent.GetStringExtra("GroupData"));
                if (GroupData != null)
                {
                    TxtTitle.Text = GroupData.GroupTitle;
                    TxtName.Text = GroupData.Username;
                    TxtAbout.Text = Methods.FunString.DecodeString(GroupData.About);

                    if (GroupData.Privacy == "0")
                    {
                        RbPrivate.Checked = true;
                        RbPublic.Checked = false;
                    }
                    else
                    {
                        RbPrivate.Checked = false;
                        RbPublic.Checked = true;
                    }

                    GroupPrivacy = GroupData.Privacy;
                    CategoryId = GroupData.CategoryId;

                    TxtCategory.Text = GroupData.Category;

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}