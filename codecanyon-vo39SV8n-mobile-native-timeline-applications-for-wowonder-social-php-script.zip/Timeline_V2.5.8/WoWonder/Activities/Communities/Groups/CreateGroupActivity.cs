﻿using System;
using System.Collections.Generic;
using System.Linq;
using AFollestad.MaterialDialogs;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AndroidHUD;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Utils;
using WoWonderClient;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Group;
using WoWonderClient.Requests;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.Communities.Groups
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class CreateGroupActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback 
    { 
        #region Variables Basic

        private TextView TxtCreate, TxtUrlDescription;
        private EditText TxtTitle, TxtName, TxtAbout, TxtCategory;
        private string CategoryId = "";

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.CreateGroup_Layout);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                TxtCategory = FindViewById<EditText>(Resource.Id.categorieset); 
                TxtCreate = FindViewById<TextView>(Resource.Id.toolbar_title);
                TxtUrlDescription = FindViewById<TextView>(Resource.Id.urldescription);

                TxtUrlDescription.Text = Client.WebsiteUrl + GetString(Resource.String.Lbl_Group_URL);

                TxtTitle = FindViewById<EditText>(Resource.Id.titleet);
                TxtName = FindViewById<EditText>(Resource.Id.nameet);
                TxtAbout = FindViewById<EditText>(Resource.Id.aboutet);

                TxtCategory.SetFocusable(ViewFocusability.NotFocusable);
                TxtCategory.Focusable = true;
                TxtCategory.FocusableInTouchMode = true;
                TxtCategory.ClearFocus();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = GetText(Resource.String.Lbl_Create_New_Group);
                    toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    TxtCreate.Click += TxtCreateOnClick; 
                    TxtCategory.Touch += TxtCategoryOnClick;
                }
                else
                {
                    TxtCreate.Click -= TxtCreateOnClick;
                    TxtCategory.Touch -= TxtCategoryOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Events

        private void TxtCategoryOnClick(object sender, View.TouchEventArgs e)
        {
            try
            {
                if (e.Event.Action == MotionEventActions.Down)
                {
                    if (CategoriesController.ListCategoriesGroup.Count > 0)
                    {
                        var arrayAdapter = new List<string>();
                        var dialogList = new MaterialDialog.Builder(this);

                        foreach (var item in CategoriesController.ListCategoriesGroup)
                            arrayAdapter.Add(item.CategoriesName);

                        dialogList.Title(GetText(Resource.String.Lbl_SelectCategories));
                        dialogList.Items(arrayAdapter);
                        dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                        dialogList.AlwaysCallSingleChoiceCallback();
                        dialogList.ItemsCallback(this).Build().Show();
                    }
                    else
                    {
                        Methods.DisplayReportResult(this, "Not have List Categories Group");
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        private async void TxtCreateOnClick(object sender, EventArgs e)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    if (string.IsNullOrEmpty(TxtName.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_enter_name), ToastLength.Short).Show();
                    }
                    else if (string.IsNullOrEmpty(TxtTitle.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_enter_title), ToastLength.Short).Show();
                    }
                    else if (string.IsNullOrEmpty(TxtAbout.Text))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_enter_about), ToastLength.Short).Show();
                    }
                    else if (string.IsNullOrEmpty(CategoryId))
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Please_select_category), ToastLength.Short).Show();
                    }
                    else
                    {
                        //Show a progress
                        AndHUD.Shared.Show(this,GetString(Resource.String.Lbl_Loading) + "...");

                        var (apiStatus, respond) = await RequestsAsync.Group.Create_Group(TxtName.Text, TxtTitle.Text,TxtAbout.Text, CategoryId);
                        if (apiStatus == 200)
                        {
                            if (respond is CreateGroupObject result)
                            {
                                if (result.GroupData != null)
                                {
                                    var item = result.GroupData; 
                                    AndHUD.Shared.ShowSuccess(this);

                                    Intent returnIntent = new Intent();  
                                    returnIntent.PutExtra("groupItem", JsonConvert.SerializeObject(item));
                                    SetResult(Result.Ok, returnIntent);
                                    Finish();
                                } 
                            }
                        }
                        else  
                        {
                            Methods.DisplayReportResult(this, respond);

                            if (respond is ErrorObject error)
                            {
                                var errorText = error._errors.ErrorText;
                                //Show a Error 
                                AndHUD.Shared.ShowError(this, errorText, MaskType.Clear, TimeSpan.FromSeconds(2)); 
                            }
                        }
                        
                        AndHUD.Shared.Dismiss(this);
                    }
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                AndHUD.Shared.Dismiss(this);
            }
        }

        #endregion
         
        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                CategoryId = CategoriesController.ListCategoriesGroup.FirstOrDefault(categories => categories.CategoriesName == itemString.ToString())?.CategoriesId; 
                TxtCategory.Text = itemString.ToString();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion 
    }
}