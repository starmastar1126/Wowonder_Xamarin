﻿using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Com.Theartofdev.Edmodo.Cropper;
using Newtonsoft.Json;
using Plugin.Share;
using Plugin.Share.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android.Content.Res;
using Android.Graphics;
using Java.Lang;
using WoWonder.Activities.AddPost;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Group;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using Exception = System.Exception;
using File = Java.IO.File;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Communities.Groups
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class GroupProfileActivity : AppCompatActivity, MaterialDialog.IListCallback,MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private Button BtnJoin;
        private ImageButton BtnMore;
        private ImageView UserProfileImage, CoverImage, IconBack, IconPrivacy;
        private TextView CategoryText, IconEdit, TxtGroupName, TxtGroupUsername, PrivacyText, TxtEditGroupInfo;
        private FloatingActionButton FloatingActionButtonView;
        private LinearLayout EditAvatarImageGroup;
        private WRecyclerView MainRecyclerView;
        private NativePostAdapter PostFeedAdapter;
        private string GroupId, ImageType;
        private GroupClass GroupDataClass;
        private ImageView JoinRequestImage1, JoinRequestImage2, JoinRequestImage3;
        private RelativeLayout LayoutJoinRequest;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                

                View mContentView = Window.DecorView;
                var uiOptions = (int)mContentView.SystemUiVisibility;
                var newUiOptions = (int)uiOptions;

                // newUiOptions |= (int)SystemUiFlags.Fullscreen;
                newUiOptions |= (int)SystemUiFlags.LayoutStable;
                mContentView.SystemUiVisibility = (StatusBarVisibility)newUiOptions;


                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Group_Profile_Layout);
                 
                GroupId = Intent.GetStringExtra("GroupId") ?? string.Empty;

                //Get Value And Set Toolbar
                InitComponent();
                SetRecyclerViewAdapters();

                GetDataGroup();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                MainRecyclerView.ReleasePlayer();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                UserProfileImage = (ImageView)FindViewById(Resource.Id.image_profile);
                CoverImage = (ImageView)FindViewById(Resource.Id.iv1);

                IconBack = (ImageView)FindViewById(Resource.Id.image_back);
                EditAvatarImageGroup = (LinearLayout)FindViewById(Resource.Id.LinearEdit);
                TxtEditGroupInfo = (TextView)FindViewById(Resource.Id.tv_EditGroupinfo);
                TxtGroupName = (TextView)FindViewById(Resource.Id.Group_name);
                TxtGroupUsername = (TextView)FindViewById(Resource.Id.Group_Username);
                BtnJoin = (Button)FindViewById(Resource.Id.joinButton);
                BtnMore = (ImageButton)FindViewById(Resource.Id.morebutton);
                IconPrivacy = (ImageView)FindViewById(Resource.Id.IconPrivacy);
                PrivacyText = (TextView)FindViewById(Resource.Id.PrivacyText);
                CategoryText = (TextView)FindViewById(Resource.Id.CategoryText);
                IconEdit = (TextView)FindViewById(Resource.Id.IconEdit); 
                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);

                JoinRequestImage1 = (ImageView)FindViewById(Resource.Id.image_user_1);
                JoinRequestImage2 = (ImageView)FindViewById(Resource.Id.image_user_2);
                JoinRequestImage3 = (ImageView)FindViewById(Resource.Id.image_user_3);

                LayoutJoinRequest = (RelativeLayout)FindViewById(Resource.Id.layout_join_Request);

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconEdit, IonIconsFonts.Edit); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void SetRecyclerViewAdapters()
        {
            try
            {
                MainRecyclerView = FindViewById<WRecyclerView>(Resource.Id.newsfeedRecyler);
                PostFeedAdapter = new NativePostAdapter(this, MainRecyclerView, NativeFeedType.Group)
                {
                    ApiIdParameter = GroupId
                };

                 
                MainRecyclerView.SetXAdapter(PostFeedAdapter, null);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    IconBack.Click += IconBackOnClick;
                    EditAvatarImageGroup.Click += EditAvatarImageGroupOnClick;
                    TxtEditGroupInfo.Click += TxtEditGroupInfoOnClick;
                    BtnJoin.Click += BtnJoinOnClick;
                    BtnMore.Click += BtnMoreOnClick;
                    FloatingActionButtonView.Click += AddPostOnClick;
                    LayoutJoinRequest.Click += LayoutJoinRequestOnClick;
                }
                else
                {
                    IconBack.Click -= IconBackOnClick;
                    EditAvatarImageGroup.Click -= EditAvatarImageGroupOnClick;
                    TxtEditGroupInfo.Click -= TxtEditGroupInfoOnClick;
                    BtnJoin.Click -= BtnJoinOnClick;
                    BtnMore.Click -= BtnMoreOnClick;
                    FloatingActionButtonView.Click -= AddPostOnClick;
                    LayoutJoinRequest.Click -= LayoutJoinRequestOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Events

        //Event Show More : Copy Link , Share , Edit (If user isOwner_Groups)
        private void BtnMoreOnClick(object sender, EventArgs e)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetString(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(GetString(Resource.String.Lbl_Share));
                if (GroupDataClass.IsOwner)
                    arrayAdapter.Add(GetString(Resource.String.Lbl_Edit));

                dialogList.Title(GetString(Resource.String.Lbl_More));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show(); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Add New post
        private void AddPostOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(this, typeof(AddPostActivity));
                Int.PutExtra("Type", "SocialGroup");
                Int.PutExtra("PostId", GroupId);
                Int.PutExtra("itemObject", JsonConvert.SerializeObject(GroupDataClass));
                StartActivityForResult(Int, 2500);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Join_Group => Joined , Join Group
        private async void BtnJoinOnClick(object sender, EventArgs e)
        {
            try
            {
                if (BtnJoin.Tag.ToString() == "MyGroup")
                {
                    EditInfoGroup_OnClick();
                }
                else
                {
                    if (!Methods.CheckConnectivity())
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    }
                    else
                    {
                        var (apiStatus, respond) = await RequestsAsync.Group.Join_Group(GroupId);
                        if (apiStatus == 200)
                        {
                            if (respond is JoinGroupObject result)
                            { 
                                if (result.JoinStatus == "requested")
                                {
                                    BtnJoin.BackgroundTintList = ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                                    BtnJoin.Text = GetText(Resource.String.Lbl_Request);
                                    BtnJoin.SetTextColor(Color.White);
                                    BtnMore.BackgroundTintList =  ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                                    BtnMore.ImageTintList = ColorStateList.ValueOf(Color.White);
                                } 
                                else
                                {
                                    string isJoined = result.JoinStatus == "left" ? "false" : "true";
                                    BtnJoin.BackgroundTintList = isJoined == "yes" || isJoined == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                                    BtnJoin.Text = GetText(isJoined == "yes" || isJoined == "true" ? Resource.String.Btn_Joined : Resource.String.Btn_Join_Group);
                                    BtnJoin.SetTextColor(isJoined == "yes" || isJoined == "true" ? Color.Black : Color.White);
                                    BtnMore.BackgroundTintList = isJoined == "yes" || isJoined == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                                    BtnMore.ImageTintList = isJoined == "yes" || isJoined == "true" ? ColorStateList.ValueOf(Color.Black) : ColorStateList.ValueOf(Color.White);
                                }   
                            }
                        }
                        else if (apiStatus == 400)
                        {
                            if (!(respond is ErrorObject error)) return;

                            var errorText = error._errors.ErrorText;

                            if (errorText.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);
                        }
                        else if (apiStatus == 404)
                        {
                            var error = respond.ToString();
                            Console.WriteLine(error);
                        }
                    }
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Update Image Cover Group
        private void TxtEditGroupInfoOnClick(object sender, EventArgs e)
        {
            try
            {
                OpenDialogGallery("Cover");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Update Image avatar Group
        private void EditAvatarImageGroupOnClick(object sender, EventArgs e)
        {
            try
            {
                OpenDialogGallery("Avatar");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Back
        private void IconBackOnClick(object sender, EventArgs e)
        {
           Finish();
        }

        //Join Request
        private void LayoutJoinRequestOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(this, typeof(JoinRequestActivity));
                Int.PutExtra("GroupId", GroupId);
                StartActivity(Int);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override async void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                //If its from Camera or Gallery
                if (requestCode == CropImage.CropImageActivityRequestCode)
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                string pathImg;
                                if (ImageType == "Cover")
                                {
                                    pathImg = resultUri.Path;
                                    UpdateImageGroup_Api(ImageType, pathImg);
                                }
                                else if (ImageType == "Avatar")
                                {
                                    pathImg = resultUri.Path;
                                    UpdateImageGroup_Api(ImageType, pathImg);
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong),ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                        }
                    } 
                }
                else if (requestCode == 2500 && resultCode == Result.Ok)//add post
                {
                    var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                    if (postData != null)
                    {
                        var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                        MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                        {
                            TypeView = postType,
                            Id = int.Parse(postData.Id),
                            PostData = postData,
                            IsDefaultFeedPost = true,
                        });
                    }
                    else
                    {
                        await MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                    }
                }
                else if (requestCode == 3950 && resultCode == Result.Ok) //Edit post
                {
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemChanged(index);
                        }
                    }
                }
                else if (requestCode == 2005 && resultCode == Result.Ok)
                {
                    string result = data.GetStringExtra("groupItem");
                    var item = JsonConvert.DeserializeObject<GroupClass>(result);
                    if (item != null)
                        LoadPassedData(item);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults); 
                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        OpenDialogGallery(ImageType);
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion
         
        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == GetString(Resource.String.Lbl_CopeLink))
                {
                    CopyLinkEvent();
                }
                else if (text == GetString(Resource.String.Lbl_Share))
                {
                    ShareEvent();
                }
                else if (text == GetString(Resource.String.Lbl_Edit))
                {
                    EditInfoGroup_OnClick();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
               if (p1 == DialogAction.Positive)
                    {

                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Copy Link
        private void CopyLinkEvent()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", GroupDataClass.Url);
                clipboardManager.PrimaryClip = clipData;

                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Share
        private async void ShareEvent()
        {
            try
            {
                //Share Plugin same as video
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = GroupDataClass.GroupName,
                    Text = GroupDataClass.About,
                    Url = GroupDataClass.Url
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Edit Info Group if user == is_owner
        private void EditInfoGroup_OnClick()
        {
            try
            {
                if (GroupDataClass.IsOwner)
                {
                    var Int = new Intent(this, typeof(EditInfoGroupActivity));
                    Int.PutExtra("GroupData", JsonConvert.SerializeObject(GroupDataClass));
                    Int.PutExtra("GroupsId", GroupId);
                    StartActivityForResult(Int, 2005);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Get Data Group

        private void GetDataGroup()
        {
            try
            {
                GroupDataClass = JsonConvert.DeserializeObject<GroupClass>(Intent.GetStringExtra("GroupObject"));
                if (GroupDataClass != null)
                {
                    LoadPassedData(GroupDataClass);
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            StartApiService();
        }

        private void LoadPassedData(GroupClass result)
        {
            try
            {
                GlideImageLoader.LoadImage(this, result.Avatar, UserProfileImage, ImageStyle.CenterCrop, ImagePlaceholders.Color, false);
                GlideImageLoader.LoadImage(this, result.Cover, CoverImage, ImageStyle.CenterCrop, ImagePlaceholders.Drawable, false);

                TxtGroupUsername.Text = "@" + result.Username;
                TxtGroupName.Text = result.Name;
                CategoryText.Text = result.Category;

                if (result.UserId == UserDetails.UserId)
                    result.IsOwner = true;

                if (result.IsOwner)
                {
                    BtnJoin.BackgroundTintList = ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnJoin.Text = GetText(Resource.String.Lbl_Edit);
                    BtnJoin.SetTextColor( Color.White);
                    BtnJoin.Tag = "MyGroup";
                    BtnMore.BackgroundTintList = ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnMore.ImageTintList = ColorStateList.ValueOf(Color.White); 
                }
                else
                {
                    BtnJoin.BackgroundTintList = result.IsJoined == "yes" || result.IsJoined == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnJoin.Text = GetText(result.IsJoined == "yes" || result.IsJoined == "true" ? Resource.String.Btn_Joined : Resource.String.Btn_Join_Group);
                    BtnJoin.SetTextColor(result.IsJoined == "yes" || result.IsJoined == "true" ? Color.Black : Color.White);
                    BtnMore.BackgroundTintList = result.IsJoined == "yes" || result.IsJoined == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnMore.ImageTintList = result.IsJoined == "yes" || result.IsJoined == "true" ? ColorStateList.ValueOf(Color.Black) : ColorStateList.ValueOf(Color.White);
                    BtnJoin.Tag = "UserGroup";
                }
                 
                PrivacyText.Text = GetText(result.Privacy == "1" ? Resource.String.Radio_Public : Resource.String.Radio_Private);

                if (result.Privacy != "1")
                    IconPrivacy.SetImageResource(Resource.Drawable.ic_private);

                if (result.IsOwner)
                {
                    EditAvatarImageGroup.Visibility = ViewStates.Visible;
                    TxtEditGroupInfo.Visibility = ViewStates.Visible;
                }
                else
                {
                    EditAvatarImageGroup.Visibility = ViewStates.Gone;
                    TxtEditGroupInfo.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { GetGroupDataApi, GetJoin,() => MainRecyclerView.FetchNewsFeedApiPosts("0") });
        }

        private async Task GetGroupDataApi()
        {
            var (apiStatus, respond) = await RequestsAsync.Group.Get_Group_Data(GroupId);

            if (apiStatus != 200 || !(respond is GetGroupDataObject result) || result.GroupData == null)
                throw new Exception();

            GroupDataClass = result.GroupData;
            LoadPassedData(GroupDataClass);
        }
          
        #endregion

        #region Update Image Avatar && Cover
         
        private void OpenDialogGallery(string typeImage)
        {
            try
            {
                ImageType = typeImage;
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Function Update Image Group : Avatar && Cover
        private async void UpdateImageGroup_Api(string type, string path)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    if (type == "Avatar")
                    {
                        var (apiStatus, respond) = await RequestsAsync.Group.Update_Group_Avatar(GroupId, path);
                        if (apiStatus == 200)
                        {
                            if (respond is MessageObject result)
                            {
                                Toast.MakeText(this, result.Message, ToastLength.Short).Show();

                                //Set image
                                var file = Uri.FromFile(new File(path));
                                GlideImageLoader.LoadImage(this, file.Path, UserProfileImage, ImageStyle.RoundedCrop, ImagePlaceholders.Color);
                            }
                        }
                        else if (apiStatus == 400)
                        {
                            if (!(respond is ErrorObject error))
                                return;
                            var errorText = error._errors.ErrorText;
                            if (errorText.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);
                        }
                    }
                    else if (type == "Cover")
                    {
                        var (apiStatus, respond) = await RequestsAsync.Group.Update_Group_Cover(GroupId, path);
                        if (apiStatus == 200)
                        {
                            if (!(respond is MessageObject result))
                                return;

                            Toast.MakeText(this, result.Message, ToastLength.Short).Show();

                            //Set image
                            var file = Uri.FromFile(new File(path));
                            GlideImageLoader.LoadImage(this, file.Path, CoverImage, ImageStyle.CenterCrop, ImagePlaceholders.Color);
                        }
                        else if (apiStatus == 400)
                        {
                            if (!(respond is ErrorObject error)) return;
                            var errorText = error._errors.ErrorText;
                            if (errorText.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private async Task GetJoin()
        {
            if (GroupDataClass.UserId == UserDetails.UserId)
            {
                (int apiStatus, var respond) = await RequestsAsync.Group.GetGroupJoinRequests(GroupId, "5");
                if (apiStatus == 200)
                {
                    if (respond is GetGroupJoinRequestsObject result)
                    {
                        RunOnUiThread(() =>
                        {
                            var respondList = result.Data.Count;
                            if (respondList > 0)
                            {
                                LayoutJoinRequest.Visibility = ViewStates.Visible;
                                try
                                {
                                    for (var i = 0; i < 4; i++)
                                        switch (i)
                                        {
                                            case 0:
                                                GlideImageLoader.LoadImage(this, result.Data[i]?.UserData?.Avatar, JoinRequestImage1, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                break;
                                            case 1:
                                                GlideImageLoader.LoadImage(this, result.Data[i]?.UserData?.Avatar, JoinRequestImage2, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                break;
                                            case 2:
                                                GlideImageLoader.LoadImage(this, result.Data[i]?.UserData?.Avatar, JoinRequestImage3, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                break;
                                        }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e);
                                }
                            }
                            else
                            {
                                LayoutJoinRequest.Visibility = ViewStates.Gone;
                            }
                        });
                    }
                }
                else if (apiStatus.Equals(400))
                {
                    if (respond is ErrorObject error)
                    {
                        var errorText = error._errors.ErrorText;

                        if (errorText.Contains("Invalid or expired access_token"))
                            ApiRequest.Logout(this);
                    }
                }
                else if (apiStatus.Equals(404))
                {
                    var error = respond.ToString();
                    Console.WriteLine(error);
                } 
            }
            else
            {
                RunOnUiThread(() => { LayoutJoinRequest.Visibility = ViewStates.Gone; });
            } 
        }
    }
}