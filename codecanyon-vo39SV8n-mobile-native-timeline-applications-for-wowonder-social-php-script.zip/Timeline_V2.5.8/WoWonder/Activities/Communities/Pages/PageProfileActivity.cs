﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Content.Res;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Com.Devs.ReadMoreOptionLib;
using Com.Theartofdev.Edmodo.Cropper;
using Java.Lang;
using Newtonsoft.Json;
using Plugin.Share;
using Plugin.Share.Abstractions;
using WoWonder.Activities.AddPost;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Page;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Requests;
using Exception = System.Exception;
using File = Java.IO.File;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Communities.Pages
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class PageProfileActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    { 
        #region Variables Basic

        private ImageView ProfileImage, CoverImage, IconBack;
        private TextView TxtPageName, TxtPageUsername, CategoryText, IconCategory, IconEdit, AboutDesc,IconLike, LikeCountText;
        private Button BtnLike;
        private ImageButton BtnMore;
        private FloatingActionButton FloatingActionButtonView;
        private LinearLayout EditAvatarImagePage;
        private TextView TxtEditPageInfo;
        private WRecyclerView MainRecyclerView;
        private NativePostAdapter PostFeedAdapter;
        private string PageId = "", ImageType = "";
        private PageClass PageData;

        #endregion
         
        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                View mContentView = Window.DecorView;
                var uiOptions = (int)mContentView.SystemUiVisibility;
                var newUiOptions = (int)uiOptions;

                // newUiOptions |= (int)SystemUiFlags.Fullscreen;
                newUiOptions |= (int)SystemUiFlags.LayoutStable;
                mContentView.SystemUiVisibility = (StatusBarVisibility)newUiOptions;

                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Page_Profile_Layout);

                PageId = Intent.GetStringExtra("PageId") ?? string.Empty;

                //Get Value And Set Toolbar
                InitComponent(); 
                SetRecyclerViewAdapters();

                GetDataPage();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                MainRecyclerView.ReleasePlayer();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                ProfileImage = (ImageView)FindViewById(Resource.Id.image_profile);
                CoverImage = (ImageView)FindViewById(Resource.Id.iv1);
                IconBack = (ImageView)FindViewById(Resource.Id.image_back);
                EditAvatarImagePage = (LinearLayout)FindViewById(Resource.Id.LinearEdit);
                TxtEditPageInfo = (TextView)FindViewById(Resource.Id.tv_EditPageinfo);
                TxtPageName = (TextView)FindViewById(Resource.Id.Page_name);
                TxtPageUsername = (TextView)FindViewById(Resource.Id.Page_Username);
                BtnLike = (Button)FindViewById(Resource.Id.likeButton);
                BtnMore = (ImageButton)FindViewById(Resource.Id.morebutton);
                IconLike = (TextView)FindViewById(Resource.Id.IconLike);
                LikeCountText = (TextView)FindViewById(Resource.Id.LikeCountText);
                IconCategory = (TextView)FindViewById(Resource.Id.IconCategory);
                CategoryText = (TextView)FindViewById(Resource.Id.CategoryText);
                IconEdit = (TextView)FindViewById(Resource.Id.IconEdit);
                AboutDesc = (TextView)FindViewById(Resource.Id.aboutdesc);

                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);

                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconLike, IonIconsFonts.Thumbsup);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconCategory, IonIconsFonts.Pricetag);
                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, IconEdit, IonIconsFonts.Edit); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void SetRecyclerViewAdapters()
        {
            try
            {
                MainRecyclerView = FindViewById<WRecyclerView>(Resource.Id.newsfeedRecyler);
                PostFeedAdapter = new NativePostAdapter(this, MainRecyclerView, NativeFeedType.Page)
                {
                    ApiIdParameter = PageId
                };
                 
                MainRecyclerView.SetXAdapter(PostFeedAdapter, null);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    CoverImage.Click += CoverImageOnClick;
                    BtnLike.Click += BtnLikeOnClick;
                    BtnMore.Click += BtnMoreOnClick;
                    TxtEditPageInfo.Click += TxtEditPageInfoOnClick;
                    IconBack.Click += IconBackOnClick;
                    EditAvatarImagePage.Click += EditAvatarImagePageOnClick;
                    FloatingActionButtonView.Click += AddPostOnClick;
                }
                else
                {
                    CoverImage.Click -= CoverImageOnClick;
                    BtnLike.Click -= BtnLikeOnClick;
                    BtnMore.Click -= BtnMoreOnClick;
                    TxtEditPageInfo.Click -= TxtEditPageInfoOnClick;
                    IconBack.Click -= IconBackOnClick;
                    EditAvatarImagePage.Click -= EditAvatarImagePageOnClick;
                    FloatingActionButtonView.Click -= AddPostOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Events

        //Event Add New post 
        private void AddPostOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(this, typeof(AddPostActivity));
                Int.PutExtra("Type", "SocialPage");
                Int.PutExtra("PostId", PageId);
                Int.PutExtra("itemObject", JsonConvert.SerializeObject(PageData));
                StartActivityForResult(Int, 2500);  
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Update Image Cover Page
        private void EditAvatarImagePageOnClick(object sender, EventArgs e)
        {
            try
            {
                OpenDialogGallery("Avatar");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void IconBackOnClick(object sender, EventArgs e)
        {
            Finish();
        }

        private void TxtEditPageInfoOnClick(object sender, EventArgs e)
        {
            try
            {
                OpenDialogGallery("Cover");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Show More : Copy Link , Share , Edit (If user isOwner_Pages)
        private void BtnMoreOnClick(object sender, EventArgs e)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetString(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(GetString(Resource.String.Lbl_Share));
                if (PageData.IsPageOnwer)
                    arrayAdapter.Add(GetString(Resource.String.Lbl_Edit));

                dialogList.Title(GetString(Resource.String.Lbl_More));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Like => like , dislike 
        private async void BtnLikeOnClick(object sender, EventArgs e)
        {
            try
            {
                if (BtnLike.Tag.ToString() == "MyPage")
                {
                    EditInfoPage_OnClick();
                }
                else
                {
                    if (!Methods.CheckConnectivity())
                    {
                        Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                    }
                    else
                    {
                        var (apiStatus, respond) = await RequestsAsync.Page.Like_Page(PageId);
                        if (apiStatus == 200)
                        {
                            if (respond is LikePageObject result)
                            {
                                string isLiked = result.LikeStatus == "unliked" ? "false" : "true";
                                BtnLike.BackgroundTintList = isLiked == "yes" || isLiked == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                                BtnLike.Text = GetText(isLiked == "yes" || isLiked == "true" ? Resource.String.Btn_Liked : Resource.String.Btn_Like);
                                BtnLike.SetTextColor(isLiked == "yes" || isLiked == "true" ? Color.Black : Color.White);
                                BtnMore.BackgroundTintList = isLiked == "yes" || isLiked == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                                BtnMore.ImageTintList = isLiked == "yes" || isLiked == "true" ? ColorStateList.ValueOf(Color.Black) : ColorStateList.ValueOf(Color.White);
                            }
                        }
                        else if (apiStatus == 400)
                        {
                            if (respond is ErrorObject error)
                            {
                                var errorText = error._errors.ErrorText;

                                if (errorText.Contains("Invalid or expired access_token"))
                                    ApiRequest.Logout(this);
                            }
                        }
                        else if (apiStatus == 404)
                        {
                            var error = respond.ToString();
                            Console.WriteLine(error);
                        }
                    }
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Update Image Cover Page
        private void CoverImageOnClick(object sender, EventArgs e)
        {
            try
            {
                OpenDialogGallery("Cover");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override async void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                //If its from Camera or Gallery
                if (requestCode == CropImage.CropImageActivityRequestCode)
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                string pathImg;
                                if (ImageType == "Cover")
                                {
                                    pathImg = resultUri.Path;
                                    UpdateImagePage_Api(ImageType, pathImg);
                                }
                                else if (ImageType == "Avatar")
                                {
                                    pathImg = resultUri.Path;
                                    UpdateImagePage_Api(ImageType, pathImg);
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                        }
                    } 
                }
                else if (requestCode == 2500 && resultCode == Result.Ok)//add post
                {
                    var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                    if (postData != null)
                    {
                        var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                        MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                        {
                            TypeView = postType,
                            Id = int.Parse(postData.Id),
                            PostData = postData,
                            IsDefaultFeedPost = true,
                        });

                    }
                    else
                    {
                        await MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                    } 
                }
                else if (requestCode == 3950 && resultCode == Result.Ok) //Edit post
                {
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemChanged(index);
                        }
                    }
                }
                else if (requestCode == 2005 && resultCode == Result.Ok)
                {
                    string result = data.GetStringExtra("pageItem"); 
                    var item = JsonConvert.DeserializeObject<PageClass>(result);
                    if (item != null)
                        LoadPassedData(item); 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        OpenDialogGallery(ImageType);
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
   
        #region Update Image Avatar && Cover

        private void OpenDialogGallery(string typeImage)
        {
            try
            {
                ImageType = typeImage;
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Function Update Image Page : Avatar && Cover
        private async void UpdateImagePage_Api(string type, string path)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
                else
                {
                    if (type == "Avatar")
                    {
                        var (apiStatus, respond) = await RequestsAsync.Page.Update_Page_Avatar(PageId, path);
                        if (apiStatus == 200)
                        {
                            if (respond is MessageObject result)
                            {
                                Toast.MakeText(this, result.Message, ToastLength.Short).Show();

                                //Set image
                                var file = Uri.FromFile(new File(path));
                                GlideImageLoader.LoadImage(this, file.Path, ProfileImage, ImageStyle.RoundedCrop, ImagePlaceholders.Color);
                            }
                        }
                        else if (apiStatus == 400)
                        {
                            if (!(respond is ErrorObject error))
                                return;
                            var errorText = error._errors.ErrorText;
                            if (errorText.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);
                        }
                    }
                    else if (type == "Cover")
                    {
                        var (apiStatus, respond) = await RequestsAsync.Page.Update_Page_Cover(PageId, path);
                        if (apiStatus == 200)
                        {
                            if (!(respond is MessageObject result))
                                return;

                            Toast.MakeText(this, result.Message, ToastLength.Short).Show();

                            //Set image
                            var file = Uri.FromFile(new File(path));
                            GlideImageLoader.LoadImage(this, file.Path, CoverImage, ImageStyle.CenterCrop, ImagePlaceholders.Color);
                        }
                        else if (apiStatus == 400)
                        {
                            if (!(respond is ErrorObject error)) return;
                            var errorText = error._errors.ErrorText;
                            if (errorText.Contains("Invalid or expired access_token"))
                                ApiRequest.Logout(this);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Get Data Page
         
        private void GetDataPage()
        {
            try
            { 
                PageData = JsonConvert.DeserializeObject<PageClass>(Intent.GetStringExtra("PageObject"));
                if (PageData != null)
                {
                    LoadPassedData(PageData);
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            StartApiService();
        }

        private void LoadPassedData(PageClass pageData)
        {
            try
            {
                //Extra  
                LikeCountText.Text = pageData.LikesCount;

                if (pageData.IsPageOnwer)
                {
                    BtnLike.BackgroundTintList = ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnLike.Text = GetText(Resource.String.Lbl_Edit);
                    BtnLike.SetTextColor(Color.White);
                    BtnLike.Tag = "MyPage";
                    BtnMore.BackgroundTintList = ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnMore.ImageTintList = ColorStateList.ValueOf(Color.White);
                }
                else
                {
                    BtnLike.BackgroundTintList = pageData.IsLiked == "yes" || pageData.IsLiked == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnLike.Text = GetText(pageData.IsLiked == "yes" || pageData.IsLiked == "true" ? Resource.String.Btn_Liked : Resource.String.Btn_Like);
                    BtnLike.SetTextColor(pageData.IsLiked == "yes" || pageData.IsLiked == "true" ? Color.Black : Color.White);
                    BtnMore.BackgroundTintList = pageData.IsLiked == "yes" || pageData.IsLiked == "true" ? ColorStateList.ValueOf(Color.ParseColor("#efefef")) : ColorStateList.ValueOf(Color.ParseColor(AppSettings.MainColor));
                    BtnMore.ImageTintList = pageData.IsLiked == "yes" || pageData.IsLiked == "true" ? ColorStateList.ValueOf(Color.Black) : ColorStateList.ValueOf(Color.White);
                    BtnLike.Tag = "UserPage";
                }

                if (pageData.IsPageOnwer)
                {
                    EditAvatarImagePage.Visibility = ViewStates.Visible;
                    TxtEditPageInfo.Visibility = ViewStates.Visible;
                    FloatingActionButtonView.Visibility = ViewStates.Visible; 
                }
                else
                {
                    EditAvatarImagePage.Visibility = ViewStates.Gone;
                    TxtEditPageInfo.Visibility = ViewStates.Gone;
                    FloatingActionButtonView.Visibility = ViewStates.Gone;
                }

                GlideImageLoader.LoadImage(this, pageData.Avatar, ProfileImage, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);
                GlideImageLoader.LoadImage(this, pageData.Cover, CoverImage, ImageStyle.CenterCrop, ImagePlaceholders.Drawable);

                TxtPageUsername.Text = "@" + pageData.Username;
                TxtPageName.Text = pageData.Name;

                CategoriesController cat = new CategoriesController();
                CategoryText.Text = cat.Get_Translate_Categories_Communities(pageData.PageCategory, pageData.Category);

                var readMoreOption = new ReadMoreOption.Builder(this)
                    .TextLength(200, ReadMoreOption.TypeCharacter)
                    .MoreLabel(GetText(Resource.String.Lbl_ReadMore))
                    .LessLabel(GetText(Resource.String.Lbl_ReadLess))
                    .MoreLabelColor(Color.ParseColor(AppSettings.MainColor))
                    .LessLabelColor(Color.ParseColor(AppSettings.MainColor))
                    .LabelUnderLine(true)
                    .Build();

                if (Methods.FunString.StringNullRemover(pageData.About) != "Empty")
                {
                    var about = Methods.FunString.DecodeString(pageData.About);
                    readMoreOption.AddReadMoreTo(AboutDesc, about);
                }
                else
                {
                    AboutDesc.Text = GetText(Resource.String.Lbl_NoAnyDescription);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { GetPageDataApi, () => MainRecyclerView.FetchNewsFeedApiPosts("0") });
        }

        private async Task GetPageDataApi()
        {
            var (apiStatus, respond) = await RequestsAsync.Page.Get_Page_Data(PageId);

            if (apiStatus != 200 || !(respond is GetPageDataObject result) || result.PageData == null)
                throw new Exception();

            PageData = result.PageData;
            LoadPassedData(PageData);
        }

        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == GetString(Resource.String.Lbl_CopeLink))
                {
                    CopyLinkEvent();
                }
                else if (text == GetString(Resource.String.Lbl_Share))
                {
                    ShareEvent();
                }
                else if (text == GetString(Resource.String.Lbl_Edit))
                {
                    EditInfoPage_OnClick();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
               if (p1 == DialogAction.Positive)
                    {

                    }
                    else if (p1 == DialogAction.Negative)
                    {
                        p0.Dismiss();
                    }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Copy Link
        private void CopyLinkEvent()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", PageData.Url);
                clipboardManager.PrimaryClip = clipData;

                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Share
        private async void ShareEvent()
        {
            try
            {
                //Share Plugin same as video
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = PageData.PageTitle,
                    Text = PageData.About,
                    Url = PageData.Url
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Edit Info Page if user == is_owner
        private void EditInfoPage_OnClick()
        {
            try
            {
                if (PageData.IsPageOnwer)
                {
                    var Int = new Intent(this, typeof(EditInfoPageActivity));
                    Int.PutExtra("PageData", JsonConvert.SerializeObject(PageData));
                    Int.PutExtra("PagesId", PageId);
                    StartActivityForResult(Int, 2005);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
    }
}