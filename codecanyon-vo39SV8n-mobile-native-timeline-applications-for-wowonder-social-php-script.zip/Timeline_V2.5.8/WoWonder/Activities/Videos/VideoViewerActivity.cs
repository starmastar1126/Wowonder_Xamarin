﻿using System;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Gms.Ads;
using Android.OS;
using Android.Views;
using Newtonsoft.Json;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Movies;
using VideoController = WoWonder.Helpers.Controller.VideoController;

namespace WoWonder.Activities.Videos
{
    [Activity(Theme = "@style/MyTheme", ResizeableActivity = true,ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class VideoViewerActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                SetContentView(Resource.Layout.Video_Viewer_Layout);


                var videoId = Intent.GetStringExtra("VideoId") ?? "Data not available";
                if (videoId != "Data not available" && !string.IsNullOrEmpty(videoId)) IdVideo = videoId;

                GetDataVideo();

                //Show Ads
                AdView = (AdView) FindViewById(Resource.Id.adView);
                if (AppSettings.ShowAdmobBanner)
                {
                    AdView.Visibility = ViewStates.Visible;
                    var adRequest = new AdRequest.Builder();
                    adRequest.AddTestDevice(UserDetails.AndroidId);
                    AdView.LoadAd(adRequest.Build());
                }
                else
                {
                    AdView.Pause();
                    AdView.Visibility = ViewStates.Gone;
                }
                AdsGoogle.Ad_RewardedVideo(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                AdView?.Pause();
                base.OnPause();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AdView?.Resume();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void GetDataVideo()
        {
            try
            {
                var data = JsonConvert.DeserializeObject<GetMoviesObject.Movie>(Intent.GetStringExtra("Viewer_Video"));
                if (data != null)
                {
                    Video = data;

                    VideoActionsController = new VideoController(this, "Viewer_Video");

                    var dbDatabase = new SqLiteDatabase();

                    var dataVideos = dbDatabase.Get_WatchOfflineVideos_ById(Video.Id);
                    if (dataVideos != null)
                        VideoActionsController.PlayVideo(dataVideos.Source, dataVideos);
                    else
                        VideoActionsController.PlayVideo(Video.Source, Video);
                    dbDatabase.Dispose();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Result
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                if (requestCode == 2000)
                    if (resultCode == Result.Ok)
                        VideoActionsController.RestartPlayAfterShrinkScreen();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnBackPressed()
        {
            try
            {
                VideoActionsController.SetStopvideo();
                base.OnBackPressed();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                VideoActionsController.SetStopvideo();


                AdView?.Destroy();

                base.OnDestroy();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #region Variables Basic

        public VideoController VideoActionsController;
        public static VideoDownloadAsyncControler VideoControler; 
        private string IdVideo = "";
        private GetMoviesObject.Movie Video; 
        private AdView AdView;

        #endregion
    }
}