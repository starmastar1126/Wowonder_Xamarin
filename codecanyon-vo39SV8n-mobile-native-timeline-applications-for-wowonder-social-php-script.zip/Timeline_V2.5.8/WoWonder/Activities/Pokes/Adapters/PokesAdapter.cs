﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Java.Util;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Pocks;
using Exception = System.Exception;
using IList = System.Collections.IList;

namespace WoWonder.Activities.Pokes.Adapters
{
    public interface IOnPokeItemClickListener
    {
        void PokeButtonClick(PokesClickEventArgs pokesClickEventArgs);
    }

   
    public class PokesAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {

        public event EventHandler<PokesAdapterClickEventArgs> ItemClick;
        public event EventHandler<PokesAdapterClickEventArgs> ItemLongClick;

        private readonly PokesActivity ActivityContext;
        public ObservableCollection<PokeObject.Datum> PokeList = new ObservableCollection<PokeObject.Datum>();
   
       public IOnPokeItemClickListener PokeItemClickListener { get; set; }
        public PokesAdapter(PokesActivity activity, IOnPokeItemClickListener clickListener)
        {
            try
            {
                PokeItemClickListener = clickListener;
                ActivityContext = activity;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                try
                {
                    if (PokeList == null || PokeList.Count <= 0)
                        return 0;
                    return PokeList.Count;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return 0;
                }
            }
        }
          
        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_HContact_view
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_HContact_view, parent, false);
                var vh = new PokesAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
               
                if (viewHolder is PokesAdapterViewHolder holder)
                {
                    var item = PokeList[position];
                    if (item != null)
                    {

                        if (item.UserData?.UserDataClass != null)
                        {
                            GlideImageLoader.LoadImage(ActivityContext, item.UserData.Value.UserDataClass?.Avatar, holder.Image, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                            holder.Name.Text = Methods.FunString.SubStringCutOf(WoWonderTools.GetNameFinal(item.UserData.Value.UserDataClass), 25);
                        }

                        holder.Button.SetBackgroundResource(Resource.Drawable.follow_button_profile_friends_pressed);
                        holder.Button.SetTextColor(Color.ParseColor("#ffffff"));
                        holder.Button.Text = ActivityContext.GetText(Resource.String.Lbl_PokeBack);
                        holder.BindEvents(position, item, holder.Button, PokeItemClickListener);
                      
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        //public override int GetItemViewType(int position)
        //{
        //    try
        //    {
        //        return position;
        //    }
        //    catch (Exception exception)
        //    {
        //        Console.WriteLine(exception);
        //        return 0;
        //    }
        //}

        public override long GetItemId(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public PokeObject.Datum GetItem(int position)
        {
            return PokeList[position];
        }


        private void Click(PokesAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(PokesAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
         
        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = PokeList[p0];
                if (item == null)
                    return Collections.SingletonList(p0);

                if (item.UserData?.UserDataClass != null && item.UserData.Value.UserDataClass.Avatar != "")
                {
                    d.Add(item.UserData.Value.UserDataClass.Avatar);
                    return d;
                }

                return d;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Collections.SingletonList(p0);
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Java.Lang.Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.CircleCrop);
        }

       
    }

    public class PokesAdapterViewHolder : RecyclerView.ViewHolder
    {
       

        public PokesAdapterViewHolder(View itemView, Action<PokesAdapterClickEventArgs> clickListener, Action<PokesAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                Image = MainView.FindViewById<ImageView>(Resource.Id.card_pro_pic);
                Name = MainView.FindViewById<TextView>(Resource.Id.card_name);
                About = MainView.FindViewById<TextView>(Resource.Id.card_dist);
                Button = MainView.FindViewById<Button>(Resource.Id.cont);

                //Event
                itemView.Click += (sender, e) => clickListener(new PokesAdapterClickEventArgs {View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new PokesAdapterClickEventArgs {View = itemView, Position = AdapterPosition});

                About.Visibility = ViewStates.Gone;

                //Dont Remove this code #####
                FontUtils.SetFont(Name, Fonts.SfRegular);
                FontUtils.SetFont(About, Fonts.SfMedium);
                FontUtils.SetFont(Button, Fonts.SfRegular);
                //##### 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        public void BindEvents(int position, PokeObject.Datum data, Button button, IOnPokeItemClickListener pokeItemClickListener)
        {
            Clicker.SetClickEvents(position, data, button, pokeItemClickListener);
            Button.SetOnClickListener(Clicker);
        }

        public class PokeClickEvents : Java.Lang.Object, View.IOnClickListener
        {
          
            public int Position;
            public PokeObject.Datum UserData;
            public Button PokeButton;
            public IOnPokeItemClickListener PokeItemClickListener;
            public void SetClickEvents(int position, PokeObject.Datum data, Button button, IOnPokeItemClickListener pokeItemClickListener)
            {
                PokeButton = button;
                   UserData = data;
                Position = position;
                PokeItemClickListener = pokeItemClickListener;
            }
            public void OnClick(View v)
            {
                if (PokeButton.Id == v.Id)
                {
                    PokeItemClickListener.PokeButtonClick(new PokesClickEventArgs { UserClass = UserData, Position = Position, ButtonFollow = PokeButton });
                }
            }

        }

        #region Variables Basic

        public View MainView { get; }
         
        public ImageView Image { get; private set; }
        public PokeClickEvents Clicker = new PokeClickEvents();
        public TextView Name { get; private set; }
        public TextView About { get; private set; }
        public Button Button { get; private set; }

        #endregion
    }

    public class PokesAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
     
    public class PokesClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
        public PokeObject.Datum UserClass { get; set; }
        public Button ButtonFollow { get; set; }
    }
}