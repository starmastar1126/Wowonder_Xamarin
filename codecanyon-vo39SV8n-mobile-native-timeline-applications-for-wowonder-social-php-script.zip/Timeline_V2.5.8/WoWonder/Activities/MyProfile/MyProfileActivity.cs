﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using AT.Markushi.UI;
using Bumptech.Glide;
using Bumptech.Glide.Request;
using Com.Theartofdev.Edmodo.Cropper;
using Com.Tuyenmonkey.Textdecorator;
using Java.IO;
using Java.Lang;
using Newtonsoft.Json;
using Plugin.Share;
using Plugin.Share.Abstractions;
using WoWonder.Activities.Communities.Pages;
using WoWonder.Activities.Contacts;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.SettingsPreferences.General;
using WoWonder.Activities.SettingsPreferences.Privacy;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using Console = System.Console;
using Exception = System.Exception;
using Toolbar = Android.Support.V7.Widget.Toolbar;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.MyProfile
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/ProfileTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MyProfileActivity : AppCompatActivity, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private CollapsingToolbarLayout CollapsingToolbar;
        private AppBarLayout AppBarLayout;
        private WRecyclerView MainRecyclerView;
        private NativePostAdapter PostFeedAdapter;
        private SwipeRefreshLayout SwipeRefreshLayout;
        private CircleButton BtnEditDataUser, BtnEditImage, BtnMore;
        private TextView TxtUsername, TxtFollowers, TxtFollowing, TxtPoints;
        private TextView TxtCountFollowers, TxtCountLikes, TxtCountFollowing, TxtCountPoints;
        private ImageView UserProfileImage, CoverImage, IconBack;
        private LinearLayout LayoutCountFollowers, LayoutCountFollowing, LayoutCountLikes, CountPointsLayout, HeaderSection;
        private View OnlineView, ViewPoints, ViewLikes, ViewFollowers;
        private string SUrlUser, ImageType;
        private bool IsPassedDataLoaded;
         
        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.MyProfile_Layout);

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
                SetRecyclerViewAdapters();

                GetMyInfoData();
                PostClickListener.OpenMyProfile = true;

                AdsGoogle.Ad_Interstitial(this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            { 
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                MainRecyclerView.ReleasePlayer();
                PostClickListener.OpenMyProfile = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                CollapsingToolbar = (CollapsingToolbarLayout)FindViewById(Resource.Id.collapsingToolbar);
                CollapsingToolbar.Title = "";

                AppBarLayout = FindViewById<AppBarLayout>(Resource.Id.appBarLayout);
                AppBarLayout.SetExpanded(true);

                BtnEditDataUser = (CircleButton)FindViewById(Resource.Id.AddUserbutton);
                BtnEditImage = (CircleButton)FindViewById(Resource.Id.message_button);
                BtnMore = (CircleButton)FindViewById(Resource.Id.morebutton);
                IconBack = (ImageView)FindViewById(Resource.Id.back);
                TxtUsername = (TextView)FindViewById(Resource.Id.username_profile);
                TxtCountFollowers = (TextView)FindViewById(Resource.Id.CountFollowers);
                TxtCountFollowing = (TextView)FindViewById(Resource.Id.CountFollowing);
                TxtCountLikes = (TextView)FindViewById(Resource.Id.CountLikes);
                TxtFollowers = FindViewById<TextView>(Resource.Id.txtFollowers);
                TxtFollowing = FindViewById<TextView>(Resource.Id.txtFollowing);
                UserProfileImage = (ImageView)FindViewById(Resource.Id.profileimage_head);
                CoverImage = (ImageView)FindViewById(Resource.Id.cover_image);
                OnlineView = FindViewById<View>(Resource.Id.online_view);
                MainRecyclerView = FindViewById<WRecyclerView>(Resource.Id.newsfeedRecyler);
                HeaderSection = FindViewById<LinearLayout>(Resource.Id.headerSection);
                LayoutCountFollowers = FindViewById<LinearLayout>(Resource.Id.CountFollowersLayout);
                LayoutCountFollowing = FindViewById<LinearLayout>(Resource.Id.CountFollowingLayout);
                LayoutCountLikes = FindViewById<LinearLayout>(Resource.Id.CountLikesLayout);

                TxtCountPoints = (TextView)FindViewById(Resource.Id.CountPoints);
                TxtPoints = FindViewById<TextView>(Resource.Id.txtPoints);
                CountPointsLayout = FindViewById<LinearLayout>(Resource.Id.CountPointsLayout);

                ViewPoints = FindViewById<View>(Resource.Id.ViewPoints);
                ViewLikes = FindViewById<View>(Resource.Id.ViewLikes);
                ViewFollowers = FindViewById<View>(Resource.Id.ViewFollowers);

                SwipeRefreshLayout = FindViewById<SwipeRefreshLayout>(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = false;
                
                if (AppSettings.FlowDirectionRightToLeft)
                    IconBack.SetImageResource(Resource.Drawable.ic_action_ic_back_rtl);

                if (AppSettings.ConnectivitySystem == 1) // Following
                {
                    TxtFollowers.Text = GetText(Resource.String.Lbl_Followers);
                    TxtFollowing.Text = GetText(Resource.String.Lbl_Following);
                }
                else // Friend
                {
                    TxtFollowers.Text = GetText(Resource.String.Lbl_Friends);
                    TxtFollowing.Text = GetText(Resource.String.Lbl_Post);
                }

                BtnEditDataUser.Visibility = ViewStates.Visible;
                BtnMore.Visibility = ViewStates.Visible;
                BtnEditImage.Visibility = ViewStates.Visible;

                if (!AppSettings.ShowUserPoint)
                {
                    ViewPoints.Visibility = ViewStates.Gone;
                    CountPointsLayout.Visibility = ViewStates.Gone;

                    HeaderSection.WeightSum = 3;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitToolbar()
        {
            try
            {
                var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (toolbar != null)
                {
                    toolbar.Title = " ";
                    toolbar.SetTitleTextColor(Color.Black);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                PostFeedAdapter = new NativePostAdapter(this, MainRecyclerView, NativeFeedType.User)
                {
                    ApiIdParameter = UserDetails.UserId,
                };
                 
                MainRecyclerView.SetXAdapter(PostFeedAdapter, SwipeRefreshLayout);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    BtnEditDataUser.Click += BtnEditDataUserOnClick;
                    BtnEditImage.Click += BtnEditImageOnClick;
                    BtnMore.Click += BtnMoreOnClick;
                    IconBack.Click += IconBackOnClick;
                    LayoutCountFollowers.Click += LayoutCountFollowersOnClick;
                    LayoutCountFollowing.Click += LayoutCountFollowingOnClick;
                    LayoutCountLikes.Click += LayoutCountLikesOnClick;
                }
                else
                {
                    BtnEditDataUser.Click -= BtnEditDataUserOnClick;
                    BtnEditImage.Click -= BtnEditImageOnClick;
                    BtnMore.Click -= BtnMoreOnClick;
                    IconBack.Click -= IconBackOnClick;
                    LayoutCountFollowers.Click -= LayoutCountFollowersOnClick;
                    LayoutCountFollowing.Click -= LayoutCountFollowingOnClick;
                    LayoutCountLikes.Click -= LayoutCountLikesOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Events

        //Event Show All Page Likes
        private void LayoutCountLikesOnClick(object sender, EventArgs e)
        {
            try
            {
                var intent = new Intent(this, typeof(PagesActivity));
                intent.PutExtra("UserID", UserDetails.UserId);
                StartActivity(intent);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Show All Users Following  
        private void LayoutCountFollowingOnClick(object sender, EventArgs e)
        {
            try
            {
                if (LayoutCountFollowing.Tag.ToString() == "Following")
                {
                    var intent = new Intent(this, typeof(MyContactsActivity));
                    intent.PutExtra("ContactsType", "Following");
                    intent.PutExtra("UserId", UserDetails.UserId);
                    StartActivity(intent);
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Event Show All Users Followers 
        private void LayoutCountFollowersOnClick(object sender, EventArgs e)
        {
            try
            {
                var intent = new Intent(this, typeof(MyContactsActivity));
                intent.PutExtra("ContactsType", "Followers");
                intent.PutExtra("UserId", UserDetails.UserId);
                StartActivity(intent);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void IconBackOnClick(object sender, EventArgs e)
        {
            Finish();
        }

        private void BtnMoreOnClick(object sender, EventArgs e)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);
                arrayAdapter.Add(GetText(Resource.String.Lbl_CopeLink));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Share));
                arrayAdapter.Add(GetText(Resource.String.Lbl_ViewPrivacy));
                arrayAdapter.Add(GetText(Resource.String.Lbl_SettingsAccount));
                dialogList.Title(Resource.String.Lbl_More);
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnEditImageOnClick(object sender, EventArgs e)
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);
                arrayAdapter.Add(GetText(Resource.String.Lbl_Avatar));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Cover));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void BtnEditDataUserOnClick(object sender, EventArgs e)
        {
            try
            {
                var Int = new Intent(this, typeof(EditMyProfileActivity));
                StartActivity(Int);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Get Profile

        private void GetMyInfoData()
        {
            try
            {
                var dataUser = ListUtils.MyProfileList.FirstOrDefault(); 
                LoadPassedDate(dataUser);

                StartApiService();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { GetProfileApi, () => MainRecyclerView.FetchNewsFeedApiPosts("0") });
        }

        private async Task GetProfileApi()
        {
            var (apiStatus, respond) = await RequestsAsync.Global.Get_User_Data(UserDetails.UserId, "user_data,followers,following");

            if (apiStatus != 200 || !(respond is GetUserDataObject result) || result.UserData == null)
            {
                Methods.DisplayReportResult(this, respond);
            }
            else
            {
                if (!IsPassedDataLoaded)
                    LoadPassedDate(result.UserData);
                  
                //if (result.likedPages.Length > 0)
                //    RunOnUiThread(() => { LoadPagesLayout(result.likedPages); });

                //if (result.joinedGroups.Length > 0)
                //    RunOnUiThread(() => { LoadGroupsLayout(result.joinedGroups, IMethods.FunString.FormatPriceValue(int.Parse(result.UserProfileObject.Details.GroupsCount))); });

                //if (SPrivacyFriend == "0" || result.UserProfileObject?.IsFollowing == "1" && SPrivacyFriend == "1" || SPrivacyFriend == "2")
                    if (result.Followers.Count > 0)
                        RunOnUiThread(() => { LoadFriendsLayout(result.Followers, Methods.FunString.FormatPriceValue(int.Parse(result.UserData.Details.FollowersCount))); });
                 
                var addPostBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.AddPostBox,
                    Id = 2
                };

                //##Set the AddBox place on Main RecyclerView
                //------------------------------------------------------------------------
                //var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.PagesBox);
                //var check2 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.GroupsBox);
                var check3 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.FollowersBox);
                //var check4 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.ImagesBox);
                var check5 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AboutBox);
                var check6 = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.EmptyState);

                //if (check != null)
                //{
                //    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check) + 1, addPostBox);
                //    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check) + 1);
                //}
                //else if (check2 != null)
                //{
                //    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check2) + 1, addPostBox);
                //    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check2) + 1);
                //}
                //else
                if (check3 != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check3) + 1, addPostBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check3) + 1);
                }
                //else if (check4 != null)
                //{
                //    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check4) + 1, addPostBox);
                //    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check4) + 1);
                //}
                else if (check5 != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check5) + 1, addPostBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check5) + 1);
                }
                else if (check6 != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check6) + 1, addPostBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check6) + 1);
                }
                //------------------------------------------------------------------------

                RunOnUiThread(() =>
                {
                    var sqlEntity = new SqLiteDatabase();
                    sqlEntity.Insert_Or_Update_To_MyProfileTable(result.UserData);
                    sqlEntity.Insert_Or_Replace_MyContactTable(new ObservableCollection<UserDataObject>(result.Following));
                    sqlEntity.Insert_Or_Replace_MyFollowersTable(new ObservableCollection<UserDataObject>(result.Followers));
                    sqlEntity.Dispose();
                }); 
            } 
        }
        
        private void LoadPassedDate(UserDataObject result)
        {
            try
            { 
                //TxtUsername.Text = result.Name;
                SUrlUser = result.Url;

                var font = Typeface.CreateFromAsset(Application.Context.Resources.Assets, "ionicons.ttf");
                TxtUsername.SetTypeface(font, TypefaceStyle.Normal);

                var textHighLighter = result.Name;
                var textIsPro = string.Empty;
                 
                if (result.Verified == "1")
                    textHighLighter += " " + IonIconsFonts.CheckmarkCircled;

                if (result.IsPro == "1")
                {
                    textIsPro = " " + IonIconsFonts.Flash;
                    textHighLighter += textIsPro;
                }
                
                var decorator = TextDecorator.Decorate(TxtUsername, textHighLighter);

                if (result.Verified == "1")
                    decorator.SetTextColor(Resource.Color.Post_IsVerified, IonIconsFonts.CheckmarkCircled);

                if (result.IsPro == "1") { }
                decorator.SetTextColor(Resource.Color.white, textIsPro);

                decorator.Build();
                
                if (result.LastseenStatus == "on")
                    OnlineView.Visibility = ViewStates.Visible;

                var checkAboutBox = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AboutBox);
                if (checkAboutBox == null)
                { 
                    var aboutBox = new AdapterModelsClass
                    {
                        TypeView = PostModelType.AboutBox,
                        Id = 0000,
                        AboutModel = new AboutModelClass {Description = WoWonderTools.GetAboutFinal(result)},
                    };
                     
                    PostFeedAdapter.PostFeedList.Insert(0, aboutBox);
                    PostFeedAdapter.NotifyItemInserted(0);
                }
                else
                {
                    checkAboutBox.AboutModel.Description = WoWonderTools.GetAboutFinal(result); 
                    PostFeedAdapter.NotifyItemChanged(0);
                }

                GlideImageLoader.LoadImage(this, result.Avatar, UserProfileImage, ImageStyle.CircleCrop, ImagePlaceholders.Color, false);
                //GlideImageLoader.LoadImage(this, result.Cover, CoverImage, ImageStyle.FitCenter, ImagePlaceholders.Color, false);
                Glide.With(this).Load(result.Cover).Apply(new RequestOptions()).Into(CoverImage);

                //Set Privacy User
                //==================================
                //SPrivacyBirth = result.BirthPrivacy;
                //SPrivacyFollow = result.FollowPrivacy;
                //SPrivacyFriend = result.FriendPrivacy;
                //SPrivacyMessage = result.MessagePrivacy;
                TxtCountLikes.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Details.LikesCount));

                //SetProfilePrivacy(result);

                if (AppSettings.ShowUserPoint)
                    TxtCountPoints.Text = Methods.FunString.FormatPriceValue(int.Parse(result.Points));

                if (result.Details != null)
                {    
                    // Following
                    if (AppSettings.ConnectivitySystem == 1)
                    {
                        TxtFollowers.Text = GetText(Resource.String.Lbl_Followers);
                        TxtFollowing.Text = GetText(Resource.String.Lbl_Following);

                        TxtCountFollowers.Text =Methods.FunString.FormatPriceValue(int.Parse(result.Details.FollowersCount));
                        TxtCountFollowing.Text =Methods.FunString.FormatPriceValue(int.Parse(result.Details.FollowingCount));

                        LayoutCountFollowing.Tag = "Following";
                    }
                    else // Friend
                    {
                        TxtFollowers.Text = GetText(Resource.String.Lbl_Friends);
                        TxtFollowing.Text = GetText(Resource.String.Lbl_Post);

                        TxtCountFollowers.Text =Methods.FunString.FormatPriceValue(int.Parse(result.Details.FollowersCount));
                        TxtCountFollowing.Text =Methods.FunString.FormatPriceValue(int.Parse(result.Details.PostCount));

                        LayoutCountFollowing.Tag = "Post";
                    }
                }

                IsPassedDataLoaded = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadFriendsLayout(List<UserDataObject> followers, string friendsCounter)
        {
            try
            {
                BtnMore.Visibility = ViewStates.Visible;

                var followersClass = new FollowersModelClass
                {
                    TitleHead = GetText(AppSettings.ConnectivitySystem == 1 ? Resource.String.Lbl_Following : Resource.String.Lbl_Friends),
                    FollowersList = new List<UserDataObject>(followers.Take(12)),
                    More = friendsCounter
                };

                var followersBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.FollowersBox,
                    Id = 1111111111,
                    FollowersModel = followersClass
                };

                var check = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.ImagesBox);
                if (check != null)
                {
                    PostFeedAdapter.PostFeedList.Insert(PostFeedAdapter.PostFeedList.IndexOf(check) + 1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(PostFeedAdapter.PostFeedList.IndexOf(check) + 1);
                }
                else
                {
                    PostFeedAdapter.PostFeedList.Insert(1, followersBox);
                    PostFeedAdapter.NotifyItemInserted(1);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region MaterialDialog
         
        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                string text = itemString.ToString();
                if (text == GetText(Resource.String.Lbl_Avatar))
                { 
                    OpenDialogGallery("Avatar");
                }
                else if (text == GetText(Resource.String.Lbl_Cover))
                {
                    OpenDialogGallery("Cover");
                }
                else if (text == GetText(Resource.String.Lbl_CopeLink))
                {
                    OnCopeLinkToProfile_Button_Click();
                } 
                else if (text == GetText(Resource.String.Lbl_Share))
                {
                    OnShare_Button_Click();
                } 
                else if (text == GetText(Resource.String.Lbl_ViewPrivacy))
                {
                    OnViewPrivacy_Button_Click();
                } 
                else if (text == GetText(Resource.String.Lbl_SettingsAccount))
                {
                    OnSettingsAccount_Button_Click();
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Cope Link To Profile
        private void OnCopeLinkToProfile_Button_Click()
        {
            try
            {
                var clipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

                var clipData = ClipData.NewPlainText("text", SUrlUser);
                clipboardManager.PrimaryClip = clipData;


                Toast.MakeText(this, GetText(Resource.String.Lbl_Copied), ToastLength.Short).Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> Share
        private async void OnShare_Button_Click()
        {
            try
            {
                //Share Plugin same as video
                if (!CrossShare.IsSupported) return;

                await CrossShare.Current.Share(new ShareMessage
                {
                    Title = UserDetails.Username,
                    Text = "",
                    Url = SUrlUser
                });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> View Privacy Shortcuts
        private void OnViewPrivacy_Button_Click()
        {
            try
            {
                var intent = new Intent(this, typeof(PrivacyActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Event Menu >> General Account 
        private void OnSettingsAccount_Button_Click()
        {
            try
            {
                var intent = new Intent(this, typeof(GeneralAccountActivity));
                StartActivity(intent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Update Image Avatar && Cover

        private void OpenDialogGallery(string typeImage)
        {
            try
            {
                ImageType = typeImage;
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private async void Update_Image_Api(string type, string path)
        {
            try
            {
                if (!Methods.CheckConnectivity())
                {
                    Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short)
                        .Show();
                }
                else
                {
                    if (type == "Avatar")
                    {
                        var (apiStatus, respond) = await RequestsAsync.Global.Update_User_Avatar(path);
                        if (apiStatus == 200)
                        {
                            if (respond is MessageObject result)
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_Image_changed_successfully), ToastLength.Short).Show();

                                //Set image 
                                var file = Uri.FromFile(new File(path)); 
                                GlideImageLoader.LoadImage(this, file.Path, UserProfileImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                            }
                        }
                        else if (apiStatus == 400)
                        {
                            if (respond is ErrorObject error)
                            {
                                var errorText = error._errors.ErrorText;
                                 
                                if (errorText.Contains("Invalid or expired access_token"))
                                    ApiRequest.Logout(this);
                            }
                        }
                        else if (apiStatus == 404)
                        {
                            var error = respond.ToString();
                            Console.WriteLine(error);
                        }
                    }
                    else if (type == "Cover")
                    {
                        var (apiStatus, respond) = await RequestsAsync.Global.Update_User_Cover(path);
                        if (apiStatus == 200)
                        {
                            if (respond is MessageObject result)
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_Image_changed_successfully), ToastLength.Short).Show();

                                //Set image 
                                var file = Uri.FromFile(new File(path));
                                GlideImageLoader.LoadImage(this, file.Path, CoverImage, ImageStyle.FitCenter, ImagePlaceholders.Drawable);
                            }
                        }
                        else if (apiStatus == 400)
                        {
                            if (respond is ErrorObject error)
                            {
                                var errorText = error._errors.ErrorText; 
                                if (errorText.Contains("Invalid or expired access_token"))
                                    ApiRequest.Logout(this);
                            }
                        }
                        else if (apiStatus == 404)
                        {
                            var error = respond.ToString();
                            Console.WriteLine(error);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override async void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                //If its from Camera or Gallery
                if (requestCode == CropImage.CropImageActivityRequestCode)
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                var pathimg = "";
                                if (ImageType == "Cover")
                                {
                                    pathimg = resultUri.Path;
                                    Update_Image_Api(ImageType, pathimg);
                                }
                                else if (ImageType == "Avatar")
                                {
                                    pathimg = resultUri.Path;
                                    Update_Image_Api(ImageType, pathimg);
                                }
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong),
                                    ToastLength.Long).Show();
                            }
                        } 
                    } 
                }
                else if (requestCode == 2500 && resultCode == Result.Ok) //add post
                {
                    var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                    if (postData != null)
                    {
                        var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                        MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                        {
                            TypeView = postType,
                            Id = int.Parse(postData.Id),
                            PostData = postData,
                            IsDefaultFeedPost = true,
                        });
                    }
                    else
                    {
                        await MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                    }
                }
                else if (requestCode == 3950 && resultCode == Result.Ok) //Edit post
                {
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemChanged(index);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        OpenDialogGallery(ImageType);
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion
         
    }
}