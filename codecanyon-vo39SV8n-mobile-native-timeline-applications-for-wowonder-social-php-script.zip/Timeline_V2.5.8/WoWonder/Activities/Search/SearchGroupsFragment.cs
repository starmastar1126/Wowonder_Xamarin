﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Android.Gms.Ads;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using WoWonder.Activities.Communities.Groups;
using WoWonder.Activities.Search.Adapters;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;

namespace WoWonder.Activities.Search
{
    public class SearchGroupsFragment : Fragment
    {
        #region Variables Basic

        public SearchGroupAdapter MAdapter;
        private SearchTabbedActivity ContextSearch;
        private SwipeRefreshLayout SwipeRefreshLayout;
        public RecyclerView MRecycler;
        public ProgressBar ProgressBarLoader;
        private LinearLayoutManager LayoutManager;
        public ViewStub EmptyStateLayout;
        public View Inflated;
        public RecyclerViewOnScrollListener MainScrollEvent;
        private AdView MAdView;

        #endregion

        #region General

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.SearchUsers_Layout, container, false);

                ContextSearch = (SearchTabbedActivity)Activity;

                InitComponent(view);
                InitAdView(view);
                SetRecyclerViewAdapters();

                if (!string.IsNullOrEmpty(ContextSearch.DataKey))
                {
                    ContextSearch.Search();

                    if (ContextSearch.DataKey == "Random_Groups")
                    {
                        if (ProgressBarLoader != null)
                            ProgressBarLoader.Visibility = ViewStates.Visible;

                        if (EmptyStateLayout != null)
                            EmptyStateLayout.Visibility = ViewStates.Gone;

                        if (MRecycler != null)
                            MRecycler.Visibility = ViewStates.Visible;

                        ContextSearch.ViewPager.SetCurrentItem(2, true);
                    }
                    else if (ContextSearch.DataKey == "Random_Pages")
                    {
                        if (ContextSearch.PagesTab.ProgressBarLoader != null)
                            ContextSearch.PagesTab.ProgressBarLoader.Visibility = ViewStates.Visible;


                        if (ContextSearch.PagesTab.EmptyStateLayout != null)
                            ContextSearch.PagesTab.EmptyStateLayout.Visibility = ViewStates.Gone;

                        if (ContextSearch.PagesTab.MRecycler != null)
                            ContextSearch.PagesTab.MRecycler.Visibility = ViewStates.Visible;

                        ContextSearch.ViewPager.SetCurrentItem(1, true);
                    }
                } 

                return view;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                MRecycler = (RecyclerView)view.FindViewById(Resource.Id.recyler);
                EmptyStateLayout = view.FindViewById<ViewStub>(Resource.Id.viewStub);

                ProgressBarLoader = (ProgressBar)view.FindViewById(Resource.Id.sectionProgress);
                ProgressBarLoader.Visibility = ViewStates.Gone;

                SwipeRefreshLayout = (SwipeRefreshLayout)view.FindViewById(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = false;
                SwipeRefreshLayout.Enabled = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                MAdapter = new SearchGroupAdapter(Activity) { GroupList = new ObservableCollection<GroupClass>() };
                MAdapter.ItemClick += MAdapterOnItemClick;
                LayoutManager = new LinearLayoutManager(Activity);
                MRecycler.SetLayoutManager(LayoutManager); 
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true;
                var sizeProvider = new FixedPreloadSizeProvider(10, 10);
                var preLoader = new RecyclerViewPreloader<GroupClass>(Activity, MAdapter, sizeProvider, 10);
                MRecycler.AddOnScrollListener(preLoader);
                MRecycler.SetAdapter(MAdapter);

                RecyclerViewOnScrollListener xamarinRecyclerViewOnScrollListener = new RecyclerViewOnScrollListener(LayoutManager);
                MainScrollEvent = xamarinRecyclerViewOnScrollListener;
                MainScrollEvent.LoadMoreEvent += MainScrollEventOnLoadMoreEvent;
                MRecycler.AddOnScrollListener(xamarinRecyclerViewOnScrollListener);
                MainScrollEvent.IsLoading = false;

                if (Inflated == null)
                    Inflated = EmptyStateLayout.Inflate();

                EmptyStateInflater x = new EmptyStateInflater();
                x.InflateLayout(Inflated, EmptyStateInflater.Type.NoSearchResult);
                if (!x.EmptyStateButton.HasOnClickListeners)
                {
                    x.EmptyStateButton.Click += null;
                    x.EmptyStateButton.Click += ContextSearch.TryAgainButton_Click;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void InitAdView(View view)
        {
            try
            {
                MAdView = view.FindViewById<AdView>(Resource.Id.adView);
                if (AppSettings.ShowAdmobBanner)
                {
                    MAdView.Visibility = ViewStates.Visible;
                    var adRequest = new AdRequest.Builder();
                    adRequest.AddTestDevice(UserDetails.AndroidId);
                    MAdView.LoadAd(adRequest.Build());
                }
                else
                {
                    MAdView.Pause();
                    MAdView.Visibility = ViewStates.Invisible;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Event

        //Scroll
        private void MainScrollEventOnLoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                //Code get last id where LoadMore >>
                var item = MAdapter.GroupList.LastOrDefault();
                if (item != null && !string.IsNullOrEmpty(item.GroupId))
                {
                    ContextSearch.OffsetGroup = item.GroupId;
                    ContextSearch.StartApiService();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void MAdapterOnItemClick(object sender, SearchGroupAdapterClickEventArgs e)
        {
            try
            {
                var item = MAdapter.GetItem(e.Position);
                if (item != null)
                {
                    MainApplication.GetInstance()?.NavigateTo(Activity, typeof(GroupProfileActivity), item);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

    }
}