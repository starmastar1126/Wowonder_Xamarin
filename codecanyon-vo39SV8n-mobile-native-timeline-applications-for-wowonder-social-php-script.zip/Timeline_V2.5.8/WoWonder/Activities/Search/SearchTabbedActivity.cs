﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Activities.NativePost.Pages;
using WoWonder.Activities.Tabbes;
using WoWonder.Activities.Tabbes.Adapters;
using WoWonder.Adapters;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.User;
using WoWonderClient.Requests;
using SearchView = Android.Support.V7.Widget.SearchView;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace WoWonder.Activities.Search
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class SearchTabbedActivity : AppCompatActivity
    {
        #region Variables Basic

        private AppBarLayout AppBarLayout;
        private TabLayout TabLayout;
        public ViewPager ViewPager;
        private SearchView SearchView;
        private RecyclerView HashRecyclerView;
        public string DataKey, SearchText = "";
        public string OffsetUser = "", OffsetPage = "", OffsetGroup = "";
        private SearchUserFragment UserTab;
        public SearchPagesFragment PagesTab;
        public SearchGroupsFragment GroupsTab;
        private FloatingActionButton FloatingActionButtonView;
        private Toolbar Toolbar;
        
        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                Window.SetSoftInputMode(SoftInput.AdjustNothing);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Search_Tabbed_Layout);

                DataKey = Intent.GetStringExtra("Key") ?? "Data not available";
                if (DataKey != "Data not available" && !string.IsNullOrEmpty(DataKey))
                {
                    SearchText = DataKey; 
                }

                //Get Value And Set Toolbar
                InitComponent();
                InitToolbar();
               

                if (SearchText == "Random" || SearchText == "Random_Groups" || SearchText == "Random_Pages")
                {
                    SearchText = "a";
                }
                else if (!string.IsNullOrEmpty(SearchText))
                {
                    SearchView?.SetQuery(SearchText, false);
                }
                else
                {
                    if (SearchView == null) return;
                    //SearchView.SetQuery(SearchText, false);
                    SearchView.ClearFocus();
                    //SearchView.OnActionViewCollapsed();
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                AddOrRemoveEvent(true); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                if (SearchView != null)
                {
                    SearchView.SetQuery("", false);
                    SearchView.ClearFocus();
                    SearchView.OnActionViewCollapsed();
                }

                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Menu

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        #endregion
 
        #region Functions

        private void InitComponent()
        {
            try
            {
                TabLayout = FindViewById<TabLayout>(Resource.Id.Searchtabs);
                ViewPager = FindViewById<ViewPager>(Resource.Id.Searchviewpager);
                 
                AppBarLayout = FindViewById<AppBarLayout>(Resource.Id.mainAppBarLayout);
                AppBarLayout.SetExpanded(true);
                 
                HashRecyclerView = FindViewById<RecyclerView>(Resource.Id.HashRecyler);

                if (AppSettings.ShowTrendingHashTags)
                {
                    if (TabbedMainActivity.GetInstance()?.HashTagUserAdapter?.MHashtagList?.Count > 0)
                    {
                        HashRecyclerView.SetLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.Horizontal,false));
                        HashRecyclerView.SetAdapter(TabbedMainActivity.GetInstance().HashTagUserAdapter);
                        TabbedMainActivity.GetInstance().HashTagUserAdapter.ItemClick += HashTagUserAdapterOnItemClick;
                        HashRecyclerView.SetAdapter(TabbedMainActivity.GetInstance().HashTagUserAdapter);
                        TabbedMainActivity.GetInstance()?.HashTagUserAdapter.BindEnd();

                        HashRecyclerView.Visibility = ViewStates.Visible;
                    }
                    else
                    {
                        HashRecyclerView.Visibility = ViewStates.Invisible;
                    }
                }
                else
                {
                    HashRecyclerView.Visibility = ViewStates.Invisible;
                }

                FloatingActionButtonView = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);
                   
                ViewPager.OffscreenPageLimit = 3;
                SetUpViewPager(ViewPager);
                TabLayout.SetupWithViewPager(ViewPager); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void InitToolbar()
        {
            try
            {
                Toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
                if (Toolbar != null)
                {
                    Toolbar.Title = " ";
                    Toolbar.SetTitleTextColor(Color.White);
                    SetSupportActionBar(Toolbar);
                    SupportActionBar.SetDisplayShowCustomEnabled(true);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetHomeButtonEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                }

                SearchView = FindViewById<SearchView>(Resource.Id.searchBox);
                SearchView.SetQuery("", false);
                SearchView.SetIconifiedByDefault(false);
                SearchView.OnActionViewExpanded();
                SearchView.Iconified = false;
                SearchView.QueryTextChange += SearchViewOnQueryTextChange;
                SearchView.QueryTextSubmit += SearchViewOnQueryTextSubmit;
                SearchView.ClearFocus();

                //Change text colors
                var editText = (EditText)SearchView.FindViewById(Resource.Id.search_src_text);
                editText.SetHintTextColor(Color.White);
                editText.SetTextColor(Color.White);

                //Remove Icon Search
                ImageView searchViewIcon = (ImageView)SearchView.FindViewById(Resource.Id.search_mag_icon);
                ViewGroup linearLayoutSearchView = (ViewGroup)searchViewIcon.Parent;
                linearLayoutSearchView.RemoveView(searchViewIcon); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    FloatingActionButtonView.Click += FloatingActionButtonViewOnClick;
                }
                else
                {
                    FloatingActionButtonView.Click -= FloatingActionButtonViewOnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion

        #region Set Tab 

        private void SetUpViewPager(ViewPager viewPager)
        {
            try
            {
                UserTab = new SearchUserFragment();
                PagesTab = new SearchPagesFragment();
                GroupsTab = new SearchGroupsFragment();

                var adapter = new MainTabAdapter(SupportFragmentManager);
                adapter.AddFragment(UserTab, GetText(Resource.String.Lbl_Users));
                adapter.AddFragment(PagesTab, GetText(Resource.String.Lbl_Pages));
                adapter.AddFragment(GroupsTab, GetText(Resource.String.Lbl_Groups));

                viewPager.OffscreenPageLimit = 3;
                viewPager.Adapter = adapter;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Events

        private void HashTagUserAdapterOnItemClick(object sender, HashtagUserAdapterClickEventArgs adapterClickEvents)
        {
            try
            {
                var position = adapterClickEvents.Position;
                if (position >= 0)
                {
                    var item = TabbedMainActivity.GetInstance()?.HashTagUserAdapter.GetItem(position);
                    if (item != null)
                    {
                        string id = item.Hash.Replace("#", "").Replace("_", " ");
                        string tag = item.Tag.Replace("#", "");
                        var Int = new Intent(this, typeof(HashTagPostsActivity));
                        Int.PutExtra("Id", id);
                        Int.PutExtra("Tag", tag);
                        StartActivity(Int);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Filter
        private void FloatingActionButtonViewOnClick(object sender, EventArgs e)
        {
            try
            {
                FilterSearchDialogFragment mFragment = new FilterSearchDialogFragment();
                mFragment.Show(SupportFragmentManager, mFragment.Tag);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void SearchViewOnQueryTextSubmit(object sender, SearchView.QueryTextSubmitEventArgs e)
        {
            try
            {
                SearchText = e.NewText;

                SearchView.ClearFocus();

                UserTab.MAdapter.UserList.Clear();
                UserTab.MAdapter.NotifyDataSetChanged();

                PagesTab.MAdapter.PageList.Clear();
                PagesTab.MAdapter.NotifyDataSetChanged();

                GroupsTab.MAdapter.GroupList.Clear();
                GroupsTab.MAdapter.NotifyDataSetChanged();

                OffsetUser = "0";
                OffsetPage = "0";
                OffsetGroup = "0";

                if (Methods.CheckConnectivity())
                {
                    if (UserTab.MAdapter.UserList.Count > 0)
                    {
                        UserTab.MAdapter.UserList.Clear();
                        UserTab.MAdapter.NotifyDataSetChanged();
                    }

                    if (PagesTab.MAdapter.PageList.Count > 0)
                    {
                        PagesTab.MAdapter.PageList.Clear();
                        PagesTab.MAdapter.NotifyDataSetChanged();
                    }

                    UserTab.ProgressBarLoader.Visibility = ViewStates.Visible;
                    UserTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                    StartApiService();
                }
                else
                {
                    if (UserTab.Inflated == null)
                        UserTab.Inflated = UserTab.EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(UserTab.Inflated, EmptyStateInflater.Type.NoConnection);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click -= EmptyStateButtonOnClick;
                        x.EmptyStateButton.Click -= TryAgainButton_Click;
                    }

                    x.EmptyStateButton.Click += TryAgainButton_Click;
                    UserTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                    UserTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void SearchViewOnQueryTextChange(object sender, SearchView.QueryTextChangeEventArgs e)
        {
            try
            {
                SearchText = e.NewText;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion
         
        #region Load Data Search 

        public void Search()
        {
            try
            { 
                if (!string.IsNullOrEmpty(SearchText))
                {
                    if (Methods.CheckConnectivity())
                    {
                        UserTab.MAdapter?.UserList?.Clear();
                        UserTab.MAdapter?.NotifyDataSetChanged();

                        PagesTab.MAdapter?.PageList?.Clear();
                        PagesTab.MAdapter?.NotifyDataSetChanged();

                        GroupsTab.MAdapter?.GroupList?.Clear();
                        GroupsTab.MAdapter?.NotifyDataSetChanged();

                        if (UserTab.ProgressBarLoader != null)
                            UserTab.ProgressBarLoader.Visibility = ViewStates.Visible;

                        if (UserTab.EmptyStateLayout != null)
                            UserTab.EmptyStateLayout.Visibility = ViewStates.Gone;

                        StartApiService();
                    }
                }
                else
                {
                    if (UserTab.Inflated == null)
                        UserTab.Inflated = UserTab.EmptyStateLayout?.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(UserTab.Inflated, EmptyStateInflater.Type.NoSearchResult);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click -= EmptyStateButtonOnClick;
                        x.EmptyStateButton.Click -= TryAgainButton_Click;
                    }

                    x.EmptyStateButton.Click += TryAgainButton_Click;
                    if (UserTab.EmptyStateLayout != null)
                    {
                        UserTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    } 

                    UserTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                    PagesTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                    GroupsTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(this, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { StartSearchRequest  });
        }

        private async Task StartSearchRequest()
        {
            int countUserList = UserTab.MAdapter.UserList.Count;
            int countPageList = PagesTab.MAdapter.PageList.Count;
            int countGroupList = GroupsTab.MAdapter.GroupList.Count;

            var dictionary = new Dictionary<string, string>
            {
                {"user_id", UserDetails.UserId},
                {"limit", "30"},
                {"user_offset", OffsetUser},
                {"group_offset", OffsetGroup},
                {"page_offset", OffsetPage},
                {"gender", UserDetails.SearchGender},
                {"search_key", SearchText},
                {"country", UserDetails.SearchCountry},
                {"status", UserDetails.SearchStatus},
                {"verified", UserDetails.SearchVerified},
                {"filterbyage", UserDetails.SearchFilterByAge},
                {"age_from", UserDetails.SearchAgeFrom},
                {"age_to", UserDetails.SearchAgeTo},
            };

            (int apiStatus, var respond) = await RequestsAsync.Global.Get_Search(dictionary);
            if (apiStatus == 200)
            {
                if (respond is GetSearchObject result)
                {
                    var respondUserList = result.Users?.Count;
                    if (respondUserList > 0)
                    {
                        if (countUserList > 0)
                        {
                            foreach (var item in result.Users)
                            {
                                var check = UserTab.MAdapter.UserList.FirstOrDefault(a => a.UserId == item.UserId);
                                if (check == null)
                                {
                                    UserTab.MAdapter.UserList.Add(item);
                                }
                            }
                           
                            RunOnUiThread(() => { UserTab.MAdapter.NotifyItemRangeInserted(countUserList - 1, UserTab.MAdapter.UserList.Count - countUserList); }); 
                        }
                        else
                        {
                            UserTab.MAdapter.UserList = new ObservableCollection<UserDataObject>(result.Users);
                            RunOnUiThread(() => { UserTab.MAdapter.NotifyDataSetChanged(); }); 
                        }
                    }
                    else
                    {
                        if (UserTab.MAdapter.UserList.Count > 10 && !UserTab.MRecycler.CanScrollVertically(1))
                            Toast.MakeText(this, GetText(Resource.String.Lbl_No_more_users), ToastLength.Short).Show();
                    }

                    var respondPageList = result.Pages?.Count;
                    if (respondPageList > 0)
                    {
                        if (countPageList > 0)
                        {
                            foreach (var item in result.Pages)
                            {
                                var check = PagesTab.MAdapter.PageList.FirstOrDefault(a => a.Id == item.Id);
                                if (check == null)
                                {
                                    PagesTab.MAdapter.PageList.Add(item);
                                }
                            }

                            RunOnUiThread(() => { PagesTab.MAdapter.NotifyItemRangeInserted(countPageList - 1, PagesTab.MAdapter.PageList.Count - countPageList); });
                        }
                        else
                        {
                            PagesTab.MAdapter.PageList = new ObservableCollection<PageClass>(result.Pages);
                            RunOnUiThread(() => { PagesTab.MAdapter.NotifyDataSetChanged(); }); 
                        }
                    }
                    else
                    {
                        if (PagesTab.MAdapter.PageList.Count > 10 && !PagesTab.MRecycler.CanScrollVertically(1))
                            Toast.MakeText(this, GetText(Resource.String.Lbl_NoMorePages), ToastLength.Short).Show();
                    }

                    var respondGroupList = result.Groups?.Count;
                    if (respondGroupList > 0)
                    {
                        if (countGroupList > 0)
                        {
                            foreach (var item in result.Groups)
                            {
                                var check = GroupsTab.MAdapter.GroupList.FirstOrDefault(a => a.Id == item.Id);
                                if (check == null)
                                {
                                    GroupsTab.MAdapter.GroupList.Add(item);
                                }
                            }

                            RunOnUiThread(() => { GroupsTab.MAdapter.NotifyItemRangeInserted(countGroupList - 1, GroupsTab.MAdapter.GroupList.Count - countGroupList); }); 
                        }
                        else
                        {
                            GroupsTab.MAdapter.GroupList = new ObservableCollection<GroupClass>(result.Groups);
                            RunOnUiThread(() => { GroupsTab.MAdapter.NotifyDataSetChanged(); });
                        }
                    }
                    else
                    {
                        if (GroupsTab.MAdapter.GroupList.Count > 10 && !GroupsTab.MRecycler.CanScrollVertically(1))
                            Toast.MakeText(this, GetText(Resource.String.Lbl_NoMoreGroup), ToastLength.Short).Show();
                    }
                }
            }
            else Methods.DisplayReportResult(this, respond);

            UserTab.MainScrollEvent.IsLoading = false;
            PagesTab.MainScrollEvent.IsLoading = false;
            GroupsTab.MainScrollEvent.IsLoading = false;

            RunOnUiThread(ShowEmptyPage); 
        }

        private void ShowEmptyPage()
        {
            try
            {
                UserTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                PagesTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                GroupsTab.ProgressBarLoader.Visibility = ViewStates.Gone;

                if (UserTab.MAdapter.UserList.Count > 0)
                {
                    UserTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    if (UserTab.Inflated == null)
                        UserTab.Inflated = UserTab.EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(UserTab.Inflated, EmptyStateInflater.Type.NoSearchResult);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click -= EmptyStateButtonOnClick;
                        x.EmptyStateButton.Click -= TryAgainButton_Click;
                    }

                    x.EmptyStateButton.Click += TryAgainButton_Click;
                    UserTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                }


                if (PagesTab.MAdapter.PageList.Count > 0)
                {
                    PagesTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    if (PagesTab.Inflated == null)
                        PagesTab.Inflated = PagesTab.EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(PagesTab.Inflated, EmptyStateInflater.Type.NoSearchResult);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click -= EmptyStateButtonOnClick;
                        x.EmptyStateButton.Click -= TryAgainButton_Click;
                    }

                    x.EmptyStateButton.Click += TryAgainButton_Click;
                    PagesTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                }

                if (GroupsTab.MAdapter.GroupList.Count > 0)
                {
                    GroupsTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    if (GroupsTab.Inflated == null)
                        GroupsTab.Inflated = GroupsTab.EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(GroupsTab.Inflated, EmptyStateInflater.Type.NoSearchResult);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click -= EmptyStateButtonOnClick;
                        x.EmptyStateButton.Click -= TryAgainButton_Click;
                    }

                    x.EmptyStateButton.Click += TryAgainButton_Click;
                    GroupsTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception e)
            {
                //SwipeRefreshLayout.Refreshing = false;
                Console.WriteLine(e);
            }
        }

        //No Internet Connection 
        public void TryAgainButton_Click(object sender, EventArgs e)
        {
            try
            {
                SearchText = "a";

                ViewPager.SetCurrentItem(0, true);

                Search();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void EmptyStateButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                SearchView.ClearFocus();
                UserTab.MAdapter.UserList.Clear();
                UserTab.MAdapter.NotifyDataSetChanged();

                PagesTab.MAdapter.PageList.Clear();
                PagesTab.MAdapter.NotifyDataSetChanged();

                GroupsTab.MAdapter.GroupList.Clear();
                GroupsTab.MAdapter.NotifyDataSetChanged();
                 
                OffsetUser = "0";
                OffsetPage = "0";
                OffsetGroup = "0"; 

                if (string.IsNullOrEmpty(SearchText) || string.IsNullOrWhiteSpace(SearchText))
                {
                    SearchText = "a";
                }

                ViewPager.SetCurrentItem(0, true);

                if (Methods.CheckConnectivity())
                {
                    UserTab.EmptyStateLayout.Visibility = ViewStates.Gone;
                    UserTab.ProgressBarLoader.Visibility = ViewStates.Visible;
                    StartApiService();
                }
                else
                {
                    if (UserTab.Inflated == null)
                        UserTab.Inflated = UserTab.EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(UserTab.Inflated, EmptyStateInflater.Type.NoSearchResult);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click -= EmptyStateButtonOnClick;
                        x.EmptyStateButton.Click -= TryAgainButton_Click;
                    }

                    x.EmptyStateButton.Click += TryAgainButton_Click;
                    UserTab.EmptyStateLayout.Visibility = ViewStates.Visible;
                    UserTab.ProgressBarLoader.Visibility = ViewStates.Gone;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        #endregion

      
    }
}