﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using AppIntro;
using WoWonder.Activities.SuggestedUsers;
using WoWonder.Activities.Tabbes;
using WoWonder.Helpers.Controller;

namespace WoWonder.Activities
{
    [Activity(Theme = "@style/Theme.AppCompat.Light.NoActionBar", ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.Orientation)]
    public class AppIntroWalkTroutPage : AppIntro2
    {
        private int Count = 1;

        private string Caller = "";

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                AddSlide(AppIntroFragment.NewInstance(GetString(Resource.String.Lbl_Title_page1),GetString(Resource.String.Lbl_Description_page1), Resource.Drawable.Image_page1,Color.ParseColor("#2d4155")));
                AddSlide(AppIntroFragment.NewInstance(GetString(Resource.String.Lbl_Title_page2),GetString(Resource.String.Lbl_Description_page2), Resource.Drawable.Image_page2,Color.ParseColor("#fcb840")));
                AddSlide(AppIntroFragment.NewInstance(GetString(Resource.String.Lbl_Title_page3),GetString(Resource.String.Lbl_Description_page3), Resource.Drawable.Image_page3,Color.ParseColor("#2485c3")));
                AddSlide(AppIntroFragment.NewInstance(GetString(Resource.String.Lbl_Title_page4),GetString(Resource.String.Lbl_Description_page4), Resource.Drawable.Image_page4,Color.ParseColor("#9244b1")));

                if (AppSettings.WalkThroughSetFlowAnimation)
                    SetFlowAnimation();
                else if (AppSettings.WalkThroughSetZoomAnimation)
                    SetZoomAnimation();
                else if (AppSettings.WalkThroughSetSlideOverAnimation)
                    SetSlideOverAnimation();
                else if (AppSettings.WalkThroughSetDepthAnimation)
                    SetDepthAnimation();
                else if (AppSettings.WalkThroughSetFadeAnimation) SetFadeAnimation();
                
                ShowStatusBar(false);
                 
                SetNavBarColor(Color.ParseColor("#333639"));
               // SetSeparatorColor(Color.ParseColor("#2196f3"));
                
                Caller = Intent.GetStringExtra("class") ?? "";

                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => ApiRequest.Get_MyProfileData_Api(this) });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnSlideChanged()
        {
            try
            {
                base.OnSlideChanged();

                if (Count == 1)
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                    }
                    else
                    {
                        RequestPermissions(new[]
                        {
                            Manifest.Permission.Camera
                        }, 208);
                    }

                    Task.Run(() =>
                    {
                        ApiRequest.GetGifts().ConfigureAwait(false);
                    });

                    Count++;
                }
                else if (Count == 2)
                {
                    Count++;
                }
                else if (Count == 3)
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                    }
                    else
                    {
                        RequestPermissions(new[]
                        {
                            Manifest.Permission.AccessFineLocation,
                            Manifest.Permission.AccessCoarseLocation
                        }, 208);
                    }

                    Count++;
                }
                else if (Count == 4)
                {
                    Count++;
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            } 

        }

        public override void OnNextPressed()
        {
            try
            {
                base.OnNextPressed();
                if (Count == 1)
                { 
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                    }
                    else
                    {
                        RequestPermissions(new[]
                        {
                            Manifest.Permission.Camera
                        }, 208);
                    }

                    Task.Run(() =>
                    {
                        ApiRequest.GetGifts().ConfigureAwait(false);
                    });

                    Count++;
                }
                else if (Count == 2)
                {
                    Count++;
                }
                else if (Count == 3)
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                    }
                    else
                    {
                        RequestPermissions(new[]
                        {
                            Manifest.Permission.AccessFineLocation,
                            Manifest.Permission.AccessCoarseLocation
                        }, 208);
                    }
                     
                    Count++;
                }
                else if (Count == 4)
                {
                    Count++;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        // Do something when users tap on Done button.
        public override void OnDonePressed()
        {
            try
            { 
                if (Caller.Contains("register"))
                { 
                    StartActivity(AppSettings.ShowSuggestedUsersOnRegister? new Intent(this, typeof(SuggestionsUsersActivity)): new Intent(this, typeof(TabbedMainActivity))); 
                }
                else
                    StartActivity(new Intent(this, typeof(TabbedMainActivity)));

                Finish();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Do something when users tap on Skip button.
        public override void OnSkipPressed()
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                }
                else
                {
                    RequestPermissions(new[]
                    {
                        Manifest.Permission.Camera,
                        Manifest.Permission.AccessFineLocation,
                        Manifest.Permission.AccessCoarseLocation
                    }, 208);
                }
                 

                if (Caller.Contains("register"))
                { 
                    StartActivity(AppSettings.ShowSuggestedUsersOnRegister
                        ? new Intent(this, typeof(SuggestionsUsersActivity))
                        : new Intent(this, typeof(TabbedMainActivity))); 
                }
                else
                    StartActivity(new Intent(this, typeof(TabbedMainActivity)));

                Finish();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}