﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.Content;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide.Integration.RecyclerView;
using Bumptech.Glide.Util;
using Newtonsoft.Json;
using WoWonder.Activities.Communities.Groups;
using WoWonder.Activities.Communities.Pages;
using WoWonder.Activities.Events;
using WoWonder.Activities.NativePost.Pages;
using WoWonder.Activities.Story;
using WoWonder.Activities.Tabbes.Adapters;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Story;
using WoWonderClient.Requests;

namespace WoWonder.Activities.Tabbes.Fragment
{
    public class NotificationsFragment : Android.Support.V4.App.Fragment
    {
        #region Variables Basic

        private NotificationsAdapter MAdapter;
        private TabbedMainActivity GlobalContext;
        private SwipeRefreshLayout SwipeRefreshLayout;
        private RecyclerView MRecycler;
        private LinearLayoutManager LayoutManager;
        private ViewStub EmptyStateLayout;
        private View Inflated;
        private RecyclerViewOnScrollListener MainScrollEvent;

        #endregion

        #region General

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Create your fragment here
            GlobalContext = (TabbedMainActivity)Activity ?? TabbedMainActivity.GetInstance();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.Tab_Notifications_Layout, container, false);

                InitComponent(view); 
                SetRecyclerViewAdapters();

                if (!AppSettings.SetTabOnButton)
                {
                    var parasms = (RelativeLayout.LayoutParams) SwipeRefreshLayout.LayoutParameters;
                    // Check if we're running on Android 5.0 or higher
                    parasms.TopMargin = (int) Build.VERSION.SdkInt < 23 ? 80 : 120;

                    MRecycler.LayoutParameters = parasms;
                    MRecycler.SetPadding(0, 0, 0, 0);
                }

                LoadGeneralData(true).ConfigureAwait(false);

                return view;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                MRecycler = (RecyclerView)view.FindViewById(Resource.Id.recyler);
                EmptyStateLayout = view.FindViewById<ViewStub>(Resource.Id.viewStub);

                SwipeRefreshLayout = (SwipeRefreshLayout)view.FindViewById(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = true;
                SwipeRefreshLayout.Refresh += SwipeRefreshLayoutOnRefresh;

                RecyclerViewOnScrollListener xamarinRecyclerViewOnScrollListener = new RecyclerViewOnScrollListener(LayoutManager);
                MainScrollEvent = xamarinRecyclerViewOnScrollListener;
                MainScrollEvent.LoadMoreEvent += MainScrollEventOnLoadMoreEvent;
                MRecycler.AddOnScrollListener(xamarinRecyclerViewOnScrollListener);
                MainScrollEvent.IsLoading = false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void SetRecyclerViewAdapters()
        {
            try
            {
                MAdapter = new NotificationsAdapter(Activity) { NotificationsList = new ObservableCollection<GetGeneralDataObject.Notification>() };
                MAdapter.ItemClick += MAdapterOnItemClick;
                LayoutManager = new LinearLayoutManager(Activity);
                MRecycler.SetLayoutManager(LayoutManager); 
                MRecycler.HasFixedSize = true;
                MRecycler.SetItemViewCacheSize(10);
                MRecycler.GetLayoutManager().ItemPrefetchEnabled = true;
                var sizeProvider = new FixedPreloadSizeProvider(10, 10);
                var preLoader = new RecyclerViewPreloader<GetGeneralDataObject.Notification>(Activity, MAdapter, sizeProvider, 10);
                MRecycler.AddOnScrollListener(preLoader);
                MRecycler.SetAdapter(MAdapter);

                MRecycler.NestedScrollingEnabled = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion
         
        #region Event

        //Open user profile
        private void MAdapterOnItemClick(object sender, NotificationsAdapterClickEventArgs e)
        {
            try
            {
                if (e.Position > -1)
                {
                    var item = MAdapter.GetItem(e.Position);
                    if (item != null)
                    {
                        if (item.Type == "following" || item.Type == "visited_profile" ||item.Type == "accepted_request")
                        {
                            WoWonderTools.OpenProfile(Activity, item.Notifier.UserId, item.Notifier);
                        }
                        else if (item.Type == "liked_page" || item.Type == "invited_page" ||item.Type == "accepted_invite")
                        { 
                            var Int = new Intent(Context, typeof(PageProfileActivity));
                            //Int.PutExtra("PageObject", JsonConvert.SerializeObject(item));
                            Int.PutExtra("PageId", item.PageId);
                            Context.StartActivity(Int);
                        }
                        else if (item.Type == "joined_group" || item.Type == "accepted_join_request" ||item.Type == "added_you_to_group")
                        {
                            var Int = new Intent(Context, typeof(GroupProfileActivity));
                            //Int.PutExtra("GroupObject", JsonConvert.SerializeObject(item));
                            Int.PutExtra("GroupId", item.GroupId);
                            Context.StartActivity(Int);
                        }
                        else if (item.Type == "comment" || item.Type == "wondered_post" ||
                                 item.Type == "wondered_comment" || item.Type == "reaction" ||
                                 item.Type == "wondered_reply_comment" || item.Type == "comment_mention" ||
                                 item.Type == "comment_reply_mention" ||
                                 item.Type == "liked_post" || item.Type == "liked_comment" ||
                                 item.Type == "liked_reply_comment" || item.Type == "post_mention" ||
                                 item.Type == "share_post" || item.Type == "shared_your_post" ||  item.Type == "comment_reply" ||
                                 item.Type == "also_replied" || item.Type == "profile_wall_post")
                        {
                            var Int = new Intent(Context, typeof(ViewFullPostActivity));
                            Int.PutExtra("Id", item.PostId); 
                            // Int.PutExtra("DataItem", JsonConvert.SerializeObject(item));
                            Context.StartActivity(Int);
                        }
                        else if (item.Type == "going_event")
                        { 
                            var Int = new Intent(Context, typeof(EventViewActivity));
                            Int.PutExtra("EventView", JsonConvert.SerializeObject(item.Event));
                            Int.PutExtra("Id", item.EventId); 
                            Context.StartActivity(Int); 
                        }
                        else if (item.Type == "viewed_story")
                        {
                            //"url": "https:\/\/demo.wowonder.com\/timeline&u=Matan&story=true&story_id=1946",
                            //var id = item.Url.Split("/").Last().Split("&story_id=").Last();

                            GetUserStoriesObject.StoryObject dataMyStory = GlobalContext?.NewsFeedTab?.PostFeedAdapter?.HolderStory?.StoryAdapter?.StoryList?.FirstOrDefault(o => o.UserId == UserDetails.UserId);
                            if (dataMyStory != null)
                            { 
                              Intent Int = new Intent(Context, typeof(ViewStoryActivity));
                              Int.PutExtra("UserId", dataMyStory.UserId); 
                              Int.PutExtra("DataItem", JsonConvert.SerializeObject(dataMyStory)); 
                              Context.StartActivity(Int);
                            } 
                        }
                        else if (item.Type == "requested_to_join_group")
                        {
                            var Int = new Intent(Context, typeof(JoinRequestActivity));
                            Int.PutExtra("GroupId", item.GroupId);
                            Context.StartActivity(Int);
                        }
                        else
                        {
                            WoWonderTools.OpenProfile(Activity,item.Notifier.UserId,item.Notifier);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Refresh
        private async void SwipeRefreshLayoutOnRefresh(object sender, EventArgs e)
        {
            try
            {
                MAdapter.NotificationsList.Clear();
                MAdapter.NotifyDataSetChanged();

                MRecycler.Visibility = ViewStates.Visible;
                EmptyStateLayout.Visibility = ViewStates.Gone;

                await LoadGeneralData(true).ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void MainScrollEventOnLoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                //Code get last id where LoadMore >>
                var item = MAdapter.NotificationsList.LastOrDefault();
                if (item != null && !string.IsNullOrEmpty(item.NotifierId))
                    LoadGeneralData(false, item.NotifierId).ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        #region Load Notification 

        //Get General Data Using Api >> notifications , pro_users , promoted_pages , trending_hashTag
        public async Task<(string, string, string, string)> LoadGeneralData(bool seenNotifications,string offset = "")
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    var countNotificationsList = MAdapter.NotificationsList?.Count ?? 0;
                    var countProUsersList = GlobalContext.ProUsersAdapter?.MProUsersList.Count ?? 0;
                    var countPromotedPagesList = GlobalContext.ProPagesAdapter?.MProPagesList.Count ?? 0;

                    (int apiStatus, var respond) = await RequestsAsync.Global.Get_General_Data(seenNotifications, UserDetails.DeviceId, offset);
                    if (apiStatus == 200)
                    {
                        if (respond is GetGeneralDataObject result)
                        {
                           Activity.RunOnUiThread(() =>
                           {
                               try
                               {
                                   // Notifications
                                   var respondList = result.Notifications.Count;
                                   if (respondList > 0)
                                   {
                                       if (countNotificationsList > 0)
                                       {
                                           var listNew = result.Notifications?.Where(c => !MAdapter.NotificationsList.Select(fc => fc.Id).Contains(c.Id)).ToList();
                                           if (listNew.Count > 0)
                                           { 
                                               foreach (var notification in listNew)
                                               {
                                                   MAdapter.NotificationsList.Insert(0 , notification);
                                               }

                                               MAdapter.NotifyItemRangeInserted(countNotificationsList - 1, MAdapter.NotificationsList.Count - countNotificationsList);
                                           }
                                       }
                                       else
                                       {
                                           MAdapter.NotificationsList = new ObservableCollection<GetGeneralDataObject.Notification>(result.Notifications);
                                           MAdapter.NotifyDataSetChanged();
                                       }
                                   }
                                   else
                                   {
                                       if (MAdapter.NotificationsList.Count > 10 && !MRecycler.CanScrollVertically(1))
                                           Toast.MakeText(Context, Context.GetText(Resource.String.Lbl_NoMoreNotifications), ToastLength.Short).Show();
                                   }

                                   // Friend Requests
                                   if (result.FriendRequests.Count > 0)
                                   {
                                       GlobalContext.FriendRequestsList = new ObservableCollection<UserDataObject>(result.FriendRequests);

                                       GlobalContext.TrendingTab.LayoutFriendRequest.Visibility = ViewStates.Visible;
                                       try
                                       {
                                           for (var i = 0; i < 4; i++)
                                               switch (i)
                                               {
                                                   case 0:
                                                       GlideImageLoader.LoadImage(Activity, GlobalContext.FriendRequestsList[i].Avatar, GlobalContext.TrendingTab.FriendRequestImage1, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                       break;
                                                   case 1:
                                                       GlideImageLoader.LoadImage(Activity, GlobalContext.FriendRequestsList[i].Avatar, GlobalContext.TrendingTab.FriendRequestImage2, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                       break;
                                                   case 2:
                                                       GlideImageLoader.LoadImage(Activity, GlobalContext.FriendRequestsList[i].Avatar, GlobalContext.TrendingTab.FriendRequestImage3, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                                                       break;
                                               }
                                       }
                                       catch (Exception e)
                                       {
                                           Console.WriteLine(e);
                                       }
                                   }
                                   else
                                   {
                                       GlobalContext.TrendingTab.LayoutFriendRequest.Visibility = ViewStates.Gone;
                                   }

                                   if (AppSettings.ShowProUsersMembers)
                                   {
                                       // Pro Users
                                       var respondListProUsers = result.ProUsers.Count;
                                       if (respondListProUsers > 0)
                                       {
                                           if (countProUsersList > 0)
                                           {
                                               foreach (var item in result.ProUsers)
                                               {
                                                   var check = GlobalContext.ProUsersAdapter.MProUsersList.FirstOrDefault(a => a.UserId == item.UserId);
                                                   if (check == null)
                                                   {
                                                       GlobalContext.ProUsersAdapter.MProUsersList.Add(item);
                                                   }
                                               }
                                               GlobalContext.ProUsersAdapter.NotifyItemRangeInserted(countProUsersList - 1, GlobalContext.ProUsersAdapter.MProUsersList.Count - countProUsersList);

                                           }
                                           else
                                           {
                                               GlobalContext.ProUsersAdapter.MProUsersList = new ObservableCollection<UserDataObject>(result.ProUsers);
                                               GlobalContext.ProUsersAdapter.NotifyDataSetChanged();
                                           }

                                           if (GlobalContext.TrendingTab.LayoutSuggestionProUsers.Visibility != ViewStates.Visible)
                                               GlobalContext.TrendingTab.LayoutSuggestionProUsers.Visibility = ViewStates.Visible;
                                       }
                                       else
                                       {
                                           if (GlobalContext.TrendingTab.LayoutSuggestionProUsers.Visibility != ViewStates.Gone)
                                               GlobalContext.TrendingTab.LayoutSuggestionProUsers.Visibility = ViewStates.Gone;
                                       }
                                   }
                                   else
                                   {
                                       if (GlobalContext.TrendingTab.LayoutSuggestionProUsers.Visibility != ViewStates.Gone)
                                           GlobalContext.TrendingTab.LayoutSuggestionProUsers.Visibility = ViewStates.Gone;
                                   }

                                   if (AppSettings.ShowPromotedPages)
                                   {
                                       // Pro Pages
                                       var respondListPromotedPages = result.PromotedPages.Count;
                                       if (respondListPromotedPages > 0)
                                       {
                                           if (countPromotedPagesList > 0)
                                           {
                                               foreach (var item in result.PromotedPages)
                                               {
                                                   var check = GlobalContext.ProPagesAdapter.MProPagesList.FirstOrDefault(a => a.Id == item.Id);
                                                   if (check == null)
                                                   {
                                                       GlobalContext.ProPagesAdapter.MProPagesList.Add(item);
                                                   }
                                               }
                                               GlobalContext.ProPagesAdapter.NotifyItemRangeInserted(countPromotedPagesList - 1, GlobalContext.ProPagesAdapter.MProPagesList.Count - countPromotedPagesList);
                                           }
                                           else
                                           {
                                               GlobalContext.ProPagesAdapter.MProPagesList = new ObservableCollection<PageClass>(result.PromotedPages);
                                               GlobalContext.ProPagesAdapter.NotifyDataSetChanged();
                                           }
                                            
                                           if (GlobalContext.TrendingTab.LayoutSuggestionPromotedPage.Visibility != ViewStates.Visible)
                                               GlobalContext.TrendingTab.LayoutSuggestionPromotedPage.Visibility = ViewStates.Visible;
                                       }
                                       else
                                       {
                                            if (GlobalContext.TrendingTab.LayoutSuggestionPromotedPage.Visibility != ViewStates.Gone)
                                                GlobalContext.TrendingTab.LayoutSuggestionPromotedPage.Visibility = ViewStates.Gone;
                                       }
                                   }
                                   else
                                   { 
                                       if (GlobalContext.TrendingTab.LayoutSuggestionPromotedPage.Visibility != ViewStates.Gone)
                                           GlobalContext.TrendingTab.LayoutSuggestionPromotedPage.Visibility = ViewStates.Gone;
                                   }
                                    
                                   if (AppSettings.ShowTrendingHashTags)
                                       if (result.trendingHashtag.Count > 0)
                                           GlobalContext.HashTagUserAdapter.MHashtagList = new ObservableCollection<GetGeneralDataObject.TrendingHashtag>(result.trendingHashtag);

                                   MainScrollEvent.IsLoading = false;
                                   ShowEmptyPage();
                               }
                               catch (Exception e)
                               {
                                   Console.WriteLine(e);
                               }
                           }); 
                            return (result.NewNotificationsCount, result.NewFriendRequestsCount, result.CountNewMessages, result?.announcement?.AnnouncementClass?.TextDecode);
                        }
                    }
                    else Methods.DisplayReportResult(Activity, respond);

                    MainScrollEvent.IsLoading = false;
                    Activity.RunOnUiThread(ShowEmptyPage);

                    return ("", "", "", "");
                }
                else
                {
                    Inflated = EmptyStateLayout.Inflate();
                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(Inflated, EmptyStateInflater.Type.NoConnection);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                        x.EmptyStateButton.Click += EmptyStateButtonOnClick;
                    }

                    Toast.MakeText(Context, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            }
            return ("", "", "", "");
        }

        private void ShowEmptyPage()
        {
            try
            {
                SwipeRefreshLayout.Refreshing = false;

                if (MAdapter.NotificationsList.Count > 0)
                {
                    MRecycler.Visibility = ViewStates.Visible;
                    EmptyStateLayout.Visibility = ViewStates.Gone;
                }
                else
                {
                    MRecycler.Visibility = ViewStates.Gone;

                    if (Inflated == null)
                        Inflated = EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(Inflated, EmptyStateInflater.Type.NoNotifications);
                    if (!x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                    }
                    EmptyStateLayout.Visibility = ViewStates.Visible;
                }
            }
            catch (Exception e)
            {
                SwipeRefreshLayout.Refreshing = false;
                Console.WriteLine(e);
            }
        }

        //No Internet Connection 
        private async void EmptyStateButtonOnClick(object sender, EventArgs e)
        {
            try
            {
               await LoadGeneralData(true).ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

    }
}