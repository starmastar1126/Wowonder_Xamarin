﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Icu.Util;
using Android.OS;
using Android.Support.V4.Widget;
using Android.Views;
using Android.Widget;
using Java.Lang;
using Newtonsoft.Json;
//using Webianks.Library;
using WoWonder.Activities.NativePost.Extra;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Posts;
using WoWonderClient.Classes.Story;
using WoWonderClient.Requests;
using Exception = System.Exception;

namespace WoWonder.Activities.Tabbes.Fragment
{
    public class NewsFeedNative : Android.Support.V4.App.Fragment
    {
        #region Variables Basic

        //private PopupBubble PopupBubbleView;  //wael
        public WRecyclerView MainRecyclerView;
        public NativePostAdapter PostFeedAdapter;
        private readonly int PostUpdaterInterval = 20000;
        private SwipeRefreshLayout SwipeRefreshLayout;
        private readonly Handler MainHandler = new Handler();
         
        #endregion

        #region General
         
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.TestNewsFeed, container, false);

                InitComponent(view); 
                SetRecyclerViewAdapters(view); 
                    
                var story = new AdapterModelsClass
                {
                    TypeView = PostModelType.Story, 
                    StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>(),
                    Id = 1
                };

                var addPostBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.AddPostBox, 
                    Id = 2
                };
                 
                if (AppSettings.ShowStory)
                    PostFeedAdapter.PostFeedList.Add(story);

                PostFeedAdapter.PostFeedList.Add(addPostBox);

                SetGreetingAlert();
                 
                StartApiService();

                //Start Updating the news feed every few minus 
                MainHandler.PostDelayed(new ApiPostUpdaterHelper(Activity,MainRecyclerView, MainHandler), PostUpdaterInterval); 

                return view;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                //PopupBubbleView = (PopupBubble)view.FindViewById(Resource.Id.popup_bubble);  //wael

                SwipeRefreshLayout = view.FindViewById<SwipeRefreshLayout>(Resource.Id.swipeRefreshLayout);
                SwipeRefreshLayout.SetColorSchemeResources(Android.Resource.Color.HoloBlueLight, Android.Resource.Color.HoloGreenLight, Android.Resource.Color.HoloOrangeLight, Android.Resource.Color.HoloRedLight);
                SwipeRefreshLayout.Refreshing = true;
                SwipeRefreshLayout.Enabled = true;
                SwipeRefreshLayout.Refresh += SwipeRefreshLayoutOnRefresh;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void SetRecyclerViewAdapters(View view)
        {
            try
            {
                MainRecyclerView = (WRecyclerView)view.FindViewById(Resource.Id.newsfeedRecyler);
                PostFeedAdapter = new NativePostAdapter(Activity, MainRecyclerView, NativeFeedType.Global);
                MainRecyclerView.SetXAdapter(PostFeedAdapter, SwipeRefreshLayout);
                //MainRecyclerView.SetXPopupBubble(PopupBubbleView); //wael
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Refresh

        //Refresh 
        private void SwipeRefreshLayoutOnRefresh(object sender, EventArgs e)
        {
            try
            {
                PostFeedAdapter.PostFeedList.Clear();

                if (AppSettings.ShowStory)
                {

                    var story = new AdapterModelsClass
                    {
                        TypeView = PostModelType.Story,
                        StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>(),
                        Id = 1
                    };
                    PostFeedAdapter.PostFeedList.Add(story);

                    var checkSection = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.Story);
                    checkSection?.StoryList.Insert(0, new GetUserStoriesObject.StoryObject()
                    {
                        Avatar = UserDetails.Avatar,
                        Type = "Your",
                        Username = Context.GetText(Resource.String.Lbl_YourStory),
                        Stories = new List<GetUserStoriesObject.StoryObject.Story>()
                        {
                            new GetUserStoriesObject.StoryObject.Story()
                            {
                                Thumbnail = UserDetails.Avatar,
                            }
                        }
                    });
                }

                var addPostBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.AddPostBox,
                    Id = 2
                };

                PostFeedAdapter.PostFeedList.Add(addPostBox);

                var checkSectionAlertBox = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.AlertBox);
                {
                    PostFeedAdapter.PostFeedList.Remove(checkSectionAlertBox);

                    var index = PostFeedAdapter.PostFeedList.IndexOf(checkSectionAlertBox);
                    if (index > -1)
                    {
                        PostFeedAdapter.NotifyItemRemoved(index);
                    }
                }

                var checkSectionAlertJoinBox = PostFeedAdapter.PostFeedList.Where(a => a.TypeView == PostModelType.AlertJoinBox).ToList();
                {
                    foreach (var adapterModelsClass in checkSectionAlertJoinBox)
                    {
                        PostFeedAdapter.PostFeedList.Remove(adapterModelsClass);

                        var index = PostFeedAdapter.PostFeedList.IndexOf(adapterModelsClass);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemRemoved(index);
                        }
                    }
                }

                PostFeedAdapter.NotifyDataSetChanged();

                StartApiService();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        #region Get Post Feed

        private void StartApiService()
        {
            if (!Methods.CheckConnectivity())
                Toast.MakeText(Activity, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
            else
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { LoadStory, () => MainRecyclerView.FetchNewsFeedApiPosts("0") });
        }

        private void SetGreetingAlert()
        {
            try
            { 
                var data = ListUtils.MyProfileList.FirstOrDefault();
                string name = data != null ? WoWonderTools.GetNameFinal(data) : UserDetails.Username;

                var alertModel = new AlertModelClass();

                var c = Calendar.Instance;
                var timeOfDay = c.Get(CalendarField.HourOfDay);

                if (timeOfDay >= 0 && timeOfDay < 12)
                {
                    alertModel = new AlertModelClass
                    {
                        TitleHead = Context.GetString(Resource.String.Lbl_GoodMorning) + ", " + name,
                        SubText = Context.GetString(Resource.String.Lbl_GoodMorning_Text),
                        LinerColor = "#ffc107",
                        ImageDrawable = Resource.Drawable.ic_post_park
                    };
                }
                else if (timeOfDay >= 12 && timeOfDay < 16)
                {
                    alertModel = new AlertModelClass
                    {
                        TitleHead = Context.GetString(Resource.String.Lbl_GoodAfternoon) + ", " + name,
                        SubText = Context.GetString(Resource.String.Lbl_GoodAfternoon_Text),
                        LinerColor = "#ffc107",
                        ImageDrawable = Resource.Drawable.ic_post_desert
                    };
                }
                else if (timeOfDay >= 16 && timeOfDay < 21)
                {
                    alertModel = new AlertModelClass
                    {
                        TitleHead = Context.GetString(Resource.String.Lbl_GoodEvening) + ", " + name,
                        SubText = Context.GetString(Resource.String.Lbl_GoodEvening_Text),
                        LinerColor = "#ffc107",
                        ImageDrawable = Resource.Drawable.ic_post_sea
                    };
                }
                else if (timeOfDay >= 21 && timeOfDay < 24)
                {
                    alertModel = new AlertModelClass
                    {
                        TitleHead = Context.GetString(Resource.String.Lbl_GoodEvening) + ", " + name,
                        SubText = Context.GetString(Resource.String.Lbl_GoodEvening_Text),
                        LinerColor = "#ffc107",
                        ImageDrawable = Resource.Drawable.ic_post_sea
                    };
                }

                var alertBox = new AdapterModelsClass
                {
                    TypeView = PostModelType.AlertBox,
                    AlertModel = alertModel,
                    Id = 3
                };

                PostFeedAdapter.PostFeedList.Add(alertBox);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void SetAnnouncementAlert(string subText,string color,int? resource=null)
        {
            try
            {
                var alertModel1 = new AlertModelClass
                {
                    TitleHead = "Announcement",
                    SubText = subText,
                    LinerColor = color
                };

                if (resource.HasValue)
                    alertModel1.ImageDrawable = resource.Value;

                var alertBox1 = new AdapterModelsClass
                {
                    TypeView = PostModelType.AlertBox,
                    AlertModel = alertModel1,
                    Id = 0
                };

                PostFeedAdapter.PostFeedList.Insert(0, alertBox1);
                PostFeedAdapter.NotifyItemInserted(0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void SetFindMoreAlert(string type)
        {
            try
            {
                //afternoon_system
                var afternoonSystem = ListUtils.SettingsSiteList.AfternoonSystem;
                if (afternoonSystem == "1")
                {
                    var alertModel1 = new AlertModelClass();
                    if (type == "Groups")
                    {
                        alertModel1 = new AlertModelClass
                        {
                            TitleHead = Context.GetString(Resource.String.Lbl_Groups),
                            SubText = Context.GetString(Resource.String.Lbl_FindMoreAler_TextGroups),
                            TypeAlert = "Groups",
                            ImageDrawable = Resource.Drawable.image2,
                            IconImage = Resource.Drawable.shareGroup,
                        };
                    }
                    else if (type == "Pages")
                    {
                        alertModel1 = new AlertModelClass
                        {
                            TitleHead = Context.GetString(Resource.String.Lbl_Pages),
                            SubText = Context.GetString(Resource.String.Lbl_FindMoreAler_TextPages),
                            TypeAlert = "Pages",
                            ImageDrawable = Resource.Drawable.image1,
                            IconImage = Resource.Drawable.sharePage,
                        };
                    }


                    var addAlertJoinBox = new AdapterModelsClass
                    {
                        TypeView = PostModelType.AlertJoinBox,
                        Id = DateTime.Now.Millisecond,
                        AlertModel = alertModel1
                    };

                    PostFeedAdapter.PostFeedList.Add(addAlertJoinBox);
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private class ApiPostUpdaterHelper : Java.Lang.Object, IRunnable
        {
            private readonly WRecyclerView MainRecyclerView;
            private readonly Handler MainHandler;
            private readonly Activity Activity;

            public ApiPostUpdaterHelper(Activity activity, WRecyclerView mainRecyclerView, Handler mainHandler)
            {
                MainRecyclerView = mainRecyclerView;
                MainHandler = mainHandler;
                Activity = activity;
            }

            public async void Run()
            {
                try
                {
                    await MainRecyclerView.FetchNewsFeedApiPosts("");
                    TabbedMainActivity.GetInstance()?.Get_Notifications();
                    await ApiRequest.Get_MyProfileData_Api(Activity).ConfigureAwait(false);
                    MainHandler.PostDelayed(new ApiPostUpdaterHelper(Activity,MainRecyclerView, MainHandler), 20000);
                    Console.WriteLine("Allen Post + started" + DateTime.Now);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    Console.WriteLine("Allen Post + failed");
                }
            }
        }

        #endregion

        #region Get Story
         
        private async Task LoadStory()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {  
                    var checkSection = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.Story);
                    if (checkSection != null)
                    {
                        if (checkSection.StoryList == null)
                            checkSection.StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>();
                        
                        int countList = checkSection.StoryList.Count;
                        (int apiStatus, var respond) = await RequestsAsync.Story.Get_UserStories();
                        if (apiStatus == 200)
                        {
                            if (respond is GetUserStoriesObject result)
                            {
                                if (countList > 0)
                                {
                                    var listNew = result.Stories?.Where(c => !checkSection.StoryList.Select(fc => fc.UserId).Contains(c.UserId)).ToList();
                                    if (listNew?.Count > 0)
                                    {
                                        foreach (var item in listNew)
                                        {
                                            var check = checkSection.StoryList.FirstOrDefault(a => a.UserId == item.UserId);
                                            if (check != null)
                                            {
                                                check.Stories = item.Stories;
                                            }
                                            else
                                            {
                                                checkSection.StoryList.Add(item);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    checkSection.StoryList = new ObservableCollection<GetUserStoriesObject.StoryObject>(result.Stories);
                                }
                            }
                        }
                        else  Methods.DisplayReportResult(Activity, respond);
                         
                        if (checkSection.StoryList.Count > 4)
                        {
                            PostFeedAdapter.HolderStory.AboutMore.Visibility = ViewStates.Visible;
                            PostFeedAdapter.HolderStory.AboutMoreIcon.Visibility = ViewStates.Visible;
                        }
                        else
                        {
                            PostFeedAdapter.HolderStory.AboutMore.Visibility = ViewStates.Invisible;
                            PostFeedAdapter.HolderStory.AboutMoreIcon.Visibility = ViewStates.Invisible;
                        }
  
                        var d = new Runnable(() =>
                        {
                            PostFeedAdapter.NotifyItemChanged(PostFeedAdapter.PostFeedList.IndexOf(checkSection));
                        });
                        d.Run();
                    } 
                }
                else
                {
                    Toast.MakeText(Context, GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Permissions && Result

        //Result

        public override async void OnActivityResult(int requestCode, int resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);

                if (requestCode == 2500 &&  resultCode == (int) Result.Ok) //add post
                {
                    var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                    if (postData != null)
                    {
                        var postType = PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                        MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                        {
                            TypeView = postType,
                            Id = int.Parse(postData.Id),
                            PostData = postData,
                            IsDefaultFeedPost = true,
                        });
                    }
                    else
                    {
                        await MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                    }
                }
                else if (requestCode == 3950 && resultCode == (int)Result.Ok) //Edit post
                {
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            PostFeedAdapter.NotifyItemChanged(index);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            }
        }
         
        #endregion

    }
}