﻿using System;
using AFollestad.MaterialDialogs;
using Android;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Java.Lang;
using WoWonder.Activities.Album;
using WoWonder.Activities.Articles;
using WoWonder.Activities.Communities.Groups;
using WoWonder.Activities.Communities.Pages;
using WoWonder.Activities.Contacts;
using WoWonder.Activities.Events;
using WoWonder.Activities.Market;
using WoWonder.Activities.Movies;
using WoWonder.Activities.MyProfile;
using WoWonder.Activities.NativePost.Pages;
using WoWonder.Activities.NearBy;
using WoWonder.Activities.Pokes;
using WoWonder.Activities.PopularPosts;
using WoWonder.Activities.SettingsPreferences.General;
using WoWonder.Activities.SettingsPreferences.Notification;
using WoWonder.Activities.SettingsPreferences.Privacy;
using WoWonder.Activities.SettingsPreferences.Support;
using WoWonder.Activities.SettingsPreferences.TellFriend;
using WoWonder.Activities.Tabbes.Adapters;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using Exception = System.Exception;

namespace WoWonder.Activities.Tabbes.Fragment
{
    public class MoreFragment : Android.Support.V4.App.Fragment, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region  Variables Basic

        public MoreSectionAdapter MoreSectionAdapter;
        private RecyclerView MoreRecylerView;

        #endregion

        #region General
  
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.Tab_More_Layout, container, false);

                SetRecyclerViewAdapters(view);

                AddOrRemoveEvent(true);

                if (!AppSettings.SetTabOnButton)
                {
                    var parasms = (LinearLayout.LayoutParams)MoreRecylerView.LayoutParameters;
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                        parasms.TopMargin = 130;
                    else
                        parasms.TopMargin = 270;

                    MoreRecylerView.LayoutParameters = parasms;
                    MoreRecylerView.SetPadding(0, 0, 0, 0);
                }

                return view;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }
         
        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion
          
        #region Functions

        private void SetRecyclerViewAdapters(View view)
        {
            try
            {
                MoreRecylerView = (RecyclerView)view.FindViewById(Resource.Id.Recyler);

                MoreRecylerView.SetLayoutManager(new LinearLayoutManager(Activity));
                MoreSectionAdapter = new MoreSectionAdapter(Activity);
                MoreRecylerView.SetAdapter(MoreSectionAdapter);
                MoreRecylerView.NestedScrollingEnabled = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                {
                    MoreSectionAdapter.ItemClick += MoreSection_OnItemClick;
                }
                else
                {
                    MoreSectionAdapter.ItemClick -= MoreSection_OnItemClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion

        #region Events

        //Event Open Intent Activity
        private void MoreSection_OnItemClick(object sender, MoreSectionAdapterClickEventArgs adapterClickEvents)
        {
            try
            {
                var position = adapterClickEvents.Position;
                if (position >= 0)
                {
                    var item = MoreSectionAdapter.GetItem(position);
                    if (item != null)
                    {
                        if (item.Id == 1) // My Profile
                        {
                            var intent = new Intent(Context, typeof(MyProfileActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 2) // Messages
                        {
                            Methods.App.OpenAppByPackageName(Context, AppSettings.MessengerPackageName);
                        }
                        else if (item.Id == 3) // Contacts
                        {
                            var intent = new Intent(Context, typeof(MyContactsActivity));
                            intent.PutExtra("ContactsType", "Following");
                            intent.PutExtra("UserId", UserDetails.UserId);
                            StartActivity(intent);
                        }
                        else if (item.Id == 4) // Pokes
                        {
                            var intent = new Intent(Context, typeof(PokesActivity));
                            StartActivity(intent); 
                        }
                        else if (item.Id == 5) // Album
                        {
                            var intent = new Intent(Context, typeof(MyAlbumActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 6) // Saved Posts
                        {
                            var intent = new Intent(Context, typeof(SavedPostsActivity)); 
                            StartActivity(intent);
                        }
                        else if (item.Id == 7) // Groups
                        {
                            var intent = new Intent(Context, typeof(GroupsActivity));
                            intent.PutExtra("UserID", UserDetails.UserId);
                            StartActivity(intent);
                        }
                        else if (item.Id == 8) // Pages
                        {
                            var intent = new Intent(Context, typeof(PagesActivity));
                            intent.PutExtra("UserID", UserDetails.UserId);
                            StartActivity(intent);
                        }
                        else if (item.Id == 9) // Blogs
                        {
                            StartActivity(new Intent(Context, typeof(ArticlesActivity)));
                        }
                        else if (item.Id == 10) // Market
                        {
                            StartActivity(new Intent(Context, typeof(TabbedMarketActivity)));
                        } 
                        else if (item.Id == 11) // Popular Posts
                        {
                            var intent = new Intent(Context, typeof(PopularPostsActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 12) // Events
                        {
                            var intent = new Intent(Context, typeof(EventMainActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 13) // Find Friends
                        {
                            var intent = new Intent(Context, typeof(PeopleNearByActivity));
                            StartActivity(intent);
                        } 
                        else if (item.Id == 14) // Movies
                        {
                            var intent = new Intent(Context, typeof(MoviesActivity));
                            StartActivity(intent);
                        } 
                        //Settings Page
                        else if (item.Id == 15) // General Account
                        {
                            var intent = new Intent(Context, typeof(GeneralAccountActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 16) // Privacy
                        {
                            var intent = new Intent(Context, typeof(PrivacyActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 17) // Notification
                        {
                            var intent = new Intent(Context, typeof(MessegeNotificationActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 18) // Tell Friends
                        {
                            var intent = new Intent(Context, typeof(TellFriendActivity));
                            StartActivity(intent);
                        } 
                        else if (item.Id == 19) // Help & Support
                        {
                            var intent = new Intent(Context, typeof(SupportActivity));
                            StartActivity(intent);
                        }
                        else if (item.Id == 20) // Logout
                        {
                            var dialog = new MaterialDialog.Builder(Context);

                            dialog.Title(Resource.String.Lbl_Warning);
                            dialog.Content(Context.GetText(Resource.String.Lbl_Are_you_logout));
                            dialog.PositiveText(Context.GetText(Resource.String.Lbl_Ok)).OnPositive(this);
                            dialog.NegativeText(Context.GetText(Resource.String.Lbl_Cancel)).OnNegative(this);
                            dialog.AlwaysCallSingleChoiceCallback();
                            dialog.ItemsCallback(this).Build().Show();
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        #endregion

        #region Permissions

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

                if (requestCode == 100)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                        ApiRequest.Logout(Activity);
                    else
                        Toast.MakeText(Activity, Activity.GetText(Resource.String.Lbl_Permission_is_denailed),
                            ToastLength.Long).Show();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion

        #region MaterialDialog

        public void OnSelection(MaterialDialog p0, View p1, int p2, ICharSequence p3)
        {
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        Toast.MakeText(Activity, Activity.GetText(Resource.String.Lbl_You_will_be_logged), ToastLength.Long).Show();
                        ApiRequest.Logout(Activity);
                    }
                    else
                    {
                        if (Activity.CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted && Activity.CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            Toast.MakeText(Activity, Activity.GetText(Resource.String.Lbl_You_will_be_logged), ToastLength.Long).Show();
                            ApiRequest.Logout(Activity);
                        }
                        else
                           new PermissionsController(Activity).RequestPermission(100); 
                    }
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        #endregion
        
    }
}