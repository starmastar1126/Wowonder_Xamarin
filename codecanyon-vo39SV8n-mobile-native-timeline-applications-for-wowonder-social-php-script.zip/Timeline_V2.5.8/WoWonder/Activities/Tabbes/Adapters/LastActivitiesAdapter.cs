﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Java.Util;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonder.Helpers.Utils;
using WoWonderClient.Classes.Global;
using IList = System.Collections.IList;

namespace WoWonder.Activities.Tabbes.Adapters
{
    public class LastActivitiesAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        public event EventHandler<LastActivitiesAdapterClickEventArgs> ItemClick;
        public event EventHandler<LastActivitiesAdapterClickEventArgs> ItemLongClick;

        private readonly Activity ActivityContext; 
        public ObservableCollection<ActivitiesObject.Activity> LastActivitiesList = new ObservableCollection<ActivitiesObject.Activity>();

        public LastActivitiesAdapter(Activity context)
        {
            try
            {
                HasStableIds = true;
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (LastActivitiesList != null)
                    return LastActivitiesList.Count;
                return 0;
            }
        }


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_LastActivities_View
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_LastActivities_View, parent, false);
                var vh = new LastActivitiesAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
                if (viewHolder is LastActivitiesAdapterViewHolder holder)
                {
                    var item = LastActivitiesList[position];
                    if (item != null)
                    {
                        Initialize(holder, item);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void Initialize(LastActivitiesAdapterViewHolder holder, ActivitiesObject.Activity item)
        {
            try
            {
                GlideImageLoader.LoadImage(ActivityContext, item.Activator.Avatar, holder.ActivitiesImage, ImageStyle.RoundedCrop, ImagePlaceholders.Drawable);
                 
                if (item.ActivityType.Contains("wondered_post"))
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.InformationCircled);
                else if (item.ActivityType.Contains("liked_post"))
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.Thumbsup);
                else if (item.ActivityType.Contains("commented_post"))
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.Chatboxes);
                else
                    FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.AndroidNotifications);

                string replace = "";
                if (item.ActivityText.Contains("commented on"))
                { 
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("commented on").Last().Replace("post", ""); 
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_CommentedOn) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else
                    {
                        replace = item.ActivityText.Replace("commented on", ActivityContext.GetString(Resource.String.Lbl_CommentedOn)).Replace("post", ActivityContext.GetString(Resource.String.Lbl_Post));
                    } 
                }
                else if (item.ActivityText.Contains("reacted to"))
                {
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("reacted to").Last().Replace("post", ""); 
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_ReactedTo) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else 
                        replace = item.ActivityText.Replace("reacted to", ActivityContext.GetString(Resource.String.Lbl_ReactedTo)).Replace("post", ActivityContext.GetString(Resource.String.Lbl_Post));
                }
                else if (item.ActivityText.Contains("started following"))
                { 
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("started following").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_StartedFollowing) +  " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("started following", ActivityContext.GetString(Resource.String.Lbl_StartedFollowing));
                }
                else if (item.ActivityText.Contains("become friends with"))
                {
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("become friends with").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_BecomeFriendsWith) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("become friends with", ActivityContext.GetString(Resource.String.Lbl_BecomeFriendsWith));
                }
                else if (item.ActivityText.Contains("is following"))
                { 
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("is following").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_IsFollowing) + " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("is following", ActivityContext.GetString(Resource.String.Lbl_IsFollowing));
                }
                else if (item.ActivityText.Contains("liked"))
                {
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("liked").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Btn_Liked) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("liked", ActivityContext.GetString(Resource.String.Btn_Liked)).Replace("post", ActivityContext.GetString(Resource.String.Lbl_Post));
                }
                else if (item.ActivityText.Contains("wondered"))
                {
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("wondered").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_wondered) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("wondered", ActivityContext.GetString(Resource.String.Lbl_wondered)).Replace("post", ActivityContext.GetString(Resource.String.Lbl_Post));
                }
                else if (item.ActivityText.Contains("disliked"))
                {
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("disliked").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_disliked) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("disliked", ActivityContext.GetString(Resource.String.Lbl_disliked)).Replace("post", ActivityContext.GetString(Resource.String.Lbl_Post));
                }
                else if (item.ActivityText.Contains("shared"))
                {
                    if (AppSettings.Lang.Contains("fr"))
                    {
                        var split = item.ActivityText.Split("shared").Last().Replace("post", "");
                        replace = item.Activator.Name + " " + ActivityContext.GetString(Resource.String.Lbl_shared) + " " + ActivityContext.GetString(Resource.String.Lbl_Post) + " " + split;
                    }
                    else
                        replace = item.ActivityText.Replace("shared", ActivityContext.GetString(Resource.String.Lbl_shared)).Replace("post", ActivityContext.GetString(Resource.String.Lbl_Post));
                }

                holder.ActivitiesEvent.Text = !string.IsNullOrEmpty(replace) ? replace : item.ActivityText;
                 
                // holder.Username.Text = item.Activator.Name; 
                holder.Username.Visibility = ViewStates.Gone;

                holder.Time.Text = Methods.Time.TimeAgo(int.Parse(item.Time));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void BindEnd()
        {
            try
            {
                NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Function 
        public void Add(ActivitiesObject.Activity item)
        {
            try
            {
                var check = LastActivitiesList.FirstOrDefault(a => a.Id == item.Id);
                if (check == null)
                {
                    LastActivitiesList.Add(item);
                    NotifyItemInserted(LastActivitiesList.IndexOf(LastActivitiesList.Last()));
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void Clear()
        {
            try
            {
                LastActivitiesList.Clear();
                NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public ActivitiesObject.Activity GetItem(int position)
        {
            return LastActivitiesList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(LastActivitiesList[position].Id);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }


        private void Click(LastActivitiesAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(LastActivitiesAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }


        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = LastActivitiesList[p0];
                if (item == null)
                    return d;
                else
                {
                    if (!string.IsNullOrEmpty(item.Activator.Avatar))
                        d.Add(item.Activator.Avatar);

                    return d;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Collections.SingletonList(p0);
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Java.Lang.Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.CircleCrop);
        }


    }

    public class LastActivitiesAdapterViewHolder : RecyclerView.ViewHolder
    {
        public LastActivitiesAdapterViewHolder(View itemView,Action<LastActivitiesAdapterClickEventArgs> clickListener,Action<LastActivitiesAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                ActivitiesImage = (ImageView) MainView.FindViewById(Resource.Id.Image);
                Username = MainView.FindViewById<TextView>(Resource.Id.LastActivitiesUserName);
                ActivitiesEvent = MainView.FindViewById<TextView>(Resource.Id.LastActivitiesText);
                Icon = MainView.FindViewById<TextView>(Resource.Id.LastActivitiesIcon);
                Time = MainView.FindViewById<TextView>(Resource.Id.Time);

                //Create an Event
                itemView.Click += (sender, e) => clickListener(new LastActivitiesAdapterClickEventArgs{View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new LastActivitiesAdapterClickEventArgs{View = itemView, Position = AdapterPosition});

                //Don't Remove this code #####
                FontUtils.SetFont(Username, Fonts.SfRegular);
                FontUtils.SetFont(ActivitiesEvent, Fonts.SfRegular);
                FontUtils.SetFont(Time, Fonts.SfMedium);
                //#####

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        public View MainView { get; set; }

        public ImageView ActivitiesImage { get; set; }
        public TextView Username { get; set; }
        public TextView ActivitiesEvent { get; set; }
        public TextView Icon { get; set; }
        public TextView Time { get; set; }

        #endregion
    }

    public class LastActivitiesAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}