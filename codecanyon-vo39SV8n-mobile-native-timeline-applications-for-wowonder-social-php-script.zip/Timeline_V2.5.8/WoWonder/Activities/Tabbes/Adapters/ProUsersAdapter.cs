﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Android.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Bumptech.Glide;
using Java.Util;
using Refractored.Controls;
using WoWonder.Helpers.CacheLoaders;
using WoWonder.Helpers.Fonts;
using WoWonderClient.Classes.Global;
using IList = System.Collections.IList;

namespace WoWonder.Activities.Tabbes.Adapters
{
    public class ProUsersAdapter : RecyclerView.Adapter, ListPreloader.IPreloadModelProvider
    {
        
        public Activity ActivityContext;

        public ObservableCollection<UserDataObject> MProUsersList = new ObservableCollection<UserDataObject>();

        public ProUsersAdapter(Activity context)
        {
            try
            {
                HasStableIds = true;
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (MProUsersList != null)
                    return MProUsersList.Count;
                return 0;
            }
        }

        public event EventHandler<ProUsersAdapterClickEventArgs> ItemClick;
        public event EventHandler<ProUsersAdapterClickEventArgs> ItemLongClick;

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_Pro_Users_view
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_Pro_Users_view, parent, false);
                var vh = new ProUsersAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
               
                if (viewHolder is ProUsersAdapterViewHolder holder)
                {
                    var item = MProUsersList[position];
                    if (item != null)
                    {
                        GlideImageLoader.LoadImage(ActivityContext, item.Avatar, holder.UserImage, ImageStyle.CircleCrop, ImagePlaceholders.Drawable);
                          
                        if (item.ProType == "1") //  STAR
                        {
                            if (holder.CircleImageView.Tag?.ToString() != "true")
                            {
                                holder.CircleImageView.SetImageResource(Resource.Drawable.DarkGreen_Color);
                                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.AndroidStar);
                                holder.CircleImageView.Tag = "true";
                            }
                            
                        }
                        else if (item.ProType == "2") // HOT
                        {
                            if (holder.CircleImageView.Tag?.ToString() != "true")
                            {
                                holder.CircleImageView.Tag = "true";
                                holder.CircleImageView.SetImageResource(Resource.Drawable.DarkOrange_Color);
                                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.Flame);
                            }
                               
                        }
                        else if (item.ProType == "3") // ULTIMA
                        {
                            if (holder.CircleImageView.Tag?.ToString() != "true")
                            {
                                holder.CircleImageView.Tag = "true";
                                holder.CircleImageView.SetImageResource(Resource.Drawable.Red_Color);
                                FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, IonIconsFonts.Flash);
                            }
                             
                        }
                        else if (item.ProType == "4") // VIP
                        {
                            if (holder.Icon.Tag?.ToString() != "true")
                            {
                                holder.Icon.Tag = "true";
                                FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.Icon, "\uf135");
                            }
                              
                        }
                        else
                        {
                            if (holder.Icon.Tag?.ToString() != "true")
                            {
                                holder.Icon.Tag = "true";
                                FontUtils.SetTextViewIcon(FontsIconFrameWork.FontAwesomeLight, holder.Icon, "\uf135");
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
          
        public UserDataObject GetItem(int position)
        {
            return MProUsersList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(MProUsersList[position].UserId);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(ProUsersAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(ProUsersAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }


        public IList GetPreloadItems(int p0)
        {
            try
            {
                var d = new List<string>();
                var item = MProUsersList[p0];
                if (item == null)
                    return d;
                else
                {
                    if (!string.IsNullOrEmpty(item.Avatar))
                        d.Add(item.Avatar);

                    return d;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
               return Collections.SingletonList(p0);
            }
        }

        public RequestBuilder GetPreloadRequestBuilder(Java.Lang.Object p0)
        {
            return GlideImageLoader.GetPreLoadRequestBuilder(ActivityContext, p0.ToString(), ImageStyle.CircleCrop);
        }


    }

    public class ProUsersAdapterViewHolder : RecyclerView.ViewHolder
    {
        public ProUsersAdapterViewHolder(View itemView, Action<ProUsersAdapterClickEventArgs> clickListener,
            Action<ProUsersAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                Icon = MainView.FindViewById<TextView>(Resource.Id.Iconpro);
                UserImage = MainView.FindViewById<ImageView>(Resource.Id.Image);
                CircleImageView = MainView.FindViewById<CircleImageView>(Resource.Id.ImageCircle);


                //Create an Event
                itemView.Click += (sender, e) => clickListener(new ProUsersAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new ProUsersAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        public View MainView { get; }

        


        public ImageView UserImage { get; set; }
        public CircleImageView CircleImageView { get; set; }
        public TextView Icon { get; set; }

        #endregion
    }

    public class ProUsersAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}