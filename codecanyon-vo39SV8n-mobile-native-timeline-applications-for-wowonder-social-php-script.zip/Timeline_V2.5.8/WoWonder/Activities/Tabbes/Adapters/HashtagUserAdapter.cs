﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Android.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Fonts;
using WoWonderClient.Classes.Global;

namespace WoWonder.Activities.Tabbes.Adapters
{
    public class HashtagUserAdapter : RecyclerView.Adapter 
    {
        
        public Activity ActivityContext;

        public ObservableCollection<GetGeneralDataObject.TrendingHashtag> MHashtagList =
            new ObservableCollection<GetGeneralDataObject.TrendingHashtag>();

        public HashtagUserAdapter(Activity context)
        {
            try
            {
                HasStableIds = true;
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (MHashtagList != null)
                    return MHashtagList.Count;
                return 0;
            }
        }

        public event EventHandler<HashtagUserAdapterClickEventArgs> ItemClick;
        public event EventHandler<HashtagUserAdapterClickEventArgs> ItemLongClick;


        // Create new views (invoked by the layout manager) 
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_HLastSearch_View
                var itemView = LayoutInflater.From(parent.Context)
                    .Inflate(Resource.Layout.Style_HLastSearch_View, parent, false);
                var vh = new HashtagUserAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {
               
                if (viewHolder is HashtagUserAdapterViewHolder holder)
                {
                    var item = MHashtagList[position];
                    if (item != null)
                    {
                        //Dont Remove this code #####
                        FontUtils.SetFont(holder.Button, Fonts.SfRegular);
                        //#####
                        holder.Button.Text = "#" + item.Tag;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void BindEnd()
        {
            try
            {
                NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Function 
        public void Add(GetGeneralDataObject.TrendingHashtag hash)
        {
            try
            {
                var check = MHashtagList.FirstOrDefault(a => a.Id == hash.Id);
                if (check == null)
                {
                    MHashtagList.Add(hash);
                    NotifyItemInserted(MHashtagList.IndexOf(MHashtagList.Last()));
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void Clear()
        {
            try
            {
                MHashtagList.Clear();
                NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public GetGeneralDataObject.TrendingHashtag GetItem(int position)
        {
            return MHashtagList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return int.Parse(MHashtagList[position].Id);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(HashtagUserAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(HashtagUserAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
    }

    public class HashtagUserAdapterViewHolder : RecyclerView.ViewHolder
    {
        public HashtagUserAdapterViewHolder(View itemView, Action<HashtagUserAdapterClickEventArgs> clickListener,
            Action<HashtagUserAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                Button = MainView.FindViewById<Button>(Resource.Id.cont);

                //Create an Event
                itemView.Click += (sender, e) => clickListener(new HashtagUserAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
                itemView.LongClick += (sender, e) => longClickListener(new HashtagUserAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #region Variables Basic

        public View MainView { get; }

        

        public Button Button { get; set; }

        #endregion
    }

    public class HashtagUserAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}