﻿using System;
using System.Collections.ObjectModel;
using Android.App;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using WoWonder.Helpers.Fonts;

namespace WoWonder.Activities.Tabbes.Adapters
{
    public class SectionItem
    {
        public int Id { get; set; }
        public string SectionName { get; set; }
        public string Icon { get; set; }
        public Color IconColor { get; set; }
        public int BadgeCount { get; set; }
        public bool Badgevisibilty { get; set; }
    }

    public class MoreSectionAdapter : RecyclerView.Adapter
    {
        public ObservableCollection<SectionItem> SectionList = new ObservableCollection<SectionItem>();

        public MoreSectionAdapter(Activity activityContext)
        {
            SectionList.Add(new SectionItem
            {
                Id = 1,
                SectionName = activityContext.GetText(Resource.String.Lbl_MyProfile),
                BadgeCount = 0,
                Badgevisibilty = false,
                Icon = IonIconsFonts.HappyOutline,
                IconColor = Color.ParseColor("#047cac")
            });
            if (AppSettings.MessengerIntegration)
                SectionList.Add(new SectionItem
                {
                    Id = 2,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Messages),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Chatbubble,
                    IconColor = Color.ParseColor("#03a9f4")
                });
            if (AppSettings.ShowUserContacts)
            {
                string name = activityContext.GetText(AppSettings.ConnectivitySystem ==1 ? Resource.String.Lbl_Following : Resource.String.Lbl_Friends);
                SectionList.Add(new SectionItem
                {
                    Id = 3,
                    SectionName = name,
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.PersonStalker,
                    IconColor = Color.ParseColor("#d80073")
                }); 
            }
            if (AppSettings.ShowPokes)
                SectionList.Add(new SectionItem
                {
                    Id = 4,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Pokes),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Aperture,
                    IconColor = Color.ParseColor("#009688")
                });
            if (AppSettings.ShowAlbum)
                SectionList.Add(new SectionItem
                {
                    Id = 5,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Albums),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Images,
                    IconColor = Color.ParseColor("#8bc34a")
                });
            if (AppSettings.ShowSavedPost)
                SectionList.Add(new SectionItem
                {
                    Id = 6,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Saved_Posts),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Bookmark,
                    IconColor = Color.ParseColor("#673ab7")
                });
            if (AppSettings.ShowCommunitiesGroups)
                SectionList.Add(new SectionItem
                {
                    Id = 7,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Groups),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.AndroidApps,
                    IconColor = Color.ParseColor("#03A9F4")
                });
            if (AppSettings.ShowCommunitiesPages)
                SectionList.Add(new SectionItem
                {
                    Id = 8,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Pages),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Flag,
                    IconColor = Color.ParseColor("#f79f58")
                });
            if (AppSettings.ShowArticles)
                SectionList.Add(new SectionItem
                {
                    Id = 9,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Blogs),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.IosBook,
                    IconColor = Color.ParseColor("#f35d4d")
                });
            if (AppSettings.ShowMarket)
                SectionList.Add(new SectionItem
                {
                    Id = 10,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Marketplace),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Bag,
                    IconColor = Color.ParseColor("#7d8250")
                });
            if (AppSettings.ShowPopularPosts)
                SectionList.Add(new SectionItem
                {
                    Id = 11,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Popular_Posts),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.AndroidClipboard,
                    IconColor = Color.ParseColor("#8d73cc")
                });
            if (AppSettings.ShowEvents)
                SectionList.Add(new SectionItem
                {
                    Id = 12,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Events),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Calendar,
                    IconColor = Color.ParseColor("#f25e4e")
                });
            if (AppSettings.ShowNearBy)
                SectionList.Add(new SectionItem
                {
                    Id = 13,
                    SectionName = activityContext.GetText(Resource.String.Lbl_FindFriends),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Location,
                    IconColor = Color.ParseColor("#b2c17c")
                });
            if (AppSettings.ShowMovies)
                SectionList.Add(new SectionItem
                {
                    Id = 14,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Movies),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.FilmMarker,
                    IconColor = Color.ParseColor("#00695C")
                });
            //Settings Page
            if (AppSettings.ShowSettingsGeneralAccount)
                SectionList.Add(new SectionItem
                {
                    Id = 15,
                    SectionName = activityContext.GetText(Resource.String.Lbl_GeneralAccount),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Settings,
                    IconColor = Color.ParseColor("#616161")
                });
            if (AppSettings.ShowSettingsPrivacy)
                SectionList.Add(new SectionItem
                {
                    Id = 16,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Privacy),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Eye,
                    IconColor = Color.ParseColor("#616161")
                });
            if (AppSettings.ShowSettingsNotification)
                SectionList.Add(new SectionItem
                {
                    Id = 17,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Notifcations),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.IosBell,
                    IconColor = Color.ParseColor("#616161")
                });
            if (AppSettings.ShowSettingsInviteFriends)
                SectionList.Add(new SectionItem
                {
                    Id = 18,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Tell_Friends),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Email,
                    IconColor = Color.ParseColor("#616161")
                });
            if (AppSettings.ShowSettingsHelpSupport)
                SectionList.Add(new SectionItem
                {
                    Id = 19,
                    SectionName = activityContext.GetText(Resource.String.Lbl_Help_Support),
                    BadgeCount = 0,
                    Badgevisibilty = false,
                    Icon = IonIconsFonts.Help,
                    IconColor = Color.ParseColor("#616161")
                });
            SectionList.Add(new SectionItem
            {
                Id = 20,
                SectionName = activityContext.GetText(Resource.String.Lbl_Logout),
                BadgeCount = 0,
                Badgevisibilty = false,
                Icon = IonIconsFonts.LogOut,
                IconColor = Color.ParseColor("#d50000")
            });
        }

        public override int ItemCount
        {
            get
            {
                if (SectionList != null)
                    return SectionList.Count;
                return 0;
            }
        }

        public event EventHandler<MoreSectionAdapterClickEventArgs> ItemClick;
        public event EventHandler<MoreSectionAdapterClickEventArgs> ItemLongClick;

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> ChannelSubscribed_View
                var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_MoreSection_view, parent, false);
                var vh = new MoreSectionAdapterViewHolder(itemView, Click, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }


        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            { 
                if (viewHolder is MoreSectionAdapterViewHolder holder)
                {
                    if (AppSettings.FlowDirectionRightToLeft)
                    {
                        holder.LinearLayoutImage.LayoutDirection = LayoutDirection.Rtl;
                        holder.LinearLayoutMain.LayoutDirection = LayoutDirection.Rtl;
                        holder.Name.LayoutDirection = LayoutDirection.Rtl;
                    }
                     
                    var item = SectionList[position];
                    if (item != null)
                    {
                        //Dont Remove this code #####
                       // FontUtils.SetFont(holder.Name, Fonts.SfRegular);
                        //#####

                        FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, holder.Icon, item.Icon);
                        holder.Icon.SetTextColor(item.IconColor);
                        holder.Name.Text = item.SectionName;

                        if (item.BadgeCount != 0)
                            holder.Badge.Text = item.BadgeCount.ToString();

                        if (item.Badgevisibilty)
                            holder.Badge.Visibility = ViewStates.Visible;
                        else
                            holder.Badge.Visibility = ViewStates.Invisible;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public SectionItem GetItem(int position)
        {
            return SectionList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        private void Click(MoreSectionAdapterClickEventArgs args)
        {
            ItemClick?.Invoke(this, args);
        }

        private void LongClick(MoreSectionAdapterClickEventArgs args)
        {
            ItemLongClick?.Invoke(this, args);
        }
    }

    public class MoreSectionAdapterViewHolder : RecyclerView.ViewHolder
    {
        public MoreSectionAdapterViewHolder(View itemView, Action<MoreSectionAdapterClickEventArgs> clickListener,Action<MoreSectionAdapterClickEventArgs> longClickListener) : base(itemView)
        {
            try
            {
                MainView = itemView;

                LinearLayoutMain = MainView.FindViewById<LinearLayout>(Resource.Id.main);
                LinearLayoutImage = MainView.FindViewById<RelativeLayout>(Resource.Id.imagecontainer);

                Icon = MainView.FindViewById<TextView>(Resource.Id.Icon);
                Name = MainView.FindViewById<TextView>(Resource.Id.section_name);
                Badge = MainView.FindViewById<TextView>(Resource.Id.badge);

                itemView.Click += (sender, e) => clickListener(new MoreSectionAdapterClickEventArgs
                    {View = itemView, Position = AdapterPosition});
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public View MainView { get; }

        public LinearLayout LinearLayoutMain { get; set; }
        public RelativeLayout LinearLayoutImage { get; set; }
        public TextView Icon { get; set; }
        public TextView Name { get; set; }
        public TextView Badge { get; set; }

        
    }

    public class MoreSectionAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
    }
}