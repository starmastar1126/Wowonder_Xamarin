﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AFollestad.MaterialDialogs;
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Graphics;
using Android.OS;
using Android.Provider;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Support.V4.Content;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using Bumptech.Glide;
using Bumptech.Glide.Load.Engine;
using Bumptech.Glide.Request;
using Com.Gigamole.Navigationtabbar.Ntb;
using Com.Theartofdev.Edmodo.Cropper;
using Java.Lang;
using Newtonsoft.Json;
using WoWonder.Activities.AddPost;
using WoWonder.Activities.NativePost.Post;
using WoWonder.Activities.Search;
using WoWonder.Activities.Story;
using WoWonder.Activities.Story.Adapters;
using WoWonder.Activities.Tabbes.Adapters;
using WoWonder.Activities.Tabbes.Fragment;
using WoWonder.Adapters;
using WoWonder.Helpers.Ads;
using WoWonder.Helpers.Controller;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using WoWonder.SQLite;
using WoWonderClient.Classes.Global;
using WoWonderClient.Classes.Posts;
using Exception = System.Exception;
using File = Java.IO.File;
using SearchView = Android.Support.V7.Widget.SearchView;
using Uri = Android.Net.Uri;

namespace WoWonder.Activities.Tabbes
{
    [Activity(Icon = "@drawable/icon", Theme = "@style/MyTheme", ConfigurationChanges =ConfigChanges.Keyboard | ConfigChanges.Orientation | ConfigChanges.KeyboardHidden |ConfigChanges.ScreenLayout | ConfigChanges.ScreenSize | ConfigChanges.SmallestScreenSize |ConfigChanges.UiMode | ConfigChanges.Locale)]
    public class TabbedMainActivity : AppCompatActivity,View.IOnClickListener, View.IOnFocusChangeListener, MaterialDialog.IListCallback, MaterialDialog.ISingleButtonCallback
    {
        #region Variables Basic

        private static TabbedMainActivity Instance; 
        public ProUsersAdapter ProUsersAdapter;
        public HashtagUserAdapter HashTagUserAdapter;
        public ProPagesAdapter ProPagesAdapter;
        public ObservableCollection<UserDataObject> FriendRequestsList = new ObservableCollection<UserDataObject>();
        private ViewPager ViewPager;
        public NewsFeedNative NewsFeedTab;
        private NotificationsFragment NotificationsTab;
        public TrendingFragment TrendingTab;
        private MoreFragment MoreTab;
        private NavigationTabBar NavigationTabBar;
        private MainTabAdapter TabAdapter;
        private JavaList<NavigationTabBar.Model> Models;
        private FloatingActionButton FloatingActionButton;
        private SearchView SearchViewBar;
        private ImageButton BtnStory;
        private string ImageType = "";
        private static string CountNotificationsStatic = "0", CountMessagesStatic = "0", CountFriendStatic = "0";
        private static bool AddAnnouncement;

        #endregion

        #region General

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);

                base.OnCreate(savedInstanceState);

                Methods.App.FullScreenApp(this);

                // Create your application here
                SetContentView(Resource.Layout.Tabbed_Main_Layout);

                Instance = this;

                //Get Value And Set Toolbar
                InitComponent(); 
                SetRecyclerViewAdapters();

                Models = new JavaList<NavigationTabBar.Model>();
                AddFragmentsTabs();
                  
                GetGeneralAppData();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                SearchViewBar?.ClearFocus();
                AdsGoogle.Ad_Interstitial(this);
                AddOrRemoveEvent(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnPause()
        {
            try
            {
                base.OnPause();
                AddOrRemoveEvent(false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnTrimMemory(TrimMemory level)
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
                base.OnTrimMemory(level);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnDestroy()
        {
            try
            {
                base.OnDestroy();
                NewsFeedTab?.MainRecyclerView?.ReleasePlayer();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Functions

        private void InitComponent()
        {
            try
            {
                NavigationTabBar = FindViewById<NavigationTabBar>(Resource.Id.ntb_horizontal);
                NavigationTabBar.StartTabSelected += NavigationTabBarOnStartTabSelected;

                ViewPager = FindViewById<ViewPager>(Resource.Id.vp_horizontal_ntb);
                TabAdapter = new MainTabAdapter(SupportFragmentManager);
                SearchViewBar = FindViewById<SearchView>(Resource.Id.searchView);
                if (SearchViewBar != null)
                {
                    SearchViewBar.SetIconifiedByDefault(false);
                    SearchViewBar.SetOnClickListener(this);
                    SearchViewBar.SetOnSearchClickListener(this);
                    SearchViewBar.SetOnQueryTextFocusChangeListener(this);
                }

                FloatingActionButton = FindViewById<FloatingActionButton>(Resource.Id.floatingActionButtonView);
                FloatingActionButton.Visibility = ViewStates.Invisible;

                BtnStory = FindViewById<ImageButton>(Resource.Id.storybutton);

                if (!Directory.Exists(Methods.Path.FolderDcimStory))
                    Directory.CreateDirectory(Methods.Path.FolderDcimStory);

                BtnStory.Visibility = AppSettings.ShowStory ? ViewStates.Visible : ViewStates.Gone;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

       
        private void SetRecyclerViewAdapters()
        {
            try
            {
                //============================= Hash tag Users ================================== 
                HashTagUserAdapter = new HashtagUserAdapter(this)
                {
                    MHashtagList = new ObservableCollection<GetGeneralDataObject.TrendingHashtag>()
                };
                ////============================= Promoted Pages ================================== 
                ProPagesAdapter = new ProPagesAdapter(this) {MProPagesList = new ObservableCollection<PageClass>()};
                ////============================= Pro Users ================================== 
                ProUsersAdapter = new ProUsersAdapter(this)
                {
                    MProUsersList = new ObservableCollection<UserDataObject>()
                };
                ////============================= Requests Users ================================== 
                FriendRequestsList = new ObservableCollection<UserDataObject>();
                //===============================================================
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void AddOrRemoveEvent(bool addEvent)
        {
            try
            {
                // true +=  // false -=
                if (addEvent)
                { 
                    if (AppSettings.ShowStory)
                        BtnStory.Click += CreateStories_OnClick;

                    FloatingActionButton.Click += Btn_AddPost_OnClick;
                }
                else
                {
                    //Close Event
                    if (AppSettings.ShowStory)
                        BtnStory.Click -= CreateStories_OnClick;

                    FloatingActionButton.Click -= Btn_AddPost_OnClick;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static TabbedMainActivity GetInstance()
        {
            try
            {
                return Instance;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        #endregion

        #region Events

        //Event Open page add post
        private void Btn_AddPost_OnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                var Int = new Intent(this, typeof(AddPostActivity));
                Int.PutExtra("Type", "Normal");
                Int.PutExtra("PostId", UserDetails.UserId);
                //Int.PutExtra("itemObject", JsonConvert.SerializeObject(PageData));
                StartActivityForResult(Int, 2500); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Permissions && Result

        //Result
        protected override async void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            try
            {
                base.OnActivityResult(requestCode, resultCode, data);
                 
                //If its from Camera or Gallery
                if (requestCode == 503) // Add story using camera
                {
                    if (IntentController.ImageCameraUri == null)
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                        return;
                    }

                    //var thumbnail = MediaStore.Images.Media.GetBitmap(ContentResolver, IntentController.imageCameraUri);

                    var path = GetRealPathFromUri(IntentController.ImageCameraUri);
                    if (Methods.MultiMedia.CheckFileIfExits(path) != "File Dont Exists")
                    {
                        //Do something with your Uri
                        Intent Int = new Intent(this, typeof(AddStoryActivity));
                        Int.PutExtra("Uri", path);
                        Int.PutExtra("Type", "image");
                        StartActivity(Int);
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Failed_to_load), ToastLength.Short).Show();
                    }
                }
                else if (requestCode == 501) // Add video story
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Video")
                        {
                            Intent Int = new Intent(this, typeof(AddStoryActivity));
                            Int.PutExtra("Uri", filepath);
                            Int.PutExtra("Type", "video");
                            StartActivity(Int);
                        }
                    } 
                }
                else if (requestCode == 500) // Add image story
                {
                    var filepath = Methods.AttachmentFiles.GetActualPathFromFile(this, data.Data);
                    if (filepath != null)
                    {
                        var type = Methods.AttachmentFiles.Check_FileExtension(filepath);
                        if (type == "Image")
                        {
                            if (!string.IsNullOrEmpty(filepath))
                            {
                                //Do something with your Uri
                                Intent Int = new Intent(this, typeof(AddStoryActivity));
                                Int.PutExtra("Uri", filepath);
                                Int.PutExtra("Type", "image");
                                StartActivity(Int);
                            } 
                        }
                    } 
                }
                else //If its from Camera or Gallery
                if (requestCode == CropImage.CropImageActivityRequestCode)
                {
                    var result = CropImage.GetActivityResult(data);

                    if (resultCode == Result.Ok)
                    {
                        if (result.IsSuccessful)
                        {
                            var resultUri = result.Uri;

                            if (!string.IsNullOrEmpty(resultUri.Path))
                            {
                                //Do something with your Uri
                                Intent Int = new Intent(this, typeof(AddStoryActivity));
                                Int.PutExtra("Uri", resultUri.Path);
                                Int.PutExtra("Type", "image");
                                StartActivity(Int);
                            }
                            else
                            {
                                Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong),ToastLength.Long).Show();
                            }
                        }
                        else
                        {
                            Toast.MakeText(this, GetText(Resource.String.Lbl_something_went_wrong), ToastLength.Long).Show();
                        }
                    } 
                }
                else if (requestCode == 2 && resultCode == Result.Ok)
                {
                    SearchViewBar.Focusable = false;
                    SearchViewBar.FocusableInTouchMode = false;
                    SearchViewBar.ClearFocus();
                }
                else if (requestCode == 2500 && resultCode == Result.Ok) //add post
                {
                   var postData = JsonConvert.DeserializeObject<PostDataObject>(data.GetStringExtra("itemObject"));
                   if (postData != null)
                   {
                       var postType = NewsFeedTab.PostFeedAdapter.BaseAdapterBinder.GetAdapterType(postData);

                       NewsFeedTab.MainRecyclerView.InsertByRowIndex(new AdapterModelsClass()
                       {
                           TypeView = postType,
                           Id = int.Parse(postData.Id),
                           PostData = postData,
                           IsDefaultFeedPost = true,
                       });
                   }
                   else
                   {
                       await NewsFeedTab.MainRecyclerView.FetchNewsFeedApiPosts("0").ConfigureAwait(false);
                   } 
                }
                else if (requestCode == 3950 && resultCode == Result.Ok) //Edit post
                { 
                    var postId = data.GetStringExtra("PostId") ?? "";
                    var postText = data.GetStringExtra("PostText") ?? "";

                    var postData = NewsFeedTab.PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.PostData?.Id == postId);
                    if (postData != null)
                    {
                        postData.PostData.Orginaltext = postText;

                        var index = NewsFeedTab.PostFeedAdapter.PostFeedList.IndexOf(postData);
                        if (index > -1)
                        {
                            NewsFeedTab.PostFeedAdapter.NotifyItemChanged(index);
                        } 
                    } 
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //Permissions
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                base.OnRequestPermissionsResult(requestCode, permissions, grantResults); 
                if (requestCode == 108)
                {
                    if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                    {
                        switch (ImageType)
                        {
                            //requestCode >> 500 => Image Gallery
                            case "Image" when AppSettings.ImageCropping:
                                OpenDialogGallery("Image");
                                break;
                            case "Image": //requestCode >> 500 => Image Gallery
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); 
                                break;
                            case "Video":
                                //requestCode >> 501 => video Gallery
                                new IntentController(this).OpenIntentVideoGallery();
                                break;
                            case "Camera":
                                //requestCode >> 503 => Camera
                                new IntentController(this).OpenIntentCamera();
                                break;
                        }
                    }
                    else
                    {
                        Toast.MakeText(this, GetText(Resource.String.Lbl_Permission_is_denailed), ToastLength.Long).Show();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        #endregion
            
        #region Search View

        public void OnClick(View v)
        {
            if (v.Id == SearchViewBar.Id)
            {
                //Hide keyboard programmatically in MonoDroid

                var inputManager = (InputMethodManager) GetSystemService(InputMethodService);
                inputManager.HideSoftInputFromWindow(SearchViewBar.WindowToken, HideSoftInputFlags.None);

                SearchViewBar.ClearFocus();

                var intent = new Intent(this, typeof(SearchTabbedActivity));
                intent.PutExtra("Key", "");
                StartActivity(intent);
            }
        }

        public void OnFocusChange(View v, bool hasFocus)
        {
            try
            {
                if (v.Id == SearchViewBar.Id && hasFocus)
                {
                    var intent = new Intent(this, typeof(SearchTabbedActivity));
                    intent.PutExtra("Key", "");
                    StartActivity(intent);
                }

                SearchViewBar.ClearFocus();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Set Tab

        private void SetTabStyle()
        {
            try
            {
                Models.Clear();

                if (Models != null && Models.Count <= 0)
                {
                    Models.Add(new NavigationTabBar.Model.Builder(ContextCompat.GetDrawable(this, Resource.Drawable.ic_tab_home), Color.ParseColor("#ffffff")).Title(GetText(Resource.String.Lbl_News_Feed)).Build());
                   Models.Add(new NavigationTabBar.Model.Builder(ContextCompat.GetDrawable(this, Resource.Drawable.ic_action_notification),Color.ParseColor("#ffffff")).Title(GetText(Resource.String.Lbl_Notifcations)).Build());
                   Models.Add(new NavigationTabBar.Model.Builder(ContextCompat.GetDrawable(this, Resource.Drawable.ic_action_trending),Color.ParseColor("#ffffff")).Title(GetText(Resource.String.Lbl_Trending)).Build());
                    Models.Add(new NavigationTabBar.Model.Builder(ContextCompat.GetDrawable(this, Resource.Drawable.ic_tab_more), Color.ParseColor("#ffffff")).Title(GetText(Resource.String.Lbl_More)).Build());

                    if (AppSettings.SetTabColoredTheme)
                    {
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_News_Feed)).Color =Color.ParseColor(AppSettings.TabColoredColor);
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_Notifcations)).Color =Color.ParseColor(AppSettings.TabColoredColor);
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_Trending)).Color =Color.ParseColor(AppSettings.TabColoredColor);
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_More)).Color =Color.ParseColor(AppSettings.TabColoredColor);

                        NavigationTabBar.BgColor = Color.ParseColor(AppSettings.MainColor);
                        NavigationTabBar.ActiveColor = Color.White;
                        NavigationTabBar.InactiveColor = Color.White;
                    }
                    else if (AppSettings.SetTabDarkTheme)
                    {
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_News_Feed)).Color =Color.ParseColor("#444444");
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_Notifcations)).Color =Color.ParseColor("#444444");
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_Trending)).Color =Color.ParseColor("#444444");
                        Models.First(a => a.Title == GetText(Resource.String.Lbl_More)).Color =Color.ParseColor("#444444");

                        NavigationTabBar.BgColor = Color.ParseColor("#282828");
                        NavigationTabBar.ActiveColor = Color.White;
                        NavigationTabBar.InactiveColor = Color.White;
                    }

                    NavigationTabBar.Models = Models;
                    NavigationTabBar.SetViewPager(ViewPager, 0);
                    NavigationTabBar.IsScaled = false;
                    NavigationTabBar.IconSizeFraction = (float) 0.450;
                    //navigationTabBar.SetBadgePosition(NavigationTabBar.BadgePosition.Center);
                    if (AppSettings.SetTabIsTitledWithText)
                    {
                        NavigationTabBar.SetTitleMode(NavigationTabBar.TitleMode.All);
                        NavigationTabBar.IsTitled = true;
                    }
                    
                    NavigationTabBar.BehaviorEnabled = true;
                    if (!AppSettings.SetTabOnButton)
                    {
                        //var eee = NavigationTabBar.BadgeGravity.TopIndex = 2;
                        // navigationTabBar.SetBadgeGravity( );
                        NavigationTabBar.SetBadgePosition(NavigationTabBar.BadgePosition.Center);

                        var parasms = (CoordinatorLayout.LayoutParams) NavigationTabBar.LayoutParameters;
                        parasms.Gravity = (int) GravityFlags.Top;

                        // Check if we're running on Android 5.0 or higher
                        if ((int) Build.VERSION.SdkInt < 23)
                            parasms.TopMargin = 70;
                        else
                            parasms.TopMargin = 115;

                        NavigationTabBar.LayoutParameters = parasms;

                        var parasms2 = (CoordinatorLayout.LayoutParams) FloatingActionButton.LayoutParameters;

                        // Check if we're running on Android 5.0 or higher
                        parasms2.BottomMargin = (int) Build.VERSION.SdkInt < 23 ? 48 : 68; 
                        FloatingActionButton.LayoutParameters = parasms2;
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void ViewPager_PageScrolled(object sender, ViewPager.PageScrolledEventArgs e)
        {
            try
            {
                var page = e.Position;
                if (page == 0) // News_Feed_Tab
                {  
                    if (FloatingActionButton.Visibility == ViewStates.Invisible)
                        FloatingActionButton.Visibility = ViewStates.Visible;
                }
                else if (page == 1) // Notifications_Tab
                { 
                    if (FloatingActionButton.Visibility == ViewStates.Visible)
                        FloatingActionButton.Visibility = ViewStates.Invisible;
                }
                else if (page == 2) // Trending_Tab
                { 
                    if (FloatingActionButton.Visibility == ViewStates.Visible)
                        FloatingActionButton.Visibility = ViewStates.Invisible;

                }
                else if (page == 3) // More_Tab
                { 
                    if (FloatingActionButton.Visibility == ViewStates.Visible)
                        FloatingActionButton.Visibility = ViewStates.Invisible;
                }
                else
                { 
                    if (FloatingActionButton.Visibility == ViewStates.Visible)
                        FloatingActionButton.Visibility = ViewStates.Invisible;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void AddFragmentsTabs()
        {
            try
            {
                TabAdapter.ClaerFragment();

                NewsFeedTab = new NewsFeedNative();
                NotificationsTab = new NotificationsFragment();
                TrendingTab = new TrendingFragment();
                MoreTab = new MoreFragment();

                if (TabAdapter != null && TabAdapter.Count <= 0)
                {
                    TabAdapter.AddFragment(NewsFeedTab, GetText(Resource.String.Lbl_News_Feed));
                    TabAdapter.AddFragment(NotificationsTab, GetText(Resource.String.Lbl_Notifcations));
                    TabAdapter.AddFragment(TrendingTab, GetText(Resource.String.Lbl_Trending));
                    TabAdapter.AddFragment(MoreTab, GetText(Resource.String.Lbl_More));
                    ViewPager.CurrentItem = 3;
                    ViewPager.OffscreenPageLimit = TabAdapter.Count;
                    ViewPager.Adapter = TabAdapter;
                    ViewPager.PageScrolled += ViewPager_PageScrolled;
                    ViewPager.PageSelected += ViewPagerOnPageSelected;
                    SetTabStyle();
                     
                    NavigationTabBar.SetZ(5);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private static int OpenNewsFeedTab = 1;
        private void ViewPagerOnPageSelected(object sender, ViewPager.PageSelectedEventArgs e)
        {
            try
            {
                if (e.Position >= 0)
                {
                    if (e.Position == 0) // News_Feed_Tab
                    {
                        AdsGoogle.Ad_Interstitial(this);
                    }
                    else if (e.Position == 1) // Notifications_Tab
                    {
                        AdsGoogle.Ad_RewardedVideo(this);
                        var dataTab = Models.FirstOrDefault(a => a.Title == GetText(Resource.String.Lbl_Notifcations));
                        dataTab?.HideBadge(); 
                    }
                    else if (e.Position == 2) // Trending_Tab
                    {
                        AdsGoogle.Ad_Interstitial(this);
                        var dataTab = Models.FirstOrDefault(a => a.Title == GetText(Resource.String.Lbl_Trending));
                        dataTab?.HideBadge();

                        if (AppSettings.ShowLastActivities)
                            Task.Run(() => { TrendingTab.StartApiService(); });
                    }
                    else if (e.Position == 3) // More_Tab
                    {
                        AdsGoogle.Ad_RewardedVideo(this);
                        PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => ApiRequest.Get_MyProfileData_Api(this) });
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void NavigationTabBarOnStartTabSelected(object sender, NavigationTabBar.StartTabSelectedEventArgs e)
        {
            try
            {
                if (e.P1 >= 0)
                {
                    if (e.P1 == 0) // News_Feed_Tab
                    {
                        if (OpenNewsFeedTab == 2)
                        {
                            OpenNewsFeedTab = 1;
                            NewsFeedTab.MainRecyclerView.ScrollToPosition(0);
                        }
                        else
                            OpenNewsFeedTab++; 
                    }
                    else if (e.P1 == 1) // Notifications_Tab
                    {
                        OpenNewsFeedTab = 1;
                    }
                    else if (e.P1 == 2) // Trending_Tab
                    {
                        OpenNewsFeedTab = 1;
                    }
                    else if (e.P1 == 3) // More_Tab
                    {
                        OpenNewsFeedTab = 1; 
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region MaterialDialog

        private void ShowDialogAddStory()
        {
            try
            {
                var arrayAdapter = new List<string>();
                var dialogList = new MaterialDialog.Builder(this);

                arrayAdapter.Add(GetText(Resource.String.image));
                arrayAdapter.Add(GetText(Resource.String.video));
                arrayAdapter.Add(GetText(Resource.String.Lbl_Camera));

                dialogList.Title(GetText(Resource.String.Lbl_Addnewstory));
                dialogList.Items(arrayAdapter);
                dialogList.NegativeText(GetText(Resource.String.Lbl_Close)).OnNegative(this);
                dialogList.AlwaysCallSingleChoiceCallback();
                dialogList.ItemsCallback(this).Build().Show();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnSelection(MaterialDialog p0, View p1, int itemId, ICharSequence itemString)
        {
            try
            {
                if (itemString.ToString() == GetText(Resource.String.image))
                {
                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        if (AppSettings.ImageCropping)
                            OpenDialogGallery("Image"); //requestCode >> 500 => Image Gallery
                        else
                            new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                            && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            if (AppSettings.ImageCropping)
                                OpenDialogGallery("Image"); //requestCode >> 500 => Image Gallery
                            else
                                new IntentController(this).OpenIntentImageGallery(GetText(Resource.String.Lbl_SelectPictures)); //requestCode >> 500 => Image Gallery
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(108);
                        }
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.video))
                {
                    ImageType = "Video";

                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        //requestCode >> 501 => video Gallery
                        new IntentController(this).OpenIntentVideoGallery();
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted 
                            && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            //requestCode >> 501 => video Gallery
                            new IntentController(this).OpenIntentVideoGallery();
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(108);
                        }
                    }
                }
                else if (itemString.ToString() == GetText(Resource.String.Lbl_Camera))
                {
                    ImageType = "Camera";

                    // Check if we're running on Android 5.0 or higher
                    if ((int)Build.VERSION.SdkInt < 23)
                    {
                        //requestCode >> 503 => Camera
                        new IntentController(this).OpenIntentCamera();
                    }
                    else
                    {
                        if (CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted
                            && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted
                            && CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted)
                        {
                            //requestCode >> 503 => Camera
                            new IntentController(this).OpenIntentCamera();
                        }
                        else
                        {
                            new PermissionsController(this).RequestPermission(108);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e); 
            }
        }

        public void OnClick(MaterialDialog p0, DialogAction p1)
        {
            try
            {
                if (p1 == DialogAction.Positive)
                {
                }
                else if (p1 == DialogAction.Negative)
                {
                    p0.Dismiss();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Stories

        public void StoryAdapterOnItemClick(object sender, StoryAdapterClickEventArgs e)
        {
            try
            {
                var checkSection = NewsFeedTab.PostFeedAdapter.PostFeedList.FirstOrDefault(a => a.TypeView == PostModelType.Story);
                if (checkSection != null)
                {
                    //Open View Story Or Create New Story
                    var item = NewsFeedTab.PostFeedAdapter?.HolderStory?.StoryAdapter.GetItem(e.Position);
                    if (item != null)
                    {
                        //var circleIndicator = e.View.FindViewById<CircleImageView>(Resource.Id.profile_indicator); 
                        //circleIndicator.BorderColor = Color.ParseColor(Settings.StoryReadColor);

                        if (item.Type == "Your")
                        {
                            ShowDialogAddStory();
                        }
                        else
                        {
                            Intent Int = new Intent(this, typeof(ViewStoryActivity));
                            Int.PutExtra("UserId", item.UserId);
                            Int.PutExtra("DataItem", JsonConvert.SerializeObject(item));
                            StartActivity(Int);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        //Menu Create Stories >>  Image , Video
        private void CreateStories_OnClick(object sender, EventArgs eventArgs)
        {
            try
            {
                ShowDialogAddStory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        private void GetGeneralAppData()
        {
            try
            {
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt >= 23)
                {
                    if (CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.AccessFineLocation) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.AccessCoarseLocation) == Permission.Granted)
                    {
                    }
                    else
                    {
                        // 100 >> Storage , 103 >> Camera , 105 >> Location
                        new PermissionsController(this).RequestPermission(108);
                        new PermissionsController(this).RequestPermission(103);
                        new PermissionsController(this).RequestPermission(105);
                    }
                }

                var sqlEntity = new SqLiteDatabase();

                var data = ListUtils.DataUserLoginList.FirstOrDefault();
                if (data != null && data.Status != "Active")
                {
                    data.Status = "Active";
                    UserDetails.Status = "Active";
                    sqlEntity.InsertOrUpdateLogin_Credentials(data);
                }

                sqlEntity.Get_MyProfile();
                Glide.With(this).Load(UserDetails.Avatar).Apply(new RequestOptions().SetDiskCacheStrategy(DiskCacheStrategy.All).CircleCrop()).Preload();

                if (ListUtils.MyProfileList?.Count == 0) 
                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> {() => ApiRequest.Get_MyProfileData_Api(this) });

                sqlEntity.Dispose();
                
                LoadConfigSettings();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void LoadConfigSettings()
        {
            try
            {
                var dbDatabase = new SqLiteDatabase();  
                var settingsData = dbDatabase.GetSettings();
                if (settingsData != null)
                    ListUtils.SettingsSiteList = settingsData;
                else
                    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => ApiRequest.GetSettings_Api(this) });

                dbDatabase.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public async void Get_Notifications()
        {
            try
            {
                var (countNotifications, countFriend, countMessages, textAnnouncement) = await NotificationsTab.LoadGeneralData(false).ConfigureAwait(false);
                if (!string.IsNullOrEmpty(countNotifications) && countNotifications != "0" && countNotifications != CountNotificationsStatic)
                    RunOnUiThread(() =>
                    {
                        try
                        {
                            var dataTab = Models.FirstOrDefault(a => a.Title == GetText(Resource.String.Lbl_Notifcations));
                            if (dataTab != null)
                            {
                                CountNotificationsStatic = countNotifications;
                                dataTab.BadgeTitle = countNotifications;
                                dataTab.UpdateBadgeTitle(countNotifications);
                                dataTab.ShowBadge();
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    });

                if (!string.IsNullOrEmpty(countFriend) && countFriend != "0" && countFriend != CountFriendStatic)
                    RunOnUiThread(() =>
                    {
                        try
                        {
                            var dataTab = Models.FirstOrDefault(a => a.Title == GetText(Resource.String.Lbl_Trending));
                            if (dataTab != null)
                            {
                                CountFriendStatic = countFriend;
                                dataTab.BadgeTitle = countFriend;
                                dataTab.UpdateBadgeTitle(countFriend);
                                dataTab.ShowBadge();
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    });
                 
                if (AppSettings.MessengerIntegration)
                {
                    if (!string.IsNullOrEmpty(countMessages) && countMessages != "0" && countMessages != CountMessagesStatic)
                    {
                        RunOnUiThread(() =>
                        {
                            try
                            {
                                var listMore = MoreTab.MoreSectionAdapter.SectionList;
                                if (listMore?.Count > 0)
                                {
                                    var dataTab = listMore.FirstOrDefault(a => a.Id == 2);
                                    if (dataTab != null)
                                    {
                                        CountMessagesStatic = countMessages;
                                        dataTab.BadgeCount = int.Parse(countMessages);
                                        dataTab.Badgevisibilty = true;
                                        dataTab.IconColor = Color.ParseColor("#b71c1c");

                                        MoreTab.MoreSectionAdapter.NotifyItemChanged(listMore.IndexOf(dataTab));
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        });
                    }
                    else
                    {
                        RunOnUiThread(() =>
                        {
                            try
                            {
                                var listMore = MoreTab.MoreSectionAdapter?.SectionList;
                                if (listMore?.Count > 0)
                                {
                                    var dataTab = listMore.FirstOrDefault(a => a.Id == 2);
                                    if (dataTab != null)
                                    {
                                        CountMessagesStatic = "0";
                                        dataTab.BadgeCount = 0;
                                        dataTab.Badgevisibilty = false;
                                        dataTab.IconColor = Color.ParseColor("#03a9f4");

                                        MoreTab.MoreSectionAdapter.NotifyItemChanged(listMore.IndexOf(dataTab));
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        });
                    }
                }

                if (!string.IsNullOrEmpty(textAnnouncement) && !AddAnnouncement)
                {
                    RunOnUiThread(() =>
                    {
                        try
                        {
                            AddAnnouncement = true;
                            NewsFeedTab?.SetAnnouncementAlert(textAnnouncement, "#3c763d");
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    });
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void OpenDialogGallery(string typeImage)
        {
            try
            {
                ImageType = typeImage;
                // Check if we're running on Android 5.0 or higher
                if ((int)Build.VERSION.SdkInt < 23)
                {
                    Methods.Path.Chack_MyFolder();

                    //Open Image 
                    var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                    CropImage.Builder()
                        .SetInitialCropWindowPaddingRatio(0)
                        .SetAutoZoomEnabled(true)
                        .SetMaxZoom(4)
                        .SetGuidelines(CropImageView.Guidelines.On)
                        .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                        .SetOutputUri(myUri).Start(this);
                }
                else
                {
                    if (!CropImage.IsExplicitCameraPermissionRequired(this) && CheckSelfPermission(Manifest.Permission.ReadExternalStorage) == Permission.Granted &&
                        CheckSelfPermission(Manifest.Permission.WriteExternalStorage) == Permission.Granted && CheckSelfPermission(Manifest.Permission.Camera) == Permission.Granted)
                    {
                        Methods.Path.Chack_MyFolder();

                        //Open Image 
                        var myUri = Uri.FromFile(new File(Methods.Path.FolderDcimImage, Methods.GetTimestamp(DateTime.Now) + ".jpeg"));
                        CropImage.Builder()
                            .SetInitialCropWindowPaddingRatio(0)
                            .SetAutoZoomEnabled(true)
                            .SetMaxZoom(4)
                            .SetGuidelines(CropImageView.Guidelines.On)
                            .SetCropMenuCropButtonTitle(GetText(Resource.String.Lbl_Crop))
                            .SetOutputUri(myUri).Start(this);
                    }
                    else
                    {
                        new PermissionsController(this).RequestPermission(108);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private string GetRealPathFromUri(Uri contentUri)
        {
            try
            {
                string[] proj = { MediaStore.Images.Media.InterfaceConsts.Data };
                var cursor = ContentResolver.Query(contentUri, proj, null, null, null);
                int columnIndex = cursor.GetColumnIndexOrThrow(MediaStore.Images.Media.InterfaceConsts.Data);
                cursor.MoveToNext();
                return cursor.GetString(columnIndex);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        } 
    }
}